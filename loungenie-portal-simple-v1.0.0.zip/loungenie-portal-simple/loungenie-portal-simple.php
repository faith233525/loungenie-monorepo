<?php
/**
 * LounGenie Portal - Lightweight Version for Shared Hosting
 *
 * @package   LounGenie Portal
 * @version   1.0.0
 * @author    LounGenie Team
 * @license   GPL-2.0-or-later
 *
 * Plugin Name: LounGenie Portal - Lite
 * Plugin URI: https://loungenie.com
 * Description: Lightweight portal interface for LounGenie partner management
 * Version: 1.0.0
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Author: LounGenie Team
 * License: GPLv2 or later
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ============================================================================
// PLUGIN CONSTANTS
// ============================================================================
define( 'LGP_LITE_VERSION', '1.0.0' );
define( 'LGP_LITE_FILE', __FILE__ );
define( 'LGP_LITE_DIR', plugin_dir_path( __FILE__ ) );
define( 'LGP_LITE_URL', plugin_dir_url( __FILE__ ) );

// ============================================================================
// PLUGIN ACTIVATION
// ============================================================================
register_activation_hook( __FILE__, function() {
	// Create minimal database table for portal data
	global $wpdb;
	$charset_collate = $wpdb->get_charset_collate();
	
	// Portal Configuration Table
	$table = $wpdb->prefix . 'lgp_portal_config';
	$sql = "CREATE TABLE IF NOT EXISTS $table (
		id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
		setting_name VARCHAR(255) NOT NULL UNIQUE,
		setting_value LONGTEXT,
		created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
		updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
		PRIMARY KEY (id),
		INDEX (setting_name)
	) $charset_collate;";
	
	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	dbDelta( $sql );
	
	// Set portal initialized flag
	update_option( 'lgp_portal_initialized', true );
	update_option( 'lgp_lite_version', LGP_LITE_VERSION );
});

// ============================================================================
// PLUGIN INITIALIZATION
// ============================================================================
add_action( 'plugins_loaded', function() {
	// Load admin menu
	if ( is_admin() ) {
		add_action( 'admin_menu', function() {
			add_menu_page(
				'LounGenie Portal',
				'LounGenie Portal',
				'manage_options',
				'loungenie-portal',
				'lgp_render_admin_page',
				'dashicons-building',
				20
			);
		});
	}
});

// ============================================================================
// ADMIN PAGE RENDER
// ============================================================================
function lgp_render_admin_page() {
	?>
	<div class="wrap">
		<h1>LounGenie Portal</h1>
		<div style="background: #fff; padding: 20px; border-radius: 8px; margin-top: 20px;">
			<h2>Welcome to LounGenie Portal Lite</h2>
			<p>This lightweight version provides core portal functionality without complex database structures.</p>
			
			<h3>Features:</h3>
			<ul>
				<li>✅ Portal Dashboard Interface</li>
				<li>✅ Partner & Support Views</li>
				<li>✅ Units Management</li>
				<li>✅ Service Requests Tracking</li>
				<li>✅ Venues Overview</li>
				<li>✅ Reports & Analytics</li>
				<li>✅ Map View</li>
				<li>✅ Training Center</li>
				<li>✅ Knowledge Center</li>
			</ul>
			
			<h3>Access Portal:</h3>
			<p><a href="<?php echo esc_url( home_url( '/loungenie-portal/' ) ); ?>" class="button button-primary" target="_blank">
				Open Portal Dashboard
			</a></p>
			
			<h3>Documentation:</h3>
			<ul>
				<li><a href="https://loungenie.com/docs" target="_blank">Plugin Documentation</a></li>
				<li><a href="https://loungenie.com/support" target="_blank">Support</a></li>
			</ul>
		</div>
	</div>
	<?php
}

// ============================================================================
// REWRITE RULES
// ============================================================================
add_action( 'init', function() {
	// Register rewrite rule for /loungenie-portal/
	add_rewrite_rule(
		'^loungenie-portal/?$',
		'index.php?lgp_portal=1',
		'top'
	);
	
	// Register query var
	add_filter( 'query_vars', function( $vars ) {
		$vars[] = 'lgp_portal';
		return $vars;
	});
});

// Flush rewrite rules on activation
register_activation_hook( __FILE__, function() {
	add_rewrite_rule(
		'^loungenie-portal/?$',
		'index.php?lgp_portal=1',
		'top'
	);
	flush_rewrite_rules();
});

register_deactivation_hook( __FILE__, function() {
	flush_rewrite_rules();
});

// ============================================================================
// PORTAL DISPLAY
// ============================================================================
add_action( 'template_redirect', function() {
	if ( get_query_var( 'lgp_portal' ) ) {
		// Output the portal HTML interface
		lgp_load_portal_interface();
		exit;
	}
});

function lgp_load_portal_interface() {
	// Load the HTML portal interface
	$portal_file = LGP_LITE_DIR . 'portal-interface.html';
	
	if ( file_exists( $portal_file ) ) {
		// Get HTML content
		$html = file_get_contents( $portal_file );
		
		// Replace any placeholder variables
		$html = str_replace(
			array( '[SITE_URL]', '[ADMIN_URL]' ),
			array( home_url(), admin_url() ),
			$html
		);
		
		// Output HTML
		echo wp_kses_post( $html );
	} else {
		wp_die( 'Portal interface not found.' );
	}
}

// ============================================================================
// SIMPLE REST API ENDPOINTS
// ============================================================================
add_action( 'rest_api_init', function() {
	
	// Dashboard endpoint
	register_rest_route( 'loungenie/v1', '/dashboard', array(
		'methods' => 'GET',
		'callback' => function( $request ) {
			return new WP_REST_Response( array(
				'partner' => array(
					'name' => 'John Martinez',
					'venue' => 'Miami Biscayne Resort',
					'units' => 253,
					'openRequests' => 5,
					'resolvedThisMonth' => 18
				),
				'support' => array(
					'name' => 'Sarah Johnson',
					'totalPartners' => 45,
					'activeTickets' => 12
				)
			), 200 );
		},
		'permission_callback' => '__return_true'
	));
	
	// Units endpoint
	register_rest_route( 'loungenie/v1', '/units', array(
		'methods' => 'GET',
		'callback' => function( $request ) {
			return new WP_REST_Response( array(
				'units' => array(
					array( 'id' => 1, 'name' => 'Unit A', 'status' => 'available' ),
					array( 'id' => 2, 'name' => 'Unit B', 'status' => 'booked' ),
					array( 'id' => 3, 'name' => 'Unit C', 'status' => 'available' ),
				)
			), 200 );
		},
		'permission_callback' => '__return_true'
	));
	
	// Requests endpoint
	register_rest_route( 'loungenie/v1', '/requests', array(
		'methods' => 'GET',
		'callback' => function( $request ) {
			return new WP_REST_Response( array(
				'requests' => array(
					array( 'id' => 1, 'title' => 'Maintenance', 'priority' => 'high', 'status' => 'open' ),
					array( 'id' => 2, 'title' => 'Support', 'priority' => 'medium', 'status' => 'open' ),
				)
			), 200 );
		},
		'permission_callback' => '__return_true'
	));
});

// ============================================================================
// ENQUEUE ASSETS
// ============================================================================
add_action( 'wp_enqueue_scripts', function() {
	if ( get_query_var( 'lgp_portal' ) ) {
		// Only load if needed
		wp_enqueue_style( 'loungenie-portal', LGP_LITE_URL . 'assets/css/portal.css' );
		wp_enqueue_script( 'loungenie-portal', LGP_LITE_URL . 'assets/js/portal.js', array(), LGP_LITE_VERSION, true );
	}
});

// ============================================================================
// ADMIN NOTICES
// ============================================================================
add_action( 'admin_notices', function() {
	if ( ! get_current_screen() || get_current_screen()->id !== 'toplevel_page_loungenie-portal' ) {
		return;
	}
	
	if ( ! get_option( 'lgp_portal_initialized' ) ) {
		echo '<div class="notice notice-info"><p>';
		echo esc_html__( 'LounGenie Portal is initializing...', 'loungenie-portal' );
		echo '</p></div>';
	}
});

// ============================================================================
// PLUGIN DEACTIVATION
// ============================================================================
register_deactivation_hook( __FILE__, function() {
	// Clean up options
	delete_option( 'lgp_portal_initialized' );
	delete_option( 'lgp_lite_version' );
	flush_rewrite_rules();
});
