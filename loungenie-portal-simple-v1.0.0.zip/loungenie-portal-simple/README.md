# LounGenie Portal - Lightweight Edition

A modern, lightweight WordPress plugin for the LounGenie partner management portal. This version is optimized for shared hosting environments with minimal dependencies.

## Features

✅ **Partner Dashboard** - View venue status and manage requests  
✅ **Units Management** - Track smart locks and USB charging  
✅ **Service Requests** - Monitor and respond to maintenance requests  
✅ **Venues Overview** - Manage multiple properties  
✅ **Reports & Analytics** - Track performance metrics  
✅ **Map View** - Interactive property layouts  
✅ **Training Center** - Staff certification programs  
✅ **Knowledge Center** - Help documentation & support resources  

## System Requirements

- WordPress 5.8+
- PHP 7.4+
- MySQL 5.6+ (compatible with older hosting)
- Minimal dependencies

## Installation

1. Upload the `loungenie-portal-simple` folder to `/wp-content/plugins/`
2. Activate the plugin in WordPress Admin → Plugins
3. Access the portal at `/loungenie-portal/`

## Usage

### Access the Portal

After activation, visit: `https://yourdomain.com/loungenie-portal/`

### Admin Settings

In WordPress Admin, go to **LounGenie Portal** for dashboard overview and documentation links.

## API Endpoints

The plugin provides basic REST API endpoints:

```
GET /wp-json/loungenie/v1/dashboard
GET /wp-json/loungenie/v1/units
GET /wp-json/loungenie/v1/requests
```

## Database

The plugin creates a minimal configuration table (`wp_lgp_portal_config`) for settings storage.

## Troubleshooting

**Portal not loading?**
- Check WordPress pretty permalinks are enabled
- Verify `/loungenie-portal/` URL is accessible
- Check browser console for errors

**Styling issues?**
- Clear browser cache
- Disable other CSS plugins temporarily

## Support

For issues or feature requests, contact: support@loungenie.com

## License

GPLv2 or later - See LICENSE file

## Version

1.0.0 - Lightweight edition optimized for shared hosting
