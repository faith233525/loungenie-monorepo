# LounGenie Portal - Complete Specification

**Project:** Full-stack WordPress Plugin + Standalone HTML/CSS/JS Testing Version
**Status:** Specification v1.0 (Jan 1, 2026)

---

## 1. Color Palette

| Role | Color | Hex | Usage |
|------|-------|-----|-------|
| Navy (Primary) | Navy | #0A1F44 | Headers, buttons, sidebar, primary text |
| Teal (Secondary) | Teal | #00BFA6 | Active nav items, secondary buttons, highlights |
| Aqua (Interactive) | Aqua | #00D4FF | Hover states, bell icon, interactive elements |
| Off-White (Background) | Off-White | #F9F7F6 | Page backgrounds, card backgrounds |
| Dark Gray (Text) | Dark Gray | #2C2C2C | Primary text content |
| Medium Gray (Borders) | Medium Gray | #B0B0B0 | Borders, secondary text, dividers |
| Success | Green | #28A745 | Success states, completed tickets, healthy indicators |
| Error/Alert | Red | #DC3545 | Errors, alert states, open critical issues |
| White | White | #FFFFFF | Header background, card accents |

---

## 2. Typography

- **Font Family:** Montserrat (Google Fonts, fallback: sans-serif)
- **Weights:** 400 (Regular), 600 (Semibold), 700 (Bold), 800 (Extra Bold)

### Font Sizes & Hierarchy
| Element | Size | Weight | Color | Usage |
|---------|------|--------|-------|-------|
| Page Title (h1) | 32px | 700 | Navy (#0A1F44) | Dashboard titles |
| Section Title (h2) | 24px | 700 | Navy (#0A1F44) | Section headers |
| Subsection (h3) | 18px | 600 | Navy (#0A1F44) | Subsection headers |
| Body Text | 14px | 400 | Dark Gray (#2C2C2C) | Content paragraphs |
| Small Text | 12px | 400 | Medium Gray (#B0B0B0) | Labels, helpers |
| Button Text | 14px | 600 | White or Navy | Action buttons |
| Sidebar Nav | 14px | 600 | Navy/Teal | Navigation links |

---

## 3. Header (Global Component)

**Layout:** Horizontal bar, fixed top, white background (#FFFFFF)

**Height:** 70px

**Components:**
- **Left:** LounGenie logo (text or icon, navy #0A1F44)
- **Center:** (Empty or optional page title)
- **Right:** 
  - Notification bell (aqua #00D4FF, 24px icon)
  - User name / Company name (12px gray text)
  - Logout button (navy text with teal hover)

**Styling:**
- Border-bottom: 1px solid medium gray (#B0B0B0)
- Box-shadow: subtle (0 2px 8px rgba(0,0,0,0.08))
- Responsive: Collapses on mobile, keeps logo and bell

---

## 4. Login Page

### Layout
- **Background:** Off-white (#F9F7F6) or subtle gradient (off-white to light aqua #E6FAFF)
- **Form Width:** 400px max-width, centered on desktop, full-width on mobile
- **Form Background:** White (#FFFFFF)

### Structure
```
[Header - white background with logo]

[Main content area - off-white background]
  ├─ LounGenie logo (centered, navy, 48px)
  ├─ Title: "Welcome to LounGenie" (navy, 28px)
  ├─ Subtitle: "Portal Management System" (medium gray, 14px)
  │
  ├─ TABS: [Partner Login] [Support Login]
  │
  ├─ Partner Login Tab Content:
  │   ├─ Username field (14px body, navy labels, aqua focus border)
  │   ├─ Password field
  │   ├─ "Remember me" checkbox
  │   ├─ "Forgot password?" link (gray, underline on hover)
  │   ├─ [Sign In] button (navy bg, white text, teal hover)
  │
  ├─ Support Login Tab Content:
  │   ├─ "Support team uses Microsoft authentication"
  │   ├─ [Sign In with Microsoft] button (navy bg, white text, teal hover)
  │   ├─ Info: "Only support@loungenie.com accounts"
  │
  └─ Footer: "Need help? Contact support@loungenie.com" (gray, 12px)
```

### Colors
- Labels: Navy (#0A1F44)
- Input borders: Medium gray (#B0B0B0)
- Input focus: Aqua border (#00D4FF) + subtle aqua glow
- Buttons: Navy (#0A1F44) background, white text
- Button hover: Teal (#00BFA6)
- Links: Gray (#B0B0B0), underline on hover

### Features
- Tab switching (Partner ↔ Support) with smooth fade/slide
- Form validation (required fields, email format)
- "Remember me" checkbox
- Responsive at all breakpoints (1440px, 768px, 375px)
- Optional custom background image (via WordPress settings)

---

## 5. Partner Portal Dashboard

### Layout
```
[Header - white background]
  ├─ Logo
  ├─ "Partner Dashboard"
  ├─ Bell icon (aqua)
  └─ Logout button

[Main area - split]
  ├─ Sidebar (240px, navy background #0A1F44, white text)
  │   ├─ Logo / Company name
  │   ├─ Navigation:
  │   │   ├─ Dashboard (teal highlight when active)
  │   │   ├─ Units
  │   │   ├─ Tickets
  │   │   ├─ Account
  │   │   └─ Help
  │
  └─ Main content (off-white #F9F7F6)
      ├─ Welcome Card (white bg, navy text)
      │   "Welcome back, [Company Name]"
      │
      ├─ Metrics Cards (white bg, off-white labels)
      │   ├─ Active Units: 12
      │   ├─ Open Tickets: 3
      │   └─ Last Service: 2 days ago
      │
      ├─ Recent Tickets Table (white bg, navy headers, gray text)
      │   ├─ Ticket ID
      │   ├─ Subject
      │   ├─ Status (color-coded)
      │   ├─ Priority
      │   └─ Date
      │
      ├─ Units Overview Table
      │   ├─ Unit Name / Location
      │   ├─ Type
      │   ├─ Volume
      │   ├─ Status (color-coded)
      │   └─ Last Check
      │
      └─ Optional Map Panel (aqua icons for unit locations)
```

### Colors & Styling
- Sidebar: Navy (#0A1F44), active nav items: Teal (#00BFA6)
- Cards: White (#FFFFFF) with subtle border (#B0B0B0)
- Card hover: Subtle aqua glow (#00D4FF, 0.1 opacity)
- Table headers: Navy (#0A1F44), white text
- Table rows: Dark gray text (#2C2C2C), white background
- Table hover: Light aqua background (#E0F7F6)
- Buttons: Navy primary, teal secondary
- Status badges:
  - Open: Teal (#00BFA6)
  - In Progress: Aqua (#00D4FF)
  - Completed: Green (#28A745)
  - Error: Red (#DC3545)

### Responsive
- Desktop (1440px): Sidebar + main content side-by-side
- Tablet (768px): Sidebar collapses to hamburger or tabs
- Mobile (375px): Full-width, sidebar becomes top nav

---

## 6. Support Portal Dashboard

### Layout
```
[Header - white background, "Support Dashboard"]

[Main area - split]
  ├─ Sidebar (240px, navy, white text)
  │   ├─ Logo
  │   ├─ Navigation:
  │   │   ├─ Dashboard (teal when active)
  │   │   ├─ Tickets (all)
  │   │   ├─ Companies
  │   │   ├─ Units
  │   │   ├─ Reports
  │   │   └─ Settings
  │
  └─ Main content (off-white #F9F7F6)
      ├─ KPI Cards (white bg, off-white labels)
      │   ├─ Total Tickets: 247
      │   ├─ Open Tickets: 35
      │   ├─ Companies: 18
      │   └─ Avg Resolution Time: 2.1 days
      │
      ├─ All Tickets Table (white bg, navy headers)
      │   ├─ Ticket ID
      │   ├─ Company Name
      │   ├─ Subject
      │   ├─ Assigned To
      │   ├─ Status (color-coded)
      │   ├─ Priority
      │   └─ Date
      │
      ├─ Companies Table
      │   ├─ Company Name
      │   ├─ Contact
      │   ├─ Units Count
      │   ├─ Open Tickets
      │   ├─ Status
      │   └─ Actions (View, Edit, Contact)
      │
      └─ Optional Map Panel (aqua icons for all partner locations)
```

### Colors & Styling
- Same as Partner portal (navy, teal, aqua, green, red)
- Slightly more data density (support team sees all companies)
- Action buttons: "View", "Edit", "Contact" (navy with teal hover)

### Responsive
- Same breakpoints as Partner portal (1440px, 768px, 375px)

---

## 7. Shared Hosting Optimization

### CSS/JS Loading
- Minify all CSS and JavaScript
- Only enqueue styles/scripts on plugin pages (not globally)
- Use CSS variables for colors (single source of truth)
- No inline scripts that break caching

### Database Optimization
- Prepared statements for all queries
- Index foreign keys (company_id, partner_id, ticket_id)
- Use transients for computed values (unit counts, ticket summaries)
- Avoid SELECT * queries; specify columns
- Limit results with LIMIT clause

### Asset Optimization
- No large images (only SVG icons)
- No heavy libraries (vanilla JS or lightweight alternatives)
- Minified CSS files
- Gzip compression enabled

### Performance Targets
- Page load: <2s on shared hosting
- CSS size: <50KB (minified)
- JS size: <30KB (minified)
- Images: <100KB total per page

---

## 8. WordPress Integration

### Plugin Structure
```
loungenie-portal/
├── loungenie-portal.php (main plugin file, header comments)
├── includes/
│   ├── class-lgp-loader.php
│   ├── class-lgp-login.php
│   ├── class-lgp-partner-portal.php
│   ├── class-lgp-support-portal.php
│   ├── class-lgp-header.php
│   └── class-lgp-auth.php
├── templates/
│   ├── login.php
│   ├── partner-dashboard.php
│   ├── support-dashboard.php
│   ├── header.php
│   └── sidebar.php
├── assets/
│   ├── css/
│   │   └── loungenie-portal.css (all styles, minified)
│   └── js/
│       └── loungenie-portal.js (all scripts, minified)
├── api/
│   ├── partners.php
│   ├── tickets.php
│   ├── units.php
│   └── auth.php
└── README.md
```

### WordPress Hooks
- `init`: Register post types, enqueue assets, setup shortcodes
- `template_redirect`: Redirect to plugin pages (no theme templates)
- `admin_menu`: Add plugin settings page
- `wp_enqueue_scripts`: Load CSS/JS (only on plugin pages)
- `wp_login_failed`: Custom auth handling

### Database Tables
- `wp_lgp_partners` (company info)
- `wp_lgp_tickets` (support tickets)
- `wp_lgp_units` (pool/spa units)
- Use WordPress $wpdb for all queries

### Settings Page
- Login background image upload
- Company logo upload
- Admin notification settings
- User role mapping (Partner/Support)

---

## 9. Standalone HTML Testing Version

### Files
```
standalone/
├── index.html (login page)
├── partner-dashboard.html
├── support-dashboard.html
├── css/
│   └── styles.css (all styles, shared)
├── js/
│   └── app.js (all scripts, shared)
└── README.md (testing instructions)
```

### Features
- Fully functional without WordPress
- Hardcoded sample data (companies, tickets, units)
- Tab switching, form validation, table interactions
- Responsive design at all breakpoints
- All brand colors, typography, icons
- Mock bell notifications
- Mock logout button
- Ready for visual approval before plugin development

---

## 10. Deliverables Checklist

### HTML/CSS/JS
- [ ] Standalone login page (index.html)
- [ ] Standalone partner dashboard (partner-dashboard.html)
- [ ] Standalone support dashboard (support-dashboard.html)
- [ ] Shared CSS file (styles.css) with all colors/typography
- [ ] Shared JS file (app.js) with tab switching, validation, interactions
- [ ] Responsive design at 1440px, 768px, 375px breakpoints
- [ ] Header component (reusable across pages)
- [ ] All icons (SVG) for bell, logout, status indicators
- [ ] Form validation (username/password, required fields)
- [ ] Table interactivity (hover, sort, click actions)

### WordPress Plugin
- [ ] Plugin file structure (loungenie-portal.php)
- [ ] Template files (login, partner-dashboard, support-dashboard)
- [ ] CSS/JS asset files (enqueued properly)
- [ ] REST API endpoints (if needed)
- [ ] Database queries (optimized, prepared statements)
- [ ] Settings page (background image, logo, email)
- [ ] Activation/deactivation hooks
- [ ] WPCS compliance check

### Performance & Optimization
- [ ] CSS minified (<50KB)
- [ ] JS minified (<30KB)
- [ ] No unused assets loaded globally
- [ ] Database queries optimized (no SELECT *)
- [ ] Transients for computed values
- [ ] Page load time <2s on shared hosting

### Testing
- [ ] Login page responsive at all breakpoints
- [ ] Partner portal fully functional
- [ ] Support portal fully functional
- [ ] Form validation working
- [ ] Tab switching smooth
- [ ] Table interactions responsive
- [ ] Bell icon clickable
- [ ] Logout button functional
- [ ] Colors match specification (pixel-perfect)
- [ ] Typography matches specification (Montserrat)

---

## 11. Brand Assets

### Logos
- LounGenie logo (will be provided or created)
- Favicon (16x16, 32x32, 180x180 for Apple)

### Icons
- Notification bell (24px SVG, aqua #00D4FF)
- Logout/exit icon (24px SVG, navy #0A1F44)
- Status indicators (checkmark, warning, error - colored)
- Unit type icons (pool, spa, hot tub, etc.)
- Location pin (for optional map)

### Images
- Login page background (optional, upload via settings)
- Company logo placeholders (circular, off-white bg)

---

## 12. Success Criteria

✅ **Brand Compliance**
- All colors match specification exactly (#0A1F44, #00BFA6, etc.)
- Typography is Montserrat throughout
- Layout matches specifications
- White header, navy sidebar, off-white backgrounds

✅ **Functionality**
- Login works with Partner and Support tabs
- Partner portal shows company data
- Support portal shows all tickets and companies
- Form validation prevents submission with errors
- Tab switching is smooth and responsive
- Bell icon is clickable and shows notifications
- Logout button is functional

✅ **Responsiveness**
- Desktop (1440px): Full sidebar + main content
- Tablet (768px): Sidebar collapsible or horizontal
- Mobile (375px): Single column, top nav
- No horizontal scrolling
- Text is readable at all sizes

✅ **Performance**
- CSS <50KB minified
- JS <30KB minified
- Page load <2s
- No layout shift (CLS)
- No blocking resources

✅ **Accessibility**
- WCAG 2.1 AA compliance
- Proper heading hierarchy (h1, h2, h3)
- Color contrast (4.5:1 for text)
- Form labels properly associated
- Keyboard navigation (Tab, Enter, Escape)
- ARIA labels where needed

---

**Created:** January 1, 2026
**Version:** 1.0
**Next Steps:** Build standalone HTML testing version, then WordPress plugin

