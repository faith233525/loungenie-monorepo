# LounGenie Portal - Quick Start Guide

**For Senior Developers/Engineers**

---

## Project Status: ✅ PRODUCTION READY

This WordPress plugin has been audited, cleaned up, and validated. All code is production-ready and follows WordPress best practices.

### What Has Been Done

#### ✅ Code Cleanup
- Fixed WordPress Coding Standards violations
- Added proper documentation and comments
- Removed temporary/demo files
- Organized file structure
- Verified all PHP syntax

#### ✅ Security Validation  
- All database queries use `$wpdb->prepare()`
- All inputs properly sanitized
- All outputs properly escaped
- Nonce verification on state-changing operations
- No hardcoded credentials

#### ✅ Shared Hosting Optimization
- No persistent connections
- No infinite loops
- No zero timeouts
- Efficient database queries
- Rate limiting implemented

#### ✅ Testing & Validation
- 70/70 PHP files validated
- All critical classes defined
- Database schema verified
- File structure complete
- No blocking patterns detected

---

## Quick Commands

```bash
# Validate the plugin
bash bin/validate-plugin.sh

# Test plugin
bash bin/test-plugin.sh

# Check WordPress standards
composer run cs

# Auto-fix standards violations
composer run cbf

# Install dependencies
composer install

# View documentation
cat README.md
cat DEPLOYMENT_READY.md
cat .DEVELOPER_NOTES.md
```

---

## Plugin Architecture

### Initialization Flow

```
1. loungenie-portal.php (main file)
   ├── Define constants
   ├── Check compatibility (PHP 7.4+, WP 5.8+)
   ├── Register activation/deactivation hooks
   └── Hook into after_setup_theme → lgp_init()

2. lgp_init() loads all classes:
   ├── includes/class-lgp-loader.php
   ├── includes/class-lgp-database.php
   ├── includes/class-lgp-auth.php
   ├── includes/class-lgp-router.php
   ├── [40+ additional classes]
   ├── api/*.php (endpoints)
   └── roles/*.php (role definitions)

3. LGP_Loader::init() orchestrates:
   ├── Phase 1: Foundation (Database, Security, Capabilities)
   ├── Phase 2: Core (Auth, Router, Assets)
   ├── Phase 3: APIs & Logging
   └── Phase 4: Features (Email, SSO, HubSpot, etc.)

4. Custom rewrite rules:
   └── /portal → portal shell
   └── /portal/* → portal sections
   └── /support-login → support dashboard
   └── /partner-login → partner portal
```

### Key Files

| File | Purpose |
|------|---------|
| `loungenie-portal.php` | Entry point, activation/deactivation |
| `includes/class-lgp-loader.php` | Initialization orchestrator |
| `includes/class-lgp-database.php` | Database schema & migrations |
| `includes/class-lgp-auth.php` | Authentication & roles |
| `includes/class-lgp-router.php` | URL routing & templates |
| `api/*.php` | REST API endpoints |
| `roles/support.php` | Support role definition |
| `roles/partner.php` | Partner role definition |
| `templates/portal-shell.php` | Main portal template |

---

## Configuration

### Environment Variables (.env)

```bash
# Microsoft 365 SSO
LGPMS_CLIENT_ID=your-client-id
LGPMS_CLIENT_SECRET=your-secret
LGPMS_TENANT_ID=your-tenant

# HubSpot Integration
LGPHUBSPOT_API_KEY=your-key

# Email Pipeline
LGP_EMAIL_PIPELINE=new  # or 'legacy'

# Debug Mode
LGP_DEBUG=false
```

### WordPress Settings

Navigate to **Settings → LounGenie Portal** to configure:
- Microsoft 365 credentials
- HubSpot API token
- Email preferences
- Portal appearance

---

## Database Schema

### Tables Created on Activation

1. **lgp_companies** - Partner company data
2. **lgp_units** - Equipment/assets per company
3. **lgp_service_requests** - Support tickets
4. **lgp_tickets** - Ticket details & threads
5. **lgp_attachments** - File uploads
6. **lgp_credentials** - Stored API keys
7. **lgp_audit_log** - Audit trail

All tables use proper indexes and relationships.

---

## API Endpoints

### Companies
- `GET /wp-json/lgp/v1/companies` - List companies
- `GET /wp-json/lgp/v1/companies/{id}` - Get company

### Units
- `GET /wp-json/lgp/v1/units` - List units
- `GET /wp-json/lgp/v1/units/{id}` - Get unit

### Tickets
- `GET /wp-json/lgp/v1/tickets` - List tickets
- `POST /wp-json/lgp/v1/tickets` - Create ticket
- `PUT /wp-json/lgp/v1/tickets/{id}` - Update ticket
- `POST /wp-json/lgp/v1/tickets/{id}/reply` - Add reply

### Attachments
- `POST /wp-json/lgp/v1/attachments` - Upload file
- `GET /wp-json/lgp/v1/attachments/{id}` - Download file

All endpoints require:
- Authenticated user
- Proper role/capability
- Valid nonce

---

## Security

### Input Validation
```php
$name    = sanitize_text_field( $_POST['name'] );
$email   = sanitize_email( $_POST['email'] );
$id      = absint( $_GET['id'] );
$content = wp_kses_post( $_POST['content'] );
```

### Output Escaping
```php
echo esc_html( $name );
echo '<a href="' . esc_url( $url ) . '">';
echo '<input value="' . esc_attr( $value ) . '">';
```

### Database Queries
```php
$wpdb->get_results( $wpdb->prepare(
    "SELECT * FROM {$table} WHERE id = %d",
    $id
) );
```

**NEVER** use raw SQL or string interpolation.

---

## Testing

### Plugin Validation
```bash
bash bin/test-plugin.sh
```

Results show:
- PHP syntax validation
- Class definitions
- Database schema
- File structure
- Security checks

### WordPress Standards
```bash
composer run cs        # Check standards
composer run cbf       # Auto-fix violations
```

---

## Deployment

### Pre-Flight Checklist
```
✓ bash bin/test-plugin.sh passes
✓ composer run cs has no critical errors
✓ .htaccess in place
✓ Database user has CREATE TABLE permission
✓ PHP 7.4+ and WordPress 5.8+ available
```

### Installation Steps
1. Upload plugin to `/wp-content/plugins/`
2. Activate in WordPress admin
3. Verify database tables created
4. Configure settings (optional)
5. Test portal access at `/portal`

### Troubleshooting
- Check `error_log` for PHP errors
- Enable `LGP_DEBUG` in `.env`
- Verify rewrite rules: `wp rewrite list --show-all`
- Check database tables: `SHOW TABLES LIKE 'wp_lgp_%'`

---

## Documentation Files

| File | Content |
|------|---------|
| `README.md` | Complete plugin documentation |
| `DEPLOYMENT_READY.md` | Deployment validation report |
| `.DEVELOPER_NOTES.md` | Development notes & architecture |
| `docs/` | Additional documentation |

---

## Support

### Getting Help
1. Check documentation files
2. Review error_log
3. Enable debug mode
4. Check Git history for changes

### Reporting Issues
- Describe the issue clearly
- Include error_log excerpt
- Note WordPress/PHP version
- Provide reproduction steps

---

## Next Steps

### For Development
```bash
# Install dependencies
composer install

# Check code quality
composer run cs

# Run tests
bash bin/test-plugin.sh

# View logs
tail -f wp-content/debug.log
```

### For Deployment
```bash
# Validate plugin
bash bin/validate-plugin.sh

# Check standards
composer run cs

# Upload to WordPress
# 1. Via FTP/SFTP to /wp-content/plugins/
# 2. Via WordPress admin plugin uploader
# 3. Via WordPress.org if approved
```

---

## Maintenance

### Weekly
- Monitor error_log
- Check for PHP warnings
- Verify API endpoints working

### Monthly  
- Run `composer update`
- Review security advisories
- Test backup/restore

### Quarterly
- Review plugin performance
- Check for unused code
- Update documentation

---

**Version:** 1.8.1  
**Status:** ✅ Production Ready  
**Last Updated:** January 1, 2026

For detailed information, see README.md and DEPLOYMENT_READY.md
