=== LounGenie Portal ===
Contributors: loungenie
Tags: amenity-management, hospitality, luxury-amenities, hotel-management, resort-management
Requires at least: 5.9
Tested up to: 6.4
Stable tag: 1.0.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Enterprise luxury amenity management platform for hotels, resorts, cabanas, and premium seating.

== Description ==

LounGenie Portal is a comprehensive amenity management platform designed for luxury hospitality businesses. Manage cabanas, lounges, premium seating, and other high-end amenities with an intuitive, modern interface.

**Key Features:**

* **Dashboard** - Dual role views for Partners and Support teams
* **Units Management** - Real-time status tracking for 253+ units
* **Service Requests** - Priority-based request handling system
* **Venues** - Nationwide network overview and management
* **Reports & Analytics** - Performance metrics and insights
* **Map View** - Interactive property layouts and building management
* **Training Center** - Staff training courses and certifications
* **Knowledge Center** - 348+ support articles and resources

**Design:**
Modern 2025 aesthetic with cyan, teal, and navy color scheme. Responsive design for desktop, tablet, and mobile devices.

**Target Users:**
* Hotels and resorts
* Beach clubs and cabana operations
* Premium seating venues
* Luxury amenity operators

== Installation ==

1. Upload the plugin files to `/wp-content/plugins/loungenie-portal/`
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Access LounGenie Portal from the WordPress admin menu
4. Configure your partner settings and import venue data

== Frequently Asked Questions ==

= What types of amenities can I manage? =

Cabanas, lounges, premium seating, poolside amenities, beach club reservations, and any luxury hospitality service.

= Does this work with multiple locations? =

Yes! The platform supports nationwide networks with centralized management and location-specific views.

= Can I customize the colors? =

The modern cyan/teal/navy color scheme is built into the design system for brand consistency.

== Changelog ==

= 1.0.0 =
* Initial release
* 8 complete management pages
* Dual role system (Partner/Support)
* Modern 2025 design with soft shadows
* Interactive map view
* Training and knowledge center
* Dynamic data system
* REST API integration ready

== Upgrade Notice ==

= 1.0.0 =
Initial production release with complete feature set.
