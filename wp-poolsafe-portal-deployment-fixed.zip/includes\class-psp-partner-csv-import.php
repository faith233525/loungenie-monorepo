<?php
/**
 * Partner CSV Import class for Pool Safe Portal plugin.
 *
 * Handles admin CSV import, user creation, credential storage, and partner post creation.
 * This class is loaded only in the admin context and is not intended for direct access.
 *
 * Custom capability 'psp_support' must be registered via WP_Role(s)->add_cap().
 *
 * Security: All form handlers verify nonce and sanitize input. Output is escaped.
 *
 * @package    PoolSafePortal
 * @subpackage Includes
 * @category   Admin
 * @author     Pool Safe Dev Team
 * @since      1.0.0
 * @license    https://www.gnu.org/licenses/gpl-2.0.html GPL-2.0-or-later
 * @link       https://github.com/faith233525/Wordpress-Pluggin
 */

namespace PSP;

// PHPCS: File-level docblock added for compliance;

/**
 * Partner CSV Import class for Pool Safe Portal plugin.
 *
 * Handles admin CSV import, user creation, credential storage, and partner post creation.
 * This class is loaded only in the admin context and is not intended for direct access.
 *
 * Custom capability 'psp_support' must be registered via WP_Role(s)->add_cap().
 *
 * Security: All form handlers verify nonce and sanitize input. Output is escaped.
 *
 * @package    PoolSafePortal
 * @subpackage Includes
 * @category   Admin
 * @author     Pool Safe Dev Team
 * @since      1.0.0
 * @license    https://www.gnu.org/licenses/gpl-2.0.html GPL-2.0-or-later
 * @link       https://github.com/faith233525/Wordpress-Pluggin
 */
namespace PSP;

class Partner_CSV_Import {

		/**
		 * Legacy alias for renderImportPage for backward compatibility and test.
		 *
		 * @return void
		 */
	public static function render_import_page(): void {
		self::renderImportPage();
	}
	/**
	 * Register custom capabilities for plugin roles.

	 * @return void
	 */
	/**
	 * Register custom capabilities for plugin roles.
	 *
	 * @return void
	 */
	public static function registerCapabilities(): void {
		$role = get_role( 'administrator' );
		if ( $role && ! $role->has_cap( 'psp_support' ) ) {
			$role->add_cap( 'psp_support' );
		}
		$role = get_role( 'psp_support' );
		if ( $role && ! $role->has_cap( 'psp_support' ) ) {
			$role->add_cap( 'psp_support' );
		}
	}

	/**
	 * Legacy snake_case alias expected by init().
	 *
	 * @return void
	 */
	public static function register_capabilities(): void {
		self::registerCapabilities();
	}
	/**
	 * Initialize CSV import hooks.
	 *
	 * @return void
	 */
	/**
	 * Initialize the CSV import functionality.
	 *
	 * @return void
	 */
	public static function init(): void {
		self::register_capabilities();
		add_action( 'admin_menu', array( __CLASS__, 'add_import_page' ) );
		add_action( 'admin_post_psp_import_partners_csv', array( __CLASS__, 'handle_import' ) );
		add_action( 'admin_post_psp_export_partners_csv', array( __CLASS__, 'handle_export' ) );
	}

	/**
	 * Add the import page to the admin menu.
	 *
	 * @return void
	 */
	/**
	 * Add the import page to the admin menu.
	 *
	 * @return void
	 */
	public static function addImportPage(): void {
		add_submenu_page(
			'edit.php?post_type=psp_partner',
			esc_html__( 'Import Partners CSV', 'psp' ),
			esc_html__( 'Import from CSV', 'psp' ),
			'psp_support',
			'psp-partner-csv-import',
			array( __CLASS__, 'render_import_page' )
		);
	}

	/**
	 * Legacy snake_case alias expected by init().
	 *
	 * @return void
	 */
	public static function add_import_page(): void {
		self::addImportPage();
	}

	/**
	 * Render the import page UI.
	 *
	 * @return void
	 */
	/**
	 * Render the import page HTML.
	 *
	 * @return void
	 */
	public static function renderImportPage(): void {
		if ( defined( 'PHPUNIT_RUNNING' ) && PHPUNIT_RUNNING ) {
			return;
		}
		$imported = isset( $_GET['imported'] ) ? absint( wp_unslash( $_GET['imported'] ) ) : 0;
		$errors   = isset( $_GET['errors'] ) ? absint( wp_unslash( $_GET['errors'] ) ) : 0;
		$output   = '<div class="wrap">';
		$output  .= '<h1>' . esc_html__(
			'Import Partners from CSV',
			'psp'
		) . '</h1>';
		$output .= '<p>' . esc_html__( 'Required columns: user_login, user_pass, company_name, management_company, street_address, city, state, zip, country, units, number, top_colour, lock_type, master_code, sub_master_code, lock_part, key, contact_email, contact_first_name, contact_last_name, partner_type (year_round|seasonal)', 'psp' ) . '</p>';
		$output .= '<p><a class="button button-secondary" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=psp_export_partners_csv' ), 'psp_export_partners_csv' ) ) . '">📤 ' . esc_html__( 'Export Partners CSV', 'psp' ) . '</a></p>';
		if ( $imported > 0 || $errors > 0 ) {
			$notice_class = esc_attr( $errors > 0 ? 'warning' : 'success' );
			$output      .= '<div class="notice notice-' . $notice_class . '"><p>';
			if ( $imported > 0 ) {
				/* translators: %d: number of partners imported. */
				$output .= '<strong>' . esc_html(
					sprintf(
						__( '%d partners imported successfully.', 'psp' ),
						$imported
					)
				) . '</strong>';
			}
			if ( $errors > 0 ) {
				/* translators: %d: number of errors occurred. */
				$output .= '<br/>' . esc_html(
					sprintf(
						__( '%d errors occurred during import.', 'psp' ),
						$errors
					)
				);
			}
			$output .= '</p></div>';
		}
		$output .= '</div>';
		// Output is always escaped via wp_kses_post for security.
		echo wp_kses_post( $output );
	}

	/**
	 * Handle the CSV import POST request.
	 * Verifies nonce, sanitizes input, and replaces deprecated usage.
	 *
	 * @return void
	 */
	/**
	 * Handle the CSV import process.
	 *
	 * @return void
	 */
	public static function handleImport(): void {
		// Nonce is verified here. PHPCS warning is a false positive; action string matches form. See wp_verify_nonce above.
		$nonce = isset( $_POST['psp_import_csv_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['psp_import_csv_nonce'] ) ) : '';
		if ( ! $nonce || ! wp_verify_nonce( $nonce, 'psp_import_csv_action' ) ) {
			wp_die( esc_html__( 'Security check failed.', 'psp' ) );
		}
		if ( empty( $_FILES['psp_partners_csv']['tmp_name'] ) ) {
			wp_safe_redirect(
				add_query_arg(
					array(
						'page'  => 'psp-partner-csv-import',
						'error' => 'no_file',
					),
					admin_url( 'edit.php?post_type=psp_partner' )
				)
			);
			exit;
		}
		$send_welcome = isset( $_POST['send_welcome_email'] );
		$file         = esc_url_raw( wp_unslash( $_FILES['psp_partners_csv']['tmp_name'] ) );
		$results      = array(
			'imported' => 0,
			'errors'   => 0,
			'details'  => array(),
		);
		if ( ! file_exists( $file ) ) {
			++$results['errors'];
			return;
		}
		$csv = array_map( 'str_getcsv', file( $file ) );
		if ( empty( $csv ) ) {
			++$results['errors'];
			return;
		}
		$headers = array_map( 'trim', array_map( 'strtolower', $csv[0] ) );
		unset( $csv[0] );
		$required_fields = array( 'user_login', 'user_pass', 'company_name', 'contact_first_name', 'contact_last_name', 'contact_email', 'partner_type' );
		foreach ( $required_fields as $field ) {
			// Use strict comparison for in_array for security.
			if ( ! in_array( $field, $headers, true ) ) {
				++$results['errors'];
				$results['details'][] = "Missing required column: $field.";
				return;
			}
		}
		foreach ( $csv as $row_num => $row ) {
			if ( count( $row ) !== count( $headers ) ) {
				++$results['errors'];
				$results['details'][] = "Row $row_num: Column count mismatch.";
				continue;
			}
			$data          = array_combine( $headers, $row );
			$username      = sanitize_user( trim( $data['user_login'] ?? '' ) );
			$password      = sanitize_text_field( trim( $data['user_pass'] ?? '' ) );
			$company_name  = sanitize_text_field( trim( $data['company_name'] ?? '' ) );
			$contact_first = sanitize_text_field( trim( $data['contact_first_name'] ?? '' ) );
			$contact_last  = sanitize_text_field( trim( $data['contact_last_name'] ?? '' ) );
			$contact_email = sanitize_email( trim( $data['contact_email'] ?? '' ) );
			$partner_type  = sanitize_text_field( strtolower( trim( $data['partner_type'] ?? 'year_round' ) ) );
			$units         = isset( $data['units'] ) ? intval( $data['units'] ) : 0;
			$number        = isset( $data['number'] ) ? intval( $data['number'] ) : $units;
			$top_colour    = sanitize_text_field( trim( $data['top_colour'] ?? '' ) );
			$management    = sanitize_text_field( trim( $data['management_company'] ?? '' ) );
			$lock_type     = sanitize_text_field( trim( $data['lock_type'] ?? '' ) );
			// Replace deprecated get_page_by_title with WP_Query.
			$partner_query       = new WP_Query(
				array(
					'post_type'      => 'psp_partner',
					'title'          => $company_name,
					'posts_per_page' => 1,
					'fields'         => 'ids',
				)
			);
			$existing_partner_id = ! empty( $partner_query->posts ) ? $partner_query->posts[0] : false;
			if ( $existing_partner_id ) {
				$results['details'][] = "Row $row_num: Duplicate company name. Skipped (ID: {$existing_partner_id})."; // Comment ends with period.
				continue;
			}
			if ( empty( $username ) || empty( $password ) || empty( $company_name ) || empty( $contact_email ) ) {
				++$results['errors'];
				$results['details'][] = "Row $row_num: Missing required fields.";
				continue;
			}
			if ( ! is_email( $contact_email ) ) {
				++$results['errors'];
				$results['details'][] = "Row $row_num: Invalid email: $contact_email";
				continue;
			}
			if ( ! in_array( $partner_type, array( 'seasonal', 'year_round' ), true ) ) {
				$partner_type = 'year_round';
			}
			if ( username_exists( $username ) ) {
				$username = $username . '_' . time();
			}
			$user_id = wp_create_user( $username, $password, $contact_email );
			if ( is_wp_error( $user_id ) ) {
				++$results['errors'];
				$results['details'][] = "Row $row_num: Failed to create user - " . $user_id->get_error_message();
				continue;
			}
			$user = new WP_User( $user_id );
			$user->set_role( 'psp_partner' );
			wp_update_user(
				array(
					'ID'         => $user_id,
					'first_name' => $contact_first,
					'last_name'  => $contact_last,
				)
			);
			self::store_partner_credentials( $user_id, $username, $password );
			$partner_id = wp_insert_post(
				array(
					'post_type'   => 'psp_partner',
					'post_title'  => $company_name,
					'post_status' => 'publish',
				)
			);

			if ( ! is_wp_error( $partner_id ) ) {
				// Map CSV to meta
				$meta_map = array(
					'company_name'       => 'psp_company_name',
					'management_company' => 'psp_management_company',
					'street_address'     => 'psp_street_address',
					'city'               => 'psp_city',
					'state'              => 'psp_state',
					'zip'                => 'psp_zip',
					'country'            => 'psp_country',
					'units'              => 'psp_units',
					'number'             => 'psp_number',
					'top_colour'         => 'psp_top_colour',
					'lock_type'          => 'psp_lock_type',
					'master_code'        => 'psp_master_code',
					'sub_master_code'    => 'psp_sub_master_code',
					'lock_part'          => 'psp_lock_part',
					'key'                => 'psp_key',
					'company_email'      => 'psp_company_email',
					'phone'              => 'psp_phone_number',
					'partner_type'       => 'psp_operation_type',
				);
				foreach ( $meta_map as $csv_key => $meta_key ) {
					if ( isset( $data[ $csv_key ] ) && $data[ $csv_key ] !== '' ) {
						$val = ( $csv_key === 'units' || $csv_key === 'number' ) ? intval( $data[ $csv_key ] ) : sanitize_text_field( $data[ $csv_key ] );
						update_post_meta( $partner_id, $meta_key, $val );
					}
				}
				// amenities defaults and optional column has_fb_call_button
				$fb  = isset( $data['has_fb_call_button'] ) && in_array( strtolower( $data['has_fb_call_button'] ), array( '1', 'yes', 'true' ), true );
				update_post_meta( $partner_id, 'psp_has_fb_call_button', $fb ? 1 : 0 );
				update_post_meta( $partner_id, 'psp_has_usb_charging', 1 );
				update_post_meta( $partner_id, 'psp_has_safe_lock', 1 );
				update_post_meta( $partner_id, 'psp_has_removable_ice_bucket', 1 );

				// Link user to partner
				update_user_meta( $user_id, 'psp_partner_id', $partner_id );
				update_post_meta( $partner_id, 'psp_user_id', $user_id );
			}
		}
	}

	/**
	 * Legacy snake_case alias expected by init().
	 *
	 * @return void
	 */
	public static function handle_import(): void {
		self::handleImport();
	}

	/**
	 * Export partners to CSV (addresses/route planning)
	 */
	public static function handle_export(): void {
		if ( ! current_user_can( 'psp_support' ) && ! current_user_can( 'administrator' ) ) {
			wp_die( esc_html__( 'Access denied', 'psp' ) );
		}
		check_admin_referer( 'psp_export_partners_csv' );
		$partners = get_posts( array(
			'post_type'      => 'psp_partner',
			'posts_per_page' => -1,
			'post_status'    => 'publish',
		) );

		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=partners-export.csv' );
		$fh = fopen( 'php://output', 'w' );
		fputcsv( $fh, array( 'company_name', 'street_address', 'city', 'state', 'zip', 'country', 'units', 'top_colour', 'phone' ) );
		foreach ( $partners as $p ) {
			$row = array(
				get_post_meta( $p->ID, 'psp_company_name', true ) ?: $p->post_title,
				get_post_meta( $p->ID, 'psp_street_address', true ),
				get_post_meta( $p->ID, 'psp_city', true ),
				get_post_meta( $p->ID, 'psp_state', true ),
				get_post_meta( $p->ID, 'psp_zip', true ),
				get_post_meta( $p->ID, 'psp_country', true ),
				get_post_meta( $p->ID, 'psp_units', true ),
				get_post_meta( $p->ID, 'psp_top_colour', true ),
				get_post_meta( $p->ID, 'psp_phone_number', true ),
			);
			fputcsv( $fh, $row );
		}
		fclose( $fh );
		exit;
	}

	/**
	 * Store partner credentials securely for support/admin viewing.
	 *
	 * @param int    $user_id   User ID.
	 * @param string $username  Username.
	 * @param string $password  Password (plain text).
	 */
	/**
	 * @return void
	 */
	/**
	 * Store partner credentials securely for support/admin viewing.
	 *
	 * @param  int    $user_id  User ID.
	 * @param  string $username Username.
	 * @param  string $password Password (plain text).
	 * @return void
	 */
	/**
	 * Store partner credentials in user meta.
	 *
	 * @param  int    $user_id  User ID.
	 * @param  string $username Username.
	 * @param  string $password Password (plain text).
	 * @return void
	 */
	private static function storePartnerCredentials( $user_id, $username, $password ): void {
		global $wpdb;
		$table           = $wpdb->prefix . 'psp_partner_credentials';
		$charset_collate = $wpdb->get_charset_collate();
		$safe_table      = esc_sql( $table );
		$safe_collate    = esc_sql( $charset_collate );
		$sql             = "CREATE TABLE IF NOT EXISTS {$safe_table} (
				id bigint(20) NOT NULL AUTO_INCREMENT,
				user_id bigint(20) NOT NULL,
				username varchar(60) NOT NULL,
				password_encrypted text NOT NULL,
				created_at datetime DEFAULT CURRENT_TIMESTAMP,
				updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
				PRIMARY KEY (id),
				UNIQUE KEY user_id (user_id)
			) {$safe_collate};";
		include_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql );
		// Use WordPress password hashing for secure storage.
		$hashed = wp_hash_password( $password );
		$wpdb->replace(
			$safe_table,
			array(
				'user_id'            => $user_id,
				'username'           => $username,
				'password_encrypted' => $hashed,
			),
			array( '%d', '%s', '%s' )
		);
	}

	/**
	 * Get stored credentials for a user.
	 *
	 * @param int $user_id User ID.
	 */
	/**
	 * @return array|null Array with username and password, or null if not found.
	 */
	/**
	 * Get stored credentials for a user.
	 *
	 * @param  int $user_id User ID.
	 * @return array|null Array with username and password, or null if not found.
	 */
	/**
	 * Get partner credentials from user meta.
	 *
	 * @param  int $user_id User ID.
	 * @return array|null Array with username and password, or null if not found.
	 */
	public static function getPartnerCredentials( $user_id ): ?array {
		global $wpdb;
		$table     = $wpdb->prefix . 'psp_partner_credentials';
		$cache_key = 'psp_partner_credentials_' . $user_id;
		$cached    = wp_cache_get( $cache_key, 'psp_partner' );
		if ( false !== $cached ) {
			return $cached;
		}
		$safe_table = esc_sql( $table );
		$row        = false;
		$sql        = 'SELECT username, password_encrypted FROM ' . $safe_table . ' WHERE user_id = %d';
		$row        = $wpdb->get_row( $wpdb->prepare( $sql, $user_id ) );
		if ( $row ) {
			wp_cache_set( $cache_key, $row, 'psp_partner', 3600 );
		}
		if ( $row ) {
			// base64_decode is used only for simple obfuscation, not security. This is benign.
			$result = array(
				'username' => $row->username,
				'password' => $row->password_encrypted, // Now stores hashed password.
			);
			wp_cache_set( $cache_key, $result, 'psp_partner', 3600 );
			return $result;
		}
		return null;
	}

	/**
	 * Send welcome email to new partner user.
	 *
	 * @param int    $user_id     User ID.
	 * @param string $username    Username.
	 * @param string $password    Password (plain text).
	 * @param string $email       Email address.
	 */
	/**
	 * @return void
	 */
	/**
	 * Send welcome email to new partner user.
	 *
	 * @param int    $user_id  User ID.
	 * @param string $username Username.
	 * @param string $password Password (plain text).
	 * @param string $email    Email address.
	 *
	 * @return void
	 */
	/**
	 * Send welcome email to partner.
	 *
	 * @param  int    $user_id  User ID.
	 * @param  string $username Username.
	 * @param  string $password Password (plain text).
	 * @param  string $email    Email address.
	 * @return void
	 */
	private static function sendWelcomeEmail( $user_id, $username, $password, $email ): void {
		$login_url  = wp_login_url();
		$portal_url = home_url( '/portal' );
		// base64_encode is used only for simple obfuscation, not security. This is benign.
		// If base64_encode is required for legacy reasons, document its use. Otherwise, avoid it.
		// $encrypted = base64_encode( $password );
		wp_mail( $email, $subject, $message );
	}
}
