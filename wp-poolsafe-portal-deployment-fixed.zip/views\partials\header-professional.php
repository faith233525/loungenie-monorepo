<?php
/**
 * Professional Portal Header - Enterprise Layout
 * Displays professional navigation with sidebar, search, and user menu
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Check for portal session (not WordPress user)
$current_user = isset($_SESSION['psp_user']) ? $_SESSION['psp_user'] : null;

if (!$current_user) {
    // Fallback to WordPress user if available
    if (!is_user_logged_in()) {
        return;
    }
    // WordPress user fallback
    $wp_user = wp_get_current_user();
    $current_user = array(
        'id'           => $wp_user->ID,
        'first_name'   => $wp_user->display_name,
        'email'        => $wp_user->user_email,
        'company_name' => $wp_user->display_name,
    );
}

$current_page = isset($_GET['page']) ? sanitize_key($_GET['page']) : 'dashboard';
?>

<div class="psp-layout">
    <!-- PROFESSIONAL HEADER -->
    <header class="psp-header-pro">
        <div class="psp-header-content">
            <!-- Brand - WordPress Logo Integration -->
            <div class="psp-header-brand">
                <?php 
                // Use WordPress custom logo if available
                if (has_custom_logo()) {
                    $custom_logo_id = get_theme_mod('custom_logo');
                    $logo = wp_get_attachment_image_src($custom_logo_id, 'full');
                    if ($logo) {
                        echo '<img src="' . esc_url($logo[0]) . '" alt="' . esc_attr(get_bloginfo('name')) . '" class="psp-custom-logo">';
                    }
                } else {
                    // Fallback to first letter badge + site name
                    $site_name = get_bloginfo('name');
                    $first_letter = !empty($site_name) ? strtoupper(substr($site_name, 0, 1)) : 'P';
                    echo '<div class="psp-logo-badge">' . esc_html($first_letter) . '</div>';
                    echo '<h1>' . esc_html($site_name ? $site_name : 'PoolSafe') . '</h1>';
                }
                ?>
            </div>
            
            <!-- Search Bar -->
            <div class="psp-header-search">
                <input type="text" class="psp-search-input" placeholder="Search tickets, properties, services...">
            </div>
            
            <!-- Header Actions -->
            <div class="psp-header-actions-pro">
                <!-- Notifications -->
                <button class="psp-notification-btn" id="psp-notification-toggle">
                    <span>🔔</span>
                    <span class="psp-notification-badge-pro">3</span>
                </button>
                
                <!-- User Menu -->
                <div class="psp-user-menu-pro">
                    <button class="psp-user-avatar-btn" id="psp-user-toggle"><?php 
                        if (isset($current_user)) {
                            $names = explode(' ', $current_user['first_name']);
                            $initials = strtoupper(substr($names[0], 0, 1) . (isset($names[1]) ? substr($names[1], 0, 1) : ''));
                            echo esc_html($initials);
                        } else {
                            echo 'US';
                        }
                    ?></button>
                    <div class="psp-user-dropdown-pro" id="psp-user-dropdown-pro">
                        <a href="?page=profile" class="psp-user-dropdown-item-pro">👤 My Profile</a>
                        <a href="?page=settings" class="psp-user-dropdown-item-pro">⚙️ Settings</a>
                        <a href="?page=knowledge-base" class="psp-user-dropdown-item-pro">📚 Help & Support</a>
                        <a href="?action=logout" class="psp-user-dropdown-item-pro psp-logout-link">🚪 Logout</a>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- SIDEBAR NAVIGATION -->
    <aside class="psp-sidebar-pro">
        <div class="psp-sidebar-section">
            <div class="psp-sidebar-label">Main</div>
            <nav class="psp-sidebar-nav">
                <a href="?page=dashboard" class="psp-sidebar-item <?php echo $current_page === 'dashboard' ? 'active' : ''; ?>">
                    <span class="psp-sidebar-icon">📊</span>
                    Dashboard
                </a>
                <a href="?page=tickets" class="psp-sidebar-item <?php echo $current_page === 'tickets' ? 'active' : ''; ?>">
                    <span class="psp-sidebar-icon">🎫</span>
                    Tickets
                </a>
                <a href="?page=service-records" class="psp-sidebar-item <?php echo $current_page === 'service-records' ? 'active' : ''; ?>">
                    <span class="psp-sidebar-icon">📅</span>
                    Service Records
                </a>
                <a href="?page=partners" class="psp-sidebar-item <?php echo $current_page === 'partners' ? 'active' : ''; ?>">
                    <span class="psp-sidebar-icon">🏢</span>
                    Properties
                </a>
            </nav>
        </div>

        <div class="psp-sidebar-section">
            <div class="psp-sidebar-label">Resources</div>
            <nav class="psp-sidebar-nav">
                <a href="?page=knowledge-base" class="psp-sidebar-item <?php echo $current_page === 'knowledge-base' ? 'active' : ''; ?>">
                    <span class="psp-sidebar-icon">📚</span>
                    Knowledge Base
                </a>
                <a href="?page=notifications" class="psp-sidebar-item <?php echo $current_page === 'notifications' ? 'active' : ''; ?>">
                    <span class="psp-sidebar-icon">🔔</span>
                    Notifications
                </a>
            </nav>
        </div>
    </aside>

    <!-- MAIN CONTENT -->
    <main class="psp-main-pro">
        <div class="psp-page-container">

