# REST API v3 - Quick Integration Guide

**Status**: ✅ Production Ready

**Updated**: December 10, 2025

---

## 🚀 Quick Start (5 minutes)

### 1. Verify Installation

```bash
# Check that REST API is registered
curl -X GET "https://yoursite.com/wp-json/poolsafe/v1" \
  -H "Authorization: Bearer <token>"
```

### 2. Create Your First Ticket

```bash
curl -X POST "https://yoursite.com/wp-json/poolsafe/v1/tickets" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer <token>" \
  -d '{
    "title": "Pool filter issue",
    "description": "Filter pressure is high",
    "company_id": 1,
    "priority": "normal"
  }'
```

### 3. List All Tickets

```bash
curl -X GET "https://yoursite.com/wp-json/poolsafe/v1/tickets?page=1&per_page=10" \
  -H "Authorization: Bearer <token>"
```

---

## 📚 API Endpoint Reference

### Videos (Training Content)

| Method | Endpoint | Purpose | Auth |
|--------|----------|---------|------|
| GET | `/videos` | List videos | User |
| GET | `/videos/{id}` | View video | User |
| POST | `/videos` | Create video | Staff |
| PUT | `/videos/{id}` | Update video | Staff |
| DELETE | `/videos/{id}` | Delete video | Admin |
| POST | `/videos/{id}/view` | Log view | User |

### Operations (Staff Visits)

| Method | Endpoint | Purpose | Auth |
|--------|----------|---------|------|
| GET | `/operations` | List operations | Staff |
| GET | `/operations/{id}` | View operation | Staff |
| POST | `/operations` | Create operation | Staff |
| PUT | `/operations/{id}` | Update operation | Staff |
| DELETE | `/operations/{id}` | Delete operation | Admin |

### Companies

| Method | Endpoint | Purpose | Auth |
|--------|----------|---------|------|
| GET | `/companies` | List companies | User |
| GET | `/companies/{id}` | View company | User |
| PUT | `/companies/{id}` | Update company | Admin |
| GET | `/companies/{id}/tickets` | Company tickets | User |
| GET | `/companies/{id}/operations` | Company operations | Staff |
| GET | `/companies/{id}/contacts` | Company contacts | Staff |
| GET | `/companies/{id}/summary` | Company stats | User |

### Tickets (Support Issues)

| Method | Endpoint | Purpose | Auth |
|--------|----------|---------|------|
| GET | `/tickets` | List tickets | User |
| GET | `/tickets/{id}` | View ticket | User |
| POST | `/tickets` | Create ticket | User |
| PUT | `/tickets/{id}` | Update ticket | Staff |
| DELETE | `/tickets/{id}` | Delete ticket | Admin |
| POST | `/tickets/{id}/replies` | Add reply | User |
| GET | `/tickets/{id}/replies` | Get replies | User |

### Email Integration

| Method | Endpoint | Purpose | Auth |
|--------|----------|---------|------|
| POST | `/email-webhook` | Process email | Key |
| GET | `/email-webhook/status` | Webhook status | Admin |

---

## 💡 Common Use Cases

### UC1: Customer Creates Support Ticket

```javascript
// 1. User submits ticket
const response = await fetch('/wp-json/poolsafe/v1/tickets', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer ' + token
  },
  body: JSON.stringify({
    title: 'Pump making noise',
    description: 'The main pump is making a grinding noise',
    company_id: 5,
    priority: 'high'
  })
});

const ticket = await response.json();
// ticket.ticket_id = 42
```

### UC2: Staff Reviews Company Activity

```javascript
// Get company overview
const company = await fetch('/wp-json/poolsafe/v1/companies/5/summary', {
  headers: { 'Authorization': 'Bearer ' + staffToken }
}).then(r => r.json());

// Returns:
// {
//   ticket_count: 12,
//   operation_count: 45,
//   contact_count: 8
// }
```

### UC3: Email Forwarding to Support System

```javascript
// External email service posts to webhook
const response = await fetch('https://yoursite.com/wp-json/poolsafe/v1/email-webhook', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'X-PoolSafe-API-Key': 'your-webhook-key-here'
  },
  body: JSON.stringify({
    to: 'support@poolsafe.com',
    from: 'customer@abc.com',
    subject: 'Equipment issue',
    body: 'The heater stopped working...'
  })
});

// Creates new ticket or adds reply to existing ticket
```

### UC4: Training Video Analytics

```javascript
// Log video view
const response = await fetch('/wp-json/poolsafe/v1/videos/1/view', {
  method: 'POST',
  headers: { 'Authorization': 'Bearer ' + token }
});

// Later, get view statistics
const video = await fetch('/wp-json/poolsafe/v1/videos/1', {
  headers: { 'Authorization': 'Bearer ' + token }
}).then(r => r.json());

console.log('Views:', video.data.view_count);
```

---

## 🔑 Authentication

### Using JWT (Recommended)

Most PoolSafe portals use JWT authentication. Include the token in every request:

```
Authorization: Bearer <jwt_token_from_login>
```

### Email Webhook Authentication

For email webhook integration, use API key instead:

```
X-PoolSafe-API-Key: <generated_webhook_key>
```

---

## ⚙️ Configuration

### Enable Email Webhook

```php
// In wp-config.php or plugin initialization:

// Generate random API key (do this once)
$webhook_key = bin2hex(random_bytes(32));

// Store securely
update_option('psp_email_webhook_key', $webhook_key);
update_option('psp_email_webhook_enabled', true);
```

### Check Webhook Status

```php
$enabled = get_option('psp_email_webhook_enabled');
$last_received = get_option('psp_email_webhook_last_received');
$error_count = get_option('psp_email_webhook_errors', 0);

echo "Webhook enabled: " . ($enabled ? 'YES' : 'NO');
echo "Last received: " . ($last_received ?: 'Never');
echo "Errors: " . $error_count;
```

---

## 📊 Response Format

All endpoints return consistent JSON structure:

### Success Response (200, 201)

```json
{
  "success": true,
  "data": {...},
  "message": "Optional message"
}
```

### Error Response (400, 401, 404, 500)

```json
{
  "success": false,
  "error": "Descriptive error message"
}
```

### List Response

```json
{
  "success": true,
  "data": [...],
  "page": 1,
  "total": 150
}
```

---

## 🧪 Testing Endpoints

### Using cURL

**Get tickets:**
```bash
curl -X GET "https://yoursite.com/wp-json/poolsafe/v1/tickets" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

**Create ticket:**
```bash
curl -X POST "https://yoursite.com/wp-json/poolsafe/v1/tickets" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{
    "title": "Test ticket",
    "description": "Testing the API",
    "company_id": 1
  }'
```

**Get company summary:**
```bash
curl -X GET "https://yoursite.com/wp-json/poolsafe/v1/companies/1/summary" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

### Using Postman

1. Import REST API collection (available in docs)
2. Set `base_url` variable: `https://yoursite.com/wp-json/poolsafe/v1`
3. Set `token` variable from login response
4. Run requests from collection

### Using JavaScript/Fetch

```javascript
async function createTicket() {
  const response = await fetch(
    'https://yoursite.com/wp-json/poolsafe/v1/tickets',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({
        title: 'API Test Ticket',
        description: 'Testing via JavaScript',
        company_id: 1,
        priority: 'normal'
      })
    }
  );

  const result = await response.json();
  if (result.success) {
    console.log('Created ticket:', result.ticket_id);
  } else {
    console.error('Error:', result.error);
  }
}
```

---

## 🐛 Troubleshooting

### 401 Unauthorized

**Problem**: "Not authenticated"

**Solutions**:
- [ ] Token expired? Refresh login
- [ ] Token included in request? Check Authorization header
- [ ] Wrong authentication method for endpoint?

```bash
# Verify token is valid
curl -X GET "https://yoursite.com/wp-json/wp/v2/users/me" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

### 403 Forbidden

**Problem**: "Permission denied"

**Solutions**:
- [ ] User has required role? Check user capabilities
- [ ] Endpoint requires admin? Only admins can delete
- [ ] Email webhook needs API key, not user token

```bash
# Check user capabilities
wp user list --field=user_login,user_email,roles
```

### 404 Not Found

**Problem**: "Resource doesn't exist"

**Solutions**:
- [ ] ID correct? Verify resource exists
- [ ] Post type published? Check post_status

```bash
# List all tickets
wp post list --post_type=psp_ticket

# Check specific ticket
wp post get 123 --post_type=psp_ticket
```

### 500 Server Error

**Problem**: "Internal server error"

**Solutions**:
- [ ] Check PHP error logs
- [ ] Verify database tables exist
- [ ] Check required fields provided

```bash
# View error log
tail -f /var/www/html/wp-content/debug.log

# Verify tables exist
wp db tables | grep psp
```

---

## 📈 Performance Tips

1. **Pagination**: Always use pagination for list endpoints
   ```
   GET /tickets?page=1&per_page=25
   ```

2. **Lazy Loading**: Load company details only when needed
   ```
   GET /companies/5/summary  // Fast (4 queries)
   vs
   GET /companies/5          // Full details
   ```

3. **Search**: Use search parameters to filter on server
   ```
   GET /videos?search=maintenance
   ```

4. **Caching**: Cache API responses on frontend
   ```javascript
   const cachedCompanies = sessionStorage.getItem('companies');
   ```

---

## 🔒 Security Best Practices

1. **Always use HTTPS** in production
2. **Validate tokens** on frontend & backend
3. **Sanitize user input** - API does this, but be careful on frontend
4. **Use API keys** for webhook, not user tokens
5. **Rotate webhook keys** periodically
6. **Log failed requests** for security monitoring
7. **Rate limit** high-volume endpoints if needed

---

## 📞 Support

For issues or questions:

1. **Check Documentation**: See REST_API_IMPLEMENTATION_COMPLETE.md
2. **Review Error Log**: Check WordPress error.log
3. **Test Endpoint**: Use cURL to isolate issues
4. **Check Permissions**: Verify user roles and capabilities

---

**Ready to integrate!** Start with the Quick Start section above.

Last Updated: December 10, 2025
