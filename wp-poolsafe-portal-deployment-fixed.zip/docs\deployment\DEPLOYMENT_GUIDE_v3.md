# PoolSafe Portal v3.0.0 - Deployment Guide

**Version**: 3.0.0  
**Date**: December 9, 2025  
**Status**: Production Ready

---

## Table of Contents

1. [System Requirements](#system-requirements)
2. [Pre-Deployment Checklist](#pre-deployment-checklist)
3. [Installation](#installation)
4. [Configuration](#configuration)
5. [Security Setup](#security-setup)
6. [Performance Tuning](#performance-tuning)
7. [Monitoring & Maintenance](#monitoring--maintenance)
8. [Troubleshooting](#troubleshooting)

---

## System Requirements

### Minimum Requirements

| Component | Requirement |
|-----------|------------|
| **PHP** | 7.4 or higher |
| **WordPress** | 5.9 or higher |
| **MySQL** | 5.7 or higher |
| **HTTPS** | Required |
| **Memory** | 256 MB minimum |
| **Storage** | 500 MB minimum |

### Recommended

| Component | Recommendation |
|-----------|---------------|
| **PHP** | 8.1+ with OPcache |
| **WordPress** | 6.0+ |
| **MySQL** | 8.0+ |
| **Memory** | 2 GB+ |
| **Storage** | 5+ GB |
| **SSL Certificate** | Modern wildcard cert |
| **CDN** | CloudFlare/Akamai |
| **Cache Layer** | Redis/Memcached |

### PHP Extensions Required

```
- curl
- json
- mbstring
- mysql/mysqli
- openssl
- gd
- zip
```

### Browser Support

- Chrome/Edge 90+
- Firefox 88+
- Safari 14+
- Mobile browsers (iOS 14+, Android 10+)

---

## Pre-Deployment Checklist

### Development → Staging

- [ ] All tests passing (156 unit & integration tests)
- [ ] Code review completed
- [ ] Security audit passed
- [ ] Performance benchmarks acceptable
- [ ] Documentation complete
- [ ] Backup of current production
- [ ] Staging environment matches production

### Staging → Production

- [ ] Load testing completed (100+ concurrent users)
- [ ] Security scanning passed
- [ ] Database migrations tested
- [ ] Rollback plan documented
- [ ] Team trained on new features
- [ ] Monitoring configured
- [ ] Support team briefed

---

## Installation

### Option 1: WordPress Plugin Repository

```bash
# Download from WordPress.org
# Navigate to Plugins → Add New → Search "PoolSafe Portal"
# Click Install → Activate
```

### Option 2: Manual Installation

1. **Download Plugin**
   ```bash
   wget https://github.com/your-org/wp-poolsafe-portal/releases/download/v3.0.0/poolsafe-portal.zip
   ```

2. **Upload to Server**
   ```bash
   # Via FTP
   cd wp-content/plugins/
   unzip poolsafe-portal.zip
   
   # OR via WordPress dashboard
   Plugins → Add New → Upload Plugin
   ```

3. **Activate Plugin**
   ```
   WordPress Dashboard → Plugins → Activate "PoolSafe Portal"
   ```

4. **Run Setup Wizard**
   - Follow on-screen setup steps
   - Configure security settings
   - Set up caching
   - Configure API keys

### Option 3: Composer Installation

```bash
# Add to composer.json
"require": {
    "poolsafe/poolsafe-portal": "^3.0.0"
}

# Install dependencies
composer install

# Activate in WordPress
wp plugin activate poolsafe-portal --allow-root
```

---

## Configuration

### 1. Environment Setup

Create `.env` in WordPress root (if using dotenv):

```env
# Database
DB_HOST=localhost
DB_NAME=poolsafe_db
DB_USER=poolsafe_user
DB_PASSWORD=secure_password

# Security
PSP_2FA_ENABLED=true
PSP_RATE_LIMIT=100
PSP_IP_WHITELIST_ENABLED=false

# Cache
PSP_CACHE_ENABLED=true
PSP_CACHE_TTL=3600
PSP_CACHE_ENGINE=wordpress  # or redis, memcached

# Features
PSP_API_ENABLED=true
PSP_BATCH_REQUESTS=true
PSP_FILE_UPLOAD_SIZE=10485760  # 10MB

# Logging
WP_DEBUG=false
WP_DEBUG_LOG=true
PSP_DEBUG_LOG=true
```

### 2. WordPress Configuration

In `wp-config.php`:

```php
<?php
// Enable security features
define('FORCE_SSL_ADMIN', true);
define('AUTOMATIC_UPDATER_DISABLED', false);

// Cache configuration
define('WP_CACHE', true);

// Performance
define('COMPRESS_CSS', true);
define('COMPRESS_SCRIPTS', true);
define('ENFORCE_GZIP', true);

// Database
define('DB_CHARSET', 'utf8mb4');
define('DB_COLLATE', 'utf8mb4_unicode_ci');

// Memory
define('WP_MEMORY_LIMIT', '256M');
define('WP_MAX_MEMORY_LIMIT', '512M');

// Security
define('DISALLOW_FILE_EDIT', true);
define('DISALLOW_FILE_MODS', false);
```

### 3. Plugin Settings

**Dashboard** → **PoolSafe Settings**

**Security Tab:**
- Enable 2FA: ✓ Yes
- Enforce 2FA: [ ] Optional
- Rate Limit: 100 req/min
- IP Whitelist: [ ] Enabled
- Session Timeout: 60 min
- Password Strength: Medium

**Cache Tab:**
- Enable Cache: ✓ Yes
- Cache Engine: WordPress/Redis
- Cache TTL: 1 hour
- Clear Cache: [Clear Now]

**Features Tab:**
- API Enabled: ✓ Yes
- Batch Requests: ✓ Yes
- File Upload: 10 MB max
- Maintenance Mode: [ ] Off

**Logging Tab:**
- Enable Logging: ✓ Yes
- Log Level: Info
- Log Rotation: 30 days

---

## Security Setup

### 1. SSL/HTTPS

**Required**. Generate certificate:

```bash
# Let's Encrypt (recommended)
sudo certbot certonly --webroot -w /var/www/html -d example.com

# Or purchase from SSL provider
# Copy certificate to server

# Update WordPress
# Settings → General
# Site URL: https://example.com
# WordPress URL: https://example.com
```

### 2. Security Headers

Configure in `.htaccess` or web server:

```apache
# .htaccess
<IfModule mod_headers.c>
    Header set Strict-Transport-Security "max-age=31536000; includeSubDomains"
    Header set X-Content-Type-Options "nosniff"
    Header set X-Frame-Options "SAMEORIGIN"
    Header set X-XSS-Protection "1; mode=block"
    Header set Referrer-Policy "strict-origin-when-cross-origin"
    Header set Permissions-Policy "geolocation=(), microphone=(), camera=()"
</IfModule>
```

Or in Nginx:

```nginx
add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
add_header X-Content-Type-Options "nosniff" always;
add_header X-Frame-Options "SAMEORIGIN" always;
add_header X-XSS-Protection "1; mode=block" always;
add_header Referrer-Policy "strict-origin-when-cross-origin" always;
```

### 3. Database Security

```bash
# Create dedicated user
CREATE USER 'poolsafe_user'@'localhost' IDENTIFIED BY 'secure_password';
GRANT ALL PRIVILEGES ON poolsafe_db.* TO 'poolsafe_user'@'localhost';

# Remove unnecessary users
DROP USER ''@'localhost';
DROP USER 'root'@'::1';

# Secure root
SET PASSWORD FOR 'root'@'localhost' = PASSWORD('strong_password');

# Apply changes
FLUSH PRIVILEGES;
```

### 4. File Permissions

```bash
# WordPress directory
chmod 750 /var/www/html
chmod 750 /var/www/html/wp-content

# Plugin files
chmod 755 /var/www/html/wp-content/plugins/poolsafe-portal
chmod 644 /var/www/html/wp-content/plugins/poolsafe-portal/*.php
chmod 755 /var/www/html/wp-content/plugins/poolsafe-portal/includes

# Uploads directory
chmod 755 /var/www/html/wp-content/uploads
chmod 644 /var/www/html/wp-content/uploads/*

# Restrict config
chmod 400 /var/www/html/wp-config.php
chmod 400 /var/www/html/.env
```

### 5. Backup Strategy

```bash
# Daily backup (cron job at 2 AM)
0 2 * * * /usr/local/bin/backup-poolsafe.sh

# Backup script
#!/bin/bash
BACKUP_DIR="/backups/poolsafe"
DATE=$(date +%Y%m%d_%H%M%S)
SITE_DIR="/var/www/html"

# Database backup
mysqldump -u root -p$DB_PASSWORD poolsafe_db > $BACKUP_DIR/db_$DATE.sql

# Files backup
tar -czf $BACKUP_DIR/files_$DATE.tar.gz $SITE_DIR/wp-content/plugins/poolsafe-portal

# Uploads backup
tar -czf $BACKUP_DIR/uploads_$DATE.tar.gz $SITE_DIR/wp-content/uploads

# Keep last 30 days
find $BACKUP_DIR -name "*.sql" -mtime +30 -delete
find $BACKUP_DIR -name "*.tar.gz" -mtime +30 -delete
```

---

## Performance Tuning

### 1. Caching

**WordPress Object Cache**
```php
// Install cache plugin
wp plugin install redis-cache --activate

// or Memcached
wp plugin install memcached --activate
```

**Database Query Cache**
- Already enabled in PoolSafe Portal
- Configure TTL in settings
- Verify cache hits in diagnostics

### 2. Web Server Optimization

**Apache** (mods_enabled):
```bash
sudo a2enmod deflate
sudo a2enmod expires
sudo a2enmod headers
sudo a2enmod rewrite
```

**Nginx** (gzip compression):
```nginx
gzip on;
gzip_vary on;
gzip_min_length 1024;
gzip_types text/plain text/css text/xml text/javascript application/json;
gzip_disable "MSIE [1-6]\.";
```

### 3. PHP Optimization

```ini
; php.ini
memory_limit = 256M
max_execution_time = 300
upload_max_filesize = 10M
post_max_size = 10M

; OPcache
opcache.enable = 1
opcache.memory_consumption = 256
opcache.max_accelerated_files = 10000

; Performance
realpath_cache_size = 4096K
realpath_cache_ttl = 3600
```

### 4. Database Optimization

```bash
# Run monthly
wp db optimize

# or manually
OPTIMIZE TABLE wp_posts;
OPTIMIZE TABLE wp_postmeta;
OPTIMIZE TABLE wp_users;
OPTIMIZE TABLE poolsafe_companies;
OPTIMIZE TABLE poolsafe_tickets;
```

### 5. CDN Setup

Configure CloudFlare:

1. Add site to CloudFlare
2. Update nameservers to CloudFlare
3. Set cache level to "Cache Everything"
4. Enable minification (CSS, JS, HTML)
5. Enable rocket loader
6. Set up page rules for exceptions

---

## Monitoring & Maintenance

### 1. Uptime Monitoring

**Tool**: Uptime Robot or similar

```bash
# Monitor these endpoints
- https://example.com/wp-admin (should be 302 redirect)
- https://example.com/wp-json/psp/v1/users/me (should be 401 or 200)
- https://example.com/wp-json (should be 200)
```

### 2. Security Scanning

**Weekly**:
```bash
# Run security scan
bash tests/security/security-scan.sh https://example.com

# Review results
cat tests/security/security-scan-results.txt
```

**Monthly**:
- Run SSL test: https://www.ssllabs.com/ssltest/
- Check for plugin vulnerabilities
- Review security logs

### 3. Performance Monitoring

```bash
# Check cache hit rate
wp poolsafe cache-stats

# Monitor response times
# K6 load testing (daily during off-hours)
k6 run tests/performance/load-test.js

# Set up APM
# New Relic / DataDog / Elastic
```

### 4. Log Rotation

```bash
# Set up logrotate
cat > /etc/logrotate.d/poolsafe << EOF
/var/www/html/wp-content/debug.log {
    daily
    rotate 14
    compress
    delaycompress
    notifempty
    create 0640 www-data www-data
}
EOF
```

### 5. Regular Updates

```bash
# Weekly: Check for updates
wp plugin list

# Monthly: Install updates
wp plugin update poolsafe-portal

# Test in staging first!
```

---

## Troubleshooting

### Plugin Won't Activate

**Symptoms**: "Plugin could not be activated"

**Solution**:
```bash
# Check PHP errors
tail -f /var/log/apache2/error.log

# Check WordPress debug log
tail -f wp-content/debug.log

# Enable debug
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);

# Check plugin requirements
php -v  # Must be 7.4+
wp plugin list
```

### Slow Response Times

**Symptoms**: Pages loading slowly

**Solutions**:
```bash
# 1. Check cache status
wp poolsafe cache-stats

# 2. Flush cache if needed
wp poolsafe cache-flush

# 3. Optimize database
wp db optimize

# 4. Check query log
# Enable query monitor plugin
wp plugin install query-monitor --activate

# 5. Run performance test
k6 run tests/performance/load-test.js
```

### 2FA Not Working

**Symptoms**: Users can't login with 2FA

**Solutions**:
```bash
# 1. Check server time (critical for TOTP)
date
timedatectl set-ntp true

# 2. Check if 2FA is enabled
wp option get psp_2fa_enabled

# 3. Verify backup codes
wp db query "SELECT COUNT(*) FROM wp_usermeta WHERE meta_key = 'psp_backup_codes'"

# 4. Check if user is locked out
wp user list --role=contributor | grep "2fa"

# 5. Reset user 2FA
wp user meta delete $USER_ID psp_2fa_secret
wp user meta delete $USER_ID psp_2fa_enabled
```

### CSRF Token Errors

**Symptoms**: "Security check failed"

**Solutions**:
```bash
# Check if sessions are working
wp eval 'echo session_status() ? "ON" : "OFF"'

# Clear session data
wp transient delete-all

# Check CSRF logs
wp db query "SELECT * FROM wp_options WHERE option_name LIKE '%csrf%' LIMIT 10"

# Reset nonce generation
wp transient delete psp_csrf_tokens
```

### API Not Working

**Symptoms**: 403/401 errors on API calls

**Solutions**:
```bash
# 1. Check if REST API is enabled
wp option get rest_api_enabled

# 2. Test basic endpoint
curl -i https://example.com/wp-json/psp/v1/companies

# 3. Check CORS headers
curl -I -H "Origin: http://localhost" https://example.com/wp-json/psp/v1/companies

# 4. Verify authentication
wp user list

# 5. Check API key in database
wp db query "SELECT * FROM wp_options WHERE option_name LIKE '%api_key%'"
```

### Database Connection Issues

**Symptoms**: White screen of death, database error

**Solutions**:
```bash
# Check connection
wp db check

# Repair tables
wp db repair

# Check credentials
cat wp-config.php | grep DB_

# Reset if needed
wp db reset --yes
wp plugin activate poolsafe-portal
```

---

## Rollback Plan

If issues occur after deployment:

### Quick Rollback (< 1 hour downtime)

```bash
# 1. Deactivate plugin
wp plugin deactivate poolsafe-portal

# 2. Restore from backup
mysqldump -u root -p$DB_PASSWORD poolsafe_db_backup > poolsafe_db_current.sql
mysql -u root -p$DB_PASSWORD poolsafe_db < poolsafe_db_previous.sql

# 3. Restore plugin files
rm -rf wp-content/plugins/poolsafe-portal
tar -xzf /backups/poolsafe/files_previous.tar.gz

# 4. Activate previous version
wp plugin activate poolsafe-portal

# 5. Verify
wp plugin list
```

### Database Rollback

```bash
# List backups
ls -la /backups/poolsafe/db_*.sql

# Restore specific backup
mysql -u root -p$DB_PASSWORD poolsafe_db < /backups/poolsafe/db_20251209_020000.sql

# Verify data
wp db check
wp user list
```

---

## Support & Resources

- **Documentation**: docs.poolsafe.com
- **GitHub Issues**: github.com/your-org/poolsafe-portal
- **Support Email**: support@poolsafe.com
- **Security Issues**: security@poolsafe.com

---

**Version**: 3.0.0  
**Last Updated**: December 9, 2025  
**Maintained By**: PoolSafe Team
