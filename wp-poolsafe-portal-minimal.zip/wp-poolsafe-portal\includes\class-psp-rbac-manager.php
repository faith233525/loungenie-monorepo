<?php
namespace PSP;

/**
 * Role-Based Access Control Manager
 * Manages plugin-specific roles and capabilities
 * Enforces access control for API settings and portal management
 *
 * @since 1.1.0
 */

if (!defined('ABSPATH')) {
	exit;
}

class RBAC_Manager {

	/**
	 * Plugin role: psp_support
	 * Can manage portal data, view tickets, manage API settings
	 *
	 * @var string
	 */
	const ROLE_SUPPORT = 'psp_support';

	/**
	 * Plugin role: psp_manager
	 * Can manage users, configure settings, view audit logs
	 *
	 * @var string
	 */
	const ROLE_MANAGER = 'psp_manager';

	/**
	 * Plugin role: psp_partner
	 * Limited access - can view own data and tickets
	 *
	 * @var string
	 */
	const ROLE_PARTNER = 'psp_partner';

	/**
	 * Capabilities for psp_support role
	 *
	 * @var array
	 */
	private static $support_caps = [
		'psp_view_partners' => true,
		'psp_edit_partners' => true,
		'psp_view_tickets' => true,
		'psp_create_ticket' => true,
		'psp_manage_api_settings' => false, // Support cannot change API settings
		'psp_view_audit_log' => false,
	];

	/**
	 * Capabilities for psp_manager role
	 *
	 * @var array
	 */
	private static $manager_caps = [
		'psp_view_partners' => true,
		'psp_edit_partners' => true,
		'psp_delete_partners' => true,
		'psp_view_tickets' => true,
		'psp_create_ticket' => true,
		'psp_manage_api_settings' => true,
		'psp_view_audit_log' => true,
		'psp_export_data' => true,
	];

	/**
	 * Capabilities for psp_partner role
	 *
	 * @var array
	 */
	private static $partner_caps = [
		'psp_view_partners' => true, // Own company only
		'psp_edit_partners' => true, // Own company only
		'psp_view_tickets' => true, // Own tickets only
		'psp_create_ticket' => true,
	];

	/**
	 * Initialize RBAC
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public static function init() {
		add_action('psp_create_roles', [self::class, 'create_roles']);
		add_action('plugins_loaded', [self::class, 'register_meta_capabilities']);
	}

	/**
	 * Create custom plugin roles
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public static function create_roles() {
		// Create psp_support role
		add_role(
			self::ROLE_SUPPORT,
			'PoolSafe Support',
			self::$support_caps
		);

		// Create psp_manager role
		add_role(
			self::ROLE_MANAGER,
			'PoolSafe Manager',
			self::$manager_caps
		);

		// Create psp_partner role
		add_role(
			self::ROLE_PARTNER,
			'PoolSafe Partner',
			self::$partner_caps
		);

		// Grant admin all capabilities
		$admin = get_role('administrator');
		if ($admin) {
			foreach (array_merge(self::$support_caps, self::$manager_caps, self::$partner_caps) as $cap => $grant) {
				$admin->add_cap($cap);
			}
		}
	}

	/**
	 * Register meta capabilities for resource-level access
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public static function register_meta_capabilities() {
		// Disabled: map_meta_cap filter removed to prevent "delete_post without post ID" warnings
		// Custom post types now use map_meta_cap => false to handle their own capabilities
		// add_filter('map_meta_cap', [self::class, 'map_meta_caps'], 10, 4);
	}

	/**
	 * Map meta capabilities for resource-level access control
	 *
	 * @since 1.1.0
	 * @param array  $caps Capabilities required.
	 * @param string $cap Capability name.
	 * @param int    $user_id User ID.
	 * @param array  $args Additional arguments.
	 * @return array Mapped capabilities.
	 */
	public static function map_meta_caps($caps, $cap, $user_id, $args) {
		$user = get_userdata($user_id);

		// Only process if user exists
		if (!$user) {
			return $caps;
		}

		// WordPress requires post ID for delete_post capability checks
		// Ignore delete_post capability mapping - let WordPress handle it natively
		if ('delete_post' === $cap || 'delete_posts' === $cap) {
			return $caps;
		}

		// Partner users can only access their own company data
		if (in_array(self::ROLE_PARTNER, $user->roles, true)) {
			if ('psp_view_partners' === $cap || 'psp_edit_partners' === $cap) {
				// Check if user belongs to the company being accessed
				if (!self::user_owns_company($user_id, $args[0] ?? 0)) {
					$caps[] = 'do_not_allow';
				}
			}

			if ('psp_view_tickets' === $cap) {
				// Partner can only view own tickets
				if (!self::user_owns_ticket($user_id, $args[0] ?? 0)) {
					$caps[] = 'do_not_allow';
				}
			}
		}

		// Support staff cannot change API settings
		if (in_array(self::ROLE_SUPPORT, $user->roles, true) && !in_array('administrator', $user->roles, true)) {
			if ('psp_manage_api_settings' === $cap) {
				$caps[] = 'do_not_allow';
			}
		}

		return $caps;
	}

	/**
	 * Check if user owns a company
	 *
	 * @since 1.1.0
	 * @param int $user_id User ID.
	 * @param int $company_id Company ID.
	 * @return bool True if user owns company.
	 */
	private static function user_owns_company($user_id, $company_id) {
		$user = get_userdata($user_id);

		if (!$user) {
			return false;
		}

		// Get user's company ID from meta
		$user_company_id = get_user_meta($user_id, 'psp_company_id', true);

		return intval($user_company_id) === intval($company_id);
	}

	/**
	 * Check if user owns a ticket
	 *
	 * @since 1.1.0
	 * @param int $user_id User ID.
	 * @param int $ticket_id Ticket ID.
	 * @return bool True if user owns ticket.
	 */
	private static function user_owns_ticket($user_id, $ticket_id) {
		$ticket = get_post($ticket_id);

		if (!$ticket || 'psp_ticket' !== $ticket->post_type) {
			return false;
		}

		// Check if user's company matches ticket's company
		$ticket_company_id = get_post_meta($ticket_id, 'company_id', true);
		$user_company_id = get_user_meta($user_id, 'psp_company_id', true);

		return intval($user_company_id) === intval($ticket_company_id);
	}

	/**
	 * Check if user can manage API settings
	 *
	 * @since 1.1.0
	 * @param int $user_id User ID.
	 * @return bool True if user can manage settings.
	 */
	public static function user_can_manage_settings($user_id = 0) {
		if (empty($user_id)) {
			$user_id = get_current_user_id();
		}

		return current_user_can('psp_manage_api_settings', $user_id);
	}

	/**
	 * Check if user can view audit logs
	 *
	 * @since 1.1.0
	 * @param int $user_id User ID.
	 * @return bool True if user can view logs.
	 */
	public static function user_can_view_logs($user_id = 0) {
		if (empty($user_id)) {
			$user_id = get_current_user_id();
		}

		return current_user_can('psp_view_audit_log', $user_id);
	}

	/**
	 * Check if user can view partners
	 *
	 * @since 1.1.0
	 * @param int $user_id User ID.
	 * @param int $partner_id Partner/company ID.
	 * @return bool True if user can view partner.
	 */
	public static function user_can_view_partner($user_id, $partner_id) {
		if (current_user_can('administrator')) {
			return true;
		}

		$user = get_userdata($user_id);

		// Managers and support can view all
		if (in_array(self::ROLE_MANAGER, $user->roles, true) || 
			in_array(self::ROLE_SUPPORT, $user->roles, true)) {
			return true;
		}

		// Partners can view own company
		return self::user_owns_company($user_id, $partner_id);
	}

	/**
	 * Check if user can edit partners
	 *
	 * @since 1.1.0
	 * @param int $user_id User ID.
	 * @param int $partner_id Partner/company ID.
	 * @return bool True if user can edit partner.
	 */
	public static function user_can_edit_partner($user_id, $partner_id) {
		if (current_user_can('administrator')) {
			return true;
		}

		$user = get_userdata($user_id);

		// Managers can edit all
		if (in_array(self::ROLE_MANAGER, $user->roles, true)) {
			return true;
		}

		// Partners can edit own company
		if (in_array(self::ROLE_PARTNER, $user->roles, true)) {
			return self::user_owns_company($user_id, $partner_id);
		}

		return false;
	}

	/**
	 * Get role description
	 *
	 * @since 1.1.0
	 * @param string $role Role name.
	 * @return string Role description.
	 */
	public static function get_role_description($role) {
		$descriptions = [
			self::ROLE_PARTNER => 'Can view and manage own company data and tickets',
			self::ROLE_SUPPORT => 'Can manage portal data, respond to tickets, cannot change API settings',
			self::ROLE_MANAGER => 'Full access to settings, API configuration, audit logs, and all portal data',
		];

		return $descriptions[$role] ?? '';
	}

	/**
	 * Get all plugin roles
	 *
	 * @since 1.1.0
	 * @return array Plugin roles.
	 */
	public static function get_plugin_roles() {
		return [
			self::ROLE_PARTNER,
			self::ROLE_SUPPORT,
			self::ROLE_MANAGER,
		];
	}
}
