<?php
namespace PSP;

/**
 * Security Manager - Rate Limiting, Brute Force Protection, Session Management
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Security_Manager {

	const RATE_LIMIT_KEY = 'psp_rate_limit_';
	const LOGIN_ATTEMPTS_KEY = 'psp_login_attempts_';

	/**
	 * Initialize security features
	 */
	public static function init(): void {
		// Rate limiting
		add_action( 'rest_api_init', array( __CLASS__, 'check_rate_limit' ) );

		// Brute force protection
		add_action( 'wp_login_failed', array( __CLASS__, 'log_failed_login' ) );
		add_filter( 'authenticate', array( __CLASS__, 'check_login_attempts' ), 1, 3 );

		// Session timeout
		add_action( 'admin_init', array( __CLASS__, 'check_session_timeout' ) );

		// Security headers
		add_action( 'wp_head', array( __CLASS__, 'add_security_headers' ) );
		add_action( 'admin_head', array( __CLASS__, 'add_security_headers' ) );

		// Admin menu
		add_action( 'admin_menu', array( __CLASS__, 'add_security_menu' ) );

		// AJAX
		add_action( 'wp_ajax_psp_get_security_settings', array( __CLASS__, 'ajax_get_settings' ) );
		add_action( 'wp_ajax_psp_save_security_settings', array( __CLASS__, 'ajax_save_settings' ) );
		add_action( 'wp_ajax_psp_get_failed_logins', array( __CLASS__, 'ajax_get_failed_logins' ) );
	}

	/**
	 * Check API rate limit
	 */
	public static function check_rate_limit(): void {
		$enabled = get_option( 'psp_rate_limiting_enabled', '1' );

		if ( ! $enabled ) {
			return;
		}

		$ip = self::get_client_ip();
		$limit = absint( get_option( 'psp_rate_limit_requests', 100 ) );
		$window = absint( get_option( 'psp_rate_limit_window', 3600 ) );

		$key = self::RATE_LIMIT_KEY . $ip;
		$requests = get_transient( $key );

		if ( false === $requests ) {
			set_transient( $key, 1, $window );
		} else {
			if ( $requests >= $limit ) {
				wp_send_json_error( 'Rate limit exceeded. Please try again later.' );
			}
			set_transient( $key, $requests + 1, $window );
		}
	}

	/**
	 * Log failed login attempt
	 */
	public static function log_failed_login( $username ): void {
		$ip = self::get_client_ip();
		$key = self::LOGIN_ATTEMPTS_KEY . $ip;

		$attempts = get_transient( $key );
		if ( false === $attempts ) {
			$attempts = 0;
		}

		$attempts++;
		set_transient( $key, $attempts, 3600 ); // 1 hour

		// Log to database
		global $wpdb;
		$wpdb->insert(
			$wpdb->prefix . 'psp_security_log',
			array(
				'event_type'  => 'failed_login',
				'username'    => $username,
				'ip_address'  => $ip,
				'user_agent'  => isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '',
				'timestamp'   => current_time( 'mysql' ),
			),
			array( '%s', '%s', '%s', '%s', '%s' )
		);

		// Email admin if threshold exceeded
		$threshold = absint( get_option( 'psp_brute_force_threshold', 5 ) );
		if ( $attempts >= $threshold ) {
			$admin_email = get_option( 'admin_email' );
			$message = sprintf(
				"Security Alert: Multiple failed login attempts detected\n\nUsername: %s\nIP Address: %s\nAttempts: %d (threshold: %d)\nTime: %s",
				$username,
				$ip,
				$attempts,
				$threshold,
				current_time( 'mysql' )
			);

			wp_mail(
				$admin_email,
				'PoolSafe Portal - Brute Force Attempt Detected',
				$message
			);
		}
	}

	/**
	 * Check login attempts before authentication
	 */
	public static function check_login_attempts( $user, $username, $password ) {
		if ( empty( $username ) || empty( $password ) ) {
			return $user;
		}

		$enabled = get_option( 'psp_brute_force_protection_enabled', '1' );

		if ( ! $enabled ) {
			return $user;
		}

		$ip = self::get_client_ip();
		$key = self::LOGIN_ATTEMPTS_KEY . $ip;
		$threshold = absint( get_option( 'psp_brute_force_threshold', 5 ) );

		$attempts = get_transient( $key );

		if ( false !== $attempts && $attempts >= $threshold ) {
			return new \WP_Error(
				'too_many_attempts',
				'Too many failed login attempts. Please try again later.',
				array( 'attempts' => $attempts )
			);
		}

		return $user;
	}

	/**
	 * Check session timeout
	 */
	public static function check_session_timeout(): void {
		if ( ! is_user_logged_in() ) {
			return;
		}

		$enabled = get_option( 'psp_session_timeout_enabled', '1' );

		if ( ! $enabled ) {
			return;
		}

		$timeout = absint( get_option( 'psp_session_timeout_minutes', 60 ) ) * 60;
		$user_id = get_current_user_id();

		if ( isset( $_SESSION['psp_last_activity'] ) ) {
			$time_since = time() - $_SESSION['psp_last_activity'];

			if ( $time_since > $timeout ) {
				wp_logout();
				wp_safe_remote_get(
					add_query_arg(
						'psp_session_expired',
						'1',
						wp_login_url( wp_get_referer() )
					)
				);
				exit;
			}
		}

		$_SESSION['psp_last_activity'] = time();
	}

	/**
	 * Add security headers
	 */
	public static function add_security_headers(): void {
		header( 'X-Content-Type-Options: nosniff' );
		header( 'X-Frame-Options: SAMEORIGIN' );
		header( 'X-XSS-Protection: 1; mode=block' );
		header( 'Referrer-Policy: strict-origin-when-cross-origin' );
		header( 'Permissions-Policy: geolocation=(), microphone=(), camera=()' );
	}

	/**
	 * Get client IP
		 */
	private static function get_client_ip(): string {
		if ( ! empty( $_SERVER['HTTP_CF_CONNECTING_IP'] ) ) {
			return sanitize_text_field( wp_unslash( $_SERVER['HTTP_CF_CONNECTING_IP'] ) );
		}
		if ( ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
			return sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_FORWARDED_FOR'] ) );
		}
		return isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	}

	/**
	 * Create security log table
	 */
	public static function create_table(): void {
		global $wpdb;

		$table_name = $wpdb->prefix . 'psp_security_log';
		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE IF NOT EXISTS $table_name (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
			event_type VARCHAR(50) NOT NULL,
			username VARCHAR(255),
			ip_address VARCHAR(100),
			user_agent VARCHAR(255),
			timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
			INDEX idx_event_type (event_type),
			INDEX idx_timestamp (timestamp)
		) $charset_collate;";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql );
	}

	/**
	 * Add security settings menu
	 */
	public static function add_security_menu(): void {
		add_submenu_page(
			'psp-settings',
			'Security Settings',
			'Security',
			'manage_options',
			'psp-security',
			array( __CLASS__, 'render_security_page' )
		);
	}

	/**
	 * AJAX: Get security settings
	 */
	public static function ajax_get_settings(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Insufficient permissions' );
		}

		wp_send_json_success(
			array(
				'rate_limiting_enabled'         => get_option( 'psp_rate_limiting_enabled', '1' ),
				'rate_limit_requests'           => get_option( 'psp_rate_limit_requests', 100 ),
				'rate_limit_window'             => get_option( 'psp_rate_limit_window', 3600 ),
				'brute_force_protection_enabled' => get_option( 'psp_brute_force_protection_enabled', '1' ),
				'brute_force_threshold'         => get_option( 'psp_brute_force_threshold', 5 ),
				'session_timeout_enabled'       => get_option( 'psp_session_timeout_enabled', '1' ),
				'session_timeout_minutes'       => get_option( 'psp_session_timeout_minutes', 60 ),
			)
		);
	}

	/**
	 * AJAX: Save security settings
	 */
	public static function ajax_save_settings(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Insufficient permissions' );
		}

		$settings = isset( $_POST['settings'] ) ? map_deep( wp_unslash( $_POST['settings'] ), 'sanitize_text_field' ) : array();

		update_option( 'psp_rate_limiting_enabled', $settings['rate_limiting_enabled'] ?? '0' );
		update_option( 'psp_rate_limit_requests', absint( $settings['rate_limit_requests'] ?? 100 ) );
		update_option( 'psp_rate_limit_window', absint( $settings['rate_limit_window'] ?? 3600 ) );
		update_option( 'psp_brute_force_protection_enabled', $settings['brute_force_protection_enabled'] ?? '0' );
		update_option( 'psp_brute_force_threshold', absint( $settings['brute_force_threshold'] ?? 5 ) );
		update_option( 'psp_session_timeout_enabled', $settings['session_timeout_enabled'] ?? '0' );
		update_option( 'psp_session_timeout_minutes', absint( $settings['session_timeout_minutes'] ?? 60 ) );

		wp_send_json_success( 'Settings saved' );
	}

	/**
	 * AJAX: Get failed logins
	 */
	public static function ajax_get_failed_logins(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Insufficient permissions' );
		}

		global $wpdb;

		$logins = $wpdb->get_results(
			"SELECT * FROM {$wpdb->prefix}psp_security_log WHERE event_type = 'failed_login' ORDER BY timestamp DESC LIMIT 100"
		);

		wp_send_json_success( $logins );
	}

	/**
	 * Render security page
	 */
	public static function render_security_page(): void {
		?>
		<div class="wrap">
			<h1>PoolSafe Portal - Security Settings</h1>

			<div style="background: white; padding: 20px; border-radius: 5px; margin: 20px 0;">
				<h2>Rate Limiting</h2>
				<p>
					<label>
						<input type="checkbox" id="psp-rate-limiting" checked>
						Enable API rate limiting
					</label>
				</p>
				<p>
					<label>Requests per window: 
						<input type="number" id="psp-rate-limit-requests" value="100" min="10" max="1000">
					</label>
				</p>
				<p>
					<label>Time window (seconds): 
						<input type="number" id="psp-rate-limit-window" value="3600" min="60" max="86400">
					</label>
				</p>
			</div>

			<div style="background: white; padding: 20px; border-radius: 5px; margin: 20px 0;">
				<h2>Brute Force Protection</h2>
				<p>
					<label>
						<input type="checkbox" id="psp-brute-force" checked>
						Enable brute force protection
					</label>
				</p>
				<p>
					<label>Failed attempts threshold: 
						<input type="number" id="psp-brute-force-threshold" value="5" min="1" max="20">
					</label>
				</p>
			</div>

			<div style="background: white; padding: 20px; border-radius: 5px; margin: 20px 0;">
				<h2>Session Management</h2>
				<p>
					<label>
						<input type="checkbox" id="psp-session-timeout" checked>
						Enable automatic session timeout
					</label>
				</p>
				<p>
					<label>Session timeout (minutes): 
						<input type="number" id="psp-session-timeout-minutes" value="60" min="5" max="480">
					</label>
				</p>
			</div>

			<button class="button button-primary" id="psp-save-security">Save Settings</button>
		</div>

		<script>
		document.getElementById('psp-save-security')?.addEventListener('click', function() {
			fetch(ajaxurl, {
				method: 'POST',
				headers: {'Content-Type': 'application/x-www-form-urlencoded'},
				body: new URLSearchParams({
					action: 'psp_save_security_settings',
					settings: {
						rate_limiting_enabled: document.getElementById('psp-rate-limiting').checked ? '1' : '0',
						rate_limit_requests: document.getElementById('psp-rate-limit-requests').value,
						rate_limit_window: document.getElementById('psp-rate-limit-window').value,
						brute_force_protection_enabled: document.getElementById('psp-brute-force').checked ? '1' : '0',
						brute_force_threshold: document.getElementById('psp-brute-force-threshold').value,
						session_timeout_enabled: document.getElementById('psp-session-timeout').checked ? '1' : '0',
						session_timeout_minutes: document.getElementById('psp-session-timeout-minutes').value
					}
				})
			})
			.then(r => r.json())
			.then(data => {
				alert(data.data || 'Settings saved');
				location.reload();
			});
		});
		</script>
		<?php
	}
}

// Initialize security manager
Security_Manager::init();
