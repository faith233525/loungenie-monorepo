<?php
/**
 * Request Signer Class
 * File: includes/class-psp-request-signer.php
 * 
 * Implements HMAC-SHA256 request signing for API authentication.
 * 
 * @package PoolSafe_Portal
 * @subpackage Security
 * @since 3.0.0
 * @author PoolSafe Team
 */

class PSP_Request_Signer {

    const ALGORITHM = 'sha256';
    const SIGNATURE_HEADER = 'X-PSP-Signature';
    const TIMESTAMP_HEADER = 'X-PSP-Timestamp';
    const NONCE_HEADER = 'X-PSP-Nonce';
    const KEY_HEADER = 'X-PSP-Key';

    /**
     * Generate API key pair
     *
     * @return array Array with 'public_key' and 'secret_key'
     */
    public static function generate_key_pair() {
        $public_key = wp_generate_password( 32, false, false );
        $secret_key = wp_generate_password( 64, false, false );

        return [
            'public_key' => $public_key,
            'secret_key' => $secret_key,
        ];
    }

    /**
     * Sign a request with HMAC-SHA256
     *
     * @param string $method HTTP method
     * @param string $endpoint API endpoint
     * @param string $secret_key Secret key
     * @param string $body Request body
     * @param string $public_key Public key (optional)
     * @return array Signature headers
     */
    public static function sign_request( $method, $endpoint, $secret_key, $body = '', $public_key = '' ) {
        $timestamp = time();
        $nonce = bin2hex( random_bytes( 16 ) );

        // Build canonical request
        $canonical = self::build_canonical_request(
            $method,
            $endpoint,
            $body,
            $timestamp,
            $nonce
        );

        // Generate signature
        $signature = hash_hmac( self::ALGORITHM, $canonical, $secret_key );

        return [
            self::SIGNATURE_HEADER => $signature,
            self::TIMESTAMP_HEADER => $timestamp,
            self::NONCE_HEADER => $nonce,
            self::KEY_HEADER => $public_key,
        ];
    }

    /**
     * Build canonical request string for signing
     *
     * @param string $method HTTP method
     * @param string $endpoint API endpoint
     * @param string $body Request body
     * @param int $timestamp Request timestamp
     * @param string $nonce Request nonce
     * @return string Canonical request string
     */
    private static function build_canonical_request( $method, $endpoint, $body, $timestamp, $nonce ) {
        $body_hash = hash( self::ALGORITHM, $body );

        return implode( "\n", [
            strtoupper( $method ),
            $endpoint,
            $timestamp,
            $nonce,
            $body_hash,
        ] );
    }

    /**
     * Verify request signature
     *
     * @param string $method HTTP method
     * @param string $endpoint API endpoint
     * @param string $body Request body
     * @param string $signature Provided signature
     * @param string $secret_key Secret key
     * @param int $timestamp Request timestamp
     * @param string $nonce Request nonce
     * @param int $max_age Maximum age of request (seconds)
     * @return bool True if signature is valid
     */
    public static function verify_signature(
        $method,
        $endpoint,
        $body,
        $signature,
        $secret_key,
        $timestamp,
        $nonce,
        $max_age = 300
    ) {
        // Check timestamp freshness
        if ( abs( time() - $timestamp ) > $max_age ) {
            return false;
        }

        // Rebuild canonical request
        $canonical = self::build_canonical_request(
            $method,
            $endpoint,
            $body,
            $timestamp,
            $nonce
        );

        // Verify signature
        $expected_signature = hash_hmac( self::ALGORITHM, $canonical, $secret_key );

        // Use hash_equals to prevent timing attacks
        return hash_equals( $expected_signature, $signature );
    }

    /**
     * Get signature from request headers
     *
     * @return array|null Array with signature data or null
     */
    public static function get_signature_from_headers() {
        $headers = getallheaders();

        if ( empty( $headers[ self::SIGNATURE_HEADER ] ) ||
             empty( $headers[ self::TIMESTAMP_HEADER ] ) ||
             empty( $headers[ self::NONCE_HEADER ] ) ) {
            return null;
        }

        return [
            'signature' => $headers[ self::SIGNATURE_HEADER ],
            'timestamp' => intval( $headers[ self::TIMESTAMP_HEADER ] ),
            'nonce' => $headers[ self::NONCE_HEADER ],
            'public_key' => $headers[ self::KEY_HEADER ] ?? '',
        ];
    }

    /**
     * Verify incoming request
     *
     * @param string $secret_key Secret key to verify against
     * @param int $max_age Maximum age of request
     * @return bool|WP_Error True if valid, WP_Error if invalid
     */
    public static function verify_incoming_request( $secret_key, $max_age = 300 ) {
        $sig_data = self::get_signature_from_headers();

        if ( empty( $sig_data ) ) {
            self::log_verification_failure( 'missing_headers' );
            return new WP_Error(
                'missing_signature',
                'Request signature headers missing',
                [ 'status' => 401 ]
            );
        }

        $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
        $endpoint = $_SERVER['REQUEST_URI'] ?? '/';
        $body = file_get_contents( 'php://input' );

        $valid = self::verify_signature(
            $method,
            $endpoint,
            $body,
            $sig_data['signature'],
            $secret_key,
            $sig_data['timestamp'],
            $sig_data['nonce'],
            $max_age
        );

        if ( ! $valid ) {
            self::log_verification_failure( 'invalid_signature' );
            return new WP_Error(
                'invalid_signature',
                'Request signature verification failed',
                [ 'status' => 401 ]
            );
        }

        return true;
    }

    /**
     * Store API key for user or application
     *
     * @param int|string $entity_id User ID or application ID
     * @param string $entity_type 'user' or 'app'
     * @param string $public_key Public key
     * @param string $secret_key Secret key (stored hashed)
     * @param string $name Key name
     * @return int|bool Key ID or false
     */
    public static function store_api_key( $entity_id, $entity_type, $public_key, $secret_key, $name = '' ) {
        global $wpdb;

        $hashed_secret = wp_hash_password( $secret_key );
        $created = current_time( 'mysql' );

        $result = $wpdb->insert(
            $wpdb->prefix . 'psp_api_keys',
            [
                'entity_id' => intval( $entity_id ),
                'entity_type' => sanitize_text_field( $entity_type ),
                'public_key' => sanitize_text_field( $public_key ),
                'secret_key_hash' => $hashed_secret,
                'key_name' => sanitize_text_field( $name ),
                'created_at' => $created,
                'last_used' => null,
            ],
            [ '%d', '%s', '%s', '%s', '%s', '%s', '%s' ]
        );

        if ( false === $result ) {
            return false;
        }

        return $wpdb->insert_id;
    }

    /**
     * Get API key
     *
     * @param string $public_key Public key to look up
     * @return object|null API key object or null
     */
    public static function get_api_key( $public_key ) {
        global $wpdb;

        return $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}psp_api_keys WHERE public_key = %s",
                $public_key
            )
        );
    }

    /**
     * Verify API key secret
     *
     * @param object $key_obj API key object from database
     * @param string $secret_key Secret key to verify
     * @return bool True if secret matches
     */
    public static function verify_api_key_secret( $key_obj, $secret_key ) {
        if ( empty( $key_obj->secret_key_hash ) ) {
            return false;
        }

        return wp_check_password( $secret_key, $key_obj->secret_key_hash );
    }

    /**
     * Update API key last used timestamp
     *
     * @param int $key_id API key ID
     */
    public static function update_last_used( $key_id ) {
        global $wpdb;

        $wpdb->update(
            $wpdb->prefix . 'psp_api_keys',
            [ 'last_used' => current_time( 'mysql' ) ],
            [ 'id' => intval( $key_id ) ],
            [ '%s' ],
            [ '%d' ]
        );
    }

    /**
     * Revoke API key
     *
     * @param int $key_id API key ID
     * @return bool Success
     */
    public static function revoke_api_key( $key_id ) {
        global $wpdb;

        $result = $wpdb->delete(
            $wpdb->prefix . 'psp_api_keys',
            [ 'id' => intval( $key_id ) ],
            [ '%d' ]
        );

        return false !== $result;
    }

    /**
     * List API keys for entity
     *
     * @param int|string $entity_id Entity ID
     * @param string $entity_type Entity type
     * @return array API keys
     */
    public static function list_api_keys( $entity_id, $entity_type = 'user' ) {
        global $wpdb;

        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, public_key, key_name, created_at, last_used FROM {$wpdb->prefix}psp_api_keys WHERE entity_id = %d AND entity_type = %s ORDER BY created_at DESC",
                intval( $entity_id ),
                sanitize_text_field( $entity_type )
            )
        );
    }

    /**
     * Log signature verification failure
     *
     * @param string $reason Failure reason
     */
    private static function log_verification_failure( $reason ) {
        $log = [
            'timestamp' => current_time( 'mysql' ),
            'reason' => $reason,
            'url' => $_SERVER['REQUEST_URI'] ?? '',
            'ip' => PSP_Rate_Limiter::get_client_ip(),
            'method' => $_SERVER['REQUEST_METHOD'] ?? 'GET',
        ];

        do_action( 'psp_signature_verification_failure', $log );

        // Store in options
        $history = get_option( 'psp_signature_failures', [] );
        $history[] = $log;

        if ( count( $history ) > 100 ) {
            $history = array_slice( $history, -100 );
        }

        update_option( 'psp_signature_failures', $history );
    }

    /**
     * Register WP-CLI commands
     */
    public static function register_cli_commands() {
        if ( ! class_exists( 'WP_CLI' ) ) {
            return;
        }

        WP_CLI::add_command( 'psp api-key generate', [ __CLASS__, 'cli_generate' ] );
        WP_CLI::add_command( 'psp api-key list', [ __CLASS__, 'cli_list' ] );
        WP_CLI::add_command( 'psp api-key revoke', [ __CLASS__, 'cli_revoke' ] );
    }

    /**
     * WP-CLI: Generate API key
     *
     * @param array $args Positional arguments
     * @param array $assoc_args Associative arguments
     */
    public static function cli_generate( $args, $assoc_args ) {
        $entity_id = $assoc_args['user'] ?? null;
        $name = $assoc_args['name'] ?? '';

        if ( empty( $entity_id ) ) {
            WP_CLI::error( 'Please provide --user=<user_id>' );
        }

        $user = get_user_by( 'id', intval( $entity_id ) );
        if ( ! $user ) {
            WP_CLI::error( "User not found: $entity_id" );
        }

        $keys = self::generate_key_pair();
        $key_id = self::store_api_key(
            $entity_id,
            'user',
            $keys['public_key'],
            $keys['secret_key'],
            $name
        );

        if ( ! $key_id ) {
            WP_CLI::error( 'Failed to store API key' );
        }

        WP_CLI::success( "API Key generated for user: {$user->user_login}" );
        WP_CLI::log( "Public Key:  {$keys['public_key']}" );
        WP_CLI::log( "Secret Key:  {$keys['secret_key']}" );
        WP_CLI::log( "⚠️  Save the secret key - it will not be shown again!" );
    }

    /**
     * WP-CLI: List API keys
     *
     * @param array $args Positional arguments
     * @param array $assoc_args Associative arguments
     */
    public static function cli_list( $args, $assoc_args ) {
        $entity_id = $assoc_args['user'] ?? null;

        if ( empty( $entity_id ) ) {
            WP_CLI::error( 'Please provide --user=<user_id>' );
        }

        $user = get_user_by( 'id', intval( $entity_id ) );
        if ( ! $user ) {
            WP_CLI::error( "User not found: $entity_id" );
        }

        $keys = self::list_api_keys( $entity_id, 'user' );

        if ( empty( $keys ) ) {
            WP_CLI::log( "No API keys found for user: {$user->user_login}" );
            return;
        }

        WP_CLI::log( "API Keys for user: {$user->user_login}" );
        WP_CLI::log( '' );

        foreach ( $keys as $key ) {
            WP_CLI::log( "ID: {$key->id}" );
            WP_CLI::log( "Name: {$key->key_name}" );
            WP_CLI::log( "Public Key: {$key->public_key}" );
            WP_CLI::log( "Created: {$key->created_at}" );
            WP_CLI::log( "Last Used: {$key->last_used}" );
            WP_CLI::log( '' );
        }
    }

    /**
     * WP-CLI: Revoke API key
     *
     * @param array $args Positional arguments
     * @param array $assoc_args Associative arguments
     */
    public static function cli_revoke( $args, $assoc_args ) {
        $key_id = $args[0] ?? null;

        if ( empty( $key_id ) ) {
            WP_CLI::error( 'Please provide key ID' );
        }

        if ( self::revoke_api_key( intval( $key_id ) ) ) {
            WP_CLI::success( "API key $key_id has been revoked" );
        } else {
            WP_CLI::error( "Failed to revoke API key $key_id" );
        }
    }
}
