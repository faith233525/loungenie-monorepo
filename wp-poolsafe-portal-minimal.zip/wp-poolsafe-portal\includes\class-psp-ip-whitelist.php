<?php
/**
 * IP Whitelist Class
 * File: includes/class-psp-ip-whitelist.php
 * 
 * Manages IP whitelist for access control.
 * Supports CIDR notation and IP ranges.
 * 
 * @package PoolSafe_Portal
 * @subpackage Security
 * @since 3.0.0
 * @author PoolSafe Team
 */

class PSP_IP_Whitelist {

    const OPTION_KEY = 'psp_ip_whitelist';
    const BYPASS_KEY = 'psp_ip_bypass';

    /**
     * Check if IP is whitelisted
     *
     * @param string $ip IP address to check
     * @return bool True if IP is allowed
     */
    public static function is_allowed( $ip ) {
        if ( empty( $ip ) ) {
            return false;
        }

        // Check if IP whitelist is enabled
        if ( ! self::is_enabled() ) {
            return true;
        }

        // Check bypass list first
        if ( self::is_in_bypass_list( $ip ) ) {
            return true;
        }

        // Check whitelist
        $whitelist = self::get_list();
        
        foreach ( $whitelist as $entry ) {
            if ( self::ip_matches( $ip, $entry ) ) {
                return true;
            }
        }

        return false;
    }

    /**
     * Check if IP is in bypass list (internal/trusted)
     *
     * @param string $ip IP address
     * @return bool True if in bypass list
     */
    public static function is_in_bypass_list( $ip ) {
        $bypass_list = get_option( self::BYPASS_KEY, self::get_default_bypass_list() );
        
        foreach ( $bypass_list as $entry ) {
            if ( self::ip_matches( $ip, $entry ) ) {
                return true;
            }
        }

        return false;
    }

    /**
     * Get default bypass list (internal IPs)
     *
     * @return array Default bypass IPs
     */
    public static function get_default_bypass_list() {
        return [
            '127.0.0.1',           // Localhost
            '::1',                 // IPv6 localhost
            '192.168.0.0/16',      // Private network
            '10.0.0.0/8',          // Private network
            '172.16.0.0/12',       // Private network
        ];
    }

    /**
     * Check if IP matches entry (supports CIDR)
     *
     * @param string $ip IP to check
     * @param string $entry IP or CIDR entry
     * @return bool True if matches
     */
    public static function ip_matches( $ip, $entry ) {
        $entry = trim( $entry );
        
        // Single IP
        if ( strpos( $entry, '/' ) === false ) {
            return $ip === $entry;
        }

        // CIDR notation
        return self::ip_in_cidr( $ip, $entry );
    }

    /**
     * Check if IP is in CIDR range
     *
     * @param string $ip IP address
     * @param string $cidr CIDR notation
     * @return bool True if in range
     */
    public static function ip_in_cidr( $ip, $cidr ) {
        if ( filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 ) ) {
            return self::ipv4_in_cidr( $ip, $cidr );
        } elseif ( filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6 ) ) {
            return self::ipv6_in_cidr( $ip, $cidr );
        }

        return false;
    }

    /**
     * Check IPv4 in CIDR
     *
     * @param string $ip IPv4 address
     * @param string $cidr CIDR notation
     * @return bool True if in range
     */
    private static function ipv4_in_cidr( $ip, $cidr ) {
        list( $subnet, $bits ) = explode( '/', $cidr );
        $ip = ip2long( $ip );
        $subnet = ip2long( $subnet );
        $mask = -1 << ( 32 - (int) $bits );
        $subnet &= $mask;

        return ( $ip & $mask ) === $subnet;
    }

    /**
     * Check IPv6 in CIDR
     *
     * @param string $ip IPv6 address
     * @param string $cidr CIDR notation
     * @return bool True if in range
     */
    private static function ipv6_in_cidr( $ip, $cidr ) {
        list( $subnet, $bits ) = explode( '/', $cidr );
        
        // Convert IPv6 to binary
        $ip_bin = inet_pton( $ip );
        $subnet_bin = inet_pton( $subnet );

        if ( false === $ip_bin || false === $subnet_bin ) {
            return false;
        }

        // Create mask
        $mask = '';
        $bytes = (int) ( (int) $bits / 8 );
        $bits = (int) $bits % 8;

        for ( $i = 0; $i < $bytes; $i++ ) {
            $mask .= chr( 255 );
        }

        if ( $bits > 0 ) {
            $mask .= chr( 255 - ( 256 - pow( 2, $bits ) ) );
        }

        for ( $i = $bytes + ( $bits > 0 ? 1 : 0 ); $i < 16; $i++ ) {
            $mask .= chr( 0 );
        }

        return ( $ip_bin & $mask ) === ( $subnet_bin & $mask );
    }

    /**
     * Get whitelist
     *
     * @return array Whitelisted IPs/CIDRs
     */
    public static function get_list() {
        $list = get_option( self::OPTION_KEY, [] );
        
        if ( ! is_array( $list ) ) {
            $list = [];
        }

        return array_filter( array_map( 'trim', $list ) );
    }

    /**
     * Add IP to whitelist
     *
     * @param string $ip IP address or CIDR
     * @return bool Success
     */
    public static function add( $ip ) {
        $ip = trim( $ip );

        // Validate format
        if ( ! self::is_valid_ip_or_cidr( $ip ) ) {
            return false;
        }

        $list = self::get_list();

        // Check if already exists
        if ( in_array( $ip, $list, true ) ) {
            return true;
        }

        $list[] = $ip;
        return update_option( self::OPTION_KEY, $list );
    }

    /**
     * Remove IP from whitelist
     *
     * @param string $ip IP address or CIDR
     * @return bool Success
     */
    public static function remove( $ip ) {
        $ip = trim( $ip );
        $list = self::get_list();

        $list = array_values( array_filter(
            $list,
            function( $item ) use ( $ip ) {
                return $item !== $ip;
            }
        ) );

        return update_option( self::OPTION_KEY, $list );
    }

    /**
     * Clear whitelist
     *
     * @return bool Success
     */
    public static function clear() {
        return delete_option( self::OPTION_KEY );
    }

    /**
     * Validate IP or CIDR format
     *
     * @param string $ip IP or CIDR to validate
     * @return bool True if valid
     */
    public static function is_valid_ip_or_cidr( $ip ) {
        $ip = trim( $ip );

        // Single IP
        if ( strpos( $ip, '/' ) === false ) {
            return false !== filter_var( $ip, FILTER_VALIDATE_IP );
        }

        // CIDR notation
        list( $subnet, $bits ) = explode( '/', $ip );
        
        if ( ! is_numeric( $bits ) || $bits < 0 ) {
            return false;
        }

        // Validate subnet is valid IP
        if ( ! filter_var( $subnet, FILTER_VALIDATE_IP ) ) {
            return false;
        }

        // Check bit range based on IP version
        if ( filter_var( $subnet, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 ) ) {
            return intval( $bits ) <= 32;
        }

        if ( filter_var( $subnet, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6 ) ) {
            return intval( $bits ) <= 128;
        }

        return false;
    }

    /**
     * Enable whitelist
     *
     * @return bool Success
     */
    public static function enable() {
        return update_option( self::OPTION_KEY . '_enabled', true );
    }

    /**
     * Disable whitelist
     *
     * @return bool Success
     */
    public static function disable() {
        return update_option( self::OPTION_KEY . '_enabled', false );
    }

    /**
     * Check if whitelist is enabled
     *
     * @return bool True if enabled
     */
    public static function is_enabled() {
        return (bool) get_option( self::OPTION_KEY . '_enabled', false );
    }

    /**
     * Get statistics
     *
     * @return array Statistics
     */
    public static function get_stats() {
        return [
            'enabled'     => self::is_enabled(),
            'count'       => count( self::get_list() ),
            'bypass_count' => count( self::get_default_bypass_list() ),
        ];
    }

    /**
     * Log IP violation
     *
     * @param string $ip IP address
     * @param string $reason Reason for blocking
     */
    public static function log_violation( $ip, $reason = 'Not whitelisted' ) {
        do_action( 'psp_ip_whitelist_violation', $ip, $reason );
        
        // Log to error handler if available
        if ( class_exists( 'PSP_Error_Handler' ) ) {
            error_log( "PSP IP Whitelist Violation: $ip - $reason" );
        }
    }

    /**
     * Register WP-CLI commands
     */
    public static function register_cli_commands() {
        if ( ! class_exists( 'WP_CLI' ) ) {
            return;
        }

        WP_CLI::add_command( 'psp whitelist add', [ __CLASS__, 'cli_add' ] );
        WP_CLI::add_command( 'psp whitelist remove', [ __CLASS__, 'cli_remove' ] );
        WP_CLI::add_command( 'psp whitelist list', [ __CLASS__, 'cli_list' ] );
        WP_CLI::add_command( 'psp whitelist enable', [ __CLASS__, 'cli_enable' ] );
        WP_CLI::add_command( 'psp whitelist disable', [ __CLASS__, 'cli_disable' ] );
    }

    /**
     * WP-CLI: Add IP
     *
     * @param array $args Positional arguments
     * @param array $assoc_args Associative arguments
     */
    public static function cli_add( $args, $assoc_args ) {
        if ( empty( $args[0] ) ) {
            WP_CLI::error( 'Please provide an IP address or CIDR' );
        }

        $ip = $args[0];

        if ( ! self::is_valid_ip_or_cidr( $ip ) ) {
            WP_CLI::error( "Invalid IP or CIDR format: $ip" );
        }

        if ( self::add( $ip ) ) {
            WP_CLI::success( "Added to whitelist: $ip" );
        } else {
            WP_CLI::warning( "IP already in whitelist: $ip" );
        }
    }

    /**
     * WP-CLI: Remove IP
     *
     * @param array $args Positional arguments
     * @param array $assoc_args Associative arguments
     */
    public static function cli_remove( $args, $assoc_args ) {
        if ( empty( $args[0] ) ) {
            WP_CLI::error( 'Please provide an IP address' );
        }

        $ip = $args[0];

        if ( self::remove( $ip ) ) {
            WP_CLI::success( "Removed from whitelist: $ip" );
        } else {
            WP_CLI::warning( "IP not found in whitelist: $ip" );
        }
    }

    /**
     * WP-CLI: List whitelist
     *
     * @param array $args Positional arguments
     * @param array $assoc_args Associative arguments
     */
    public static function cli_list( $args, $assoc_args ) {
        $list = self::get_list();
        $stats = self::get_stats();

        WP_CLI::log( 'IP Whitelist Status:' );
        WP_CLI::log( '  Enabled: ' . ( $stats['enabled'] ? 'Yes' : 'No' ) );
        WP_CLI::log( '  Entries: ' . $stats['count'] );
        WP_CLI::log( '  Bypass IPs: ' . $stats['bypass_count'] );
        WP_CLI::log( '' );

        if ( empty( $list ) ) {
            WP_CLI::log( 'No IPs whitelisted' );
            return;
        }

        WP_CLI::log( 'Whitelisted IPs:' );
        foreach ( $list as $ip ) {
            WP_CLI::log( "  - $ip" );
        }
    }

    /**
     * WP-CLI: Enable whitelist
     *
     * @param array $args Positional arguments
     * @param array $assoc_args Associative arguments
     */
    public static function cli_enable( $args, $assoc_args ) {
        self::enable();
        WP_CLI::success( 'IP whitelist enabled' );
    }

    /**
     * WP-CLI: Disable whitelist
     *
     * @param array $args Positional arguments
     * @param array $assoc_args Associative arguments
     */
    public static function cli_disable( $args, $assoc_args ) {
        self::disable();
        WP_CLI::success( 'IP whitelist disabled' );
    }
}
