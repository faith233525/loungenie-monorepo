/**
 * Input Validation - Frontend
 * Client-side validation for frontend forms
 */

jQuery(document).ready(function ($) {
    // Email validation on blur
    $(document).on('blur', '.psp-email-input', function () {
        validateEmail($(this));
    });

    // Email validation on input (visual feedback)
    $(document).on('input', '.psp-email-input', function () {
        const value = $(this).val();
        const validation = $(this).closest('.psp-email-wrapper').find('.psp-email-validation');

        if (value && !isValidEmail(value)) {
            validation.html('<span style="color:red;">⚠ Invalid email format</span>');
        } else {
            validation.html('');
        }
    });

    // Form submission validation
    $(document).on('submit', 'form', function (e) {
        let isValid = true;
        const form = $(this);

        // Validate all required fields
        form.find('input[required], select[required], textarea[required]').each(function () {
            if (!$(this).val()) {
                $(this).addClass('error');
                isValid = false;
            } else {
                $(this).removeClass('error');
            }
        });

        // Validate emails
        form.find('.psp-email-input').each(function () {
            if ($(this).val() && !isValidEmail($(this).val())) {
                $(this).addClass('error');
                isValid = false;
            }
        });

        // Validate phone numbers
        form.find('.psp-phone-input').each(function () {
            if ($(this).val() && !isValidPhone($(this).val())) {
                $(this).addClass('error');
                isValid = false;
            }
        });

        // Validate date ranges
        form.find('.psp-date-range-wrapper').each(function () {
            const start = $(this).find('input[type="date"]').first().val();
            const end = $(this).find('input[type="date"]').last().val();

            if (start && end && start >= end) {
                $(this).find('input[type="date"]').addClass('error');
                isValid = false;
            }
        });

        if (!isValid) {
            e.preventDefault();
            alert('Please fix validation errors');
            return false;
        }
    });

    /**
     * Check if email format is valid
     */
    function isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    /**
     * Check if phone format is valid
     */
    function isValidPhone(phone) {
        const digitCount = phone.replace(/\D/g, '').length;
        return digitCount >= 10;
    }

    /**
     * Validate email field
     */
    function validateEmail($input) {
        const value = $input.val();
        const wrapper = $input.closest('.psp-email-wrapper');
        const validation = wrapper.find('.psp-email-validation');

        if (!value) {
            validation.html('<span style="color:red;">⚠ Email is required</span>');
            $input.addClass('error');
            return false;
        }

        if (!isValidEmail(value)) {
            validation.html('<span style="color:red;">⚠ Invalid email format</span>');
            $input.addClass('error');
            return false;
        }

        validation.html('<span style="color:green;">✓ Valid email</span>');
        $input.removeClass('error');
        return true;
    }
});
