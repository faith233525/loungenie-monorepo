<?php
/**
 * Portal REST API - Main Endpoint Handler
 *
 * Provides unified REST API for the PoolSafe Portal frontend with:
 * - Session & cookie-based authentication
 * - Role-based data filtering and authorization
 * - Comprehensive error handling and logging
 * - CSRF protection via nonce verification
 * - Rate limiting and security headers
 * - Cache management and performance optimization
 *
 * @package   PoolSafe Portal
 * @version   2.5.3
 * @since     1.0.0
 *
 * BASE NAMESPACE: /wp-json/psp/v1/
 *
 * ENDPOINTS:
 * - GET  /stats              - Dashboard statistics (auth required)
 * - GET  /tickets            - List user's tickets (auth required)
 * - GET  /services           - Service records (auth required)
 * - GET  /companies          - Partner/company list (auth required)
 * - POST /tickets            - Create new ticket (auth required)
 * - POST /auth/login         - User login (no auth required)
 * - POST /auth/logout        - User logout (auth required)
 * - GET  /health             - API status check (no auth required)
 *
 * AUTHENTICATION METHODS:
 * - WordPress session (is_user_logged_in)
 * - Cookie fallback (psp_user_id cookie)
 * - Nonce verification (X-WP-Nonce header)
 *
 * ROLES & PERMISSIONS:
 * - administrator         - Full access
 * - pool_safe_support     - Staff access
 * - pool_safe_partner     - Partner-restricted access
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * PSP_Portal_API Class
 *
 * Manages all REST API endpoints for the PoolSafe Portal.
 * Handles authentication, authorization, and data transformation.
 */
class PSP_Portal_API {

    /**
     * REST API namespace
     *
     * @var string
     */
    private $namespace = 'psp/v1';

    /**
     * Constructor
     *
     * Hooks into WordPress REST API initialization
     */
    public function __construct() {
        add_action( 'rest_api_init', array( $this, 'register_routes' ) );
    }

    /**
     * Register all REST API routes with comprehensive error handling
     *
     * Sets up endpoints with proper authentication,
     * validation, and error handling. All route registrations
     * wrapped in try-catch for graceful degradation.
     *
     * @return void
     */
    public function register_routes() {
        // Validate registration function exists
        if ( ! function_exists( 'register_rest_route' ) ) {
            error_log( '[PSP API] register_rest_route function not available' );
            return;
        }

        // ====================================================================
        // AUTHENTICATION ENDPOINTS
        // ====================================================================

        try {
            // POST /auth/login - User login
            register_rest_route(
                $this->namespace,
                '/auth/login',
                array(
                    'methods'             => 'POST',
                    'callback'            => array( $this, 'handle_login' ),
                    'permission_callback' => '__return_true',
                )
            );
        } catch ( \Exception $e ) {
            error_log( '[PSP API] Failed to register /auth/login route: ' . $e->getMessage() );
        }

        try {
            // POST /auth/logout - User logout
            register_rest_route(
                $this->namespace,
                '/auth/logout',
                array(
                    'methods'             => 'POST',
                    'callback'            => array( $this, 'handle_logout' ),
                    'permission_callback' => array( $this, 'check_auth' ),
                )
            );
        } catch ( \Exception $e ) {
            error_log( '[PSP API] Failed to register /auth/logout route: ' . $e->getMessage() );
        }

        // ====================================================================
        // HEALTH & STATUS ENDPOINTS
        // ====================================================================

        // GET /health - API health check (no authentication required)
        register_rest_route(
            $this->namespace,
            '/health',
            array(
                'methods'             => 'GET',
                'callback'            => array( $this, 'health' ),
                'permission_callback' => '__return_true',
            )
        );

        // ====================================================================
        // COMPANY/PARTNER ENDPOINTS
        // ====================================================================

        // GET /companies - List companies
        register_rest_route(
            $this->namespace,
            '/companies',
            array(
                'methods'             => 'GET',
                'callback'            => array( $this, 'get_companies' ),
                'permission_callback' => array( $this, 'check_auth' ),
            )
        );

        // GET/PUT /companies/{id} - Get/update company details
        register_rest_route(
            $this->namespace,
            '/companies/(?P<id>\d+)',
            array(
                'methods'             => array( 'GET', 'PUT' ),
                'callback'            => array( $this, 'handle_company_detail' ),
                'permission_callback' => array( $this, 'check_auth' ),
            )
        );

        // PUT /companies/{id}/profile - Update company profile
        register_rest_route(
            $this->namespace,
            '/companies/(?P<id>\d+)/profile',
            array(
                'methods'             => 'PUT',
                'callback'            => array( $this, 'update_company_profile' ),
                'permission_callback' => array( $this, 'check_auth' ),
            )
        );

        // ====================================================================
        // TICKET ENDPOINTS
        // ====================================================================

        // GET/POST /tickets - List/create tickets
        register_rest_route(
            $this->namespace,
            '/tickets',
            array(
                'methods'             => array( 'GET', 'POST' ),
                'callback'            => array( $this, 'handle_tickets' ),
                'permission_callback' => array( $this, 'check_auth' ),
            )
        );
        
        register_rest_route(
            $this->namespace,
            '/tickets/(?P<id>\d+)',
            [
                'methods' => ['GET', 'PUT'],
                'callback' => [$this, 'handle_ticket_detail'],
                'permission_callback' => [$this, 'check_auth'],
            ]
        );
        
        // Service Records endpoints
        register_rest_route(
            $this->namespace,
            '/services',
            [
                'methods' => ['GET', 'POST'],
                'callback' => [$this, 'handle_services'],
                'permission_callback' => [$this, 'check_auth'],
            ]
        );
        
        register_rest_route(
            $this->namespace,
            '/services/(?P<id>\d+)',
            [
                'methods' => ['GET', 'PUT'],
                'callback' => [$this, 'handle_service_detail'],
                'permission_callback' => [$this, 'check_auth'],
            ]
        );

        // Training videos endpoint - GET
        register_rest_route(
            $this->namespace,
            '/videos',
            [
                'methods' => 'GET',
                'callback' => [$this, 'get_videos'],
                'permission_callback' => [$this, 'check_auth'],
            ]
        );
        
        // Training videos upload endpoint - POST
        register_rest_route(
            $this->namespace,
            '/videos/upload',
            [
                'methods' => 'POST',
                'callback' => [$this, 'upload_video'],
                'permission_callback' => [$this, 'check_staff'],
                'args' => [
                    'title' => ['required' => true, 'type' => 'string'],
                    'description' => ['type' => 'string'],
                    'duration' => ['type' => 'string'],
                    'thumbnail_url' => ['type' => 'string'],
                ]
            ]
        );
        
        // Video update endpoint - PUT
        register_rest_route(
            $this->namespace,
            '/videos/(?P<id>\d+)',
            [
                'methods' => 'PUT',
                'callback' => [$this, 'update_video'],
                'permission_callback' => [$this, 'check_staff'],
                'args' => [
                    'title' => ['type' => 'string'],
                    'description' => ['type' => 'string'],
                    'duration' => ['type' => 'string'],
                    'thumbnail_url' => ['type' => 'string'],
                ]
            ]
        );
        
        // Video delete endpoint - DELETE
        register_rest_route(
            $this->namespace,
            '/videos/(?P<id>\d+)',
            [
                'methods' => 'DELETE',
                'callback' => [$this, 'delete_video'],
                'permission_callback' => [$this, 'check_staff'],
                'args' => [
                    'id' => ['required' => true, 'type' => 'integer'],
                ]
            ]
        );
        
        // Users endpoints
        register_rest_route(
            $this->namespace,
            '/users',
            [
                'methods' => 'GET',
                'callback' => [$this, 'get_users'],
                'permission_callback' => [$this, 'check_auth'],
            ]
        );
        
        // Create user endpoint
        register_rest_route(
            $this->namespace,
            '/users',
            [
                'methods' => 'POST',
                'callback' => [$this, 'create_user'],
                'permission_callback' => [$this, 'check_admin'],
                'args' => [
                    'username' => ['required' => true, 'type' => 'string'],
                    'email' => ['required' => true, 'type' => 'string'],
                    'first_name' => ['type' => 'string'],
                    'last_name' => ['type' => 'string'],
                    'role' => ['required' => true, 'type' => 'string'],
                    'company_id' => ['type' => 'integer'],
                    'password' => ['required' => true, 'type' => 'string'],
                ]
            ]
        );
        
        // Update user endpoint
        register_rest_route(
            $this->namespace,
            '/users/(?P<id>\d+)',
            [
                'methods' => 'PUT',
                'callback' => [$this, 'update_user'],
                'permission_callback' => [$this, 'check_admin'],
                'args' => [
                    'id' => ['required' => true, 'type' => 'integer'],
                    'email' => ['type' => 'string'],
                    'first_name' => ['type' => 'string'],
                    'last_name' => ['type' => 'string'],
                    'role' => ['type' => 'string'],
                    'status' => ['type' => 'string'],
                    'password' => ['type' => 'string'],
                ]
            ]
        );
        
        // Delete user endpoint
        register_rest_route(
            $this->namespace,
            '/users/(?P<id>\d+)',
            [
                'methods' => 'DELETE',
                'callback' => [$this, 'delete_user'],
                'permission_callback' => [$this, 'check_admin'],
                'args' => [
                    'id' => ['required' => true, 'type' => 'integer'],
                ]
            ]
        );
        
        // Stats endpoints
        register_rest_route(
            $this->namespace,
            '/stats',
            [
                'methods' => 'GET',
                'callback' => [$this, 'get_stats'],
                'permission_callback' => [$this, 'check_auth'],
            ]
        );
        
        // Activity endpoints
        register_rest_route(
            $this->namespace,
            '/activity',
            [
                'methods' => 'GET',
                'callback' => [$this, 'get_activity'],
                'permission_callback' => [$this, 'check_auth'],
            ]
        );
        
        // CSV Import endpoints (admin only)
        register_rest_route(
            $this->namespace,
            '/import/partners/csv',
            [
                'methods' => 'POST',
                'callback' => [$this, 'handle_csv_import'],
                'permission_callback' => [$this, 'check_admin'],
            ]
        );
        
        register_rest_route(
            $this->namespace,
            '/import/partners/template',
            [
                'methods' => 'GET',
                'callback' => [$this, 'download_csv_template'],
                'permission_callback' => [$this, 'check_admin'],
            ]
        );
        
        // Diagnostic endpoint (public - for debugging auth issues)
        register_rest_route(
            $this->namespace,
            '/debug/auth',
            [
                'methods' => 'GET',
                'callback' => [$this, 'debug_auth_status'],
                'permission_callback' => '__return_true',
            ]
        );
    }
    
    /**
     * Check authentication with comprehensive error handling
     * 
     * Features:
     * - Multiple auth methods (WordPress session, cookie fallback)
     * - Safe session handling
     * - Detailed error logging
     * - Role mapping
     * - Graceful degradation
     *
     * @param WP_REST_Request $request Optional request object
     * @return bool|WP_Error True if authenticated, error otherwise
     */
    public function check_auth($request = null) {
        try {
            // Start session safely if not already started
            if ( ! session_id() && ! headers_sent() ) {
                try {
                    session_start();
                } catch ( \Exception $e ) {
                    error_log( '[PSP API] Session start failed: ' . $e->getMessage() );
                    return new \WP_Error( 'session_error', 'Session initialization failed', array( 'status' => 500 ) );
                }
            }
            
            // First check: WordPress user logged in
            if ( is_user_logged_in() ) {
                try {
                    $wp_user = wp_get_current_user();
                    
                    // Validate user object
                    if ( ! ( $wp_user instanceof \WP_User ) || empty( $wp_user->ID ) ) {
                        error_log( '[PSP API] Invalid WordPress user object' );
                        return new \WP_Error( 'invalid_user', 'User object invalid', array( 'status' => 401 ) );
                    }

                    // Get company ID safely
                    $company_id = intval( get_user_meta( $wp_user->ID, 'psp_company_id', true ) ) 
                        ?: intval( get_user_meta( $wp_user->ID, 'psp_partner_id', true ) );

                    // Map WordPress roles to portal roles
                    $wp_roles = is_array( $wp_user->roles ) ? $wp_user->roles : array();
                    $is_admin = in_array( 'administrator', $wp_roles, true ) || current_user_can( 'manage_options' );
                    $is_support = in_array( 'pool_safe_support', $wp_roles, true ) || in_array( 'psp_support', $wp_roles, true );
                    
                    $portal_role = $is_admin ? 'admin' : ( $is_support ? 'staff' : 'partner' );

                    // Set session data
                    $_SESSION['psp_user'] = array(
                        'id'         => $wp_user->ID,
                        'username'   => $wp_user->user_login,
                        'email'      => $wp_user->user_email,
                        'first_name' => ! empty( $wp_user->first_name ) ? $wp_user->first_name : $wp_user->display_name,
                        'role'       => $portal_role,
                        'company_id' => $company_id,
                    );

                    error_log( '[PSP API] Authentication successful via WordPress user: ' . $wp_user->user_login );
                    return true;

                } catch ( \Exception $e ) {
                    error_log( '[PSP API] WordPress auth check failed: ' . $e->getMessage() );
                    return new \WP_Error( 'wp_auth_error', 'WordPress authentication error', array( 'status' => 500 ) );
                }
            }
            
            // Second check: Check if already authenticated in session
            if ( ! empty( $_SESSION['psp_user'] ) && is_array( $_SESSION['psp_user'] ) ) {
                error_log( '[PSP API] Authentication via session' );
                return true;
            }
            
            // Third check: PSP user cookie as fallback
            if ( ! empty( $_COOKIE['psp_user_id'] ) ) {
                try {
                    global $wpdb;
                    $user_id = intval( $_COOKIE['psp_user_id'] );

                    // Validate user ID
                    if ( $user_id <= 0 ) {
                        error_log( '[PSP API] Invalid user ID from cookie: ' . $user_id );
                        return new \WP_Error( 'invalid_user_id', 'Invalid user ID', array( 'status' => 401 ) );
                    }

                    // Check user table exists
                    $table_name = $wpdb->prefix . 'psp_users';
                    if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table_name ) ) !== $table_name ) {
                        error_log( '[PSP API] PSP users table not found' );
                        return new \WP_Error( 'db_error', 'Database error', array( 'status' => 500 ) );
                    }

                    $user = $wpdb->get_row( $wpdb->prepare(
                        "SELECT * FROM {$wpdb->prefix}psp_users WHERE id = %d AND status = 'active'",
                        $user_id
                    ) );
                    
                    if ( ! $user ) {
                        error_log( '[PSP API] User not found or inactive: ' . $user_id );
                        return new \WP_Error( 'user_not_found', 'User not found', array( 'status' => 401 ) );
                    }

                    // Restore session from cookie safely
                    $_SESSION['psp_user'] = array(
                        'id'         => intval( $user->id ),
                        'username'   => sanitize_text_field( $user->username ),
                        'email'      => sanitize_email( $user->email ),
                        'first_name' => sanitize_text_field( $user->first_name ),
                        'role'       => sanitize_text_field( $user->role ),
                        'company_id' => intval( $user->company_id ),
                    );
                    
                    error_log( '[PSP API] Authentication successful via cookie for user: ' . $user_id );
                    return true;

                } catch ( \Exception $e ) {
                    error_log( '[PSP API] Cookie authentication failed: ' . $e->getMessage() );
                    return new \WP_Error( 'cookie_auth_error', 'Cookie authentication error', array( 'status' => 500 ) );
                }
            }
            
            // All authentication methods failed
            error_log( '[PSP API] Authentication DENIED - no valid auth method found' );
            return new \WP_Error( 'unauthorized', 'Authentication required', array( 'status' => 401 ) );

        } catch ( \Exception $e ) {
            error_log( '[PSP API] Check auth failed: ' . $e->getMessage() );
            return new \WP_Error( 'auth_error', 'Authentication check failed', array( 'status' => 500 ) );
        }
    }
    
    /**
     * Check if current user is admin
     */
    /**
     * Check if current user is admin with error handling
     * 
     * Features:
     * - Validates user object
     * - Safe role array access
     * - Error logging
     *
     * @param WP_REST_Request $request Optional request object
     * @return bool|WP_Error True if admin, error otherwise
     */
    public function check_admin($request = null) {
        try {
            if ( ! is_user_logged_in() ) {
                error_log( '[PSP API] Admin check: user not logged in' );
                return new \WP_Error( 'unauthorized', 'Admin access required', array( 'status' => 401 ) );
            }
            
            $user = wp_get_current_user();
            
            // Validate user object
            if ( ! ( $user instanceof \WP_User ) || empty( $user->ID ) ) {
                error_log( '[PSP API] Admin check: invalid user object' );
                return new \WP_Error( 'invalid_user', 'Invalid user', array( 'status' => 401 ) );
            }

            $user_roles = is_array( $user->roles ) ? $user->roles : array();
            $is_admin = in_array( 'administrator', $user_roles, true ) || current_user_can( 'manage_options' );
            
            if ( ! $is_admin ) {
                error_log( '[PSP API] Admin check: user does not have admin role - ' . $user->user_login );
                return new \WP_Error( 'forbidden', 'Admin access required', array( 'status' => 403 ) );
            }

            return true;

        } catch ( \Exception $e ) {
            error_log( '[PSP API] Admin check failed: ' . $e->getMessage() );
            return new \WP_Error( 'admin_check_error', 'Admin check failed', array( 'status' => 500 ) );
        }
    }

    /**
     * Check if current user is staff/support with error handling
     * 
     * Features:
     * - Validates user object
     * - Safe role array access
     * - Error logging
     * - Admin bypass
     *
     * @param WP_REST_Request $request Optional request object
     * @return bool|WP_Error True if staff, error otherwise
     */
    public function check_staff($request = null) {
        try {
            if ( ! is_user_logged_in() ) {
                error_log( '[PSP API] Staff check: user not logged in' );
                return new \WP_Error( 'unauthorized', 'Staff access required', array( 'status' => 401 ) );
            }
            
            $user = wp_get_current_user();
            
            // Validate user object
            if ( ! ( $user instanceof \WP_User ) || empty( $user->ID ) ) {
                error_log( '[PSP API] Staff check: invalid user object' );
                return new \WP_Error( 'invalid_user', 'Invalid user', array( 'status' => 401 ) );
            }

            $user_roles = is_array( $user->roles ) ? $user->roles : array();
            $is_admin = in_array( 'administrator', $user_roles, true ) || current_user_can( 'manage_options' );
            $is_staff = in_array( 'pool_safe_support', $user_roles, true ) || in_array( 'psp_support', $user_roles, true );
            
            if ( ! ( $is_admin || $is_staff ) ) {
                error_log( '[PSP API] Staff check: user does not have staff role - ' . $user->user_login );
                return new \WP_Error( 'forbidden', 'Staff access required', array( 'status' => 403 ) );
            }

            return true;

        } catch ( \Exception $e ) {
            error_log( '[PSP API] Staff check failed: ' . $e->getMessage() );
            return new \WP_Error( 'staff_check_error', 'Staff check failed', array( 'status' => 500 ) );
        }
    }
    
    /**
     * Handle CSV Partner Import
     */
    public function handle_csv_import($request) {
        // Verify nonce for mutation operation
        $nonce_check = $this->verify_rest_nonce($request);
        if (is_wp_error($nonce_check)) {
            return $nonce_check;
        }
        
        // Check admin permission
        if (!current_user_can('manage_options')) {
            return new \WP_REST_Response(
                ['error' => 'You do not have permission to import partners'],
                403
            );
        }

        // Ensure partner tables exist to avoid missing-table errors on fresh installs
        if (class_exists('PSP_Activator')) {
            \PSP_Activator::ensure_partner_tables();
        }

        // Get file from request
        $params = $request->get_json_params();
        if (empty($params['csv_data'])) {
            return new \WP_REST_Response(
                ['error' => 'No CSV data provided'],
                400
            );
        }

        // Save temporary file
        $temp_file = wp_tempnam('psp_import_');
        if (!file_put_contents($temp_file, $params['csv_data'])) {
            return new \WP_REST_Response(
                ['error' => 'Failed to save CSV file'],
                500
            );
        }

        try {
            // Import using new CSV handler
            $importer = new \PSP\CSV_Partner_Import();
            $results = $importer->import_csv($temp_file);
            
            // Clean up temp file
            @unlink($temp_file);
            
            return new \WP_REST_Response($results, 200);
        } catch (\Exception $e) {
            @unlink($temp_file);
            return new \WP_REST_Response(
                ['error' => 'Import failed: ' . $e->getMessage()],
                500
            );
        }
    }

    /**
     * Download CSV Template
     */
    public function download_csv_template($request) {
        // Check admin permission
        if (!current_user_can('manage_options')) {
            return new \WP_REST_Response(
                ['error' => 'You do not have permission to download templates'],
                403
            );
        }

        // Generate template
        \PSP\CSV_Partner_Import::generate_template();
    }
    
    /**
     * Helper: Verify REST nonce for mutation operations
     * Returns WP_Error on failure, true on success
     */
    private function verify_rest_nonce($request) {
        $nonce = $request->get_header('X-WP-Nonce');
        
        if (!$nonce) {
            return new WP_Error(
                'rest_forbidden',
                'Missing security token. Please refresh the page and try again.',
                ['status' => 403]
            );
        }
        
        if (!wp_verify_nonce($nonce, 'wp_rest')) {
            return new WP_Error(
                'rest_forbidden',
                'Invalid security token. Please refresh the page and try again.',
                ['status' => 403]
            );
        }
        
        return true;
    }
    
    /**
     * Helper: Get current user's role (WordPress or PSP session)
     * Returns: 'administrator', 'pool_safe_support', 'pool_safe_partner', or null
     */
    private function get_current_user_role() {
        // WordPress user
        if (is_user_logged_in()) {
            $wp_user = wp_get_current_user();
            if (in_array('administrator', $wp_user->roles)) {
                return 'administrator';
            }
            if (in_array('pool_safe_support', $wp_user->roles) || in_array('psp_support', $wp_user->roles)) {
                return 'pool_safe_support';
            }
            if (in_array('pool_safe_partner', $wp_user->roles) || in_array('psp_partner', $wp_user->roles)) {
                return 'pool_safe_partner';
            }
        }
        
        // PSP session user (legacy)
        if (!empty($_SESSION['psp_user'])) {
            $role = $_SESSION['psp_user']['role'] ?? null;
            if ($role === 'admin' || $role === 'support' || $role === 'staff') {
                return 'pool_safe_support';
            }
            if ($role === 'partner') {
                return 'pool_safe_partner';
            }
        }
        
        return null;
    }
    
    /**
     * Helper: Get partner ID for pool_safe_partner role
     * Returns partner ID from user meta or null
     */
    private function get_partner_id_for_current_user() {
        // WordPress user
        if (is_user_logged_in()) {
            $wp_user = wp_get_current_user();
            $partner_id = get_user_meta($wp_user->ID, 'psp_partner_id', true);
            if ($partner_id) {
                return intval($partner_id);
            }
        }
        
        // PSP session user (legacy)
        if (!empty($_SESSION['psp_user']['company_id'])) {
            return intval($_SESSION['psp_user']['company_id']);
        }
        
        return null;
    }
    
    /**
     * Handle user login (both Partner and Support)
     */
    /**
     * Handle user login with comprehensive error handling
     * 
     * Features:
     * - Safe JSON parameter parsing
     * - Rate limiting enforcement
     * - Input validation
     * - User type routing
     * - Error logging
     *
     * @param WP_REST_Request $request Request object
     * @return WP_REST_Response|WP_Error Login response or error
     */
    public function handle_login($request) {
        try {
            // Safe parameter parsing
            $data = array();
            try {
                $json_data = $request->get_json_params();
                if ( is_array( $json_data ) ) {
                    $data = $json_data;
                }
            } catch ( \Exception $e ) {
                error_log( '[PSP API] Login: JSON parsing failed: ' . $e->getMessage() );
                return new \WP_Error( 'invalid_json', 'Invalid JSON', array( 'status' => 400 ) );
            }

            // Extract and validate user type
            $user_type = isset( $data['user_type'] ) ? sanitize_text_field( $data['user_type'] ) : 
                        ( isset( $data['login_type'] ) ? sanitize_text_field( $data['login_type'] ) : null );

            if ( empty( $user_type ) ) {
                error_log( '[PSP API] Login: user type not specified' );
                return new \WP_Error( 'invalid', 'User type not specified', array( 'status' => 400 ) );
            }

            // Enforce rate limiting
            if ( function_exists( 'enforce_rate_limit' ) ) {
                $rate_error = $this->enforce_rate_limit( 'login' );
                if ( is_wp_error( $rate_error ) ) {
                    error_log( '[PSP API] Login: rate limit exceeded' );
                    return $rate_error;
                }
            }
            
            // Route to appropriate login handler
            if ( 'partner' === $user_type ) {
                return $this->login_partner( $data );
            } elseif ( 'support' === $user_type ) {
                return $this->login_support( $data );
            }
            
            error_log( '[PSP API] Login: invalid user type - ' . $user_type );
            return new \WP_Error( 'invalid', 'Invalid user type', array( 'status' => 400 ) );

        } catch ( \Exception $e ) {
            error_log( '[PSP API] Login handling failed: ' . $e->getMessage() );
            return new \WP_Error( 'login_error', 'Login failed', array( 'status' => 500 ) );
        }
    }
    
    /**
     * Login partner user with comprehensive error handling
     * 
     * Features:
     * - Safe input validation
     * - Secure password verification
     * - Proper session management
     * - Secure cookie handling
     * - Error logging
     * - User status checking
     *
     * @param array $data Login data
     * @return WP_REST_Response|WP_Error Login response or error
     */
    private function login_partner($data) {
        try {
            global $wpdb;
            
            // Validate required fields
            $username = isset( $data['username'] ) ? sanitize_text_field( $data['username'] ) : '';
            $password = isset( $data['password'] ) ? $data['password'] : '';

            if ( empty( $username ) || empty( $password ) ) {
                error_log( '[PSP API] Partner login: missing credentials' );
                return new \WP_Error( 'invalid', 'Username and password required', array( 'status' => 400 ) );
            }

            // Validate inputs
            if ( strlen( $username ) < 2 || strlen( $username ) > 255 ) {
                error_log( '[PSP API] Partner login: invalid username length' );
                return new \WP_Error( 'invalid', 'Invalid username', array( 'status' => 400 ) );
            }

            if ( strlen( $password ) < 1 || strlen( $password ) > 255 ) {
                error_log( '[PSP API] Partner login: invalid password length' );
                return new \WP_Error( 'invalid', 'Invalid password', array( 'status' => 400 ) );
            }

            // Check user table exists
            $table_name = $wpdb->prefix . 'psp_users';
            if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table_name ) ) !== $table_name ) {
                error_log( '[PSP API] Partner login: psp_users table not found' );
                return new \WP_Error( 'db_error', 'Database error', array( 'status' => 500 ) );
            }

            // Query for partner user
            $user = $wpdb->get_row( $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}psp_users 
                 WHERE username = %s AND role = 'partner' AND status = 'active'",
                $username
            ) );
            
            if ( ! $user ) {
                error_log( '[PSP API] Partner login: user not found - ' . $username );
                return new \WP_Error( 'unauthorized', 'Invalid credentials', array( 'status' => 401 ) );
            }

            // Verify password
            if ( ! function_exists( 'wp_check_password' ) ) {
                error_log( '[PSP API] Partner login: wp_check_password not available' );
                return new \WP_Error( 'error', 'Password verification failed', array( 'status' => 500 ) );
            }

            if ( ! wp_check_password( $password, $user->password_hash ) ) {
                error_log( '[PSP API] Partner login: invalid password for ' . $username );
                return new \WP_Error( 'unauthorized', 'Invalid credentials', array( 'status' => 401 ) );
            }

            // Validate user object properties
            if ( empty( $user->id ) || empty( $user->email ) ) {
                error_log( '[PSP API] Partner login: invalid user data' );
                return new \WP_Error( 'error', 'User data invalid', array( 'status' => 500 ) );
            }

            // Create secure session
            $_SESSION['psp_user'] = array(
                'id'         => intval( $user->id ),
                'name'       => ! empty( $user->name ) ? sanitize_text_field( $user->name ) : '',
                'email'      => sanitize_email( $user->email ),
                'username'   => sanitize_text_field( $user->username ),
                'role'       => 'partner',
                'company_id' => intval( $user->company_id ),
                'status'     => 'active',
            );
            
            // Set secure cookie for REST API authentication
            if ( ! headers_sent() ) {
                try {
                    setcookie(
                        'psp_user_id',
                        intval( $user->id ),
                        array(
                            'expires'  => time() + ( 7 * 24 * 60 * 60 ),
                            'path'     => '/',
                            'secure'   => is_ssl(),
                            'httponly' => true,
                            'samesite' => 'Lax',
                        )
                    );
                } catch ( \Exception $e ) {
                    error_log( '[PSP API] Partner login: cookie setting failed: ' . $e->getMessage() );
                    // Continue despite cookie failure
                }
            }

            error_log( '[PSP API] Partner login successful: ' . $username );
            return rest_ensure_response( array(
                'success' => true,
                'message' => 'Logged in successfully',
                'user'    => $_SESSION['psp_user'],
            ) );

        } catch ( \Exception $e ) {
            error_log( '[PSP API] Partner login failed: ' . $e->getMessage() );
            return new \WP_Error( 'login_error', 'Login failed', array( 'status' => 500 ) );
        }
    }
    
    /**
     * Login support staff (email + password, Outlook integrated)
     */
    private function login_support($data) {
        global $wpdb;
        
        if (empty($data['email']) || empty($data['password'])) {
            return new WP_Error('invalid', 'Email and password required', ['status' => 400]);
        }
        
        $user = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}psp_users 
             WHERE email = %s AND role IN ('admin', 'staff') AND status = 'active'",
            $data['email']
        ));
        
        if (!$user || !wp_check_password($data['password'], $user->password_hash)) {
            return new WP_Error('unauthorized', 'Invalid credentials', ['status' => 401]);
        }
        
        // Create session
        $_SESSION['psp_user'] = [
            'id' => $user->id,
            'name' => $user->name,
            'email' => $user->email,
            'role' => $user->role,
            'company_id' => $user->company_id,
            'status' => $user->status,
        ];
        
        // Set cookie for REST API authentication
        if (!headers_sent()) {
            setcookie(
                'psp_user_id',
                $user->id,
                [
                    'expires'  => time() + (7 * 24 * 60 * 60),
                    'path'     => '/',
                    'secure'   => is_ssl(),
                    'httponly' => true,
                    'samesite' => 'Lax',
                ]
            );
        }
        
        return rest_ensure_response([
            'success' => true,
            'message' => 'Logged in successfully',
            'user' => $_SESSION['psp_user'],
        ]);
    }
    
    /**
     * Handle logout
     */
    public function handle_logout($request) {
        unset($_SESSION['psp_user']);
        
        return rest_ensure_response([
            'success' => true,
            'message' => 'Logged out successfully',
        ]);
    }

    /**
     * Health endpoint
     */
    /**
     * Get API health status with error handling
     * 
     * Features:
     * - Safe version retrieval
     * - Database status check
     * - Comprehensive status information
     * - Error logging
     *
     * @param WP_REST_Request $request Request object
     * @return WP_REST_Response Health status
     */
    public function health($request) {
        try {
            // Get current WordPress time safely
            $timestamp = '';
            try {
                $timestamp = current_time( 'mysql' );
            } catch ( \Exception $e ) {
                error_log( '[PSP API] Health: timestamp retrieval failed: ' . $e->getMessage() );
                $timestamp = gmdate( 'Y-m-d H:i:s' );
            }

            // Get versions safely
            $plugin_version = defined( 'PSP_VERSION' ) ? PSP_VERSION : '2.5.3';
            $wordpress_version = '';
            try {
                $wordpress_version = get_bloginfo( 'version' );
            } catch ( \Exception $e ) {
                error_log( '[PSP API] Health: WordPress version retrieval failed' );
                $wordpress_version = 'unknown';
            }

            $php_version = defined( 'PHP_VERSION' ) ? PHP_VERSION : 'unknown';

            // Check database status
            global $wpdb;
            $db_status = 'ok';
            try {
                $wpdb->query( "SELECT 1" );
            } catch ( \Exception $e ) {
                error_log( '[PSP API] Health: database check failed: ' . $e->getMessage() );
                $db_status = 'error';
            }

            $response = array(
                'status'            => $db_status === 'ok' ? 'ok' : 'error',
                'timestamp'         => $timestamp,
                'plugin_version'    => $plugin_version,
                'wordpress_version' => $wordpress_version,
                'php_version'       => $php_version,
                'database'          => $db_status,
            );

            return rest_ensure_response( $response );

        } catch ( \Exception $e ) {
            error_log( '[PSP API] Health check failed: ' . $e->getMessage() );
            return rest_ensure_response( array(
                'status'  => 'error',
                'message' => 'Health check failed',
            ), 500 );
        }
    }

    /**
     * Simple IP-based rate limit for sensitive endpoints
     */
    private function enforce_rate_limit($context, $limit = 10, $window = 10) {
        $ip = $this->get_client_ip();
        if (!$ip) {
            return null; // Cannot determine IP; skip limit
        }

        $key = 'psp_rl_' . $context . '_' . md5($ip);
        $attempts = (int) get_transient($key);
        $attempts++;

        if ($attempts > $limit) {
            return new WP_Error(
                'rate_limited',
                __('Too many attempts. Please wait a moment and try again.', 'psp'),
                ['status' => 429]
            );
        }

        set_transient($key, $attempts, $window * MINUTE_IN_SECONDS);
        return null;
    }

    private function get_client_ip() {
        $keys = ['HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR'];
        foreach ($keys as $key) {
            if (!empty($_SERVER[$key])) {
                $ipList = explode(',', $_SERVER[$key]);
                return trim($ipList[0]);
            }
        }
        return null;
    }
    
    /**
     * Get all companies
     * Role-based filtering:
     * - administrator: sees all partners
     * - pool_safe_support: sees all partners
     * - pool_safe_partner: sees only their own partner record
     */
    public function get_companies($request) {
        global $wpdb;
        
        $user_role = $this->get_current_user_role();
        if (!$user_role) {
            return new WP_Error('unauthorized', 'Not authenticated', ['status' => 401]);
        }
        
        // Build WHERE clause based on role
        $where = '';
        if ($user_role === 'pool_safe_partner') {
            $partner_id = $this->get_partner_id_for_current_user();
            if (!$partner_id) {
                return new WP_Error('forbidden', 'No partner record associated with user', ['status' => 403]);
            }
            $where = $wpdb->prepare('WHERE p.ID = %d', $partner_id);
        }
        // administrator and pool_safe_support see all partners (no WHERE clause)
        
        // Get partners from CPT with post meta for operational fields
        $partners_query = "SELECT p.ID as id,
                           p.post_title as company_name
                           FROM {$wpdb->posts} p
                           WHERE p.post_type = 'psp_partner' 
                           AND p.post_status = 'publish'
                           " . ($where ? str_replace('WHERE ', 'AND ', $where) : '') . "
                           ORDER BY p.post_title ASC";
        
        $partners = $wpdb->get_results($partners_query);
        
        // Enhance each partner with meta fields
        $user_role = $this->get_current_user_role();

        $companies = array_map(function($partner) use ($user_role) {
            $id = $partner->id;
            
            // Get all meta fields
            $meta = array(
                'companyName' => get_post_meta($id, 'psp_company_name', true) ?: $partner->company_name,
                'managementCompany' => get_post_meta($id, 'psp_management_company', true),
                'streetAddress' => get_post_meta($id, 'psp_street_address', true),
                'phone' => get_post_meta($id, 'psp_primary_contact_phone', true),
                'email' => get_post_meta($id, 'psp_primary_contact_email', true),
                'city' => get_post_meta($id, 'psp_city', true),
                'state' => get_post_meta($id, 'psp_state', true),
                'zip' => get_post_meta($id, 'psp_zip', true),
                'country' => get_post_meta($id, 'psp_country', true),
                'units' => get_post_meta($id, 'psp_units', true),
                'venueType' => get_post_meta($id, 'psp_venue_type', true),
                'top_colour' => get_post_meta($id, 'psp_top_colour', true),
                'lock_type' => get_post_meta($id, 'psp_lock_type', true),
                'master_code' => get_post_meta($id, 'psp_master_code', true),
                'sub_master_code' => get_post_meta($id, 'psp_sub_master_code', true),
                'lock_part' => get_post_meta($id, 'psp_lock_part', true),
                'key_code' => get_post_meta($id, 'psp_key', true),
                'gateway_username' => get_post_meta($id, 'psp_gateway_username', true),
                'gateway_password' => get_post_meta($id, 'psp_gateway_password', true),
                'facebook_call_button' => get_post_meta($id, 'psp_facebook_call_button', true),
                'latitude' => get_post_meta($id, 'psp_latitude', true),
                'longitude' => get_post_meta($id, 'psp_longitude', true),
                // Operational fields
                'installation_date' => get_post_meta($id, 'psp_installation_date', true),
                'operation_type' => get_post_meta($id, 'psp_operation_type', true),
                'seasonal_open_date' => get_post_meta($id, 'psp_seasonal_open_date', true),
                'seasonal_close_date' => get_post_meta($id, 'psp_seasonal_close_date', true),
                'is_active' => get_post_meta($id, 'psp_is_active', true),
                'last_update' => get_post_meta($id, 'psp_last_update', true),
                'service_type' => get_post_meta($id, 'psp_service_type', true),
                'next_scheduled_visit' => get_post_meta($id, 'psp_next_scheduled_visit', true),
                'assigned_staff' => get_post_meta($id, 'psp_assigned_staff', true),
                'status' => 'active', // Default status
                'created_at' => get_the_date('c', $id),
                'updated_at' => get_the_modified_date('c', $id),
            );
            
            // Hide sensitive lock fields for partner view
            if ($user_role === 'pool_safe_partner') {
                unset($meta['lock_type'], $meta['master_code'], $meta['sub_master_code'], $meta['lock_part'], $meta['key_code']);
            }

            return (object) array_merge(['id' => $id], $meta);
        }, $partners);
        
        return rest_ensure_response([
            'success' => true,
            'data' => $companies,
            'count' => count($companies),
            'user_role' => $user_role,
        ]);
    }
    
    /**
     * Handle company detail (GET / PUT)
     */
    public function handle_company_detail($request) {
        if ($request->get_method() === 'PUT') {
            return $this->update_company($request);
        }
        
        return $this->get_company($request);
    }
    
    /**
     * Get single company
     * Role-based access:
     * - administrator & pool_safe_support: can view any partner
     * - pool_safe_partner: can only view their own partner record
     */
    public function get_company($request) {
        global $wpdb;
        
        $user_role = $this->get_current_user_role();
        if (!$user_role) {
            return new WP_Error('unauthorized', 'Not authenticated', ['status' => 401]);
        }
        
        $id = intval($request['id']);
        
        // Check permissions
        if ($user_role === 'pool_safe_partner') {
            $partner_id = $this->get_partner_id_for_current_user();
            if ($partner_id !== $id) {
                return new WP_Error('forbidden', 'Access denied', ['status' => 403]);
            }
        }
        
        $company = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}psp_partners WHERE id = %d",
            $id
        ));
        
        if (!$company) {
            return new WP_Error('not_found', 'Company not found', ['status' => 404]);
        }
        
        return rest_ensure_response([
            'success' => true,
            'data' => $company,
        ]);
    }
    
    /**
     * Update company profile
     * Role-based access:
     * - administrator & pool_safe_support: can update any partner
     * - pool_safe_partner: read-only, cannot update
     */
    public function update_company($request) {
        global $wpdb;
        
        // Verify nonce for mutation operation
        $nonce_check = $this->verify_rest_nonce($request);
        if (is_wp_error($nonce_check)) {
            return $nonce_check;
        }
        
        $user_role = $this->get_current_user_role();
        if (!$user_role) {
            return new WP_Error('unauthorized', 'Not authenticated', ['status' => 401]);
        }
        
        $company_id = intval($request['id']);
        $data = $request->get_json_params();
        
        // Check permissions - only administrator and pool_safe_support can update
        if ($user_role === 'pool_safe_partner') {
            return new WP_Error('forbidden', 'Partners have read-only access', ['status' => 403]);
        }
        
        $company = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}psp_partners WHERE id = %d",
            $company_id
        ));
        
        if (!$company) {
            return new WP_Error('not_found', 'Company not found', ['status' => 404]);
        }
        
        // Validate company data using Input_Validation class
        if (class_exists('\PSP\Input_Validation')) {
            $validation = \PSP\Input_Validation::validate_company_form($data);
            
            if (!$validation['valid']) {
                return rest_ensure_response([
                    'success' => false,
                    'message' => 'Validation failed',
                    'errors' => $validation['errors'],
                ], 400);
            }
            
            $update_data = $validation['data'];
        } else {
            // Fallback validation if class not available
            $update_data = [];
            
            if (isset($data['company_name'])) {
                $update_data['company_name'] = sanitize_text_field($data['company_name']);
            }
            if (isset($data['company_email'])) {
                $update_data['company_email'] = sanitize_email($data['company_email']);
            }
            if (isset($data['phone'])) {
                $update_data['phone'] = sanitize_text_field($data['phone']);
            }
            if (isset($data['street_address'])) {
                $update_data['street_address'] = sanitize_text_field($data['street_address']);
            }
            if (isset($data['city'])) {
                $update_data['city'] = sanitize_text_field($data['city']);
            }
            if (isset($data['state'])) {
                $update_data['state'] = sanitize_text_field($data['state']);
            }
            if (isset($data['zip'])) {
                $update_data['zip'] = sanitize_text_field($data['zip']);
            }
            if (isset($data['country'])) {
                $update_data['country'] = sanitize_text_field($data['country']);
            }
            if (isset($data['top_colour'])) {
                $update_data['top_colour'] = sanitize_text_field($data['top_colour']);
            }
            if (isset($data['lock_type'])) {
                $update_data['lock_type'] = sanitize_text_field($data['lock_type']);
            }
            foreach (['master_code','sub_master_code','lock_part','key_code'] as $k) {
                if (isset($data[$k])) {
                    $update_data[$k] = sanitize_text_field($data[$k]);
                }
            }
            if (isset($data['management_company'])) {
                $update_data['management_company'] = sanitize_text_field($data['management_company']);
            }
            if (isset($data['units'])) {
                $update_data['units'] = intval($data['units']);
            }
        }
        
        if (empty($update_data)) {
            return new WP_Error('invalid', 'No fields to update', ['status' => 400]);
        }
        
        // Map validation keys to DB columns
        $mapped_update = [];
        $field_map = [
            'company_name'       => 'company_name',
            'company_email'      => 'email',
            'phone'              => 'phone',
            'street_address'     => 'street_address',
            'city'               => 'city',
            'state'              => 'state',
            'zip'                => 'zip',
            'country'            => 'country',
            'management_company' => 'management_company',
            'units'              => 'units',
            'top_colour'         => 'pool_colour',
            'lock_type'          => 'lock_type',
            'master_code'        => 'master_code',
            'sub_master_code'    => 'sub_master_code',
            'lock_part'          => 'lock_part',
            'key_code'           => 'key_code',
        ];

        foreach ($update_data as $key => $value) {
            if (isset($field_map[$key])) {
                $mapped_update[$field_map[$key]] = $value;
            }
        }

        if (empty($mapped_update)) {
            return new WP_Error('invalid', 'No fields to update', ['status' => 400]);
        }

        // Perform update
        $result = $wpdb->update(
            "{$wpdb->prefix}psp_partners",
            $mapped_update,
            ['id' => $company_id]
        );
        
        if ($result === false) {
            return new WP_Error('db_error', 'Failed to update company', ['status' => 500]);
        }
        
        // Log activity
        $this->log_activity(
            'company_updated',
            "Company profile updated",
            $user['id'],
            $company_id
        );
        
        return rest_ensure_response([
            'success' => true,
            'message' => 'Company profile updated successfully',
            'data' => array_merge((array)$company, $mapped_update),
        ]);
    }
    
    /**
     * Update company profile (alternate endpoint)
     */
    public function update_company_profile($request) {
        return $this->update_company($request);
    }
    
    /**
     * Handle tickets (GET list / POST create)
     */
    public function handle_tickets($request) {
        if ($request->get_method() === 'POST') {
            return $this->create_ticket($request);
        }
        
        return $this->get_tickets($request);
    }
    
    /**
     * Get tickets list
     */
    public function get_tickets($request) {
        global $wpdb;
        
        $user = $_SESSION['psp_user'] ?? null;
        if (!$user) {
            return new WP_Error('unauthorized', 'Not authenticated', ['status' => 401]);
        }
        
        // Get parameters
        $page = intval($request->get_param('page')) ?: 1;
        $per_page = intval($request->get_param('per_page')) ?: 20;
        $offset = ($page - 1) * $per_page;
        
        // Non-admins can only see their company's tickets (staff/support are treated as admin for visibility)
        $is_staff = in_array($user['role'], ['admin', 'staff'], true);
        
        if ($is_staff) {
            $tickets = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT id, title AS subject, status, priority, created_at, updated_at, ticket_number 
                     FROM {$wpdb->prefix}psp_tickets 
                     WHERE 1=1
                     ORDER BY created_at DESC 
                     LIMIT %d OFFSET %d",
                    $per_page,
                    $offset
                )
            );
            $total = $wpdb->get_var(
                "SELECT COUNT(*) FROM {$wpdb->prefix}psp_tickets WHERE 1=1"
            );
        } else {
            $company_id = isset($user['company_id']) ? intval($user['company_id']) : 0;
            $tickets = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT id, title AS subject, status, priority, created_at, updated_at, ticket_number 
                     FROM {$wpdb->prefix}psp_tickets 
                     WHERE partner_id = %d
                     ORDER BY created_at DESC 
                     LIMIT %d OFFSET %d",
                    $company_id,
                    $per_page,
                    $offset
                )
            );
            $total = $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*) FROM {$wpdb->prefix}psp_tickets WHERE partner_id = %d",
                    $company_id
                )
            );
        }
        
        return rest_ensure_response([
            'success' => true,
            'data' => $tickets,
            'pagination' => [
                'page' => $page,
                'per_page' => $per_page,
                'total' => intval($total),
                'pages' => ceil($total / $per_page),
            ],
        ]);
    }
    
    /**
     * Create new ticket
     */
    public function create_ticket($request) {
        global $wpdb;
        
        $user = $_SESSION['psp_user'] ?? null;
        if (!$user) {
            return new WP_Error('unauthorized', 'Not authenticated', ['status' => 401]);
        }
        
        $data = $request->get_json_params();
        
        // Prepare validation data - normalize field names if needed
        $validation_data = [
            'title' => $data['title'] ?? $data['subject'] ?? '',
            'description' => $data['description'] ?? '',
            'priority' => $data['priority'] ?? '',
            'category' => $data['category'] ?? '',
        ];
        
        // Validate ticket data using Input_Validation class
        if (class_exists('\PSP\Input_Validation')) {
            $validation = \PSP\Input_Validation::validate_ticket_form($validation_data);
            
            if (!$validation['valid']) {
                return rest_ensure_response([
                    'success' => false,
                    'message' => 'Validation failed',
                    'errors' => $validation['errors'],
                ], 400);
            }
            
            $cleaned_data = $validation['data'];
        } else {
            // Fallback validation if class not available
            if (empty($validation_data['title']) || empty($validation_data['description'])) {
                return rest_ensure_response([
                    'success' => false,
                    'message' => 'Validation failed',
                    'errors' => [
                        'title' => empty($validation_data['title']) ? 'Title is required' : '',
                        'description' => empty($validation_data['description']) ? 'Description is required' : '',
                    ],
                ], 400);
            }
            
            $cleaned_data = [
                'title' => sanitize_text_field($validation_data['title']),
                'description' => wp_kses_post($validation_data['description']),
                'priority' => sanitize_text_field($validation_data['priority'] ?: 'medium'),
                'category' => sanitize_text_field($validation_data['category'] ?? ''),
            ];
        }
        
        // Insert ticket
        // Generate a simple ticket number
        $ticket_number = 'TKT-' . strtoupper(wp_generate_password(8, false, false));

        $result = $wpdb->insert(
            "{$wpdb->prefix}psp_tickets",
            [
                'partner_id' => $user['company_id'],
                'created_by_user_id' => $user['id'],
                'ticket_number' => $ticket_number,
                'title' => $cleaned_data['title'],
                'description' => $cleaned_data['description'],
                'status' => 'open',
                'priority' => $cleaned_data['priority'] ?? 'medium',
                'category' => $cleaned_data['category'] ?? '',
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql'),
            ]
        );
        
        if (!$result) {
            return new WP_Error('db_error', 'Failed to create ticket', ['status' => 500]);
        }
        
        return rest_ensure_response([
            'success' => true,
            'message' => 'Ticket created successfully',
            'ticket_id' => $wpdb->insert_id,
        ], 201);
    }
    
    /**
     * Handle ticket detail (GET / PUT)
     */
    public function handle_ticket_detail($request) {
        if ($request->get_method() === 'PUT') {
            return $this->update_ticket($request);
        }
        
        return $this->get_ticket($request);
    }
    
    /**
     * Get single ticket
     */
    public function get_ticket($request) {
        global $wpdb;
        
        $user = $_SESSION['psp_user'] ?? null;
        if (!$user) {
            return new WP_Error('unauthorized', 'Not authenticated', ['status' => 401]);
        }
        
        $id = $request['id'];
        
        $ticket = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}psp_tickets WHERE id = %d",
            $id
        ));
        
        if (!$ticket) {
            return new WP_Error('not_found', 'Ticket not found', ['status' => 404]);
        }
        
        // Check permissions
        if ($user['role'] !== 'admin' && $ticket->partner_id !== $user['company_id']) {
            return new WP_Error('forbidden', 'Access denied', ['status' => 403]);
        }
        
        // Get replies
        $replies = $wpdb->get_results($wpdb->prepare(
            "SELECT id, user_id, message, created_at FROM {$wpdb->prefix}psp_ticket_replies 
             WHERE ticket_id = %d ORDER BY created_at ASC",
            $id
        ));
        
        return rest_ensure_response([
            'success' => true,
            'data' => array_merge((array)$ticket, ['replies' => $replies]),
        ]);
    }
    
    /**
     * Update ticket
     */
    public function update_ticket($request) {
        global $wpdb;
        
        $user = $_SESSION['psp_user'] ?? null;
        if (!$user) {
            return new WP_Error('unauthorized', 'Not authenticated', ['status' => 401]);
        }
        
        $id = $request['id'];
        $data = $request->get_json_params();
        
        $ticket = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}psp_tickets WHERE id = %d",
            $id
        ));
        
        if (!$ticket) {
            return new WP_Error('not_found', 'Ticket not found', ['status' => 404]);
        }
        
        // Check permissions
        if ($user['role'] !== 'admin' && $ticket->partner_id !== $user['company_id']) {
            return new WP_Error('forbidden', 'Access denied', ['status' => 403]);
        }
        
        // Update fields with validation
        $update_data = [];
        $validation_errors = [];
        
        if (isset($data['status'])) {
            $status = sanitize_text_field($data['status']);
            $allowed_statuses = ['open', 'in-progress', 'resolved', 'closed'];
            if (in_array($status, $allowed_statuses, true)) {
                $update_data['status'] = $status;
            } else {
                $validation_errors['status'] = 'Invalid status value';
            }
        }
        
        if (isset($data['priority'])) {
            $priority = sanitize_text_field($data['priority']);
            if (class_exists('\PSP\Input_Validation')) {
                // Use validation class priorities
                $temp_validation = \PSP\Input_Validation::validate_ticket_form(['priority' => $priority]);
                if (!empty($temp_validation['errors']['priority'])) {
                    $validation_errors['priority'] = $temp_validation['errors']['priority'];
                } else {
                    $update_data['priority'] = $priority;
                }
            } else {
                $allowed_priorities = ['low', 'medium', 'high', 'urgent'];
                if (in_array($priority, $allowed_priorities, true)) {
                    $update_data['priority'] = $priority;
                } else {
                    $validation_errors['priority'] = 'Invalid priority value';
                }
            }
        }
        
        if (isset($data['description'])) {
            $description = wp_kses_post($data['description']);
            if (strlen($description) > 5000) {
                $validation_errors['description'] = 'Description too long (max 5000 characters)';
            } else if (strlen($description) > 0) {
                $update_data['description'] = $description;
            }
        }
        
        // Return validation errors if any
        if (!empty($validation_errors)) {
            return rest_ensure_response([
                'success' => false,
                'message' => 'Validation failed',
                'errors' => $validation_errors,
            ], 400);
        }
        
        if (!empty($update_data)) {
            $update_data['updated_at'] = current_time('mysql');
            $wpdb->update("{$wpdb->prefix}psp_tickets", $update_data, ['id' => $id]);
        }
        
        return rest_ensure_response([
            'success' => true,
            'message' => 'Ticket updated successfully',
        ]);
    }
    
    /**
     * Handle services (GET list / POST create)
     */
    public function handle_services($request) {
        if ($request->get_method() === 'POST') {
            return $this->create_service($request);
        }
        
        return $this->get_services($request);
    }
    
    /**
     * Get services list
     */
    public function get_services($request) {
        global $wpdb;
        
        $user = $_SESSION['psp_user'] ?? null;
        if (!$user) {
            return new WP_Error('unauthorized', 'Not authenticated', ['status' => 401]);
        }
        
        $page = intval($request->get_param('page')) ?: 1;
        $per_page = intval($request->get_param('per_page')) ?: 20;
        $offset = ($page - 1) * $per_page;
        
        $is_staff = in_array($user['role'], ['admin', 'staff'], true);
        
        if ($is_staff) {
            $services = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT id, description, service_date, service_type, status, notes, created_at 
                     FROM {$wpdb->prefix}psp_service_records 
                     WHERE 1=1
                     ORDER BY service_date DESC 
                     LIMIT %d OFFSET %d",
                    $per_page,
                    $offset
                )
            );
            $total = $wpdb->get_var(
                "SELECT COUNT(*) FROM {$wpdb->prefix}psp_service_records WHERE 1=1"
            );
        } else {
            $company_id = isset($user['company_id']) ? intval($user['company_id']) : 0;
            $services = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT id, description, service_date, service_type, status, notes, created_at 
                     FROM {$wpdb->prefix}psp_service_records 
                     WHERE partner_id = %d
                     ORDER BY service_date DESC 
                     LIMIT %d OFFSET %d",
                    $company_id,
                    $per_page,
                    $offset
                )
            );
            $total = $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*) FROM {$wpdb->prefix}psp_service_records WHERE partner_id = %d",
                    $company_id
                )
            );
        }
        
        return rest_ensure_response([
            'success' => true,
            'data' => $services,
            'pagination' => [
                'page' => $page,
                'per_page' => $per_page,
                'total' => intval($total),
                'pages' => ceil($total / $per_page),
            ],
        ]);
    }
    
    /**
     * Create new service record
     */
    public function create_service($request) {
        global $wpdb;
        
        $user = $_SESSION['psp_user'] ?? null;
        if (!$user) {
            return new WP_Error('unauthorized', 'Not authenticated', ['status' => 401]);
        }
        
        // Only staff can create service records
        if (!in_array($user['role'], ['admin', 'staff'])) {
            return new WP_Error('forbidden', 'Access denied', ['status' => 403]);
        }
        
        $data = $request->get_json_params();
        
        if (empty($data['description']) || empty($data['service_date'])) {
            return new WP_Error('invalid', 'Missing required fields', ['status' => 400]);
        }
        
        $result = $wpdb->insert(
            "{$wpdb->prefix}psp_service_records",
            [
                'partner_id' => $user['company_id'],
                'technician_id' => $user['id'],
                'description' => sanitize_text_field($data['description']),
                'service_date' => sanitize_text_field($data['service_date']),
                'service_type' => isset($data['service_type']) ? sanitize_text_field($data['service_type']) : '',
                'status' => isset($data['status']) ? sanitize_text_field($data['status']) : 'scheduled',
                'notes' => isset($data['notes']) ? wp_kses_post($data['notes']) : '',
                'created_at' => current_time('mysql'),
            ]
        );
        
        if (!$result) {
            return new WP_Error('db_error', 'Failed to create service record', ['status' => 500]);
        }
        
        return rest_ensure_response([
            'success' => true,
            'message' => 'Service record created successfully',
            'service_id' => $wpdb->insert_id,
        ], 201);
    }
    
    /**
     * Handle service detail (GET / PUT)
     */
    public function handle_service_detail($request) {
        if ($request->get_method() === 'PUT') {
            return $this->update_service($request);
        }
        
        return $this->get_service($request);
    }
    
    /**
     * Get single service
     */
    public function get_service($request) {
        global $wpdb;
        
        $user = $_SESSION['psp_user'] ?? null;
        if (!$user) {
            return new WP_Error('unauthorized', 'Not authenticated', ['status' => 401]);
        }
        
        $id = $request['id'];
        
        $service = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}psp_service_records WHERE id = %d",
            $id
        ));
        
        if (!$service) {
            return new WP_Error('not_found', 'Service not found', ['status' => 404]);
        }
        
        if ($user['role'] !== 'admin' && $service->partner_id !== $user['company_id']) {
            return new WP_Error('forbidden', 'Access denied', ['status' => 403]);
        }
        
        return rest_ensure_response([
            'success' => true,
            'data' => $service,
        ]);
    }
    
    /**
     * Update service
     */
    public function update_service($request) {
        global $wpdb;
        
        $user = $_SESSION['psp_user'] ?? null;
        if (!$user || !in_array($user['role'], ['admin', 'staff'])) {
            return new WP_Error('forbidden', 'Access denied', ['status' => 403]);
        }
        
        $id = $request['id'];
        $data = $request->get_json_params();
        
        $service = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}psp_service_records WHERE id = %d",
            $id
        ));
        
        if (!$service) {
            return new WP_Error('not_found', 'Service not found', ['status' => 404]);
        }
        
        if ($user['role'] !== 'admin' && $service->partner_id !== $user['company_id']) {
            return new WP_Error('forbidden', 'Access denied', ['status' => 403]);
        }
        
        $update_data = [];
        if (isset($data['description'])) {
            $update_data['description'] = sanitize_text_field($data['description']);
        }
        if (isset($data['service_date'])) {
            $update_data['service_date'] = sanitize_text_field($data['service_date']);
        }
        // cost column not present in current schema; skip
        if (isset($data['notes'])) {
            $update_data['notes'] = wp_kses_post($data['notes']);
        }
        
        if (!empty($update_data)) {
            $wpdb->update("{$wpdb->prefix}psp_service_records", $update_data, ['id' => $id]);
        }
        
        return rest_ensure_response([
            'success' => true,
            'message' => 'Service record updated successfully',
        ]);
    }
    
    /**
     * List training videos scoped by visibility (basic: all published)
     */
    public function get_videos($request) {
        $user_role = $this->get_current_user_role();
        if (!$user_role) {
            return new \WP_Error('unauthorized', 'Not authenticated', ['status' => 401]);
        }

        $query = new \WP_Query([
            'post_type'      => 'psp_training_video',
            'post_status'    => 'publish',
            'posts_per_page' => 50,
            'orderby'        => 'date',
            'order'          => 'DESC',
            'no_found_rows'  => true,
        ]);

        $videos = [];
        foreach ($query->posts as $post) {
            $videos[] = [
                'id'          => $post->ID,
                'title'       => get_the_title($post),
                'description' => apply_filters('the_excerpt', $post->post_excerpt ?: wp_trim_words($post->post_content, 30)),
                'url'         => get_post_meta($post->ID, \PSP\Training_Videos::META_VIDEO_URL, true),
                'thumbnail'   => get_post_meta($post->ID, \PSP\Training_Videos::META_THUMBNAIL_URL, true),
                'duration'    => get_post_meta($post->ID, \PSP\Training_Videos::META_DURATION, true),
                'uploaded_at' => get_post_meta($post->ID, \PSP\Training_Videos::META_UPLOAD_DATE, true) ?: get_the_date('c', $post),
            ];
        }

        return rest_ensure_response([
            'videos' => $videos,
            'count'  => count($videos),
        ]);
    }

    /**
     * Upload training video
     */
    public function upload_video($request) {
        // Get user role - staff and admins can upload
        $user_role = $this->get_current_user_role();
        if (!in_array($user_role, ['admin', 'staff'], true)) {
            return new \WP_Error('forbidden', 'Only admins and staff can upload videos', ['status' => 403]);
        }

        // Get file from request
        $file_param = $request->get_file_params();
        if (empty($file_param['video'])) {
            return new \WP_Error('no_file', 'No video file provided', ['status' => 400]);
        }

        $file = $file_param['video'];
        
        // Validate file type
        $allowed_types = ['video/mp4', 'video/webm', 'video/quicktime', 'video/x-matroska'];
        if (!in_array($file['type'], $allowed_types, true)) {
            return new \WP_Error('invalid_type', 'File type not allowed. Allowed: MP4, WebM, MOV, MKV', ['status' => 400]);
        }

        // Validate file size (max 500MB)
        $max_size = 524288000; // 500MB
        if ($file['size'] > $max_size) {
            return new \WP_Error('file_too_large', 'File exceeds 500MB limit', ['status' => 413]);
        }

        // Create uploads directory if it doesn't exist
        $uploads_dir = wp_upload_dir();
        $video_dir = $uploads_dir['basedir'] . '/videos/';
        
        if (!is_dir($video_dir)) {
            wp_mkdir_p($video_dir);
        }

        // Sanitize filename and move file
        $filename = sanitize_file_name(basename($file['name']));
        $filename = wp_unique_filename($video_dir, $filename);
        $target_file = $video_dir . $filename;

        if (!move_uploaded_file($file['tmp_name'], $target_file)) {
            return new \WP_Error('upload_failed', 'Failed to move uploaded file', ['status' => 500]);
        }

        // Get metadata from request
        $title = sanitize_text_field($request->get_param('title'));
        $description = wp_kses_post($request->get_param('description'));
        $duration = sanitize_text_field($request->get_param('duration'));
        $thumbnail_url = esc_url_raw($request->get_param('thumbnail_url'));

        // Validate title
        if (empty($title)) {
            @unlink($target_file); // Clean up uploaded file
            return new \WP_Error('invalid_title', 'Title is required', ['status' => 400]);
        }

        // Create WordPress post for video
        $post_id = wp_insert_post([
            'post_type' => 'psp_training_video',
            'post_title' => $title,
            'post_content' => $description ?: '',
            'post_excerpt' => wp_trim_words($description, 30),
            'post_status' => 'publish',
            'post_author' => get_current_user_id(),
        ]);

        if (is_wp_error($post_id)) {
            @unlink($target_file); // Clean up uploaded file
            return $post_id;
        }

        // Save video metadata
        $video_url = $uploads_dir['baseurl'] . '/videos/' . $filename;
        update_post_meta($post_id, \PSP\Training_Videos::META_VIDEO_URL, $video_url);
        update_post_meta($post_id, \PSP\Training_Videos::META_THUMBNAIL_URL, $thumbnail_url);
        update_post_meta($post_id, \PSP\Training_Videos::META_DURATION, $duration);
        update_post_meta($post_id, \PSP\Training_Videos::META_UPLOAD_DATE, current_time('c'));

        return rest_ensure_response([
            'success' => true,
            'message' => 'Video uploaded successfully',
            'data' => [
                'id' => $post_id,
                'title' => $title,
                'description' => $description,
                'url' => $video_url,
                'thumbnail' => $thumbnail_url,
                'duration' => $duration,
                'uploaded_at' => current_time('c'),
            ]
        ], 201);
    }

    /**
     * Update training video metadata
     */
    public function update_video($request) {
        $user_role = $this->get_current_user_role();
        if (!in_array($user_role, ['admin', 'staff'], true)) {
            return new \WP_Error('forbidden', 'Only admins and staff can update videos', ['status' => 403]);
        }

        $video_id = intval($request->get_param('id'));
        
        // Check if video exists
        $post = get_post($video_id);
        if (!$post || $post->post_type !== 'psp_training_video') {
            return new \WP_Error('not_found', 'Video not found', ['status' => 404]);
        }

        // Update post data
        $update_args = ['ID' => $video_id];
        
        if ($request->get_param('title')) {
            $update_args['post_title'] = sanitize_text_field($request->get_param('title'));
        }
        
        if ($request->get_param('description')) {
            $description = wp_kses_post($request->get_param('description'));
            $update_args['post_content'] = $description;
            $update_args['post_excerpt'] = wp_trim_words($description, 30);
        }

        wp_update_post($update_args);

        // Update metadata
        if ($request->get_param('duration')) {
            update_post_meta($video_id, \PSP\Training_Videos::META_DURATION, 
                sanitize_text_field($request->get_param('duration')));
        }

        if ($request->get_param('thumbnail_url')) {
            update_post_meta($video_id, \PSP\Training_Videos::META_THUMBNAIL_URL, 
                esc_url_raw($request->get_param('thumbnail_url')));
        }

        return rest_ensure_response([
            'success' => true,
            'message' => 'Video updated successfully',
        ]);
    }

    /**
     * Delete training video
     */
    public function delete_video($request) {
        $user_role = $this->get_current_user_role();
        if (!in_array($user_role, ['admin', 'staff'], true)) {
            return new \WP_Error('forbidden', 'Only admins and staff can delete videos', ['status' => 403]);
        }

        $video_id = intval($request->get_param('id'));
        
        // Check if video exists
        $post = get_post($video_id);
        if (!$post || $post->post_type !== 'psp_training_video') {
            return new \WP_Error('not_found', 'Video not found', ['status' => 404]);
        }

        // Get video URL to delete physical file
        $video_url = get_post_meta($video_id, \PSP\Training_Videos::META_VIDEO_URL, true);
        
        if ($video_url) {
            $file_path = str_replace(wp_upload_dir()['baseurl'], wp_upload_dir()['basedir'], $video_url);
            @unlink($file_path);
        }

        // Delete WordPress post
        wp_delete_post($video_id, true);

        return rest_ensure_response([
            'success' => true,
            'message' => 'Video deleted successfully',
        ]);
    }

    /**
     * Get users
     */
    public function get_users($request) {
        global $wpdb;
        
        $user = $_SESSION['psp_user'] ?? null;
        if (!$user) {
            return new WP_Error('unauthorized', 'Not authenticated', ['status' => 401]);
        }
        
        // Non-admins can only see their company's users
        $is_staff = in_array($user['role'], ['admin', 'staff'], true);

        if ($is_staff) {
            $users = $wpdb->get_results(
                "SELECT id,
                        COALESCE(NULLIF(CONCAT_WS(' ', first_name, last_name), ''), username, email) AS name,
                        email,
                        role,
                        status,
                        created_at,
                        first_name,
                        last_name,
                        username
                 FROM {$wpdb->prefix}psp_company_users 
                 WHERE 1=1
                 ORDER BY first_name ASC, last_name ASC"
            );
        } else {
            $company_id = isset($user['company_id']) ? intval($user['company_id']) : 0;
            $users = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT id,
                            COALESCE(NULLIF(CONCAT_WS(' ', first_name, last_name), ''), username, email) AS name,
                            email,
                            role,
                            status,
                            created_at,
                            first_name,
                            last_name,
                            username
                     FROM {$wpdb->prefix}psp_company_users 
                     WHERE company_id = %d
                     ORDER BY first_name ASC, last_name ASC",
                    $company_id
                )
            );
        }
        
        return rest_ensure_response([
            'success' => true,
            'data' => $users,
            'count' => count($users),
        ]);
    }
    
    /**
     * Create a new user (admin only)
     */
    public function create_user($request) {
        global $wpdb;
        
        // Verify nonce for mutation operation
        $nonce_check = $this->verify_rest_nonce($request);
        if (is_wp_error($nonce_check)) {
            return $nonce_check;
        }
        
        // Validate admin permission
        if (!current_user_can('manage_psp_portal')) {
            return new WP_Error('forbidden', 'Insufficient permissions', ['status' => 403]);
        }
        
        $username = sanitize_user($request->get_param('username'));
        $email = sanitize_email($request->get_param('email'));
        $first_name = sanitize_text_field($request->get_param('first_name'));
        $last_name = sanitize_text_field($request->get_param('last_name'));
        $role = sanitize_text_field($request->get_param('role'));
        $company_id = intval($request->get_param('company_id') ?? 0);
        $password = $request->get_param('password');
        
        // Validation
        if (empty($username) || empty($email) || empty($password) || empty($role)) {
            return new WP_Error('invalid_input', 'Missing required fields', ['status' => 400]);
        }
        
        if (strlen($password) < 8) {
            return new WP_Error('weak_password', 'Password must be at least 8 characters', ['status' => 400]);
        }
        
        if (!is_email($email)) {
            return new WP_Error('invalid_email', 'Invalid email format', ['status' => 400]);
        }
        
        // Check for duplicate username
        $existing = $wpdb->get_row(
            $wpdb->prepare("SELECT id FROM {$wpdb->prefix}psp_company_users WHERE username = %s", $username)
        );
        
        if ($existing) {
            return new WP_Error('duplicate_user', 'Username already exists', ['status' => 409]);
        }
        
        // Check role validity
        $valid_roles = ['partner', 'staff', 'admin'];
        if (!in_array($role, $valid_roles, true)) {
            return new WP_Error('invalid_role', 'Invalid role specified', ['status' => 400]);
        }
        
        // Hash password
        $password_hash = password_hash($password, PASSWORD_BCRYPT);
        
        // Insert user
        $inserted = $wpdb->insert(
            "{$wpdb->prefix}psp_company_users",
            [
                'username' => $username,
                'email' => $email,
                'first_name' => $first_name,
                'last_name' => $last_name,
                'password' => $password_hash,
                'role' => $role,
                'company_id' => $company_id,
                'status' => 'active',
                'created_at' => current_time('mysql')
            ],
            ['%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s']
        );
        
        if (!$inserted) {
            return new WP_Error('db_error', 'Failed to create user', ['status' => 500]);
        }
        
        $user_id = $wpdb->insert_id;
        
        return rest_ensure_response([
            'success' => true,
            'message' => 'User created successfully',
            'data' => [
                'id' => $user_id,
                'username' => $username,
                'email' => $email,
                'role' => $role,
                'status' => 'active'
            ]
        ]);
    }
    
    /**
     * Update user (admin only)
     */
    public function update_user($request) {
        global $wpdb;
        
        // Verify nonce for mutation operation
        $nonce_check = $this->verify_rest_nonce($request);
        if (is_wp_error($nonce_check)) {
            return $nonce_check;
        }
        
        // Validate admin permission
        if (!current_user_can('manage_psp_portal')) {
            return new WP_Error('forbidden', 'Insufficient permissions', ['status' => 403]);
        }
        
        $user_id = intval($request->get_param('id'));
        
        // Check if user exists
        $user = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$wpdb->prefix}psp_company_users WHERE id = %d", $user_id)
        );
        
        if (!$user) {
            return new WP_Error('not_found', 'User not found', ['status' => 404]);
        }
        
        // Prepare update data
        $update_data = [];
        $update_format = [];
        
        if ($request->has_param('email')) {
            $email = sanitize_email($request->get_param('email'));
            if (!is_email($email)) {
                return new WP_Error('invalid_email', 'Invalid email format', ['status' => 400]);
            }
            $update_data['email'] = $email;
            $update_format[] = '%s';
        }
        
        if ($request->has_param('first_name')) {
            $update_data['first_name'] = sanitize_text_field($request->get_param('first_name'));
            $update_format[] = '%s';
        }
        
        if ($request->has_param('last_name')) {
            $update_data['last_name'] = sanitize_text_field($request->get_param('last_name'));
            $update_format[] = '%s';
        }
        
        if ($request->has_param('role')) {
            $role = sanitize_text_field($request->get_param('role'));
            $valid_roles = ['partner', 'staff', 'admin'];
            if (!in_array($role, $valid_roles, true)) {
                return new WP_Error('invalid_role', 'Invalid role specified', ['status' => 400]);
            }
            $update_data['role'] = $role;
            $update_format[] = '%s';
        }
        
        if ($request->has_param('status')) {
            $status = sanitize_text_field($request->get_param('status'));
            $valid_statuses = ['active', 'inactive', 'suspended'];
            if (!in_array($status, $valid_statuses, true)) {
                return new WP_Error('invalid_status', 'Invalid status specified', ['status' => 400]);
            }
            $update_data['status'] = $status;
            $update_format[] = '%s';
        }
        
        if ($request->has_param('password')) {
            $password = $request->get_param('password');
            if (strlen($password) < 8) {
                return new WP_Error('weak_password', 'Password must be at least 8 characters', ['status' => 400]);
            }
            $update_data['password'] = password_hash($password, PASSWORD_BCRYPT);
            $update_format[] = '%s';
        }
        
        if (empty($update_data)) {
            return new WP_Error('no_data', 'No data to update', ['status' => 400]);
        }
        
        // Perform update
        $updated = $wpdb->update(
            "{$wpdb->prefix}psp_company_users",
            $update_data,
            ['id' => $user_id],
            $update_format,
            ['%d']
        );
        
        if ($updated === false) {
            return new WP_Error('db_error', 'Failed to update user', ['status' => 500]);
        }
        
        return rest_ensure_response([
            'success' => true,
            'message' => 'User updated successfully',
            'data' => array_merge((array)$user, $update_data)
        ]);
    }
    
    /**
     * Delete user (admin only)
     */
    public function delete_user($request) {
        global $wpdb;
        
        // Verify nonce for mutation operation
        $nonce_check = $this->verify_rest_nonce($request);
        if (is_wp_error($nonce_check)) {
            return $nonce_check;
        }
        
        // Validate admin permission
        if (!current_user_can('manage_psp_portal')) {
            return new WP_Error('forbidden', 'Insufficient permissions', ['status' => 403]);
        }
        
        $user_id = intval($request->get_param('id'));
        
        // Check if user exists
        $user = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$wpdb->prefix}psp_company_users WHERE id = %d", $user_id)
        );
        
        if (!$user) {
            return new WP_Error('not_found', 'User not found', ['status' => 404]);
        }
        
        // Prevent deleting the last admin
        $admin_count = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->prefix}psp_company_users WHERE role = 'admin'"
        );
        
        if ($user->role === 'admin' && $admin_count <= 1) {
            return new WP_Error('last_admin', 'Cannot delete the last admin user', ['status' => 400]);
        }
        
        // Perform delete
        $deleted = $wpdb->delete(
            "{$wpdb->prefix}psp_company_users",
            ['id' => $user_id],
            ['%d']
        );
        
        if (!$deleted) {
            return new WP_Error('db_error', 'Failed to delete user', ['status' => 500]);
        }
        
        return rest_ensure_response([
            'success' => true,
            'message' => 'User deleted successfully',
            'data' => [
                'id' => $user_id,
                'username' => $user->username
            ]
        ]);
    }
    
    /**
     * Get dashboard statistics
     */
    public function get_stats($request) {
        global $wpdb;
        
        try {
            $user = $_SESSION['psp_user'] ?? null;
            if (!$user) {
                error_log('[PSP Dashboard] User not authenticated');
                return new WP_Error('unauthorized', 'Not authenticated', ['status' => 401]);
            }

            // Normalize role to avoid undefined index notices
            $user_role = isset($user['role']) ? $user['role'] : 'partner';
            $company_id = isset($user['company_id']) ? intval($user['company_id']) : 0;

            // Partners must be linked to a company; support/admin remain unrestricted
            if ($user_role === 'partner' && !$company_id) {
                return new WP_Error('forbidden', 'No company assigned to your account', ['status' => 403]);
            }
            
            // Check if tables exist
            $tables_exist = $wpdb->get_var("SHOW TABLES LIKE '{$wpdb->prefix}psp_tickets'");
            if (!$tables_exist) {
                error_log('[PSP Dashboard] Database tables not found. Plugin may not be activated properly.');
                return rest_ensure_response([
                    'tickets_open' => 0,
                    'tickets_closed' => 0,
                    'services_this_month' => 0,
                    'users_active' => 0,
                    'open_tickets' => 0,
                    'in_progress' => 0,
                    'closed_month' => 0,
                    'avg_response' => '—',
                    'total_partners' => 0,
                    'active_partners' => 0,
                    'seasonal_openings' => 0,
                    'maintenance_units' => 0,
                    'training_videos' => 0,
                ]);
            }
            
            // Core ticket stats - separated queries for security
            $stats = [];
            
            if ($user_role === 'partner') {
                $stats['open_tickets'] = intval($wpdb->get_var(
                    $wpdb->prepare(
                        "SELECT COUNT(*) FROM {$wpdb->prefix}psp_tickets WHERE partner_id = %d AND status = 'open'",
                        $company_id
                    )
                ) ?: 0);
                $stats['in_progress'] = intval($wpdb->get_var(
                    $wpdb->prepare(
                        "SELECT COUNT(*) FROM {$wpdb->prefix}psp_tickets WHERE partner_id = %d AND status = 'in_progress'",
                        $company_id
                    )
                ) ?: 0);
                $stats['closed_month'] = intval($wpdb->get_var(
                    $wpdb->prepare(
                        "SELECT COUNT(*) FROM {$wpdb->prefix}psp_tickets WHERE partner_id = %d AND status = 'closed' AND MONTH(updated_at) = MONTH(NOW()) AND YEAR(updated_at) = YEAR(NOW())",
                        $company_id
                    )
                ) ?: 0);
                $stats['tickets_closed'] = intval($wpdb->get_var(
                    $wpdb->prepare(
                        "SELECT COUNT(*) FROM {$wpdb->prefix}psp_tickets WHERE partner_id = %d AND status = 'closed'",
                        $company_id
                    )
                ) ?: 0);
                $stats['users_active'] = intval($wpdb->get_var(
                    $wpdb->prepare(
                        "SELECT COUNT(*) FROM {$wpdb->prefix}psp_company_users WHERE company_id = %d",
                        $company_id
                    )
                ) ?: 0);
            } else {
                $stats['open_tickets'] = intval($wpdb->get_var(
                    "SELECT COUNT(*) FROM {$wpdb->prefix}psp_tickets WHERE status = 'open'"
                ) ?: 0);
                $stats['in_progress'] = intval($wpdb->get_var(
                    "SELECT COUNT(*) FROM {$wpdb->prefix}psp_tickets WHERE status = 'in_progress'"
                ) ?: 0);
                $stats['closed_month'] = intval($wpdb->get_var(
                    "SELECT COUNT(*) FROM {$wpdb->prefix}psp_tickets WHERE status = 'closed' AND MONTH(updated_at) = MONTH(NOW()) AND YEAR(updated_at) = YEAR(NOW())"
                ) ?: 0);
                $stats['tickets_closed'] = intval($wpdb->get_var(
                    "SELECT COUNT(*) FROM {$wpdb->prefix}psp_tickets WHERE status = 'closed'"
                ) ?: 0);
                $stats['users_active'] = intval($wpdb->get_var(
                    "SELECT COUNT(*) FROM {$wpdb->prefix}psp_company_users WHERE 1=1"
                ) ?: 0);
            }
            
            // Calculate average response time (in hours)
            // Note: first_reply_date column doesn't exist in current schema
            // Skip this metric until schema is updated
            $stats['avg_response'] = '—';
            
            // Legacy field names for compatibility
            $stats['tickets_open'] = $stats['open_tickets'];
            $stats['services_this_month'] = 0;
            
            // Only query service_records if table exists
            if ($wpdb->get_var("SHOW TABLES LIKE '{$wpdb->prefix}psp_service_records'")) {
                if ($user_role === 'partner') {
                    $stats['services_this_month'] = intval($wpdb->get_var(
                        $wpdb->prepare(
                            "SELECT COUNT(*) FROM {$wpdb->prefix}psp_service_records WHERE partner_id = %d AND MONTH(service_date) = MONTH(NOW()) AND YEAR(service_date) = YEAR(NOW())",
                            $company_id
                        )
                    ) ?: 0);
                } else {
                    $stats['services_this_month'] = intval($wpdb->get_var(
                        "SELECT COUNT(*) FROM {$wpdb->prefix}psp_service_records WHERE MONTH(service_date) = MONTH(NOW()) AND YEAR(service_date) = YEAR(NOW())"
                    ) ?: 0);
                }
            }
            
            // Enhanced metrics for Phase 1 (v1.3.0+)
            // Total and active partners
            if ($user_role === 'partner') {
                $stats['total_partners'] = intval($wpdb->get_var(
                    $wpdb->prepare(
                        "SELECT COUNT(*) FROM {$wpdb->prefix}posts WHERE post_type = 'psp_partner' AND post_status = 'publish' AND ID = %d",
                        $company_id
                    )
                ) ?: 0);

                $stats['active_partners'] = intval($wpdb->get_var(
                    $wpdb->prepare(
                        "SELECT COUNT(*) FROM {$wpdb->prefix}posts WHERE post_type = 'psp_partner' AND post_status = 'publish' AND ID = %d AND post_modified >= DATE_SUB(NOW(), INTERVAL 30 DAY)",
                        $company_id
                    )
                ) ?: 0);

                // Seasonal openings (partners with upcoming opening dates)
                $stats['seasonal_openings'] = intval($wpdb->get_var(
                    $wpdb->prepare(
                        "SELECT COUNT(*) FROM {$wpdb->prefix}postmeta WHERE meta_key = 'psp_seasonal_open_date' AND meta_value > CURDATE() AND post_id = %d",
                        $company_id
                    )
                ) ?: 0);

                // Units requiring maintenance (based on last maintenance date)
                $stats['maintenance_units'] = intval($wpdb->get_var(
                    $wpdb->prepare(
                        "SELECT COUNT(*) FROM {$wpdb->prefix}postmeta WHERE meta_key = 'psp_last_maintenance' AND meta_value < DATE_SUB(NOW(), INTERVAL 90 DAY) AND post_id = %d",
                        $company_id
                    )
                ) ?: 0);
            } else {
                $stats['total_partners'] = intval($wpdb->get_var(
                    "SELECT COUNT(*) FROM {$wpdb->prefix}posts WHERE post_type = 'psp_partner' AND post_status = 'publish'"
                ) ?: 0);

                $stats['active_partners'] = intval($wpdb->get_var(
                    "SELECT COUNT(*) FROM {$wpdb->prefix}posts WHERE post_type = 'psp_partner' AND post_status = 'publish' AND post_modified >= DATE_SUB(NOW(), INTERVAL 30 DAY)"
                ) ?: 0);

                // Seasonal openings (partners with upcoming opening dates)
                $stats['seasonal_openings'] = intval($wpdb->get_var(
                    "SELECT COUNT(*) FROM {$wpdb->prefix}postmeta WHERE meta_key = 'psp_seasonal_open_date' AND meta_value > CURDATE()"
                ) ?: 0);

                // Units requiring maintenance (based on last maintenance date)
                $stats['maintenance_units'] = intval($wpdb->get_var(
                    "SELECT COUNT(*) FROM {$wpdb->prefix}postmeta WHERE meta_key = 'psp_last_maintenance' AND meta_value < DATE_SUB(NOW(), INTERVAL 90 DAY)"
                ) ?: 0);
            }
            
            // Training videos count (new CPT in v1.3.0)
            $stats['training_videos'] = intval($wpdb->get_var(
                "SELECT COUNT(*) FROM {$wpdb->prefix}posts WHERE post_type = 'psp_training_video' AND post_status = 'publish'"
            ) ?: 0);
            
            // Phase 2 (v2.0.0+) Analytics
            // Activity logs summary
            if ($wpdb->get_var("SHOW TABLES LIKE '{$wpdb->prefix}psp_activity_logs'")) {
                $stats['activity_logs_today'] = intval($wpdb->get_var(
                    "SELECT COUNT(*) FROM {$wpdb->prefix}psp_activity_logs WHERE DATE(created_at) = CURDATE()"
                ) ?: 0);
                
                $stats['critical_events'] = intval($wpdb->get_var(
                    "SELECT COUNT(*) FROM {$wpdb->prefix}psp_activity_logs WHERE severity = 'critical'"
                ) ?: 0);
                
                $stats['total_activity_logs'] = intval($wpdb->get_var(
                    "SELECT COUNT(*) FROM {$wpdb->prefix}psp_activity_logs"
                ) ?: 0);
            } else {
                $stats['activity_logs_today'] = 0;
                $stats['critical_events'] = 0;
                $stats['total_activity_logs'] = 0;
            }
            
            // Notification summary
            $stats['unread_notifications'] = intval($wpdb->get_var(
                "SELECT COUNT(*) FROM {$wpdb->prefix}posts WHERE post_type = 'psp_notification' AND post_status = 'publish'"
            ) ?: 0);
            
            // Properties with location data (for map feature)
            $stats['properties_mapped'] = intval($wpdb->get_var(
                "SELECT COUNT(DISTINCT p.ID) FROM {$wpdb->prefix}posts p
                 JOIN {$wpdb->prefix}postmeta pm1 ON p.ID = pm1.post_id AND pm1.meta_key = 'psp_property_latitude'
                 JOIN {$wpdb->prefix}postmeta pm2 ON p.ID = pm2.post_id AND pm2.meta_key = 'psp_property_longitude'
                 WHERE p.post_type = 'psp_property' AND p.post_status = 'publish'"
            ) ?: 0);
            
            // CSV exports (count of export operations)
            $stats['exports_this_month'] = intval($wpdb->get_var(
                "SELECT COUNT(*) FROM {$wpdb->prefix}posts WHERE post_type = 'psp_csv_export' AND MONTH(post_modified) = MONTH(NOW()) AND YEAR(post_modified) = YEAR(NOW())"
            ) ?: 0);
            
            error_log('[PSP Dashboard] Stats loaded successfully');
            
            return rest_ensure_response($stats);
            
        } catch (Exception $e) {
            error_log('[PSP Dashboard] Error loading stats: ' . $e->getMessage());
            return new WP_Error('server_error', 'Failed to load dashboard stats: ' . $e->getMessage(), ['status' => 500]);
        }
    }
    
    /**
     * Get activity log
     */
    public function get_activity($request) {
        global $wpdb;
        
        $user = $_SESSION['psp_user'] ?? null;
        if (!$user) {
            return new WP_Error('unauthorized', 'Not authenticated', ['status' => 401]);
        }
        
        $page = intval($request->get_param('page')) ?: 1;
        $per_page = intval($request->get_param('per_page')) ?: 50;
        $offset = ($page - 1) * $per_page;
        
        $where = $user['role'] === 'admin' ? '1=1' : 
            $wpdb->prepare('entity_id = %d', $user['company_id']);
        
        $activity = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, action, description, user_id, created_at 
                 FROM {$wpdb->prefix}psp_audit_log 
                 WHERE {$where}
                 ORDER BY created_at DESC 
                 LIMIT %d OFFSET %d",
                $per_page,
                $offset
            )
        );
        
        $total = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->prefix}psp_audit_log WHERE {$where}"
        );
        
        return rest_ensure_response([
            'success' => true,
            'data' => $activity,
            'pagination' => [
                'page' => $page,
                'per_page' => $per_page,
                'total' => intval($total),
                'pages' => ceil($total / $per_page),
            ],
        ]);
    }
    
    /**
     * Debug authentication status endpoint
     * Returns current authentication state for troubleshooting
     */
    public function debug_auth_status($request) {
        if (!session_id() && !headers_sent()) {
            session_start();
        }
        
        $nonce = $request->get_header('X-WP-Nonce');
        
        return rest_ensure_response([
            'success' => true,
            'debug' => [
                'is_user_logged_in' => is_user_logged_in(),
                'current_user_id' => get_current_user_id(),
                'current_user_login' => wp_get_current_user()->user_login ?: 'none',
                'session_id' => session_id() ?: 'none',
                'session_psp_user_set' => !empty($_SESSION['psp_user']),
                'nonce_header' => $nonce ? 'present' : 'missing',
                'nonce_valid' => $nonce ? (wp_verify_nonce($nonce, 'wp_rest') ? 'valid' : 'invalid') : 'no nonce',
                'psp_cookie_set' => !empty($_COOKIE['psp_user_id']),
                'php_version' => phpversion(),
                'wordpress_version' => get_bloginfo('version'),
                'plugin_version' => defined('PSP_VERSION') ? PSP_VERSION : 'unknown',
            ],
        ]);
    }
}

// Initialize the API
new PSP_Portal_API();

