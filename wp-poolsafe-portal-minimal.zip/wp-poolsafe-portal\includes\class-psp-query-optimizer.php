<?php
namespace PSP;

/**
 * Query Optimization Helper
 * Provides optimized database queries for common operations
 * Reduces query count and improves performance
 *
 * @since 1.1.0
 */

if (!defined('ABSPATH')) {
	exit;
}

class Query_Optimizer {

	/**
	 * Get partners with optimal queries
	 *
	 * @since 1.1.0
	 * @param array $args Query arguments.
	 * @return array Array of partner data.
	 */
	public static function get_partners( array $args = [] ): array {
		global $wpdb;

		// Use cache if available
		$cached = Cache_Manager::get_partners_cached($args);
		if (!empty($cached)) {
			return $cached;
		}

		$defaults = [
			'posts_per_page' => 50,
			'paged' => 1,
			'orderby' => 'title',
			'order' => 'ASC',
		];

		$args = wp_parse_args($args, $defaults);

		// Single optimized query with JOIN
		$query = $wpdb->prepare(
			"
			SELECT 
				p.ID as id,
				p.post_title as name,
				p.post_content as description,
				pm1.meta_value as company_name,
				pm2.meta_value as management_company,
				pm3.meta_value as street_address,
				pm4.meta_value as city,
				pm5.meta_value as state,
				pm6.meta_value as installation_date,
				pm7.meta_value as operation_type,
				COUNT(t.ID) as ticket_count
			FROM {$wpdb->posts} p
			LEFT JOIN {$wpdb->postmeta} pm1 ON (p.ID = pm1.post_id AND pm1.meta_key = 'psp_company_name')
			LEFT JOIN {$wpdb->postmeta} pm2 ON (p.ID = pm2.post_id AND pm2.meta_key = 'psp_management_company')
			LEFT JOIN {$wpdb->postmeta} pm3 ON (p.ID = pm3.post_id AND pm3.meta_key = 'psp_street_address')
			LEFT JOIN {$wpdb->postmeta} pm4 ON (p.ID = pm4.post_id AND pm4.meta_key = 'psp_city')
			LEFT JOIN {$wpdb->postmeta} pm5 ON (p.ID = pm5.post_id AND pm5.meta_key = 'psp_state')
			LEFT JOIN {$wpdb->postmeta} pm6 ON (p.ID = pm6.post_id AND pm6.meta_key = 'psp_installation_date')
			LEFT JOIN {$wpdb->postmeta} pm7 ON (p.ID = pm7.post_id AND pm7.meta_key = 'psp_operation_type')
			LEFT JOIN {$wpdb->posts} t ON (p.ID = t.post_parent AND t.post_type = 'psp_ticket')
			WHERE p.post_type = 'psp_partner' AND p.post_status = 'publish'
			GROUP BY p.ID
			ORDER BY p.post_title ASC
			LIMIT %d OFFSET %d
			",
			$args['posts_per_page'],
			($args['paged'] - 1) * $args['posts_per_page']
		);

		// Execute with single query
		$results = $wpdb->get_results($query, ARRAY_A);

		return $results ?: [];
	}

	/**
	 * Get single partner with meta fields in one query
	 *
	 * @since 1.1.0
	 * @param int $partner_id Partner post ID.
	 * @return array|null Partner data or null.
	 */
	public static function get_partner( int $partner_id ): ?array {
		// Try cache first
		$cached = Cache_Manager::get_partner_cached($partner_id);
		if (!empty($cached)) {
			return $cached;
		}

		$post = get_post($partner_id);
		if (!$post || 'psp_partner' !== $post->post_type) {
			return null;
		}

		// Get all meta in one query
		$meta = get_post_meta($partner_id);

		return [
			'id' => $post->ID,
			'name' => $post->post_title,
			'description' => $post->post_content,
			'meta' => $meta,
		];
	}

	/**
	 * Get tickets with optimized query
	 *
	 * @since 1.1.0
	 * @param string $user_role User role.
	 * @param int $user_id User ID.
	 * @param array $args Query args.
	 * @return array Array of tickets.
	 */
	public static function get_tickets( string $user_role, int $user_id, array $args = [] ): array {
		// Try cache first
		$cached = Cache_Manager::get_tickets_cached($user_role, $user_id, $args);
		if (!empty($cached)) {
			return $cached;
		}

		global $wpdb;

		$defaults = [
			'posts_per_page' => 20,
			'paged' => 1,
			'status' => 'any',
		];

		$args = wp_parse_args($args, $defaults);

		$where = "WHERE p.post_type = 'psp_ticket' AND p.post_status IN ('publish', 'pending', 'draft')";

		// Filter by role
		if ('psp_partner' === $user_role) {
			// Partners only see tickets for their company
			$partner_id = (int) get_user_meta($user_id, 'psp_partner_id', true);
			$where .= $wpdb->prepare(' AND pm1.meta_value = %d', $partner_id);
		}

		// Single optimized query
		$query = $wpdb->prepare(
			"
			SELECT 
				p.ID as id,
				p.post_title as title,
				p.post_status as status,
				p.post_author as author_id,
				p.post_date as created,
				pm1.meta_value as partner_id,
				pm2.meta_value as priority,
				pm3.meta_value as category,
				COUNT(pr.ID) as reply_count
			FROM {$wpdb->posts} p
			LEFT JOIN {$wpdb->postmeta} pm1 ON (p.ID = pm1.post_id AND pm1.meta_key = 'psp_partner_id')
			LEFT JOIN {$wpdb->postmeta} pm2 ON (p.ID = pm2.post_id AND pm2.meta_key = 'psp_priority')
			LEFT JOIN {$wpdb->postmeta} pm3 ON (p.ID = pm3.post_id AND pm3.meta_key = 'psp_category')
			LEFT JOIN {$wpdb->prefix}psp_ticket_replies pr ON (p.ID = pr.ticket_id)
			{$where}
			GROUP BY p.ID
			ORDER BY p.post_date DESC
			LIMIT %d OFFSET %d
			",
			$args['posts_per_page'],
			($args['paged'] - 1) * $args['posts_per_page']
		);

		$results = $wpdb->get_results($query, ARRAY_A);

		return $results ?: [];
	}

	/**
	 * Get user role efficiently (with caching)
	 *
	 * @since 1.1.0
	 * @param int $user_id User ID.
	 * @return string User role.
	 */
	public static function get_user_role( int $user_id ): string {
		// Try cache
		return Cache_Manager::get_user_role_cached($user_id);
	}

	/**
	 * Count records efficiently
	 *
	 * @since 1.1.0
	 * @param string $post_type Post type to count.
	 * @param string $status Post status.
	 * @return int Record count.
	 */
	public static function count_posts( string $post_type, string $status = 'publish' ): int {
		global $wpdb;

		$query = $wpdb->prepare(
			"SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = %s AND post_status = %s",
			$post_type,
			$status
		);

		return (int) $wpdb->get_var($query);
	}

	/**
	 * Get activity log efficiently
	 *
	 * @since 1.1.0
	 * @param int $limit Number of records to return.
	 * @return array Activity log records.
	 */
	public static function get_activity_log( int $limit = 50 ): array {
		global $wpdb;

		$query = $wpdb->prepare(
			"
			SELECT 
				id,
				partner_id,
				action,
				description,
				user_id,
				timestamp
			FROM {$wpdb->prefix}psp_partner_activity
			ORDER BY timestamp DESC
			LIMIT %d
			",
			$limit
		);

		return $wpdb->get_results($query, ARRAY_A) ?: [];
	}

	/**
	 * Bulk update post meta (single query vs multiple)
	 *
	 * @since 1.1.0
	 * @param int $post_id Post ID.
	 * @param array $meta_updates Key-value pairs of meta.
	 * @return void
	 */
	public static function bulk_update_meta( int $post_id, array $meta_updates ): void {
		foreach ($meta_updates as $key => $value) {
			update_post_meta($post_id, 'psp_' . $key, sanitize_text_field($value));
		}
	}

	/**
	 * Get user-related posts (with caching)
	 *
	 * @since 1.1.0
	 * @param int $user_id User ID.
	 * @param string $post_type Post type.
	 * @return array Posts.
	 */
	public static function get_user_posts( int $user_id, string $post_type ): array {
		global $wpdb;

		$query = $wpdb->prepare(
			"
			SELECT p.ID, p.post_title, p.post_date
			FROM {$wpdb->posts} p
			WHERE p.post_author = %d AND p.post_type = %s AND p.post_status = 'publish'
			ORDER BY p.post_date DESC
			LIMIT 50
			",
			$user_id,
			$post_type
		);

		return $wpdb->get_results($query, ARRAY_A) ?: [];
	}

	/**
	 * Check if user has access to resource
	 *
	 * @since 1.1.0
	 * @param int $user_id User ID.
	 * @param int $resource_id Resource ID.
	 * @param string $resource_type Resource type (partner/ticket).
	 * @return bool True if user has access.
	 */
	public static function user_has_access( int $user_id, int $resource_id, string $resource_type ): bool {
		$user = get_user_by('id', $user_id);
		if (!$user) {
			return false;
		}

		// Admins have access to everything
		if (in_array('administrator', $user->roles, true)) {
			return true;
		}

		// Support staff see all tickets
		if ('psp_ticket' === $resource_type && in_array('psp_support', $user->roles, true)) {
			return true;
		}

		// Partners only see their own company
		if ('psp_partner' === $resource_type && in_array('psp_partner', $user->roles, true)) {
			$user_partner_id = (int) get_user_meta($user_id, 'psp_partner_id', true);
			return $user_partner_id === $resource_id;
		}

		return false;
	}

	/**
	 * Batch fetch with limit
	 *
	 * @since 1.1.0
	 * @param string $post_type Post type.
	 * @param int $limit Records to fetch.
	 * @return array Posts.
	 */
	public static function get_batch( string $post_type, int $limit = 100 ): array {
		global $wpdb;

		$query = $wpdb->prepare(
			"
			SELECT ID, post_title, post_date, post_status
			FROM {$wpdb->posts}
			WHERE post_type = %s AND post_status = 'publish'
			ORDER BY post_date DESC
			LIMIT %d
			",
			$post_type,
			min($limit, 500) // Max 500 to prevent timeouts
		);

		return $wpdb->get_results($query, ARRAY_A) ?: [];
	}
}
