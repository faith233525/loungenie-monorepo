<?php
/**
 * Internal Notes & Comments System
 * Private notes visible only to support team, separate from customer replies
 */

namespace PSP;

class Internal_Notes {

	const TABLE_NAME = 'psp_internal_notes';

	public static function init() {
		add_action( 'wp_ajax_psp_add_internal_note', array( __CLASS__, 'ajax_add_note' ) );
		add_action( 'wp_ajax_psp_get_internal_notes', array( __CLASS__, 'ajax_get_notes' ) );
		add_action( 'wp_ajax_psp_delete_internal_note', array( __CLASS__, 'ajax_delete_note' ) );
	}

	/**
	 * Create internal notes table
	 */
	public static function create_table() {
		global $wpdb;
		$charset_collate = $wpdb->get_charset_collate();
		$table_name      = $wpdb->prefix . self::TABLE_NAME;

		$sql = "CREATE TABLE IF NOT EXISTS $table_name (
			id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
			ticket_id BIGINT UNSIGNED NOT NULL,
			user_id BIGINT UNSIGNED NOT NULL,
			message LONGTEXT NOT NULL,
			mentions LONGTEXT,
			attachments LONGTEXT,
			edited_count INT DEFAULT 0,
			edited_at DATETIME,
			edited_by BIGINT UNSIGNED,
			created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
			updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			KEY (ticket_id),
			KEY (user_id),
			KEY (created_at)
		) $charset_collate;";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql );
	}

	/**
	 * Add internal note
	 */
	public static function add_note( $ticket_id, $message, $mentions = array(), $attachments = array() ) {
		global $wpdb;
		$table = $wpdb->prefix . self::TABLE_NAME;

		if ( ! current_user_can( 'psp_support' ) && ! current_user_can( 'administrator' ) ) {
			return false;
		}

		$insert_data = array(
			'ticket_id'   => absint( $ticket_id ),
			'user_id'     => get_current_user_id(),
			'message'     => wp_kses_post( $message ),
			'mentions'    => ! empty( $mentions ) ? wp_json_encode( $mentions ) : null,
			'attachments' => ! empty( $attachments ) ? wp_json_encode( $attachments ) : null,
		);

		$result = $wpdb->insert( $table, $insert_data );

		if ( $result ) {
			$note_id = $wpdb->insert_id;

			// Send notifications to mentioned users
			self::notify_mentioned_users( $ticket_id, $mentions, $message );

			// Log action
			do_action( 'psp_internal_note_added', $ticket_id, $note_id, get_current_user_id() );

			return $note_id;
		}

		return false;
	}

	/**
	 * Get internal notes for ticket
	 */
	public static function get_notes( $ticket_id, $limit = 50, $offset = 0 ) {
		global $wpdb;
		$table = $wpdb->prefix . self::TABLE_NAME;

		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT n.*, u.display_name, u.user_email 
				FROM $table n
				JOIN $wpdb->users u ON n.user_id = u.ID
				WHERE n.ticket_id = %d
				ORDER BY n.created_at DESC
				LIMIT %d OFFSET %d",
				$ticket_id,
				$limit,
				$offset
			)
		);
	}

	/**
	 * Get note count for ticket
	 */
	public static function get_note_count( $ticket_id ) {
		global $wpdb;
		$table = $wpdb->prefix . self::TABLE_NAME;

		return $wpdb->get_var(
			$wpdb->prepare( "SELECT COUNT(*) FROM $table WHERE ticket_id = %d", $ticket_id )
		);
	}

	/**
	 * Delete internal note
	 */
	public static function delete_note( $note_id ) {
		global $wpdb;
		$table = $wpdb->prefix . self::TABLE_NAME;

		$note = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM $table WHERE id = %d", $note_id )
		);

		if ( ! $note ) {
			return false;
		}

		// Only allow deletion by note author or admin
		if ( $note->user_id !== get_current_user_id() && ! current_user_can( 'manage_options' ) ) {
			return false;
		}

		return $wpdb->delete(
			$table,
			array( 'id' => $note_id ),
			array( '%d' )
		);
	}

	/**
	 * Notify mentioned users
	 */
	private static function notify_mentioned_users( $ticket_id, $mentions, $message ) {
		if ( empty( $mentions ) ) {
			return;
		}

		$ticket = get_post( $ticket_id );
		$author = get_user_by( 'id', get_current_user_id() );

		foreach ( $mentions as $user_id ) {
			$user = get_user_by( 'id', $user_id );

			if ( ! $user ) {
				continue;
			}

			$subject = sprintf(
				__( '[PoolSafe] You were mentioned in ticket #%d', 'psp' ),
				$ticket_id
			);

			$body = sprintf(
				__( 'Hi %s,' . "\n\n" . 
				'%s mentioned you in ticket #%d:' . "\n\n" .
				'%s' . "\n\n" .
				'View ticket: %s' . "\n\n" .
				'Best regards,' . "\n" .
				'PoolSafe Portal', 'psp' ),
				$user->display_name,
				$author->display_name,
				$ticket_id,
				wp_trim_words( $message, 30 ),
				admin_url( "post.php?post=$ticket_id&action=edit" )
			);

			wp_mail( $user->user_email, $subject, $body );
		}
	}

	/**
	 * AJAX: Add internal note
	 */
	public static function ajax_add_note() {
		check_ajax_referer( 'psp_nonce' );

		if ( ! current_user_can( 'psp_support' ) && ! current_user_can( 'administrator' ) ) {
			wp_send_json_error( 'Permission denied' );
		}

		$ticket_id = isset( $_POST['ticket_id'] ) ? absint( $_POST['ticket_id'] ) : 0;
		$message = isset( $_POST['message'] ) ? wp_kses_post( $_POST['message'] ) : '';
		$mentions = isset( $_POST['mentions'] ) ? array_map( 'absint', (array) $_POST['mentions'] ) : array();

		if ( ! $ticket_id || empty( $message ) ) {
			wp_send_json_error( 'Invalid parameters' );
		}

		$note_id = self::add_note( $ticket_id, $message, $mentions );

		if ( $note_id ) {
			wp_send_json_success( array( 'note_id' => $note_id, 'message' => 'Note added successfully' ) );
		} else {
			wp_send_json_error( 'Failed to add note' );
		}
	}

	/**
	 * AJAX: Get internal notes
	 */
	public static function ajax_get_notes() {
		check_ajax_referer( 'psp_nonce' );

		if ( ! current_user_can( 'psp_support' ) && ! current_user_can( 'administrator' ) ) {
			wp_send_json_error( 'Permission denied' );
		}

		$ticket_id = isset( $_GET['ticket_id'] ) ? absint( $_GET['ticket_id'] ) : 0;
		$limit = isset( $_GET['limit'] ) ? absint( $_GET['limit'] ) : 50;
		$offset = isset( $_GET['offset'] ) ? absint( $_GET['offset'] ) : 0;

		if ( ! $ticket_id ) {
			wp_send_json_error( 'Invalid ticket ID' );
		}

		$notes = self::get_notes( $ticket_id, $limit, $offset );
		$count = self::get_note_count( $ticket_id );

		wp_send_json_success(
			array(
				'notes' => $notes,
				'count' => $count,
			)
		);
	}

	/**
	 * AJAX: Delete internal note
	 */
	public static function ajax_delete_note() {
		check_ajax_referer( 'psp_nonce' );

		$note_id = isset( $_POST['note_id'] ) ? absint( $_POST['note_id'] ) : 0;

		if ( ! $note_id ) {
			wp_send_json_error( 'Invalid note ID' );
		}

		if ( self::delete_note( $note_id ) ) {
			wp_send_json_success( array( 'message' => 'Note deleted successfully' ) );
		} else {
			wp_send_json_error( 'Permission denied or note not found' );
		}
	}

	/**
	 * Render internal notes section
	 */
	public static function render_internal_notes( $ticket_id ) {
		if ( ! current_user_can( 'psp_support' ) && ! current_user_can( 'administrator' ) ) {
			return '';
		}

		$notes = self::get_notes( $ticket_id, 10 );
		$note_count = self::get_note_count( $ticket_id );

		?>
		<div class="psp-internal-notes-section">
			<h4><?php esc_html_e( 'Internal Notes', 'psp' ); ?> (<?php echo $note_count; ?>)</h4>
			
			<div class="psp-add-note-form">
				<textarea id="internal-note-text" placeholder="<?php esc_attr_e( 'Add internal note...', 'psp' ); ?>" rows="3"></textarea>
				<button class="button button-primary psp-add-note-btn" data-ticket-id="<?php echo esc_attr( $ticket_id ); ?>">
					<?php esc_html_e( 'Add Note', 'psp' ); ?>
				</button>
			</div>
			
			<div class="psp-notes-list">
				<?php foreach ( $notes as $note ) : ?>
					<div class="psp-note-item">
						<div class="psp-note-header">
							<strong><?php echo esc_html( $note->display_name ); ?></strong>
							<span class="psp-note-time"><?php echo wp_date( 'M j, Y g:i A', strtotime( $note->created_at ) ); ?></span>
							<?php if ( $note->edited_count > 0 ) : ?>
								<span class="psp-note-edited"><?php esc_html_e( '(edited)', 'psp' ); ?></span>
							<?php endif; ?>
						</div>
						<div class="psp-note-body"><?php echo wp_kses_post( $note->message ); ?></div>
						<?php if ( $note->user_id === get_current_user_id() || current_user_can( 'manage_options' ) ) : ?>
							<button class="button button-small psp-delete-note-btn" data-note-id="<?php echo esc_attr( $note->id ); ?>">
								<?php esc_html_e( 'Delete', 'psp' ); ?>
							</button>
						<?php endif; ?>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
		<?php
	}
}
