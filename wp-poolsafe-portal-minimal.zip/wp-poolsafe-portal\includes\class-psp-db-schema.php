<?php
namespace PSP;

if (!defined('ABSPATH')) exit;

/**
 * Database Schema for Company Authentication
 */
class DB_Schema {
    
    public static function create_tables() {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();

        // Companies table
        $companies_table = $wpdb->prefix . 'psp_companies';
        $sql_companies = "CREATE TABLE IF NOT EXISTS $companies_table (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            company_name varchar(255) NOT NULL,
            username varchar(100) NOT NULL UNIQUE,
            password_hash varchar(255) NOT NULL,
            status varchar(20) DEFAULT 'active',
            last_login datetime DEFAULT NULL,
            created_at datetime NOT NULL,
            updated_at datetime DEFAULT NULL,
            PRIMARY KEY (id),
            KEY username (username),
            KEY status (status)
        ) $charset;";

        // Company contacts
        $contacts_table = $wpdb->prefix . 'psp_company_contacts';
        $sql_contacts = "CREATE TABLE IF NOT EXISTS $contacts_table (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            company_id bigint(20) UNSIGNED NOT NULL,
            name varchar(255) NOT NULL,
            email varchar(255) NOT NULL,
            phone varchar(50) DEFAULT NULL,
            is_primary tinyint(1) DEFAULT 0,
            created_at datetime NOT NULL,
            PRIMARY KEY (id),
            KEY company_id (company_id),
            KEY email (email)
        ) $charset;";

        // Sessions table
        $sessions_table = $wpdb->prefix . 'psp_sessions';
        $sql_sessions = "CREATE TABLE IF NOT EXISTS $sessions_table (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            token varchar(64) NOT NULL UNIQUE,
            entity_id bigint(20) UNSIGNED NOT NULL,
            entity_type varchar(20) NOT NULL,
            contact_id bigint(20) UNSIGNED DEFAULT NULL COMMENT 'Which contact is logged in (for company logins)',
            expires_at datetime NOT NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY (id),
            KEY token (token),
            KEY expires_at (expires_at),
            KEY entity (entity_type, entity_id),
            KEY contact_id (contact_id)
        ) $charset;";

        // Login log
        $log_table = $wpdb->prefix . 'psp_login_log';
        $sql_log = "CREATE TABLE IF NOT EXISTS $log_table (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            company_id bigint(20) UNSIGNED DEFAULT NULL,
            success tinyint(1) NOT NULL,
            ip_address varchar(45) DEFAULT NULL,
            user_agent text DEFAULT NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY (id),
            KEY company_id (company_id),
            KEY created_at (created_at)
        ) $charset;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql_companies);
        dbDelta($sql_contacts);
        dbDelta($sql_sessions);
        dbDelta($sql_log);

        // Create support role
        add_role('psp_support', 'PoolSafe Support', [
            'read' => true,
            'psp_access_portal' => true,
            'psp_manage_companies' => true,
        ]);
    }

    public static function clean_expired_sessions() {
        global $wpdb;
        $table = $wpdb->prefix . 'psp_sessions';
        $wpdb->query("DELETE FROM $table WHERE expires_at < NOW()");
    }
}
