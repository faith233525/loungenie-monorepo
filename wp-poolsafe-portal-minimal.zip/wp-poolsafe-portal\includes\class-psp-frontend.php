<?php
/**
 * Frontend class - Handles shortcodes and frontend rendering
 *
 * @package PSP
 */

namespace PSP;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Frontend {

	/**
	 * Cached Vite manifest contents.
	 *
	 * @var array|false|null
	 */
	private static $manifest_cache = null;

	/**
	 * Load Vite manifest if present (dist/manifest.json).
	 *
	 * Implements caching to avoid repeated file I/O operations.
	 * Caches in object memory for current request.
	 *
	 * @return array|false Manifest array or false when missing/invalid
	 */
	private static function get_manifest() {
		if ( null !== self::$manifest_cache ) {
			return self::$manifest_cache;
		}

		$manifest_path = PSP_PLUGIN_DIR . 'dist/.vite/manifest.json';
		if ( ! file_exists( $manifest_path ) ) {
			self::$manifest_cache = false;
			return false;
		}

		try {
			$manifest_raw = file_get_contents( $manifest_path );
			if ( false === $manifest_raw ) {
				self::$manifest_cache = false;
				return false;
			}

			$manifest = json_decode( $manifest_raw, true );
			if ( json_last_error() !== JSON_ERROR_NONE ) {
				error_log( '[PSP] Manifest JSON error: ' . json_last_error_msg() );
				self::$manifest_cache = false;
				return false;
			}

			self::$manifest_cache = is_array( $manifest ) ? $manifest : false;
			return self::$manifest_cache;

		} catch ( \Exception $e ) {
			error_log( '[PSP] Manifest load error: ' . $e->getMessage() );
			self::$manifest_cache = false;
			return false;
		}
	}

	/**
	 * Retrieve a manifest entry by name.
	 *
	 * @param string $entry Entry key (e.g., 'psp-portal').
	 * @return array|null
	 */
	private static function get_manifest_entry( $entry ) {
		$manifest = self::get_manifest();
		if ( ! $manifest ) {
			return null;
		}

		if ( isset( $manifest[ $entry ] ) && is_array( $manifest[ $entry ] ) ) {
			return $manifest[ $entry ];
		}

		// Fallback: find by name or filename match
		foreach ( $manifest as $key => $value ) {
			if ( ! is_array( $value ) ) {
				continue;
			}

			$name           = $value['name'] ?? '';
			$key_base       = pathinfo( $key, PATHINFO_FILENAME );
			$entry_base     = pathinfo( $entry, PATHINFO_FILENAME );

			if ( $name === $entry || $name === $entry_base || $key === $entry || $key_base === $entry || $key_base === $entry_base ) {
				return $value;
			}
		}

		return null;
	}

	/**
	 * Get time-based greeting message
	 *
	 * @return string Greeting message
	 */
	/**
	 * Get time-based greeting with error handling
	 * 
	 * Features:
	 * - Safe hour retrieval
	 * - Graceful fallback on timezone issues
	 * - Proper i18n translation
	 * - Error logging
	 *
	 * @return string Time-appropriate greeting
	 */
	private static function get_greeting() {
		try {
			// Get current hour safely
			$current_time = current_time( 'timestamp' );
			if ( ! is_numeric( $current_time ) ) {
				error_log( '[PSP] Invalid current_time value' );
				return esc_html__( 'Welcome', 'psp' );
			}

			$current_hour = (int) gmdate( 'H', $current_time );

			// Validate hour is within expected range
			if ( $current_hour < 0 || $current_hour > 23 ) {
				error_log( '[PSP] Invalid hour value: ' . $current_hour );
				return esc_html__( 'Welcome', 'psp' );
			}

			// Return appropriate greeting
			if ( $current_hour < 12 ) {
				return esc_html__( 'Good Morning', 'psp' );
			} elseif ( $current_hour < 18 ) {
				return esc_html__( 'Good Afternoon', 'psp' );
			} else {
				return esc_html__( 'Good Evening', 'psp' );
			}

		} catch ( \Exception $e ) {
			error_log( '[PSP] Greeting generation failed: ' . $e->getMessage() );
			return esc_html__( 'Welcome', 'psp' );
		}
	}

	/**
	 * Register all shortcodes with comprehensive error handling
	 * 
	 * Features:
	 * - Safe filter hook registration
	 * - Error logging for hook failures
	 * - Graceful degradation if filters fail
	 * - Validates hook registration success
	 */
	public static function register_shortcodes() {
		try {
			// Validate add_filter function exists
			if ( ! function_exists( 'add_filter' ) ) {
				error_log( '[PSP] WordPress add_filter function not available' );
				return false;
			}

			// Register menu filters with error handling
			try {
				// Hide menu from unauthenticated users
				$result1 = add_filter( 'wp_nav_menu_args', array( __CLASS__, 'hide_menu_if_not_logged_in' ) );
				if ( false === $result1 ) {
					error_log( '[PSP] Failed to register wp_nav_menu_args filter' );
				}

				// Register menu filter for Astra theme
				$result2 = add_filter( 'wp_nav_menu_objects', array( __CLASS__, 'filter_menu_items' ) );
				if ( false === $result2 ) {
					error_log( '[PSP] Failed to register wp_nav_menu_objects filter' );
				}

				return ( false !== $result1 || false !== $result2 );

			} catch ( \Exception $e ) {
				error_log( '[PSP] Error registering menu filters: ' . $e->getMessage() );
				return false;
			}

			// NOTE: Shortcodes are registered via PSP_Shortcodes class to avoid duplicates
			// This prevents duplicate shortcode registration errors
			// See includes/class-psp-shortcodes.php for all shortcode registrations

		} catch ( \Exception $e ) {
			error_log( '[PSP] Shortcode registration failed: ' . $e->getMessage() );
			return false;
		}
	}

	/**
	 * Hide menu completely if user is not logged in with error handling
	 * 
	 * Features:
	 * - Safe argument handling
	 * - Validates menu args structure
	 * - Error logging for edge cases
	 * - Graceful degradation
	 *
	 * @param array $args Menu arguments
	 * @return array Modified menu arguments
	 */
	public static function hide_menu_if_not_logged_in( $args ) {
		try {
			// Validate args is array
			if ( ! is_array( $args ) ) {
				error_log( '[PSP] Invalid menu arguments passed to hide_menu_if_not_logged_in' );
				return $args;
			}

			// Check user login status
			if ( ! is_user_logged_in() ) {
				// Set fallback to empty string to completely hide menu
				$args['fallback_cb'] = '__return_empty_string';
			}

			return $args;

		} catch ( \Exception $e ) {
			error_log( '[PSP] Menu hiding failed: ' . $e->getMessage() );
			return $args;
		}
	}

	/**
	 * Enqueue frontend assets with comprehensive error handling
	 *
	 * Features:
	 * - Safe file existence checks
	 * - Fallback asset resolution
	 * - Proper error logging
	 * - Asset version management
	 * - Duplicate prevention
	 */
	public static function enqueue_assets() {
		static $enqueued = false;
		if ( $enqueued ) {
			return;
		}
		$enqueued = true;

		$plugin_url = PSP_PLUGIN_URL;
		$plugin_dir = PSP_PLUGIN_DIR;

		// CSP-COMPLIANT: Only external CSS file, NO inline styles
		$portal_css_path = $plugin_dir . 'css/portal-shortcode.css';
		$portal_css_ver = file_exists( $portal_css_path ) ? filemtime( $portal_css_path ) : PSP_VERSION;
		wp_enqueue_style( 'psp-portal-main', $plugin_url . 'css/portal-shortcode.css', array(), $portal_css_ver );
		
		// Ensure CSS is marked as stylesheet (workaround for caching plugins)
		add_filter( 'style_loader_src', array( __CLASS__, 'add_css_version_param' ), 10, 2 );

		// CSP-COMPLIANT: Only external JavaScript file, NO inline scripts
		$portal_js_path = $plugin_dir . 'js/psp-portal-app.js';
		$portal_js_ver = file_exists( $portal_js_path ) ? filemtime( $portal_js_path ) : PSP_VERSION;
		wp_enqueue_script( 'psp-portal-app', $plugin_url . 'js/psp-portal-app.js', array( 'jquery' ), $portal_js_ver, true );

		// CSP-COMPLIANT: Pass configuration to JavaScript (uses wp_localize_script, not inline)
		$current_user = wp_get_current_user();
		$portal_config = array(
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'nonce' => wp_create_nonce( 'psp_portal_nonce' ),
			'user_id' => get_current_user_id(),
			'user_role' => isset( $current_user->roles[0] ) ? $current_user->roles[0] : '',
			'plugin_url' => $plugin_url,
			'is_admin' => current_user_can( 'manage_options' ),
		);
		wp_localize_script( 'psp-portal-app', 'PORTAL_CONFIG', $portal_config );
	}

	/**
	 * Get first existing asset path from array of candidates
	 *
	 * @param array $candidates Array of potential file paths to check
	 * @return string|false First existing path or false
	 */
	private static function get_asset_path( array $candidates ) {
		foreach ( $candidates as $path ) {
			if ( file_exists( $path ) && is_readable( $path ) ) {
				return $path;
			}
		}
		return false;
	}

	/**
	 * Add version parameter and ensure correct MIME type for CSS
	 * Workaround for caching plugins stripping CSS
	 *
	 * @param string $src The stylesheet URL
	 * @param string $handle The stylesheet handle
	 * @return string Modified stylesheet URL
	 */
	public static function add_css_version_param( $src, $handle ) {
		if ( 'psp-portal-main' === $handle ) {
			// Ensure cache busting parameter is present
			if ( strpos( $src, 'ver=' ) === false ) {
				$src = add_query_arg( 'ver', PSP_VERSION, $src );
			}
		}
		return $src;
	}

	/**
	 * Generate CSS variables that inherit theme palette when available
	 * 
	 * Features:
	 * - Caches theme colors to avoid repeated wp_get_global_settings calls
	 * - Graceful fallback to defaults
	 * - Error handling for theme data
	 * - Safe color variable generation
	 *
	 * @return string CSS root variables
	 */
	private static function theme_variables_css() {
		static $css_cache = null;
		
		// Return cached CSS if available
		if ( null !== $css_cache ) {
			return $css_cache;
		}

		try {
			$defaults = array(
				'primary'   => '#3AA6B9',  // Primary Teal
				'secondary' => '#25D0EE',  // Accent Cyan
				'success'   => '#10B981',
				'warning'   => '#F59E0B',
				'danger'    => '#EF4444',
				'info'      => '#3AA6B9',  // Use Primary Teal for info
				'gray-900'  => '#0F172A',  // Dark Navy
				'gray-700'  => '#454F5E',  // Slate Gray
				'gray-500'  => '#64748B',
				'gray-100'  => '#CAE6E8',  // Soft Cyan
				'gray-50'   => '#E9F8F9',  // Light Cyan
				'background' => '#FFFFFF', // White
				'text'      => '#0F172A',  // Dark Navy
				'border'    => '#CAE6E8',  // Soft Cyan
			);

			// Safe retrieval of global settings
			$palette = array();
			if ( function_exists( 'wp_get_global_settings' ) ) {
				try {
					$palette_data = wp_get_global_settings( array( 'color', 'palette', 'theme' ) );
					if ( is_array( $palette_data ) ) {
						$palette = $palette_data;
					}
				} catch ( \Exception $e ) {
					error_log( '[PSP] Theme palette retrieval failed: ' . $e->getMessage() );
					$palette = array();
				}
			}

			// Helper to find color in palette
			$find = function( $slug ) use ( $palette, $defaults ) {
				try {
					if ( is_array( $palette ) && ! empty( $palette ) ) {
						foreach ( $palette as $color ) {
							if ( is_array( $color ) 
								&& isset( $color['slug'], $color['color'] ) 
								&& $color['slug'] === $slug 
								&& is_string( $color['color'] ) ) {
								return $color['color'];
							}
						}
					}
					return isset( $defaults[ $slug ] ) ? $defaults[ $slug ] : null;
				} catch ( \Exception $e ) {
					error_log( '[PSP] Color lookup failed for ' . $slug . ': ' . $e->getMessage() );
					return isset( $defaults[ $slug ] ) ? $defaults[ $slug ] : null;
				}
			};

			// Resolve colors with safe fallback
			$primary   = $find( 'primary' ) ?: $defaults['primary'];
			$secondary = $find( 'secondary' ) ?: $defaults['secondary'];
			$success   = $find( 'success' ) ?: $defaults['success'];
			$warning   = $find( 'warning' ) ?: $defaults['warning'];
			$danger    = $find( 'danger' ) ?: $defaults['danger'];
			$info      = $find( 'info' ) ?: $defaults['info'];
			$text      = $find( 'text' ) ?: $defaults['gray-900'];
			$muted     = $find( 'muted' ) ?: $defaults['gray-700'];
			$border    = $find( 'border' ) ?: $defaults['gray-100'];

			// Validate colors are hex format
			$colors = array(
				'primary'   => $primary,
				'secondary' => $secondary,
				'success'   => $success,
				'warning'   => $warning,
				'danger'    => $danger,
				'info'      => $info,
				'text'      => $text,
				'muted'     => $muted,
				'border'    => $border,
			);

			foreach ( $colors as $name => $color ) {
				if ( ! preg_match( '/^#[0-9A-F]{3}(?:[0-9A-F]{3})?$/i', $color ) ) {
					error_log( '[PSP] Invalid color format for ' . $name . ': ' . $color );
					$colors[ $name ] = $defaults[ $name ] ?? '#000000';
				}
			}

			// Generate CSS variables
			$css  = ':root{' . PHP_EOL;
			$css .= '--psp-primary: ' . sanitize_hex_color( $colors['primary'] ) . ';' . PHP_EOL;
			$css .= '--psp-primary-hover: ' . sanitize_hex_color( $colors['secondary'] ) . ';' . PHP_EOL;
			$css .= '--psp-primary-dark: ' . sanitize_hex_color( $colors['secondary'] ) . ';' . PHP_EOL;
			$css .= '--psp-secondary: ' . sanitize_hex_color( $colors['secondary'] ) . ';' . PHP_EOL;
			$css .= '--psp-success: ' . sanitize_hex_color( $colors['success'] ) . ';' . PHP_EOL;
			$css .= '--psp-warning: ' . sanitize_hex_color( $colors['warning'] ) . ';' . PHP_EOL;
			$css .= '--psp-danger: ' . sanitize_hex_color( $colors['danger'] ) . ';' . PHP_EOL;
			$css .= '--psp-info: ' . sanitize_hex_color( $colors['info'] ) . ';' . PHP_EOL;
			$css .= '--psp-text: ' . sanitize_hex_color( $colors['text'] ) . ';' . PHP_EOL;
			$css .= '--psp-gray-600: ' . sanitize_hex_color( $colors['muted'] ) . ';' . PHP_EOL;
			$css .= '--psp-gray-200: ' . sanitize_hex_color( $colors['border'] ) . ';' . PHP_EOL;
			$css .= '}' . PHP_EOL;

			// Cache for subsequent calls
			$css_cache = $css;
			return $css;

		} catch ( \Exception $e ) {
			error_log( '[PSP] Theme CSS generation failed: ' . $e->getMessage() );
			// Return minimal safe CSS on error
			return ':root { --psp-primary: #3AA6B9; --psp-secondary: #25D0EE; }' . PHP_EOL;
		}
	}

	/**
	 * Filter menu items by user role with comprehensive error handling
	 * 
	 * Features:
	 * - Hide entire menu if not logged in
	 * - Role-based visibility
	 * - Safe item property access
	 * - Error logging for edge cases
	 *
	 * @param array $items Menu items
	 * @return array Filtered menu items
	 */
	public static function filter_menu_items( $items ) {
		try {
			// Hide entire menu if not logged in
			if ( ! is_user_logged_in() ) {
				return array();
			}

			// Validate items is array
			if ( ! is_array( $items ) || empty( $items ) ) {
				return $items;
			}

			// Get current user and role
			$user = wp_get_current_user();
			
			// Safely get user role with fallback
			$role = '';
			if ( $user instanceof \WP_User && ! empty( $user->roles ) ) {
				$role = is_array( $user->roles ) ? $user->roles[0] : '';
			}

			if ( empty( $role ) ) {
				error_log( '[PSP] Could not determine user role for menu filtering' );
				return $items;
			}

			// Define role-based visibility rules
			$admin_only = array( 'manage-users', 'contact-approval-center', 'bulk-import' );
			$partner_only = array( 'contact-update-request' );

			// Filter items
			$filtered_items = array();
			foreach ( $items as $key => $item ) {
				try {
					// Safe property access
					if ( ! is_object( $item ) || ! isset( $item->url ) ) {
						$filtered_items[ $key ] = $item;
						continue;
					}

					// Extract slug from URL
					$slug = '';
					if ( is_string( $item->url ) && ! empty( $item->url ) ) {
						$slug = basename( wp_parse_url( $item->url, PHP_URL_PATH ) );
					}

					// Apply role-based filtering
					$should_include = true;

					// Hide admin/support-only pages from partners
					if ( in_array( $slug, $admin_only, true ) && 'psp_partner' === $role ) {
						$should_include = false;
					}

					// Hide login management for partners
					if ( 'login' === $slug && 'psp_partner' === $role ) {
						$should_include = false;
					}

					// Only show Contact Update Request for partners
					if ( in_array( $slug, $partner_only, true ) && 'psp_partner' !== $role ) {
						$should_include = false;
					}

					if ( $should_include ) {
						$filtered_items[ $key ] = $item;
					}

				} catch ( \Exception $e ) {
					error_log( '[PSP] Error filtering menu item: ' . $e->getMessage() );
					// Include item on error to be safe
					$filtered_items[ $key ] = $item;
				}
			}

			return $filtered_items;

		} catch ( \Exception $e ) {
			error_log( '[PSP] Menu filtering failed: ' . $e->getMessage() );
			// Return original items on critical error
			return $items;
		}
	}

	/**
	 * Render main portal dashboard
	 *
	 * @return string HTML output
	 */
	public static function render_portal() {
		if ( ! is_user_logged_in() ) {
			return self::render_login();
		}

		self::enqueue_assets();

		ob_start();

		$user = wp_get_current_user();
		$role = $user->roles[0] ?? '';
		$is_support = in_array( $role, array( 'administrator', 'psp_support' ), true );
		$greeting = self::get_greeting();

		?>
		<div class="psp-portal-container">
			<!-- Header with Welcome Message -->
			<div class="psp-portal-header">
				<div class="psp-header-content">
					<div>
						<h1><?php esc_html_e( 'PoolSafe Portal', 'psp' ); ?></h1>
						<p class="psp-welcome-message">
							<?php printf( 
								esc_html__( '%s, %s', 'psp' ),
								esc_html( $greeting ),
								'<strong>' . esc_html( $user->display_name ) . '</strong>'
							); ?>
						</p>
					</div>
					<div class="psp-user-info">
						<span class="psp-role-badge"><?php echo esc_html( ucfirst( str_replace( 'psp_', '', $role ) ) ); ?></span>
					</div>
				</div>
			</div>

			<!-- Quick Actions / Quick Links -->
			<div class="psp-quick-actions">
				<a href="#tickets" class="psp-quick-action-btn">
					<svg width="20" height="20" fill="currentColor" viewBox="0 0 20 20">
						<path d="M2 3a1 1 0 011-1h2.153a1 1 0 01.986.836l.74 4.435a1 1 0 01-.54 1.06l-1.487.744a1.5 1.5 0 00-.596 1.422 16.002 16.002 0 006.636 6.636 1.5 1.5 0 001.422-.596l.744-1.487a1 1 0 011.06-.54l4.435.74a1 1 0 01.836.986V17a1 1 0 01-1 1h-2.694a7 7 0 01-6.993-6.993V3z"/>
					</svg>
					<span><?php esc_html_e( 'Tickets', 'psp' ); ?></span>
				</a>
				<a href="#partners" class="psp-quick-action-btn">
					<svg width="20" height="20" fill="currentColor" viewBox="0 0 20 20">
						<path d="M9 6a3 3 0 11-6 0 3 3 0 016 0zM17 6a3 3 0 11-6 0 3 3 0 016 0zM12.93 11a6 6 0 00-11.86 0v.5a2 2 0 002 2v1a1 1 0 001 1h5a1 1 0 001-1v-1a2 2 0 002-2v-.5z"/>
					</svg>
					<span><?php esc_html_e( 'Partners', 'psp' ); ?></span>
				</a>
				<a href="#calendar" class="psp-quick-action-btn">
					<svg width="20" height="20" fill="currentColor" viewBox="0 0 20 20">
						<path fill-rule="evenodd" d="M6 2a1 1 0 00-1 1v2H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V7a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v2H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clip-rule="evenodd"/>
					</svg>
					<span><?php esc_html_e( 'Calendar', 'psp' ); ?></span>
				</a>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=psp-search' ) ); ?>" class="psp-quick-action-btn">
					<svg width="20" height="20" fill="currentColor" viewBox="0 0 20 20">
						<path fill-rule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clip-rule="evenodd"/>
					</svg>
					<span><?php esc_html_e( 'Search', 'psp' ); ?></span>
				</a>
			</div>

			<!-- Search Bar -->
			<div class="psp-search-bar">
				<form method="get" class="psp-search-form">
					<input type="text" 
						   name="psp_search" 
						   placeholder="<?php esc_attr_e( 'Search tickets, partners, or service records...', 'psp' ); ?>" 
						   value="<?php echo esc_attr( $_GET['psp_search'] ?? '' ); ?>"
						   class="psp-search-input">
					<button type="submit" class="psp-search-btn">
						<svg width="20" height="20" fill="currentColor" viewBox="0 0 20 20">
							<path fill-rule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clip-rule="evenodd"/>
						</svg>
						<?php esc_html_e( 'Search', 'psp' ); ?>
					</button>
				</form>
			</div>

			<?php if ( $is_support ) : ?>
			<!-- Analytics Section -->
			<div class="psp-analytics-section">
				<h2><?php esc_html_e( 'Dashboard Analytics', 'psp' ); ?></h2>
				<div class="psp-analytics-grid">
					<div class="psp-analytics-card">
						<div class="psp-analytics-icon">
							<svg width="24" height="24" fill="currentColor" viewBox="0 0 20 20">
								<path d="M2 11a1 1 0 011-1h2a1 1 0 011 1v5a1 1 0 01-1 1H3a1 1 0 01-1-1v-5zM8 7a1 1 0 011-1h2a1 1 0 011 1v9a1 1 0 01-1 1H9a1 1 0 01-1-1V7zM14 4a1 1 0 011-1h2a1 1 0 011 1v12a1 1 0 01-1 1h-2a1 1 0 01-1-1V4z"/>
							</svg>
						</div>
						<h3><?php esc_html_e( 'Open Tickets', 'psp' ); ?></h3>
						<div class="psp-analytics-value">
							<?php
							global $wpdb;
							$table_name = $wpdb->prefix . 'psp_tickets';
							if ( self::table_exists( $table_name ) ) {
								$count = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table_name} WHERE status IN ('open', 'in-progress')" ) );
								echo esc_html( $count ?? 0 );
							} else {
								echo '—';
							}
							?>
						</div>
					</div>
					<div class="psp-analytics-card">
						<div class="psp-analytics-icon">
							<svg width="24" height="24" fill="currentColor" viewBox="0 0 20 20">
								<path d="M13 6a3 3 0 11-6 0 3 3 0 016 0zM18 8a2 2 0 11-4 0 2 2 0 014 0zM14 15a4 4 0 00-8 0v2a2 2 0 002 2h4a2 2 0 002-2v-2zM16 11a1 1 0 100-2 1 1 0 000 2z"/>
							</svg>
						</div>
						<h3><?php esc_html_e( 'Active Partners', 'psp' ); ?></h3>
						<div class="psp-analytics-value">
							<?php
							$user_counts = count_users();
							$partners = isset( $user_counts['avail_roles']['psp_partner'] ) ? $user_counts['avail_roles']['psp_partner'] : 0;
							echo esc_html( (string) $partners );
							?>
						</div>
					</div>
					<div class="psp-analytics-card">
						<div class="psp-analytics-icon">
							<svg width="24" height="24" fill="currentColor" viewBox="0 0 20 20">
								<path d="M9 2a1 1 0 000 2h2a1 1 0 100-2H9z"/><path fill-rule="evenodd" d="M4 5a2 2 0 012-2 1 1 0 000-2 4 4 0 00-4 4v10a4 4 0 004 4h8a4 4 0 004-4V5a1 1 0 00-1-1 2 2 0 01-2-2 1 1 0 00-1 0h-2a1 1 0 00-1 1v2H8V4a1 1 0 00-1-1 2 2 0 01-2-2zm5 10a1 1 0 100-2 1 1 0 000 2z" clip-rule="evenodd"/>
							</svg>
						</div>
						<h3><?php esc_html_e( 'Pending Approvals', 'psp' ); ?></h3>
						<div class="psp-analytics-value">
							<?php
							$pending_users = get_users( array( 'meta_key' => 'psp_approval_status', 'meta_value' => 'pending', 'count_total' => true ) );
							$pending = is_array( $pending_users ) ? count( $pending_users ) : 0;
							echo esc_html( (string) $pending );
							?>
						</div>
					</div>
				</div>
			</div>
			<?php endif; ?>

			<!-- Main Content Grid -->
			<div class="psp-portal-grid">
				<div class="psp-portal-section psp-tickets-section">
					<h2><?php esc_html_e( 'Support Tickets', 'psp' ); ?></h2>
					<?php echo self::render_tickets(); ?>
				</div>

				<div class="psp-portal-section psp-partners-section">
					<h2><?php esc_html_e( 'Partner Directory', 'psp' ); ?></h2>
					<?php echo self::render_partners(); ?>
				</div>

				<div class="psp-portal-section psp-notifications-section">
					<h2><?php esc_html_e( 'Notifications', 'psp' ); ?></h2>
					<?php echo self::render_notifications(); ?>
				</div>

			<div class="psp-portal-section psp-calendar-section">
				<h2><?php esc_html_e( 'Calendar', 'psp' ); ?></h2>
				<?php echo self::render_calendar(); ?>
			</div>

			<?php if ( $is_support ) : ?>
				<div class="psp-portal-section psp-support-tools-section">
					<h2><?php esc_html_e( 'Support Tools', 'psp' ); ?></h2>
					<?php echo self::render_support_tools(); ?>
				</div>
				<?php endif; ?>
			</div>
		</div>
		<?php

		return ob_get_clean();
	}

	/**
	 * Render partner directory
	 *
	 * @return string HTML output
	 */
	/**
	 * Check if a database table exists.
	 *
	 * @param string $table_name The table name to check.
	 * @return bool True if table exists, false otherwise.
	 */
	private static function table_exists( $table_name ) {
		global $wpdb;
		return (bool) $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table_name ) );
	}

	public static function render_partners() {
		if ( ! is_user_logged_in() ) {
			return '<p>' . esc_html__( 'Please log in to view partners.', 'psp' ) . '</p>';
		}

		self::enqueue_assets();

		ob_start();

		global $wpdb;
		$table_name = $wpdb->prefix . 'psp_partners';
		
		// Check if table exists before querying
		if ( ! self::table_exists( $table_name ) ) {
			echo '<div class="psp-notice psp-notice-info">';
			echo '<p>' . esc_html__( 'Partner data is being initialized. Please refresh the page in a moment.', 'psp' ) . '</p>';
			echo '</div>';
			return ob_get_clean();
		}
		
		$partners = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table_name} WHERE status = %s ORDER BY company_name ASC", 'active' ) );

		?>
		<div class="psp-partners-container">
			<div class="psp-partners-header">
				<input type="text" id="psp-partner-search" class="psp-search-input" placeholder="<?php esc_attr_e( 'Search partners...', 'psp' ); ?>">
			</div>

			<div class="psp-partners-grid">
				<?php if ( ! empty( $partners ) ) : ?>
					<?php foreach ( $partners as $partner ) : ?>
					<div class="psp-partner-card" data-partner-id="<?php echo esc_attr( $partner->id ); ?>">
						<h3 class="psp-partner-name"><?php echo esc_html( $partner->name ); ?></h3>
						<div class="psp-partner-details">
							<?php if ( ! empty( $partner->email ) ) : ?>
							<p><strong><?php esc_html_e( 'Email:', 'psp' ); ?></strong> 
								<a href="mailto:<?php echo esc_attr( $partner->email ); ?>">
									<?php echo esc_html( $partner->email ); ?>
								</a>
							</p>
							<?php endif; ?>

							<?php if ( ! empty( $partner->phone ) ) : ?>
							<p><strong><?php esc_html_e( 'Phone:', 'psp' ); ?></strong> 
								<?php echo esc_html( $partner->phone ); ?>
							</p>
							<?php endif; ?>

							<?php if ( ! empty( $partner->city ) || ! empty( $partner->state ) ) : ?>
							<p><strong><?php esc_html_e( 'Location:', 'psp' ); ?></strong> 
								<?php echo esc_html( trim( $partner->city . ', ' . $partner->state ) ); ?>
							</p>
							<?php endif; ?>
						</div>
						<div class="psp-partner-actions">
							<button class="psp-btn psp-btn-view" data-partner-id="<?php echo esc_attr( $partner->id ); ?>">
								<?php esc_html_e( 'View Details', 'psp' ); ?>
							</button>
						</div>
					</div>
					<?php endforeach; ?>
				<?php else : ?>
					<p class="psp-no-partners"><?php esc_html_e( 'No partners found.', 'psp' ); ?></p>
				<?php endif; ?>
			</div>

			<?php echo self::render_map(); ?>
		</div>
		<?php

		return ob_get_clean();
	}

	/**
	 * Render login form
	 *
	 * @return string HTML output
	 */
	public static function render_login() {
		if ( is_user_logged_in() ) {
			return '<p>' . esc_html__( 'You are already logged in.', 'psp' ) . ' <a href="' . esc_url( wp_logout_url() ) . '">' . esc_html__( 'Logout', 'psp' ) . '</a></p>';
		}

		self::enqueue_assets();

		ob_start();

		?>
		<div class="psp-login-container">
			<div class="psp-login-form">
				<h2><?php esc_html_e( 'PoolSafe Portal Login', 'psp' ); ?></h2>
				
				<?php
				wp_login_form( array(
					'echo'           => true,
					'redirect'       => ( is_ssl() ? 'https://' : 'http://' ) . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'],
					'form_id'        => 'psp-loginform',
					'label_username' => __( 'Username or Email', 'psp' ),
					'label_password' => __( 'Password', 'psp' ),
					'label_remember' => __( 'Remember Me', 'psp' ),
					'label_log_in'   => __( 'Log In', 'psp' ),
					'remember'       => true,
				) );
				?>

				<div class="psp-login-links">
					<a href="<?php echo esc_url( wp_lostpassword_url() ); ?>">
						<?php esc_html_e( 'Forgot Password?', 'psp' ); ?>
					</a>
					<?php if ( get_option( 'users_can_register' ) ) : ?>
					<a href="<?php echo esc_url( wp_registration_url() ); ?>">
						<?php esc_html_e( 'Register', 'psp' ); ?>
					</a>
					<?php endif; ?>
				</div>

			<?php if ( class_exists( 'PSP\Azure_Auth' ) ) : ?>
			<div class="psp-login-divider">
				<span><?php esc_html_e( 'OR', 'psp' ); ?></span>
			</div>
			<div class="psp-azure-login">
				<a href="<?php echo esc_url( admin_url( 'admin-ajax.php?action=psp_azure_login' ) ); ?>" class="psp-button psp-button-microsoft">
					<svg width="21" height="21" viewBox="0 0 21 21" fill="none" class="psp-microsoft-logo">
						<rect width="10" height="10" fill="#F25022"/>
						<rect x="11" width="10" height="10" fill="#7FBA00"/>
						<rect y="11" width="10" height="10" fill="#00A4EF"/>
						<rect x="11" y="11" width="10" height="10" fill="#FFB900"/>
					</svg>
					<?php esc_html_e( 'Sign in with Microsoft', 'psp' ); ?>
				</a>
			</div>
			<?php endif; ?>
			</div>
		</div>
		<?php

		return ob_get_clean();
	}

	/**
	 * Render search results
	 *
	 * @return string HTML output
	 */
	public static function render_search() {
		if ( ! is_user_logged_in() ) {
			return '<p>' . esc_html__( 'Please log in to search.', 'psp' ) . '</p>';
		}

		self::enqueue_assets();

		$search_term = isset( $_GET['psp_search'] ) ? sanitize_text_field( $_GET['psp_search'] ) : '';

		if ( empty( $search_term ) ) {
			return '<div class="psp-search-container"><p>' . esc_html__( 'Enter a search term to find tickets, partners, or service records.', 'psp' ) . '</p></div>';
		}

		ob_start();

		global $wpdb;
		$tickets_table = $wpdb->prefix . 'psp_tickets';
		$partners_table = $wpdb->prefix . 'psp_partners';
		$records_table = $wpdb->prefix . 'psp_service_records';

		$search_like = '%' . $wpdb->esc_like( $search_term ) . '%';

		// Search tickets
		$tickets = $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM {$tickets_table} WHERE subject LIKE %s OR description LIKE %s ORDER BY created_at DESC LIMIT 10",
			$search_like,
			$search_like
		) );

		// Search partners
		$partners = $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM {$partners_table} WHERE company_name LIKE %s OR email LIKE %s ORDER BY company_name ASC LIMIT 10",
			$search_like,
			$search_like
		) );

		// Search service records
		$records = $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM {$records_table} WHERE notes LIKE %s ORDER BY service_date DESC LIMIT 10",
			$search_like
		) );

		?>
		<div class="psp-search-container">
			<h2><?php printf( esc_html__( 'Search Results for: %s', 'psp' ), '<em>' . esc_html( $search_term ) . '</em>' ); ?></h2>

			<?php if ( ! empty( $tickets ) ) : ?>
			<div class="psp-search-section">
				<h3><?php esc_html_e( 'Tickets', 'psp' ); ?> (<?php echo count( $tickets ); ?>)</h3>
				<ul class="psp-search-results">
					<?php foreach ( $tickets as $ticket ) : ?>
					<li>
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=psp-tickets&ticket_id=' . $ticket->id ) ); ?>">
							<strong><?php echo esc_html( $ticket->subject ); ?></strong>
							<span class="psp-search-meta">Status: <?php echo esc_html( $ticket->status ); ?> | <?php echo esc_html( $ticket->created_at ); ?></span>
						</a>
					</li>
					<?php endforeach; ?>
				</ul>
			</div>
			<?php endif; ?>

			<?php if ( ! empty( $partners ) ) : ?>
			<div class="psp-search-section">
				<h3><?php esc_html_e( 'Partners', 'psp' ); ?> (<?php echo count( $partners ); ?>)</h3>
				<ul class="psp-search-results">
					<?php foreach ( $partners as $partner ) : ?>
					<li>
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=psp-partners&partner_id=' . $partner->id ) ); ?>">
							<strong><?php echo esc_html( $partner->name ); ?></strong>
							<span class="psp-search-meta"><?php echo esc_html( $partner->contact_email ); ?></span>
						</a>
					</li>
					<?php endforeach; ?>
				</ul>
			</div>
			<?php endif; ?>

			<?php if ( ! empty( $records ) ) : ?>
			<div class="psp-search-section">
				<h3><?php esc_html_e( 'Service Records', 'psp' ); ?> (<?php echo count( $records ); ?>)</h3>
				<ul class="psp-search-results">
					<?php foreach ( $records as $record ) : ?>
					<li>
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=psp-service-records&record_id=' . $record->id ) ); ?>">
							<strong><?php echo esc_html( $record->service_date ); ?></strong>
							<span class="psp-search-meta"><?php echo esc_html( wp_trim_words( $record->notes, 15 ) ); ?></span>
						</a>
					</li>
					<?php endforeach; ?>
				</ul>
			</div>
			<?php endif; ?>

			<?php if ( empty( $tickets ) && empty( $partners ) && empty( $records ) ) : ?>
			<p class="psp-no-results"><?php esc_html_e( 'No results found. Try a different search term.', 'psp' ); ?></p>
			<?php endif; ?>
		</div>
		<?php

		return ob_get_clean();
	}

	/**
	 * Render knowledge base
	 *
	 * @return string HTML output
	 */
	public static function render_knowledge_base() {
		if ( ! is_user_logged_in() ) {
			return '<p>' . esc_html__( 'Please log in to view the knowledge base.', 'psp' ) . '</p>';
		}

		self::enqueue_assets();

		ob_start();

		$args = array(
			'post_type'      => 'psp_kb',
			'posts_per_page' => -1,
			'orderby'        => 'title',
			'order'          => 'ASC',
		);

		$kb_posts = get_posts( $args );

		?>
		<div class="psp-kb-container">
			<div class="psp-kb-header">
				<input type="text" id="psp-kb-search" class="psp-search-input" placeholder="<?php esc_attr_e( 'Search knowledge base...', 'psp' ); ?>">
			</div>

			<div class="psp-kb-categories">
				<?php
				$categories = get_terms( array(
					'taxonomy'   => 'psp_kb_category',
					'hide_empty' => true,
				) );

				if ( ! empty( $categories ) && ! is_wp_error( $categories ) ) :
					foreach ( $categories as $category ) :
				?>
					<div class="psp-kb-category">
						<h3><?php echo esc_html( $category->name ); ?></h3>
						<?php if ( $category->description ) : ?>
						<p class="psp-kb-category-desc"><?php echo esc_html( $category->description ); ?></p>
						<?php endif; ?>
						
						<?php
						$cat_posts = get_posts( array(
							'post_type'      => 'psp_kb',
							'posts_per_page' => -1,
							'tax_query'      => array(
								array(
									'taxonomy' => 'psp_kb_category',
									'field'    => 'term_id',
									'terms'    => $category->term_id,
								),
							),
						) );

						if ( ! empty( $cat_posts ) ) :
						?>
							<ul class="psp-kb-articles">
								<?php foreach ( $cat_posts as $post ) : ?>
								<li>
									<a href="<?php echo esc_url( get_permalink( $post->ID ) ); ?>">
										<?php echo esc_html( $post->post_title ); ?>
									</a>
								</li>
								<?php endforeach; ?>
							</ul>
						<?php endif; ?>
					</div>
				<?php
					endforeach;
				endif;
				?>
			</div>

			<?php if ( empty( $categories ) || is_wp_error( $categories ) ) : ?>
				<p class="psp-no-kb"><?php esc_html_e( 'No knowledge base articles found.', 'psp' ); ?></p>
			<?php endif; ?>
		</div>
		<?php

		return ob_get_clean();
	}

	/**
	 * Render user dashboard
	 *
	 * @return string HTML output
	 */
	public static function render_dashboard() {
		if ( ! is_user_logged_in() ) {
			return self::render_login();
		}

		self::enqueue_assets();

		ob_start();

		$user = wp_get_current_user();
		$role = $user->roles[0] ?? '';

		?>
		<div class="psp-dashboard-container">
			<div class="psp-dashboard-header">
				<h1><?php esc_html_e( 'My Dashboard', 'psp' ); ?></h1>
				<div class="psp-user-welcome">
					<?php printf( esc_html__( 'Welcome back, %s!', 'psp' ), esc_html( $user->display_name ) ); ?>
				</div>
			</div>

			<div class="psp-dashboard-grid">
				<div class="psp-dashboard-section">
					<h2><?php esc_html_e( 'My Tickets', 'psp' ); ?></h2>
					<?php echo self::render_tickets(); ?>
				</div>

				<div class="psp-dashboard-section">
					<h2><?php esc_html_e( 'Recent Notifications', 'psp' ); ?></h2>
					<?php echo self::render_notifications(); ?>
				</div>

				<div class="psp-dashboard-section">
					<h2><?php esc_html_e( 'Upcoming Events', 'psp' ); ?></h2>
					<?php echo self::render_calendar(); ?>
				</div>

				<?php if ( in_array( $role, array( 'administrator', 'psp_support', 'psp_partner' ), true ) ) : ?>
				<div class="psp-dashboard-section">
					<h2><?php esc_html_e( 'Service Records', 'psp' ); ?></h2>
					<?php echo self::render_service_records(); ?>
				</div>
				<?php endif; ?>
			</div>

			<div class="psp-dashboard-actions">
				<a href="<?php echo esc_url( admin_url( 'profile.php' ) ); ?>" class="psp-btn psp-btn-primary">
					<?php esc_html_e( 'Edit Profile', 'psp' ); ?>
				</a>
				<a href="<?php echo esc_url( wp_logout_url( home_url() ) ); ?>" class="psp-btn psp-btn-secondary">
					<?php esc_html_e( 'Logout', 'psp' ); ?>
				</a>
			</div>
		</div>
		<?php

		return ob_get_clean();
	}

	/**
	 * Render partner map
	 *
	 * @return string HTML output
	 */
	public static function render_map() {
		ob_start();

		?>
		<div class="psp-map-container">
			<div id="psp-partner-map" class="psp-map"></div>
		</div>
		<?php

		return ob_get_clean();
	}

	/**
	 * Render tickets list
	 *
	 * @return string HTML output
	 */
	public static function render_tickets() {
		if ( ! is_user_logged_in() ) {
			return '<p>' . esc_html__( 'Please log in to view tickets.', 'psp' ) . '</p>';
		}

		ob_start();

		global $wpdb;
		$table_name = $wpdb->prefix . 'psp_tickets';
		
		// Check if table exists before querying
		if ( ! self::table_exists( $table_name ) ) {
			echo '<div class="psp-notice psp-notice-info">';
			echo '<p>' . esc_html__( 'Ticket data is being initialized. Please refresh the page in a moment.', 'psp' ) . '</p>';
			echo '</div>';
			return ob_get_clean();
		}
		
		$user = wp_get_current_user();
		$role = $user->roles[0] ?? '';

		// Build query based on role
		if ( in_array( $role, array( 'administrator', 'psp_support' ), true ) ) {
			$tickets = $wpdb->get_results( "SELECT * FROM {$table_name} ORDER BY created_at DESC LIMIT 10" );
		} else {
			$tickets = $wpdb->get_results( $wpdb->prepare(
				"SELECT * FROM {$table_name} WHERE created_by = %d ORDER BY created_at DESC LIMIT 10",
				$user->ID
			) );
		}

		?>
		<div class="psp-tickets-list">
			<?php if ( ! empty( $tickets ) ) : ?>
				<table class="psp-table">
					<thead>
						<tr>
							<th><?php esc_html_e( 'ID', 'psp' ); ?></th>
							<th><?php esc_html_e( 'Subject', 'psp' ); ?></th>
							<th><?php esc_html_e( 'Status', 'psp' ); ?></th>
							<th><?php esc_html_e( 'Priority', 'psp' ); ?></th>
							<th><?php esc_html_e( 'Created', 'psp' ); ?></th>
							<th><?php esc_html_e( 'Actions', 'psp' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $tickets as $ticket ) : ?>
						<tr>
							<td>#<?php echo esc_html( $ticket->id ); ?></td>
							<td><?php echo esc_html( $ticket->subject ?? __( 'No Subject', 'psp' ) ); ?></td>
							<td><span class="psp-status-badge psp-status-<?php echo esc_attr( $ticket->status ); ?>">
								<?php echo esc_html( ucfirst( $ticket->status ) ); ?>
							</span></td>
							<td><span class="psp-priority-badge psp-priority-<?php echo esc_attr( $ticket->priority ?? 'normal' ); ?>">
								<?php echo esc_html( ucfirst( $ticket->priority ?? 'normal' ) ); ?>
							</span></td>
							<td><?php echo esc_html( date_i18n( get_option( 'date_format' ), strtotime( $ticket->created_at ) ) ); ?></td>
							<td>
								<button class="psp-btn psp-btn-small psp-btn-view-ticket" data-ticket-id="<?php echo esc_attr( $ticket->id ); ?>">
									<?php esc_html_e( 'View', 'psp' ); ?>
								</button>
							</td>
						</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			<?php else : ?>
				<p class="psp-no-tickets"><?php esc_html_e( 'No tickets found.', 'psp' ); ?></p>
			<?php endif; ?>

			<div class="psp-tickets-actions">
				<button class="psp-btn psp-btn-primary psp-btn-create-ticket">
					<?php esc_html_e( 'Create New Ticket', 'psp' ); ?>
				</button>
			</div>
		</div>
		<?php

		return ob_get_clean();
	}

	/**
	 * Render notifications
	 *
	 * @return string HTML output
	 */
	public static function render_notifications() {
		if ( ! is_user_logged_in() ) {
			return '<p>' . esc_html__( 'Please log in to view notifications.', 'psp' ) . '</p>';
		}

		ob_start();

		$user = wp_get_current_user();
		
		// Get user notifications (custom implementation or use WordPress notifications)
		$notifications = get_user_meta( $user->ID, 'psp_notifications', true );
		if ( ! is_array( $notifications ) ) {
			$notifications = array();
		}

		// Limit to 5 most recent
		$notifications = array_slice( $notifications, 0, 5 );

		?>
		<div class="psp-notifications-list">
			<?php if ( ! empty( $notifications ) ) : ?>
				<ul class="psp-notifications">
					<?php foreach ( $notifications as $notification ) : ?>
					<li class="psp-notification <?php echo esc_attr( $notification['read'] ?? false ? 'read' : 'unread' ); ?>">
						<div class="psp-notification-content">
							<span class="psp-notification-title"><?php echo esc_html( $notification['title'] ?? '' ); ?></span>
							<span class="psp-notification-message"><?php echo esc_html( $notification['message'] ?? '' ); ?></span>
							<span class="psp-notification-time"><?php echo esc_html( human_time_diff( $notification['timestamp'] ?? time(), time() ) . ' ago' ); ?></span>
						</div>
					</li>
					<?php endforeach; ?>
				</ul>
			<?php else : ?>
				<p class="psp-no-notifications"><?php esc_html_e( 'No notifications.', 'psp' ); ?></p>
			<?php endif; ?>

			<div class="psp-notifications-actions">
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=psp-notifications' ) ); ?>" class="psp-btn psp-btn-small">
					<?php esc_html_e( 'View All', 'psp' ); ?>
				</a>
			</div>
		</div>
		<?php

		return ob_get_clean();
	}

	/**
	 * Render calendar
	 *
	 * @return string HTML output
	 */
	public static function render_calendar() {
		if ( ! is_user_logged_in() ) {
			return '<p>' . esc_html__( 'Please log in to view the calendar.', 'psp' ) . '</p>';
		}

		ob_start();

		?>
		<div class="psp-calendar-container">
			<div id="psp-calendar" class="psp-calendar"></div>
		</div>
		<?php

		return ob_get_clean();
	}

	/**
	 * Render service records
	 *
	 * @return string HTML output
	 */
	public static function render_service_records() {
		if ( ! is_user_logged_in() ) {
			return '<p>' . esc_html__( 'Please log in to view service records.', 'psp' ) . '</p>';
		}

		ob_start();

		global $wpdb;
		$table_name = $wpdb->prefix . 'psp_service_records';
		$user = wp_get_current_user();
		$role = $user->roles[0] ?? '';

		// Build query based on role
		if ( in_array( $role, array( 'administrator', 'psp_support' ), true ) ) {
			$records = $wpdb->get_results( "SELECT * FROM {$table_name} ORDER BY service_date DESC LIMIT 10" );
		} else {
			$records = $wpdb->get_results( $wpdb->prepare(
				"SELECT * FROM {$table_name} WHERE partner_id = %d ORDER BY service_date DESC LIMIT 10",
				$user->ID
			) );
		}

		?>
		<div class="psp-service-records-list">
			<?php if ( ! empty( $records ) ) : ?>
				<table class="psp-table">
					<thead>
						<tr>
							<th><?php esc_html_e( 'ID', 'psp' ); ?></th>
							<th><?php esc_html_e( 'Service Date', 'psp' ); ?></th>
							<th><?php esc_html_e( 'Type', 'psp' ); ?></th>
							<th><?php esc_html_e( 'Status', 'psp' ); ?></th>
							<th><?php esc_html_e( 'Actions', 'psp' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $records as $record ) : ?>
						<tr>
							<td>#<?php echo esc_html( $record->id ); ?></td>
							<td><?php echo esc_html( date_i18n( get_option( 'date_format' ), strtotime( $record->service_date ) ) ); ?></td>
							<td><?php echo esc_html( $record->service_type ?? '' ); ?></td>
							<td><span class="psp-status-badge psp-status-<?php echo esc_attr( $record->status ); ?>">
								<?php echo esc_html( ucfirst( $record->status ) ); ?>
							</span></td>
							<td>
								<button class="psp-btn psp-btn-small psp-btn-view-record" data-record-id="<?php echo esc_attr( $record->id ); ?>">
									<?php esc_html_e( 'View', 'psp' ); ?>
								</button>
							</td>
						</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			<?php else : ?>
				<p class="psp-no-records"><?php esc_html_e( 'No service records found.', 'psp' ); ?></p>
			<?php endif; ?>
		</div>
		<?php

		return ob_get_clean();
	}

	/**
	 * Render support tools (admin/support only)
	 *
	 * @return string HTML output
	 */
	public static function render_support_tools() {
		if ( ! is_user_logged_in() ) {
			return '<p>' . esc_html__( 'Please log in to access support tools.', 'psp' ) . '</p>';
		}

		$user = wp_get_current_user();
		$role = $user->roles[0] ?? '';

		if ( ! in_array( $role, array( 'administrator', 'psp_support' ), true ) ) {
			return '<p>' . esc_html__( 'Access denied.', 'psp' ) . '</p>';
		}

		ob_start();

		?>
		<div class="psp-support-tools">
			<ul class="psp-tools-list">
				<li>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=psp-bulk-import' ) ); ?>" class="psp-tool-link">
						<span class="dashicons dashicons-upload"></span>
						<?php esc_html_e( 'Bulk Import', 'psp' ); ?>
					</a>
				</li>
				<li>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=psp-user-management' ) ); ?>" class="psp-tool-link">
						<span class="dashicons dashicons-admin-users"></span>
						<?php esc_html_e( 'User Management', 'psp' ); ?>
					</a>
				</li>
				<li>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=psp-audit-log' ) ); ?>" class="psp-tool-link">
						<span class="dashicons dashicons-list-view"></span>
						<?php esc_html_e( 'Audit Log', 'psp' ); ?>
					</a>
				</li>
				<li>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=psp-settings' ) ); ?>" class="psp-tool-link">
						<span class="dashicons dashicons-admin-settings"></span>
						<?php esc_html_e( 'Settings', 'psp' ); ?>
					</a>
				</li>
			</ul>
		</div>
		<?php

		return ob_get_clean();
	}

	/**
	 * Render tickets list page
	 *
	 * @return string HTML output
	 */
	public static function render_tickets_list() {
		if ( ! is_user_logged_in() ) {
			return '<p>' . esc_html__( 'Please log in to view tickets.', 'psp' ) . '</p>';
		}

		self::enqueue_assets();

		// Include the template
		$template = plugin_dir_path( dirname( __FILE__ ) ) . 'views/tickets-list.php';
		if ( file_exists( $template ) ) {
			ob_start();
			include $template;
			return ob_get_clean();
		}

		return '<p>' . esc_html__( 'Tickets template not found.', 'psp' ) . '</p>';
	}

	/**
	 * Render ticket detail page
	 *
	 * @return string HTML output
	 */
	public static function render_tickets_detail() {
		if ( ! is_user_logged_in() ) {
			return '<p>' . esc_html__( 'Please log in to view ticket details.', 'psp' ) . '</p>';
		}

		self::enqueue_assets();

		// Include the template
		$template = plugin_dir_path( dirname( __FILE__ ) ) . 'views/tickets-detail.php';
		if ( file_exists( $template ) ) {
			ob_start();
			include $template;
			return ob_get_clean();
		}

		return '<p>' . esc_html__( 'Ticket detail template not found.', 'psp' ) . '</p>';
	}

	/**
	 * Render ticket create page
	 *
	 * @return string HTML output
	 */
	public static function render_tickets_create() {
		if ( ! is_user_logged_in() ) {
			return '<p>' . esc_html__( 'Please log in to create a ticket.', 'psp' ) . '</p>';
		}

		self::enqueue_assets();

		// Include the template
		$template = plugin_dir_path( dirname( __FILE__ ) ) . 'views/tickets-create.php';
		if ( file_exists( $template ) ) {
			ob_start();
			include $template;
			return ob_get_clean();
		}

		return '<p>' . esc_html__( 'Ticket create template not found.', 'psp' ) . '</p>';
	}
}

