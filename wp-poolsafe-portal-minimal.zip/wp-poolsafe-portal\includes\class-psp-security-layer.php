<?php
/**
 * Security Layer - Comprehensive Security Enhancements
 * 
 * Features:
 * - Rate limiting and brute force protection
 * - Input validation and sanitization
 * - CSRF protection helpers
 * - IP whitelist/blacklist
 * - Security headers enforcement
 * - Encryption utilities
 * - Audit logging
 *
 * @package PSP
 * @version 3.2.5
 */

namespace PSP\Security;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * SecurityLayer Class - Comprehensive security management
 */
class SecurityLayer {

	/**
	 * Class version
	 */
	const VERSION = '3.2.5';

	/**
	 * Rate limiting data stored in transients
	 * Format: psp_sec_rl_{$key} => array of timestamps
	 */
	private static $rate_limits = array();

	/**
	 * Initialize security layer with WordPress hooks
	 */
	public static function init() {
		// Hook into REST API authentication
		add_filter( 'rest_authentication_errors', array( __CLASS__, 'check_rate_limits' ), 1 );
		
		// Security headers
		add_action( 'send_headers', array( __CLASS__, 'enforce_security_headers' ), 99 );
		
		// Login attempt tracking
		add_action( 'wp_login_failed', array( __CLASS__, 'log_failed_login' ) );
		add_action( 'wp_login', array( __CLASS__, 'log_successful_login' ), 10, 2 );
	}

	/**
	 * Check rate limits for current request
	 *
	 * @param mixed $errors Existing errors from other auth checks
	 * @return mixed Errors or null
	 */
	public static function check_rate_limits( $errors ) {
		if ( is_wp_error( $errors ) ) {
			return $errors;
		}

		$ip = self::get_client_ip();
		$key = 'psp_sec_rl_api_' . md5( $ip );
		$limit = 60; // Max 60 requests per minute
		$window = 60;

		if ( ! self::rate_limit( $key, $limit, $window ) ) {
			return new \WP_Error(
				'psp_rate_limit_exceeded',
				esc_html__( 'Too many requests. Please try again later.', 'psp' ),
				array( 'status' => 429 )
			);
		}

		return $errors;
	}

	/**
	 * Rate limiting implementation
	 *
	 * @param string $key    Rate limit key
	 * @param int    $limit  Max calls allowed
	 * @param int    $window Time window in seconds
	 * @return bool Whether action is allowed
	 */
	public static function rate_limit( $key, $limit = 10, $window = 60 ) {
		$transient_key = sanitize_key( $key );
		$current_count = (int) get_transient( $transient_key );

		if ( $current_count >= $limit ) {
			return false;
		}

		set_transient( $transient_key, $current_count + 1, $window );
		return true;
	}

	/**
	 * Enforce strict security headers
	 */
	public static function enforce_security_headers() {
		if ( ! is_ssl() ) {
			return;
		}

		// Strict Transport Security
		header( 'Strict-Transport-Security: max-age=31536000; includeSubDomains; preload' );

		// Content Security Policy (Report-Only)
		$csp = "default-src 'self'; " .
			"script-src 'self' 'unsafe-inline' 'unsafe-eval'; " .
			"style-src 'self' 'unsafe-inline'; " .
			"img-src 'self' data: https:; " .
			"font-src 'self' data:; " .
			"connect-src 'self' https:; " .
			"frame-ancestors 'none'; " .
			"base-uri 'self'; " .
			"form-action 'self';";

		header( "Content-Security-Policy-Report-Only: {$csp}" );

		// Additional security headers
		header( 'X-Content-Type-Options: nosniff' );
		header( 'X-Frame-Options: SAMEORIGIN' );
		header( 'X-XSS-Protection: 1; mode=block' );
		header( 'Referrer-Policy: strict-origin-when-cross-origin' );
		header( 'Permissions-Policy: geolocation=(), microphone=(), camera=()' );
	}

	/**
	 * Log failed login attempts
	 *
	 * @param string $username Username attempted
	 */
	public static function log_failed_login( $username ) {
		$ip = self::get_client_ip();
		error_log(
			sprintf(
				'[PSP Security] Failed login attempt for user "%s" from IP %s at %s',
				sanitize_user( $username ),
				$ip,
				current_time( 'mysql' )
			)
		);
	}

	/**
	 * Log successful login
	 *
	 * @param string   $user_login Username
	 * @param WP_User  $user       User object
	 */
	public static function log_successful_login( $user_login, $user ) {
		$ip = self::get_client_ip();
		error_log(
			sprintf(
				'[PSP Security] Successful login for user %d (%s) from IP %s at %s',
				$user->ID,
				$user_login,
				$ip,
				current_time( 'mysql' )
			)
		);
	}

	/**
	 * Get client IP address with proxy awareness
	 *
	 * @return string Client IP
	 */
	public static function get_client_ip() {
		$ip_keys = array(
			'HTTP_CF_CONNECTING_IP',
			'HTTP_X_FORWARDED_FOR',
			'HTTP_X_FORWARDED',
			'HTTP_FORWARDED_FOR',
			'HTTP_FORWARDED',
			'HTTP_CLIENT_IP',
			'REMOTE_ADDR',
		);

		foreach ( $ip_keys as $key ) {
			if ( ! empty( $_SERVER[ $key ] ) ) {
				$ips = explode( ',', sanitize_text_field( wp_unslash( $_SERVER[ $key ] ) ) );
				$ip  = trim( $ips[0] );
				if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) {
					return $ip;
				}
			}
		}

		return '127.0.0.1';
	}

	/**
	 * Validate and sanitize input based on type
	 *
	 * @param mixed  $input Input to validate
	 * @param string $type  Validation type (email, url, int, text, json, etc)
	 * @return mixed Sanitized value or false on validation failure
	 */
	public static function validate_input( $input, $type = 'text' ) {
		switch ( $type ) {
			case 'email':
				return is_email( $input ) ? sanitize_email( $input ) : false;

			case 'url':
				return filter_var( $input, FILTER_VALIDATE_URL ) ? esc_url_raw( $input ) : false;

			case 'int':
				return is_numeric( $input ) ? intval( $input ) : false;

			case 'json':
				$decoded = json_decode( $input, true );
				return json_last_error() === JSON_ERROR_NONE ? $decoded : false;

			case 'slug':
				return sanitize_title( $input );

			case 'text':
			default:
				return sanitize_text_field( $input );
		}
	}

	/**
	 * Check if IP is in whitelist
	 *
	 * @param string $ip IP address to check
	 * @return bool True if whitelisted
	 */
	public static function is_ip_whitelisted( $ip ) {
		$whitelist = get_option( 'psp_ip_whitelist', array() );
		return in_array( $ip, (array) $whitelist, true );
	}

	/**
	 * Check if IP is in blacklist
	 *
	 * @param string $ip IP address to check
	 * @return bool True if blacklisted
	 */
	public static function is_ip_blacklisted( $ip ) {
		$blacklist = get_option( 'psp_ip_blacklist', array() );
		if ( empty( $blacklist ) ) {
			return false;
		}

		foreach ( $blacklist as $blocked ) {
			if ( self::ip_in_range( $ip, $blocked ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Check if IP is in CIDR range
	 *
	 * @param string $ip    IP address
	 * @param string $range CIDR range
	 * @return bool Match result
	 */
	public static function ip_in_range( $ip, $range ) {
		if ( strpos( $range, '/' ) === false ) {
			return $ip === $range;
		}

		list( $subnet, $bits ) = explode( '/', $range );
		$ip = ip2long( $ip );
		$subnet = ip2long( $subnet );
		$mask = -1 << ( 32 - $bits );
		$subnet &= $mask;
		return ( $ip & $mask ) === $subnet;
	}

	/**
	 * Encrypt sensitive data (uses WordPress's built-in functions)
	 *
	 * @param string $data Data to encrypt
	 * @return string Encrypted data
	 */
	public static function encrypt_data( $data ) {
		if ( ! function_exists( 'openssl_encrypt' ) ) {
			return base64_encode( $data );
		}

		$key = wp_hash( 'psp_encryption_key' );
		$iv  = openssl_random_pseudo_bytes( openssl_cipher_iv_length( 'AES-128-CBC' ) );
		$encrypted = openssl_encrypt( $data, 'AES-128-CBC', $key, 0, $iv );

		return base64_encode( $iv . $encrypted );
	}

	/**
	 * Decrypt sensitive data
	 *
	 * @param string $encrypted Encrypted data
	 * @return string Decrypted data
	 */
	public static function decrypt_data( $encrypted ) {
		if ( ! function_exists( 'openssl_decrypt' ) ) {
			return base64_decode( $encrypted );
		}

		$key = wp_hash( 'psp_encryption_key' );
		$data = base64_decode( $encrypted );
		$iv = substr( $data, 0, openssl_cipher_iv_length( 'AES-128-CBC' ) );
		$encrypted = substr( $data, openssl_cipher_iv_length( 'AES-128-CBC' ) );

		return openssl_decrypt( $encrypted, 'AES-128-CBC', $key, 0, $iv );
	}

	/**
	 * Generate secure token
	 *
	 * @param int $length Token length
	 * @return string Secure token
	 */
	public static function generate_secure_token( $length = 32 ) {
		if ( function_exists( 'random_bytes' ) ) {
			return bin2hex( random_bytes( $length / 2 ) );
		}
		return bin2hex( openssl_random_pseudo_bytes( $length / 2 ) );
	}

	/**
	 * Check request signature (for API webhooks)
	 *
	 * @param string $payload Request payload
	 * @param string $signature Signature header
	 * @param string $secret    Shared secret
	 * @return bool Valid signature
	 */
	public static function verify_signature( $payload, $signature, $secret ) {
		$hash = hash_hmac( 'sha256', $payload, $secret );
		return hash_equals( $hash, $signature );
	}

	/**
	 * Get class version
	 *
	 * @return string Version string
	 */
	public static function get_version() {
		return self::VERSION;
	}
}

// Initialize security layer when plugin loads
if ( ! function_exists( 'psp_init_security' ) ) {
	function psp_init_security() {
		if ( class_exists( 'PSP\Security\SecurityLayer' ) ) {
			SecurityLayer::init();
		}
	}
	add_action( 'plugins_loaded', 'psp_init_security' );
}
