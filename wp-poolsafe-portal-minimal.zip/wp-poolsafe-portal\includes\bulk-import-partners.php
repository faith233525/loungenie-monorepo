<?php
/**
 * Bulk Partner Import Script
 * Imports all partners from CSV data into PoolSafe Portal
 * Run this from WordPress admin or via WP-CLI
 *
 * @package PoolSafe_Portal
 */

// Partner data - Tab-separated values
$partners_data = array(
    array('user_login' => 'adventureland', 'user_pass' => 'AdventurelandIA', 'units' => 15, 'number' => '8002557826', 'display_name' => 'Adventureland', 'top_colour' => 'Ice Blue', 'company_name' => 'Adventureland', 'management_company' => 'Palace Entertainment', 'street_address' => '3300 Adventureland Dr', 'city' => 'Altoona', 'state' => 'IA', 'zip' => '50009', 'country' => 'USA', 'lock' => 'L&F Lock', 'master_code' => '94091848', 'sub_master_code' => '236499', 'lock_part' => '3781745', 'key' => 'E2222'),
    array('user_login' => 'beechbend', 'user_pass' => 'BeechBendKY', 'units' => 19, 'number' => '2707817634', 'display_name' => 'Beech Bend Park & Splash Lagoon', 'top_colour' => 'Ice Blue', 'company_name' => 'Beech Bend Park & Splash Lagoon', 'management_company' => 'Beech Bend Park & Splash Lagoon', 'street_address' => '798 Beech Bend Rd', 'city' => 'Bowling Green', 'state' => 'KY', 'zip' => '42101', 'country' => 'USA', 'lock' => 'L&F Lock', 'master_code' => 'N/A', 'sub_master_code' => 'N/A', 'lock_part' => 'N/A', 'key' => 'N/A'),
    array('user_login' => 'bigdamwaterpark', 'user_pass' => 'BigDamAR', 'units' => 12, 'number' => '8707744677', 'display_name' => 'Big Dam Waterpark', 'top_colour' => 'Classic Blue', 'company_name' => 'Big Dam Waterpark', 'management_company' => 'P23 - Big Dam Waterpark', 'street_address' => '5501 Crossroads Pkwy', 'city' => 'Texarkana', 'state' => 'AR', 'zip' => '71854', 'country' => 'USA', 'lock' => 'L&F Lock', 'master_code' => '52738919', 'sub_master_code' => '652816', 'lock_part' => '3781744', 'key' => 'E2221'),
    array('user_login' => 'breakwaterbeach', 'user_pass' => 'BreakwaterBeachNJ', 'units' => 10, 'number' => '7327936488', 'display_name' => 'Breakwater Beach Waterpark', 'top_colour' => 'Ice Blue', 'company_name' => 'Breakwater Beach Waterpark', 'management_company' => 'Breakwater Beach Waterpark', 'street_address' => '800 Ocean Terrace', 'city' => 'Seaside Heights', 'state' => 'NJ', 'zip' => '8751', 'country' => 'USA', 'lock' => 'L&F Lock', 'master_code' => 'N/A', 'sub_master_code' => 'N/A', 'lock_part' => 'N/A', 'key' => 'N/A'),
    array('user_login' => 'calibunga', 'user_pass' => 'CaliBungaCA', 'units' => 26, 'number' => '4087677110', 'display_name' => 'CaliBunga Waterpark', 'top_colour' => 'Ice Blue', 'company_name' => 'CaliBunga Waterpark', 'management_company' => 'CaliBunga Waterpark', 'street_address' => '2333 S White Rd', 'city' => 'San Jose', 'state' => 'CA', 'zip' => '95148', 'country' => 'USA', 'lock' => 'L&F Lock', 'master_code' => '97408180', 'sub_master_code' => '518922', 'lock_part' => 'Default', 'key' => 'E0208'),
    array('user_login' => 'cowabungabay', 'user_pass' => 'CowabungaBayNV', 'units' => 48, 'number' => '7025669000', 'display_name' => 'Cowabunga Bay', 'top_colour' => 'BASF 4616 Yellow', 'company_name' => 'Cowabunga Bay', 'management_company' => 'PYEK', 'street_address' => '900 Galleria Dr', 'city' => 'Henderson', 'state' => 'NV', 'zip' => '89011', 'country' => 'USA', 'lock' => 'L&F Lock', 'master_code' => '31963865', 'sub_master_code' => '127206', 'lock_part' => '3781743', 'key' => 'E2220'),
    array('user_login' => 'cowabungacanyon', 'user_pass' => 'CowabungaCanyonNV', 'units' => 35, 'number' => '7028966530', 'display_name' => 'Cowabunga Canyon', 'top_colour' => 'PoolSafe Orange', 'company_name' => 'Cowabunga Canyon', 'management_company' => 'PYEK', 'street_address' => '121 E Sunset Rd', 'city' => 'Las Vegas', 'state' => 'NV', 'zip' => '89119', 'country' => 'USA', 'lock' => 'L&F Lock', 'master_code' => '55915569', 'sub_master_code' => '855413', 'lock_part' => '3781742', 'key' => 'E2219'),
    array('user_login' => 'daytonalagoon', 'user_pass' => 'DaytonaLagoonFL', 'units' => 24, 'number' => '3862545020', 'display_name' => 'Daytona Lagoon', 'top_colour' => 'Classic Blue', 'company_name' => 'Daytona Lagoon', 'management_company' => 'Daytona Lagoon', 'street_address' => '601 Earl St', 'city' => 'Daytona Beach', 'state' => 'FL', 'zip' => '32118', 'country' => 'USA', 'lock' => 'L&F Lock', 'master_code' => '83952987', 'sub_master_code' => '406805', 'lock_part' => 'Default', 'key' => 'E0208'),
    array('user_login' => 'dutchwonderland', 'user_pass' => 'DutchWonderlandPA', 'units' => 9, 'number' => '7173978200', 'display_name' => 'Dutch Wonderland', 'top_colour' => 'x6 Trojan Blue / x3 Yellow', 'company_name' => 'Dutch Wonderland', 'management_company' => 'Palace Entertainment', 'street_address' => '2249 Lincoln Hwy E', 'city' => 'Lancaster', 'state' => 'PA', 'zip' => '17602', 'country' => 'USA', 'lock' => 'L&F Lock', 'master_code' => '99205955', 'sub_master_code' => '242983', 'lock_part' => '3781747', 'key' => 'E2224'),
    array('user_login' => 'fantasyworld', 'user_pass' => 'FantasyWorldFL', 'units' => 10, 'number' => '4073961808', 'display_name' => 'Fantasy World Resort', 'top_colour' => 'Ice Blue', 'company_name' => 'Fantasy World Resort', 'management_company' => 'Fantasy World Resort', 'street_address' => '5005 Kyngâ€™s Heath Rd', 'city' => 'Kissimmee', 'state' => 'FL', 'zip' => '34746', 'country' => 'USA', 'lock' => 'L&F Lock', 'master_code' => '67643313', 'sub_master_code' => '577896', 'lock_part' => '3781742', 'key' => 'E2219'),
    array('user_login' => 'idlewild', 'user_pass' => 'IdlewildPA', 'units' => 12, 'number' => '7242383666', 'display_name' => 'Idlewild & SoakZone', 'top_colour' => 'Ice Blue', 'company_name' => 'Idlewild & SoakZone', 'management_company' => 'Palace Entertainment', 'street_address' => '2574 US-30', 'city' => 'Ligonier', 'state' => 'PA', 'zip' => '15658', 'country' => 'USA', 'lock' => 'L&F Lock', 'master_code' => '73974808', 'sub_master_code' => '520809', 'lock_part' => '3781744', 'key' => 'E2221'),
    array('user_login' => 'lagoonfest', 'user_pass' => 'LagoonFestTX', 'units' => 23, 'number' => '3469663378', 'display_name' => 'Lagoon Fest Texas', 'top_colour' => 'Yellow / Ice Blue', 'company_name' => 'Lagoon Fest Texas', 'management_company' => 'Lagoon Fest Texas', 'street_address' => '12600 Crystal View Blvd', 'city' => 'Texas City', 'state' => 'TX', 'zip' => '77568', 'country' => 'USA', 'lock' => 'L&F Lock', 'master_code' => 'N/A', 'sub_master_code' => 'N/A', 'lock_part' => 'N/A', 'key' => 'N/A'),
    array('user_login' => 'lakecompounce', 'user_pass' => 'LakeCompounceCT', 'units' => 40, 'number' => '8605831234', 'display_name' => 'Lake Compounce', 'top_colour' => 'Ice Blue', 'company_name' => 'Lake Compounce', 'management_company' => 'Palace Entertainment', 'street_address' => '822 Lake Ave', 'city' => 'Bristol', 'state' => 'CT', 'zip' => '6010', 'country' => 'USA', 'lock' => 'L&F Lock', 'master_code' => '43877608', 'sub_master_code' => '177973', 'lock_part' => '3781746', 'key' => 'E2223'),
    array('user_login' => 'margar_negril', 'user_pass' => 'MargaritavilleNegrilJM', 'units' => 10, 'number' => '8769574467', 'display_name' => 'Margaritaville Beach Resort Negril', 'top_colour' => 'Ice Blue', 'company_name' => 'Margaritaville Beach Resort Negril', 'management_company' => 'Margaritaville Caribbean', 'street_address' => 'Norman Manley Blvd', 'city' => 'Negril', 'state' => '-', 'zip' => '-', 'country' => 'Jamaica', 'lock' => 'L&F Lock', 'master_code' => '80788810', 'sub_master_code' => '795888', 'lock_part' => '3781742|3781747', 'key' => 'E2219|E2224'),
    array('user_login' => 'Margaritaville_ocho', 'user_pass' => 'MargaritavilleOchoJM', 'units' => 18, 'number' => '8769574467', 'display_name' => 'Margaritaville Beach Resort Ocho Rios', 'top_colour' => 'Ice Blue', 'company_name' => 'Margaritaville Beach Resort Ocho Rios', 'management_company' => 'Margaritaville Caribbean', 'street_address' => 'Ocho Rios', 'city' => 'Ocho Rios', 'state' => '-', 'zip' => '-', 'country' => 'Jamaica', 'lock' => 'L&F Lock', 'master_code' => '17756403', 'sub_master_code' => '434619', 'lock_part' => 'Default', 'key' => 'E0208'),
    array('user_login' => 'Margaritaville_turq', 'user_pass' => 'MargaritavilleTurksTC', 'units' => 32, 'number' => '8769574467', 'display_name' => 'Margaritaville Beach Resort Turks & Caicos', 'top_colour' => 'Ice Blue', 'company_name' => 'Margaritaville Beach Resort Turks & Caicos', 'management_company' => 'Margaritaville Caribbean', 'street_address' => 'Providenciales', 'city' => 'Providenciales', 'state' => '-', 'zip' => '-', 'country' => 'Turks & Caicos', 'lock' => 'L&F Lock', 'master_code' => 'N/A', 'sub_master_code' => 'N/A', 'lock_part' => 'N/A', 'key' => 'N/A'),
    array('user_login' => 'massasnutten', 'user_pass' => 'MassanuttenVA', 'units' => 25, 'number' => '5402899441', 'display_name' => 'Massanutten WaterPark', 'top_colour' => 'Ice Blue / Yellow', 'company_name' => 'Massanutten WaterPark', 'management_company' => 'Massanutten Resort', 'street_address' => '1200 Adventure Dr', 'city' => 'Massanutten', 'state' => 'VA', 'zip' => '22840', 'country' => 'USA', 'lock' => 'L&F Lock', 'master_code' => '24192527', 'sub_master_code' => '259460', 'lock_part' => 'Default', 'key' => 'E0208'),
    array('user_login' => 'miamibiscayne', 'user_pass' => 'MiamiBiscayneFL', 'units' => 6, 'number' => '3058664000', 'display_name' => 'Miami Biscayne', 'top_colour' => 'Ice Blue', 'company_name' => 'Miami Biscayne', 'management_company' => 'Miami Biscayne', 'street_address' => '7960 Biscayne Point Cir', 'city' => 'Miami', 'state' => 'FL', 'zip' => '33141', 'country' => 'USA', 'lock' => 'L&F Lock', 'master_code' => '40294727', 'sub_master_code' => '100515', 'lock_part' => 'Default', 'key' => 'E0208'),
    array('user_login' => 'noahsark', 'user_pass' => 'NoahsArkWI', 'units' => 60, 'number' => '6082546351', 'display_name' => 'Noah\'s Ark Waterpark', 'top_colour' => 'Yellow', 'company_name' => 'Noah\'s Ark Waterpark', 'management_company' => 'Palace Entertainment', 'street_address' => '1410 Wisconsin Dells Pkwy', 'city' => 'Wisconsin Dells', 'state' => 'WI', 'zip' => '53965', 'country' => 'USA', 'lock' => 'L&F Lock', 'master_code' => '65363112', 'sub_master_code' => '273690', 'lock_part' => '3781744', 'key' => 'E2221'),
    array('user_login' => 'olympia', 'user_pass' => 'OlympiaBR', 'units' => 30, 'number' => '4073511800', 'display_name' => 'Olympia Waterpark', 'top_colour' => 'Ice Blue', 'company_name' => 'Olympia Waterpark', 'management_company' => 'Olympia Waterpark', 'street_address' => '3000 S John Young Pkwy', 'city' => 'Orlando', 'state' => 'FL', 'zip' => '32805', 'country' => 'USA', 'lock' => 'L&F Lock', 'master_code' => 'N/A', 'sub_master_code' => 'N/A', 'lock_part' => 'N/A', 'key' => 'N/A'),
    array('user_login' => 'orlandoworldcentre', 'user_pass' => 'OrlandoWorldCenterFL', 'units' => 38, 'number' => '4072394200', 'display_name' => 'Orlando World Center Marriott', 'top_colour' => 'Ice Blue / Yellow', 'company_name' => 'Orlando World Center Marriott', 'management_company' => 'Orlando World Center Marriott', 'street_address' => '8701 World Center Dr', 'city' => 'Orlando', 'state' => 'FL', 'zip' => '32821', 'country' => 'USA', 'lock' => 'L&F Lock', 'master_code' => 'N/A', 'sub_master_code' => 'N/A', 'lock_part' => 'N/A', 'key' => 'N/A'),
    array('user_login' => 'owa', 'user_pass' => 'OWAAL', 'units' => 37, 'number' => '2519232111', 'display_name' => 'OWA Tropic Falls Indoor Waterpark', 'top_colour' => 'Ice Blue', 'company_name' => 'OWA Tropic Falls Indoor Waterpark', 'management_company' => 'OWA', 'street_address' => '1501 S OWA Blvd', 'city' => 'Foley', 'state' => 'AL', 'zip' => '36535', 'country' => 'USA', 'lock' => 'L&F Lock', 'master_code' => '67558085', 'sub_master_code' => '532380', 'lock_part' => 'Default', 'key' => 'E0208'),
    array('user_login' => 'piratesbay', 'user_pass' => 'PiratesBayTX', 'units' => 20, 'number' => '2814212300', 'display_name' => 'Pirates Bay', 'top_colour' => 'Classic Blue', 'company_name' => 'Pirates Bay', 'management_company' => 'P23 - Pirates Bay', 'street_address' => '5300 E Rd', 'city' => 'Baytown', 'state' => 'TX', 'zip' => '77521', 'country' => 'USA', 'lock' => 'L&F Lock', 'master_code' => '75768676', 'sub_master_code' => '597791', 'lock_part' => 'Default', 'key' => 'E0208'),
    array('user_login' => 'piratescove', 'user_pass' => 'PiratesCoveBS', 'units' => 25, 'number' => '2423733434', 'display_name' => 'Pirates Cove Zipline & Water Park', 'top_colour' => 'Coral', 'company_name' => 'Pirates Cove Zipline & Water Park', 'management_company' => 'Pirates Cove Zipline & Water Park', 'street_address' => 'Taino Beach West, West Beach Rd', 'city' => 'Freeport', 'state' => '-', 'zip' => '-', 'country' => 'Bahamas', 'lock' => 'L&F Lock', 'master_code' => '75103113', 'sub_master_code' => '60535238', 'lock_part' => 'Make 072', 'key' => ''),
    array('user_login' => 'ragingwaters', 'user_pass' => 'RagingWatersCA', 'units' => 61, 'number' => '9095992267', 'display_name' => 'Raging Waters', 'top_colour' => 'Ice Blue', 'company_name' => 'Raging Waters', 'management_company' => 'Palace Entertainment', 'street_address' => '111 Raging Waters Dr', 'city' => 'San Dimas', 'state' => 'CA', 'zip' => '91773', 'country' => 'USA', 'lock' => 'L&F Lock', 'master_code' => '61734195', 'sub_master_code' => '597220', 'lock_part' => '3781742', 'key' => 'E2219'),
    array('user_login' => 'sandcastle', 'user_pass' => 'SandcastlePA', 'units' => 20, 'number' => '4128287575', 'display_name' => 'Sandcastle', 'top_colour' => 'Ice Blue', 'company_name' => 'Sandcastle', 'management_company' => 'Palace Entertainment', 'street_address' => '1000 Sandcastle Dr', 'city' => 'Pittsburgh', 'state' => 'PA', 'zip' => '15120', 'country' => 'USA', 'lock' => 'L&F Lock', 'master_code' => '73404288', 'sub_master_code' => '769708', 'lock_part' => '3781746', 'key' => 'E2223'),
    array('user_login' => 'serengetiwaterpark', 'user_pass' => 'SerengetiSpringsUT', 'units' => 32, 'number' => '6016025777', 'display_name' => 'Serengeti Springs Water Park', 'top_colour' => 'Ice Blue', 'company_name' => 'Serengeti Springs Water Park', 'management_company' => 'Serengeti Springs Water Park', 'street_address' => '1700 Hardy Street', 'city' => 'Hattiesburg', 'state' => 'MS', 'zip' => '39401', 'country' => 'USA', 'lock' => 'L&F Lock', 'master_code' => '22453071', 'sub_master_code' => '465300', 'lock_part' => 'Default', 'key' => 'E0208'),
    array('user_login' => 'shipwreckisland', 'user_pass' => 'ShipwreckIslandFL', 'units' => 10, 'number' => '8502354444', 'display_name' => 'Shipwreck Island', 'top_colour' => 'Classic Blue', 'company_name' => 'Shipwreck Island', 'management_company' => 'Shipwreck Island', 'street_address' => '12202 Front Beach Rd', 'city' => 'Panama City Beach', 'state' => 'FL', 'zip' => '32407', 'country' => 'USA', 'lock' => 'L&F Lock', 'master_code' => '28779009', 'sub_master_code' => '241195', 'lock_part' => '-', 'key' => 'E2219'),
    array('user_login' => 'sixflagscarowinds', 'user_pass' => 'SixFlagsCarowindsNC', 'units' => 12, 'number' => '8033960800', 'display_name' => 'Six Flags Carowinds', 'top_colour' => 'Ice Blue', 'company_name' => 'Six Flags Carowinds', 'management_company' => 'Six Flags Carowinds', 'street_address' => '14523 Carowinds Blvd', 'city' => 'Charlotte', 'state' => 'NC', 'zip' => '28273', 'country' => 'USA', 'lock' => 'L&F Lock', 'master_code' => '46294744', 'sub_master_code' => '556232', 'lock_part' => 'Default', 'key' => 'E0208'),
    array('user_login' => 'sixflagsfiestatexas', 'user_pass' => 'SixFlagsFiestaTX', 'units' => 39, 'number' => '2106975052', 'display_name' => 'Six Flags Fiesta Texas', 'top_colour' => 'Ice Blue', 'company_name' => 'Six Flags Fiesta Texas', 'management_company' => 'Six Flags Fiesta Texas', 'street_address' => '17000 W I-10', 'city' => 'San Antonio', 'state' => 'TX', 'zip' => '78257', 'country' => 'USA', 'lock' => 'L&F Lock', 'master_code' => '64776193', 'sub_master_code' => '350614', 'lock_part' => 'Default', 'key' => 'E0208'),
    array('user_login' => 'sixflagsphoenix', 'user_pass' => 'SixFlagsPhoenixAZ', 'units' => 18, 'number' => '6232012000', 'display_name' => 'Six Flags Hurricane Harbour', 'top_colour' => 'Ice Blue', 'company_name' => 'Six Flags Hurricane Harbour', 'management_company' => 'Six Flags Hurricane Harbour', 'street_address' => '4243 W Pinnacle Peak Rd', 'city' => 'Glendale', 'state' => 'AZ', 'zip' => '85310', 'country' => 'USA', 'lock' => 'L&F Lock', 'master_code' => '66170836', 'sub_master_code' => '581662', 'lock_part' => '3781742', 'key' => 'E2219'),
    array('user_login' => 'soakymountain', 'user_pass' => 'SoakyMountainTN', 'units' => 21, 'number' => '8654294567', 'display_name' => 'Soaky Mountain Waterpark', 'top_colour' => 'Ice Blue', 'company_name' => 'Soaky Mountain Waterpark', 'management_company' => 'Soaky Mountain Waterpark', 'street_address' => '175 Gists Creek Rd', 'city' => 'Sevierville', 'state' => 'TN', 'zip' => '37876', 'country' => 'USA', 'lock' => 'L&F Lock', 'master_code' => '45542214', 'sub_master_code' => '432890', 'lock_part' => '3781746', 'key' => 'E2223'),
    array('user_login' => 'splashkingdomcanton', 'user_pass' => 'SplashKingdomTX', 'units' => 24, 'number' => '3304564316', 'display_name' => 'Splash Kingdom - Canton', 'top_colour' => 'Classic Blue', 'company_name' => 'Splash Kingdom - Canton', 'management_company' => 'P23 - Splash Kingdom', 'street_address' => '3300 N Main St', 'city' => 'Canton', 'state' => 'OH', 'zip' => '44720', 'country' => 'USA', 'lock' => 'L&F Lock', 'master_code' => '58770333', 'sub_master_code' => '666393', 'lock_part' => '3781746', 'key' => 'E2223'),
    array('user_login' => 'splashkingdomgreenville', 'user_pass' => 'SplashKingdomTX', 'units' => 12, 'number' => '8642687397', 'display_name' => 'Splash Kingdom - Greenville', 'top_colour' => 'Classic Blue', 'company_name' => 'Splash Kingdom - Greenville', 'management_company' => 'P23 - Splash Kingdom', 'street_address' => '400 Congaree Rd', 'city' => 'Greenville', 'state' => 'SC', 'zip' => '29607', 'country' => 'USA', 'lock' => 'L&F Lock', 'master_code' => '51224658', 'sub_master_code' => '706695', 'lock_part' => '3781747', 'key' => 'E2224'),
    array('user_login' => 'splashkingdomhudsonoaks', 'user_pass' => 'SplashKingdomTX', 'units' => 12, 'number' => '8172054545', 'display_name' => 'Splash Kingdom - Hudson Oaks', 'top_colour' => 'Classic Blue', 'company_name' => 'Splash Kingdom - Hudson Oaks', 'management_company' => 'P23 - Splash Kingdom', 'street_address' => '1001 Cinema Dr', 'city' => 'Hudson Oaks', 'state' => 'TX', 'zip' => '76087', 'country' => 'USA', 'lock' => 'L&F Lock', 'master_code' => '39772253', 'sub_master_code' => '279488', 'lock_part' => '3781743', 'key' => 'E2220'),
    array('user_login' => 'splashkingdomnacogdoches', 'user_pass' => 'SplashKingdomTX', 'units' => 12, 'number' => '9365602171', 'display_name' => 'Splash Kingdom - Nacogdoches', 'top_colour' => 'Classic Blue', 'company_name' => 'Splash Kingdom - Nacogdoches', 'management_company' => 'P23 - Splash Kingdom', 'street_address' => '6501 N University Dr', 'city' => 'Nacogdoches', 'state' => 'TX', 'zip' => '75965', 'country' => 'USA', 'lock' => 'L&F Lock', 'master_code' => '74419466', 'sub_master_code' => '118671', 'lock_part' => '3781742', 'key' => 'E2219'),
    array('user_login' => 'splishsplash', 'user_pass' => 'SplishSplashNY', 'units' => 28, 'number' => '8007711612', 'display_name' => 'Splish Splash', 'top_colour' => 'Classic Blue', 'company_name' => 'Splish Splash', 'management_company' => 'Palace Entertainment', 'street_address' => '2549 Splish Splash Dr', 'city' => 'Calverton', 'state' => 'NY', 'zip' => '11933', 'country' => 'USA', 'lock' => 'L&F Lock', 'master_code' => '44956067', 'sub_master_code' => '206923', 'lock_part' => '3781747', 'key' => 'E2224'),
    array('user_login' => 'thegrove', 'user_pass' => 'TheGroveFL', 'units' => 75, 'number' => '4073944444', 'display_name' => 'The Grove Resort & Water Park', 'top_colour' => 'Trojan Blue', 'company_name' => 'The Grove Resort & Water Park', 'management_company' => 'The Grove Resort & Water Park', 'street_address' => '14501 Grove Resort Ave', 'city' => 'Winter Garden', 'state' => 'FL', 'zip' => '34787', 'country' => 'USA', 'lock' => 'L&F Lock', 'master_code' => '53282583', 'sub_master_code' => '840434', 'lock_part' => '3781747', 'key' => 'E2224'),
    array('user_login' => 'typhoonaustin', 'user_pass' => 'TyphoonAustinTX', 'units' => 34, 'number' => '5122514877', 'display_name' => 'Typhoon Texas - Austin', 'top_colour' => 'Ice Blue', 'company_name' => 'Typhoon Texas - Austin', 'management_company' => 'PYEK', 'street_address' => '18500 TX-130 Service Rd', 'city' => 'Pflugerville', 'state' => 'TX', 'zip' => '78660', 'country' => 'USA', 'lock' => 'L&F Lock', 'master_code' => '32546546', 'sub_master_code' => '979032', 'lock_part' => '3781744', 'key' => 'E2221'),
    array('user_login' => 'typhoonhouston', 'user_pass' => 'TyphoonHoustonTX', 'units' => 48, 'number' => '2816443377', 'display_name' => 'Typhoon Texas - Houston', 'top_colour' => 'Lime Green', 'company_name' => 'Typhoon Texas - Houston', 'management_company' => 'PYEK', 'street_address' => '555 Katy Fort Bend Rd', 'city' => 'Katy', 'state' => 'TX', 'zip' => '77494', 'country' => 'USA', 'lock' => 'L&F Lock', 'master_code' => '92730070', 'sub_master_code' => '719026', 'lock_part' => '3781745', 'key' => 'E2222'),
    array('user_login' => 'villatel', 'user_pass' => 'VillatelFL', 'units' => 22, 'number' => '4073072794', 'display_name' => 'Villatel Orlando Resort', 'top_colour' => 'Classic Blue', 'company_name' => 'Villatel Orlando Resort', 'management_company' => 'Villatel Orlando Resort', 'street_address' => '5120 Del Verde Way', 'city' => 'Orlando', 'state' => 'FL', 'zip' => '32819', 'country' => 'USA', 'lock' => 'L&F Lock', 'master_code' => '45114028', 'sub_master_code' => '924585', 'lock_part' => 'Default', 'key' => 'E0208'),
    array('user_login' => 'watercountry', 'user_pass' => 'WaterCountryVA', 'units' => 55, 'number' => '7572205600', 'display_name' => 'Water Country USA', 'top_colour' => 'Trojan Blue', 'company_name' => 'Water Country USA', 'management_company' => 'Palace Entertainment', 'street_address' => '176 Water Country Pkwy', 'city' => 'Williamsburg', 'state' => 'VA', 'zip' => '23185', 'country' => 'USA', 'lock' => 'L&F Lock', 'master_code' => '31644703', 'sub_master_code' => '424084', 'lock_part' => '3781745', 'key' => 'E2222'),
    array('user_login' => 'waterwizz', 'user_pass' => 'WaterWizzMA', 'units' => 32, 'number' => '5082915333', 'display_name' => 'Water Wizz Waterpark', 'top_colour' => 'Yellow', 'company_name' => 'Water Wizz Waterpark', 'management_company' => 'Water Wizz Waterpark', 'street_address' => '3031 Cranberry Hwy', 'city' => 'East Wareham', 'state' => 'MA', 'zip' => '2538', 'country' => 'USA', 'lock' => 'L&F Lock', 'master_code' => '26901529', 'sub_master_code' => '770356', 'lock_part' => 'Default', 'key' => 'E0208'),
    array('user_login' => 'waterworld', 'user_pass' => 'WaterWorldCO', 'units' => 101, 'number' => '3034277873', 'display_name' => 'Water World Waterpark', 'top_colour' => 'Classic Blue', 'company_name' => 'Water World Waterpark', 'management_company' => 'Water World Waterpark', 'street_address' => '8801 N Pecos St', 'city' => 'Federal Heights', 'state' => 'CO', 'zip' => '80260', 'country' => 'USA', 'lock' => 'L&F Lock', 'master_code' => '17567023', 'sub_master_code' => '143161', 'lock_part' => 'Default', 'key' => 'E0208'),
    array('user_login' => 'westinhiltonhead', 'user_pass' => 'WestinHiltonHeadSC', 'units' => 20, 'number' => '8436814100', 'display_name' => 'Westin Hilton Head Island Resort & Spa', 'top_colour' => 'Ice Blue', 'company_name' => 'Westin Hilton Head Island Resort & Spa', 'management_company' => 'Westin Hilton Head Island Resort & Spa', 'street_address' => '2 Grasslawn Ave', 'city' => 'Hilton Head Island', 'state' => 'SC', 'zip' => '29928', 'country' => 'USA', 'lock' => 'L&F Lock', 'master_code' => '43725518', 'sub_master_code' => '895852', 'lock_part' => 'Default', 'key' => 'E0208'),
    array('user_login' => 'wetnwild', 'user_pass' => 'WetnWildHI', 'units' => 31, 'number' => '3362943767', 'display_name' => 'Wet\'n\'Wild', 'top_colour' => 'Ice Blue', 'company_name' => 'Wet\'n\'Wild', 'management_company' => 'Palace Entertainment', 'street_address' => '3910 S Holden Rd', 'city' => 'Greensboro', 'state' => 'NC', 'zip' => '27406', 'country' => 'USA', 'lock' => 'L&F Lock', 'master_code' => '12466620', 'sub_master_code' => '767966', 'lock_part' => '3781743', 'key' => 'E2220'),
    array('user_login' => 'wildrivers', 'user_pass' => 'WildRiversCA', 'units' => 69, 'number' => '9497491900', 'display_name' => 'Wild Rivers Waterpark', 'top_colour' => 'Ice Blue', 'company_name' => 'Wild Rivers Waterpark', 'management_company' => 'Wild Rivers Waterpark', 'street_address' => '10000 Great Park Blvd', 'city' => 'Irvine', 'state' => 'CA', 'zip' => '92618', 'country' => 'USA', 'lock' => 'L&F Lock', 'master_code' => '19368324', 'sub_master_code' => '587696', 'lock_part' => 'Default', 'key' => 'E0208'),
    array('user_login' => 'wonderoasiswaterpark', 'user_pass' => 'WonderOasisTX', 'units' => 10, 'number' => '3185914969', 'display_name' => 'Wonder Oasis Waterpark', 'top_colour' => 'Classic Blue', 'company_name' => 'Wonder Oasis Waterpark', 'management_company' => 'Wonder Oasis Waterpark', 'street_address' => '7670 W 70th St', 'city' => 'Shreveport', 'state' => 'LA', 'zip' => '71129', 'country' => 'USA', 'lock' => 'L&F Lock', 'master_code' => '86818645', 'sub_master_code' => '616102', 'lock_part' => '-', 'key' => 'E2219'),
);

/**
 * Bulk import partners into database
 */
function bulk_import_partners() {
    global $wpdb, $partners_data;
    
    // Safety check: Ensure partners_data is defined and is an array
    if (!isset($partners_data) || !is_array($partners_data)) {
        echo "❌ Error: Partners data not found or invalid\n";
        return array('imported' => 0, 'errors' => 1);
    }
    
    $imported = 0;
    $errors = 0;
    
    foreach ($partners_data as $partner) {
        // Check if partner already exists
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}psp_partners WHERE company_name = %s",
            $partner['company_name']
        ));
        
        if ($existing) {
            // Skip silently - partner already exists
            continue;
        }
        
        // Insert partner
        $result = $wpdb->insert(
            $wpdb->prefix . 'psp_partners',
            array(
                'company_name' => $partner['company_name'],
                'management_company' => $partner['management_company'],
                'street_address' => $partner['street_address'],
                'city' => $partner['city'],
                'state' => $partner['state'],
                'zip' => $partner['zip'],
                'country' => $partner['country'],
                'phone' => $partner['number'],
                'units' => $partner['units'],
                'pool_colour' => $partner['top_colour'],
                'lock_type' => $partner['lock'],
                'master_code' => $partner['master_code'],
                'sub_master_code' => $partner['sub_master_code'],
                'lock_part' => $partner['lock_part'],
                'key_code' => $partner['key'],
                'created_at' => current_time('mysql'),
                'status' => 'active'
            ),
            array('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')
        );
        
        if ($result) {
            $partner_id = $wpdb->insert_id;
            
            // Create portal user for partner
            $password_hash = password_hash($partner['user_pass'], PASSWORD_BCRYPT);
            
            $wpdb->insert(
                $wpdb->prefix . 'psp_company_users',
                array(
                    'company_id' => $partner_id,
                    'username' => $partner['user_login'],
                    'password' => $password_hash,
                    'email' => strtolower($partner['user_login']) . '@poolsafe.local',
                    'first_name' => $partner['display_name'],
                    'last_name' => 'Admin',
                    'role' => 'admin',
                    'status' => 'active',
                    'created_at' => current_time('mysql')
                ),
                array('%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')
            );
            
            // Partner imported successfully
            $imported++;
        } else {
            // Failed to import - log error silently
            error_log("PSP Import Error: Failed to import {$partner['company_name']}: " . $wpdb->last_error);
            $errors++;
        }
    }
    
    return array('imported' => $imported, 'errors' => $errors);
}

// Run import only when explicitly called - DO NOT auto-execute
// To run: call bulk_import_partners() manually from admin or WP-CLI
