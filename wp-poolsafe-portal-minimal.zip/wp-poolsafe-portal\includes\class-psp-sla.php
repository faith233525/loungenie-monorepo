<?php
/**
 * SLA Tracking - Response time targets and compliance
 * Critical for service level agreements
 */

if (!defined('ABSPATH')) {
    exit;
}

class PSP_SLA {
    
    private $sla_config = [
        'urgent' => 2,      // 2 hours
        'high' => 8,        // 8 hours
        'normal' => 24,     // 24 hours
        'low' => 72,        // 72 hours
    ];
    
    public function __construct() {
        add_action('rest_api_init', [$this, 'register_endpoints']);
    }
    
    /**
     * Register SLA endpoints
     */
    public function register_endpoints() {
        register_rest_route('psp/v1', '/sla/config', [
            'methods' => 'GET',
            'callback' => [$this, 'get_config'],
            'permission_callback' => [$this, 'check_admin'],
        ]);
        
        register_rest_route('psp/v1', '/sla/tickets', [
            'methods' => 'GET',
            'callback' => [$this, 'get_sla_tickets'],
            'permission_callback' => [$this, 'check_auth'],
        ]);
        
        register_rest_route('psp/v1', '/sla/tickets/(?P<id>\d+)', [
            'methods' => 'GET',
            'callback' => [$this, 'get_ticket_sla'],
            'permission_callback' => [$this, 'check_auth'],
        ]);
        
        register_rest_route('psp/v1', '/sla/metrics', [
            'methods' => 'GET',
            'callback' => [$this, 'get_metrics'],
            'permission_callback' => [$this, 'check_admin'],
        ]);
    }
    
    /**
     * Check authentication
     */
    public function check_auth() {
        return !empty($_SESSION['psp_user']);
    }
    
    /**
     * Check admin
     */
    public function check_admin() {
        $user = $_SESSION['psp_user'] ?? null;
        return $user && in_array($user['role'], ['admin', 'staff']);
    }
    
    /**
     * Get SLA configuration
     */
    public function get_config() {
        return rest_ensure_response([
            'success' => true,
            'data' => $this->sla_config,
        ]);
    }
    
    /**
     * Get all tickets with SLA status
     */
    public function get_sla_tickets($request) {
        global $wpdb;
        
        $user = $_SESSION['psp_user'] ?? null;
        if (!$user) {
            return new WP_Error('unauthorized', 'Not authenticated', ['status' => 401]);
        }
        
        $status = sanitize_text_field($request->get_param('status')) ?? 'open';
        $priority = sanitize_text_field($request->get_param('priority'));
        
        // Build query
        $where = "status = %s";
        $params = [$status];
        
        // Role-based filtering
        if ($user['role'] === 'partner') {
            $where .= " AND company_id = %d";
            $params[] = $user['company_id'];
        }
        
        if (!empty($priority)) {
            $where .= " AND priority = %s";
            $params[] = $priority;
        }
        
        $tickets = $wpdb->get_results($wpdb->prepare(
            "SELECT id, subject, priority, status, created_at, first_reply_at, closed_at 
             FROM {$wpdb->prefix}psp_tickets 
             WHERE $where
             ORDER BY created_at DESC",
            ...($params ?: [])
        ));
        
        // Enrich with SLA data
        $tickets_with_sla = array_map(function($ticket) {
            return $this->calculate_sla($ticket);
        }, $tickets);
        
        return rest_ensure_response([
            'success' => true,
            'data' => $tickets_with_sla,
            'count' => count($tickets_with_sla),
        ]);
    }
    
    /**
     * Get single ticket SLA
     */
    public function get_ticket_sla($request) {
        global $wpdb;
        
        $user = $_SESSION['psp_user'] ?? null;
        if (!$user) {
            return new WP_Error('unauthorized', 'Not authenticated', ['status' => 401]);
        }
        
        $ticket_id = intval($request['id']);
        
        $ticket = $wpdb->get_row($wpdb->prepare(
            "SELECT id, subject, priority, status, created_at, first_reply_at, closed_at, company_id 
             FROM {$wpdb->prefix}psp_tickets 
             WHERE id = %d",
            $ticket_id
        ));
        
        if (!$ticket) {
            return new WP_Error('not_found', 'Ticket not found', ['status' => 404]);
        }
        
        // Permission check
        if ($user['role'] === 'partner' && $ticket->company_id !== $user['company_id']) {
            return new WP_Error('forbidden', 'Access denied', ['status' => 403]);
        }
        
        $sla_data = $this->calculate_sla($ticket);
        
        return rest_ensure_response([
            'success' => true,
            'data' => $sla_data,
        ]);
    }
    
    /**
     * Calculate SLA status for a ticket
     */
    private function calculate_sla($ticket) {
        $sla_hours = $this->sla_config[$ticket->priority] ?? $this->sla_config['normal'];
        $created = strtotime($ticket->created_at);
        $now = current_time('timestamp');
        
        // Elapsed hours since creation
        $elapsed_hours = round(($now - $created) / 3600, 2);
        
        // First response time
        $first_response_hours = null;
        if ($ticket->first_reply_at) {
            $first_reply = strtotime($ticket->first_reply_at);
            $first_response_hours = round(($first_reply - $created) / 3600, 2);
        }
        
        // Determine SLA status
        if ($ticket->status === 'closed') {
            $sla_status = 'met';
            $breach_time = null;
        } elseif ($first_response_hours && $first_response_hours > $sla_hours) {
            $sla_status = 'breached';
            $breach_time = $first_response_hours - $sla_hours;
        } elseif ($elapsed_hours > $sla_hours) {
            $sla_status = 'breached';
            $breach_time = $elapsed_hours - $sla_hours;
        } else {
            $sla_status = 'on_track';
            $breach_time = $sla_hours - $elapsed_hours;
        }
        
        return [
            'id' => $ticket->id,
            'subject' => $ticket->subject,
            'priority' => $ticket->priority,
            'status' => $ticket->status,
            'created_at' => $ticket->created_at,
            'first_reply_at' => $ticket->first_reply_at,
            'closed_at' => $ticket->closed_at,
            'sla' => [
                'target_hours' => $sla_hours,
                'elapsed_hours' => $elapsed_hours,
                'first_response_hours' => $first_response_hours,
                'sla_status' => $sla_status,
                'time_remaining_or_overdue' => round($breach_time, 2),
                'percent_complete' => min(100, round(($elapsed_hours / $sla_hours) * 100, 1)),
            ],
        ];
    }
    
    /**
     * Get SLA metrics (admin only)
     */
    public function get_metrics($request) {
        global $wpdb;
        
        $user = $_SESSION['psp_user'] ?? null;
        if (!$user || $user['role'] !== 'admin') {
            return new WP_Error('forbidden', 'Admin only', ['status' => 403]);
        }
        
        $days = intval($request->get_param('days')) ?: 30;
        $cutoff = date('Y-m-d H:i:s', strtotime("-{$days} days"));
        
        // Get all closed tickets in period
        $closed_tickets = $wpdb->get_results($wpdb->prepare(
            "SELECT id, priority, created_at, first_reply_at, closed_at 
             FROM {$wpdb->prefix}psp_tickets 
             WHERE status = 'closed' AND closed_at >= %s
             ORDER BY closed_at DESC",
            $cutoff
        ));
        
        // Get all open tickets
        $open_tickets = $wpdb->get_results(
            "SELECT id, priority, created_at, first_reply_at 
             FROM {$wpdb->prefix}psp_tickets 
             WHERE status = 'open'"
        );
        
        $all_tickets = array_merge($closed_tickets, $open_tickets);
        $sla_results = array_map(fn($t) => $this->calculate_sla($t), $all_tickets);
        
        // Calculate metrics
        $total = count($sla_results);
        $met = count(array_filter($sla_results, fn($t) => $t['sla']['sla_status'] === 'met'));
        $on_track = count(array_filter($sla_results, fn($t) => $t['sla']['sla_status'] === 'on_track'));
        $breached = count(array_filter($sla_results, fn($t) => $t['sla']['sla_status'] === 'breached'));
        
        // By priority
        $by_priority = [];
        foreach (['urgent', 'high', 'normal', 'low'] as $priority) {
            $priority_tickets = array_filter($sla_results, fn($t) => $t['priority'] === $priority);
            $priority_breached = count(array_filter($priority_tickets, fn($t) => $t['sla']['sla_status'] === 'breached'));
            $by_priority[$priority] = [
                'total' => count($priority_tickets),
                'breached' => $priority_breached,
                'compliance' => count($priority_tickets) > 0 ? round((count($priority_tickets) - $priority_breached) / count($priority_tickets) * 100, 1) : 100,
            ];
        }
        
        return rest_ensure_response([
            'success' => true,
            'period_days' => $days,
            'metrics' => [
                'total' => $total,
                'met' => $met,
                'on_track' => $on_track,
                'breached' => $breached,
                'compliance_rate' => $total > 0 ? round(($met + $on_track) / $total * 100, 1) : 100,
            ],
            'by_priority' => $by_priority,
            'breached_tickets' => array_slice(
                array_filter($sla_results, fn($t) => $t['sla']['sla_status'] === 'breached'),
                0,
                10
            ),
        ]);
    }
}

// Initialize
new PSP_SLA();
