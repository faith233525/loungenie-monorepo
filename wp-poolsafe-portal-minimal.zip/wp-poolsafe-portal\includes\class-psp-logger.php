<?php
/**
 * Centralized Error Logging System
 *
 * Provides unified logging interface for the PoolSafe Portal plugin.
 * Respects PSP_DEBUG constant and writes to dedicated log file.
 *
 * @package PoolSafe_Portal
 * @version 3.2.5
 * @since 3.2.5
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * PSP_Logger Class
 *
 * Centralized logging with severity levels and conditional output.
 */
class PSP_Logger {

	/**
	 * Log levels
	 */
	const LEVEL_DEBUG   = 'DEBUG';
	const LEVEL_INFO    = 'INFO';
	const LEVEL_WARNING = 'WARNING';
	const LEVEL_ERROR   = 'ERROR';

	/**
	 * Log file path
	 *
	 * @var string
	 */
	private static $log_file = null;

	/**
	 * Whether debug mode is enabled
	 *
	 * @var bool
	 */
	private static $debug_enabled = null;

	/**
	 * Initialize the logger
	 */
	public static function init() {
		if ( self::$debug_enabled === null ) {
			self::$debug_enabled = defined( 'PSP_DEBUG' ) && PSP_DEBUG;
		}

		if ( self::$log_file === null ) {
			self::$log_file = WP_CONTENT_DIR . '/psp-debug.log';
		}
	}

	/**
	 * Log a debug message (only when PSP_DEBUG is true)
	 *
	 * @param string $message The message to log
	 * @param array  $context Optional context data
	 */
	public static function debug( $message, $context = array() ) {
		if ( self::is_debug_enabled() ) {
			self::write( self::LEVEL_DEBUG, $message, $context );
		}
	}

	/**
	 * Log an informational message
	 *
	 * @param string $message The message to log
	 * @param array  $context Optional context data
	 */
	public static function info( $message, $context = array() ) {
		self::write( self::LEVEL_INFO, $message, $context );
	}

	/**
	 * Log a warning message
	 *
	 * @param string $message The message to log
	 * @param array  $context Optional context data
	 */
	public static function warning( $message, $context = array() ) {
		self::write( self::LEVEL_WARNING, $message, $context );
	}

	/**
	 * Log an error message
	 *
	 * @param string $message The message to log
	 * @param array  $context Optional context data
	 */
	public static function error( $message, $context = array() ) {
		self::write( self::LEVEL_ERROR, $message, $context );
	}

	/**
	 * Log a caught exception
	 *
	 * @param Exception $exception The exception to log
	 * @param string    $context_message Optional additional context
	 */
	public static function exception( $exception, $context_message = '' ) {
		$message = sprintf(
			'%s%s: %s in %s:%d',
			$context_message ? $context_message . ' - ' : '',
			get_class( $exception ),
			$exception->getMessage(),
			$exception->getFile(),
			$exception->getLine()
		);

		$context = array(
			'trace' => $exception->getTraceAsString(),
		);

		self::write( self::LEVEL_ERROR, $message, $context );
	}

	/**
	 * Log API request and response for debugging
	 *
	 * @param string $endpoint The API endpoint
	 * @param array  $request Request data
	 * @param mixed  $response Response data
	 * @param int    $status_code HTTP status code
	 */
	public static function api_request( $endpoint, $request, $response, $status_code ) {
		if ( ! self::is_debug_enabled() ) {
			return;
		}

		$context = array(
			'endpoint'    => $endpoint,
			'request'     => self::sanitize_sensitive_data( $request ),
			'response'    => $response,
			'status_code' => $status_code,
		);

		$level = $status_code >= 400 ? self::LEVEL_ERROR : self::LEVEL_DEBUG;
		
		self::write( $level, sprintf( 'API Request: %s', $endpoint ), $context );
	}

	/**
	 * Log database query for debugging
	 *
	 * @param string $query The SQL query
	 * @param float  $execution_time Query execution time in seconds
	 */
	public static function query( $query, $execution_time = null ) {
		if ( ! self::is_debug_enabled() ) {
			return;
		}

		$context = array(
			'query' => $query,
		);

		if ( $execution_time !== null ) {
			$context['execution_time'] = sprintf( '%.4f seconds', $execution_time );
		}

		self::write( self::LEVEL_DEBUG, 'Database Query', $context );
	}

	/**
	 * Write log entry to file
	 *
	 * @param string $level Log level
	 * @param string $message Log message
	 * @param array  $context Additional context
	 */
	private static function write( $level, $message, $context = array() ) {
		self::init();

		$timestamp = current_time( 'Y-m-d H:i:s' );
		
		// Format: [2024-01-15 14:23:45] ERROR: User authentication failed
		$log_entry = sprintf( '[%s] %s: %s', $timestamp, $level, $message );

		// Add context data if present
		if ( ! empty( $context ) ) {
			$log_entry .= PHP_EOL . 'Context: ' . wp_json_encode( $context, JSON_PRETTY_PRINT );
		}

		$log_entry .= PHP_EOL;

		// Write to log file
		if ( self::is_debug_enabled() || in_array( $level, array( self::LEVEL_ERROR, self::LEVEL_WARNING ), true ) ) {
			// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
			error_log( $log_entry, 3, self::$log_file );
		}

		// Also write errors to WordPress debug.log if WP_DEBUG_LOG is enabled
		if ( in_array( $level, array( self::LEVEL_ERROR, self::LEVEL_WARNING ), true ) && defined( 'WP_DEBUG_LOG' ) && WP_DEBUG_LOG ) {
			// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
			error_log( '[PoolSafe Portal] ' . $message );
		}
	}

	/**
	 * Check if debug mode is enabled
	 *
	 * @return bool
	 */
	public static function is_debug_enabled() {
		if ( self::$debug_enabled === null ) {
			self::init();
		}
		return self::$debug_enabled;
	}

	/**
	 * Get the log file path
	 *
	 * @return string
	 */
	public static function get_log_file() {
		self::init();
		return self::$log_file;
	}

	/**
	 * Clear the log file
	 *
	 * @return bool Success status
	 */
	public static function clear_log() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return false;
		}

		self::init();

		if ( file_exists( self::$log_file ) ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_unlink
			return unlink( self::$log_file );
		}

		return true;
	}

	/**
	 * Get recent log entries
	 *
	 * @param int $lines Number of lines to retrieve
	 * @return array Log entries
	 */
	public static function get_recent_entries( $lines = 100 ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return array();
		}

		self::init();

		if ( ! file_exists( self::$log_file ) ) {
			return array();
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		$content = file_get_contents( self::$log_file );
		$log_lines = explode( PHP_EOL, $content );
		
		return array_slice( array_filter( $log_lines ), -$lines );
	}

	/**
	 * Remove sensitive data from context before logging
	 *
	 * @param array $data Data to sanitize
	 * @return array Sanitized data
	 */
	private static function sanitize_sensitive_data( $data ) {
		$sensitive_keys = array(
			'password',
			'passwd',
			'pwd',
			'api_key',
			'apikey',
			'secret',
			'token',
			'auth',
			'authorization',
			'cookie',
		);

		if ( ! is_array( $data ) ) {
			return $data;
		}

		foreach ( $data as $key => $value ) {
			$key_lower = strtolower( $key );
			
			// Check if key contains sensitive words
			foreach ( $sensitive_keys as $sensitive ) {
				if ( strpos( $key_lower, $sensitive ) !== false ) {
					$data[ $key ] = '[REDACTED]';
					continue 2;
				}
			}

			// Recursively sanitize nested arrays
			if ( is_array( $value ) ) {
				$data[ $key ] = self::sanitize_sensitive_data( $value );
			}
		}

		return $data;
	}

	/**
	 * Get log file size
	 *
	 * @return int|false File size in bytes or false on failure
	 */
	public static function get_log_file_size() {
		self::init();

		if ( file_exists( self::$log_file ) ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_filesize
			return filesize( self::$log_file );
		}

		return 0;
	}

	/**
	 * Rotate log file if it exceeds size limit (10MB default)
	 *
	 * @param int $max_size Maximum file size in bytes
	 * @return bool Whether rotation occurred
	 */
	public static function rotate_if_needed( $max_size = 10485760 ) {
		self::init();

		$current_size = self::get_log_file_size();

		if ( $current_size > $max_size ) {
			$backup_file = self::$log_file . '.' . gmdate( 'Y-m-d-His' ) . '.bak';
			
			// phpcs:ignore WordPress.WP.AlternativeFunctions.rename_rename
			if ( rename( self::$log_file, $backup_file ) ) {
				self::info( 'Log file rotated', array( 'backup' => $backup_file ) );
				return true;
			}
		}

		return false;
	}
}

// Initialize logger
PSP_Logger::init();
