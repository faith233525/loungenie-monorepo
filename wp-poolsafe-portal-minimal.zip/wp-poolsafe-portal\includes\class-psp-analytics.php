<?php
namespace PSP;

/**
 * Advanced Analytics Dashboard
 * Tracks metrics: tickets, partners, response times, team performance
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Analytics_Dashboard {

	/**
	 * Initialize analytics
	 */
	public static function init(): void {
		add_action( 'admin_menu', array( __CLASS__, 'add_analytics_menu' ) );
		add_action( 'wp_ajax_psp_get_ticket_stats', array( __CLASS__, 'ajax_get_ticket_stats' ) );
		add_action( 'wp_ajax_psp_get_partner_stats', array( __CLASS__, 'ajax_get_partner_stats' ) );
		add_action( 'wp_ajax_psp_get_team_performance', array( __CLASS__, 'ajax_get_team_performance' ) );
		add_action( 'wp_ajax_psp_export_analytics', array( __CLASS__, 'ajax_export_analytics' ) );
	}

	/**
	 * Get ticket statistics
	 */
	public static function get_ticket_stats( $days = 30 ): array {
		global $wpdb;

		$start_date = date( 'Y-m-d', strtotime( "-$days days" ) );

		// Total tickets created
		$total = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->prefix}psp_tickets WHERE created_at >= %s",
				$start_date
			)
		);

		// By status
		$by_status = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT status, COUNT(*) as count FROM {$wpdb->prefix}psp_tickets WHERE created_at >= %s GROUP BY status",
				$start_date
			)
		);

		// By priority
		$by_priority = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT priority, COUNT(*) as count FROM {$wpdb->prefix}psp_tickets WHERE created_at >= %s GROUP BY priority",
				$start_date
			)
		);

		// Average response time (hours between creation and first response)
		$avg_response = $wpdb->get_var(
			"SELECT AVG(HOUR(TIMEDIFF(tr.created_at, t.created_at))) as avg_hours
			FROM {$wpdb->prefix}psp_tickets t
			INNER JOIN {$wpdb->prefix}psp_ticket_responses tr ON t.id = tr.ticket_id
			WHERE t.created_at >= '$start_date'
			GROUP BY t.id
			ORDER BY avg_hours DESC LIMIT 1"
		);

		// Daily trend
		$daily_trend = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT DATE(created_at) as date, COUNT(*) as count FROM {$wpdb->prefix}psp_tickets WHERE created_at >= %s GROUP BY DATE(created_at) ORDER BY date",
				$start_date
			)
		);

		return array(
			'total_tickets'       => intval( $total ),
			'by_status'          => $by_status,
			'by_priority'        => $by_priority,
			'avg_response_hours' => round( $avg_response ?? 0, 2 ),
			'daily_trend'        => $daily_trend,
		);
	}

	/**
	 * Get partner statistics
	 */
	public static function get_partner_stats( $days = 30 ): array {
		global $wpdb;

		$start_date = date( 'Y-m-d', strtotime( "-$days days" ) );

		// Total partners
		$total = $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}psp_partners" );

		// By status
		$by_status = $wpdb->get_results(
			"SELECT status, COUNT(*) as count FROM {$wpdb->prefix}psp_partners GROUP BY status"
		);

		// New partners in period
		$new_partners = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->prefix}psp_partners WHERE created_at >= %s",
				$start_date
			)
		);

		// Conversion rate (approved / total)
		$approved = $wpdb->get_var(
			"SELECT COUNT(*) FROM {$wpdb->prefix}psp_partners WHERE status = 'approved'"
		);
		$conversion_rate = $total > 0 ? round( ( $approved / $total ) * 100, 2 ) : 0;

		// Top partners by ticket count
		$top_partners = $wpdb->get_results(
			"SELECT p.name, COUNT(t.id) as ticket_count
			FROM {$wpdb->prefix}psp_partners p
			LEFT JOIN {$wpdb->prefix}psp_tickets t ON p.id = t.partner_id
			GROUP BY p.id
			ORDER BY ticket_count DESC
			LIMIT 10"
		);

		return array(
			'total_partners'    => intval( $total ),
			'new_partners'      => intval( $new_partners ),
			'by_status'         => $by_status,
			'conversion_rate'   => $conversion_rate,
			'top_partners'      => $top_partners,
		);
	}

	/**
	 * Get team performance metrics
	 */
	public static function get_team_performance(): array {
		global $wpdb;

		// Get all support team users
		$support_users = get_users( array( 'role' => 'psp_support' ) );

		$team_stats = array();

		foreach ( $support_users as $user ) {
			// Tickets responded to
			$responses = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT COUNT(*) FROM {$wpdb->prefix}psp_ticket_responses WHERE user_id = %d",
					$user->ID
				)
			);

			// Tickets closed
			$closed = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT COUNT(*) FROM {$wpdb->prefix}psp_tickets WHERE created_by = %d AND status = 'closed'",
					$user->ID
				)
			);

			// Average response time
			$avg_response = $wpdb->get_var(
				"SELECT AVG(HOUR(TIMEDIFF(tr.created_at, t.created_at)))
				FROM {$wpdb->prefix}psp_tickets t
				INNER JOIN {$wpdb->prefix}psp_ticket_responses tr ON t.id = tr.ticket_id
				WHERE tr.user_id = {$user->ID}"
			);

			$team_stats[] = array(
				'user_id'              => $user->ID,
				'name'                 => $user->display_name,
				'email'                => $user->user_email,
				'responses'            => intval( $responses ),
				'closed_tickets'       => intval( $closed ),
				'avg_response_hours'   => round( $avg_response ?? 0, 2 ),
			);
		}

		// Sort by responses descending
		usort( $team_stats, function( $a, $b ) {
			return $b['responses'] - $a['responses'];
		});

		return $team_stats;
	}

	/**
	 * AJAX: Get ticket stats
	 */
	public static function ajax_get_ticket_stats(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Insufficient permissions' );
		}

		$days = isset( $_POST['days'] ) ? absint( $_POST['days'] ) : 30;
		$stats = self::get_ticket_stats( $days );

		wp_send_json_success( $stats );
	}

	/**
	 * AJAX: Get partner stats
	 */
	public static function ajax_get_partner_stats(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Insufficient permissions' );
		}

		$days = isset( $_POST['days'] ) ? absint( $_POST['days'] ) : 30;
		$stats = self::get_partner_stats( $days );

		wp_send_json_success( $stats );
	}

	/**
	 * AJAX: Get team performance
	 */
	public static function ajax_get_team_performance(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Insufficient permissions' );
		}

		$stats = self::get_team_performance();
		wp_send_json_success( $stats );
	}

	/**
	 * AJAX: Export analytics to CSV
	 */
	public static function ajax_export_analytics(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Insufficient permissions' );
		}

		$ticket_stats = self::get_ticket_stats( 30 );
		$partner_stats = self::get_partner_stats( 30 );
		$team_stats = self::get_team_performance();

		$csv = "PoolSafe Portal Analytics Report\n";
		$csv .= "Generated: " . current_time( 'Y-m-d H:i:s' ) . "\n\n";

		// Ticket stats
		$csv .= "TICKET STATISTICS (Last 30 Days)\n";
		$csv .= "Total Tickets," . $ticket_stats['total_tickets'] . "\n";
		$csv .= "Avg Response Hours," . $ticket_stats['avg_response_hours'] . "\n";

		if ( ! empty( $ticket_stats['by_status'] ) ) {
			$csv .= "\nBy Status\n";
			foreach ( $ticket_stats['by_status'] as $status ) {
				$csv .= $status->status . "," . $status->count . "\n";
			}
		}

		// Partner stats
		$csv .= "\n\nPARTNER STATISTICS\n";
		$csv .= "Total Partners," . $partner_stats['total_partners'] . "\n";
		$csv .= "New Partners (30 Days)," . $partner_stats['new_partners'] . "\n";
		$csv .= "Conversion Rate," . $partner_stats['conversion_rate'] . "%\n";

		// Team performance
		$csv .= "\n\nTEAM PERFORMANCE\n";
		$csv .= "Team Member,Responses,Closed Tickets,Avg Response Hours\n";
		foreach ( $team_stats as $member ) {
			$csv .= $member['name'] . "," . $member['responses'] . "," . $member['closed_tickets'] . "," . $member['avg_response_hours'] . "\n";
		}

		header( 'Content-Type: text/csv' );
		header( 'Content-Disposition: attachment; filename="analytics-' . current_time( 'Y-m-d' ) . '.csv"' );
		echo $csv;
		exit;
	}

	/**
	 * Add analytics menu
	 */
	public static function add_analytics_menu(): void {
		add_submenu_page(
			'psp-settings',
			'Analytics',
			'Analytics',
			'manage_options',
			'psp-analytics',
			array( __CLASS__, 'render_analytics_page' )
		);
	}

	/**
	 * Render analytics page
	 */
	public static function render_analytics_page(): void {
		$ticket_stats = self::get_ticket_stats( 30 );
		$partner_stats = self::get_partner_stats( 30 );
		$team_stats = self::get_team_performance();
		?>
		<div class="wrap">
			<h1>Analytics Dashboard</h1>

			<div style="margin: 20px 0;">
				<button class="button button-primary" id="psp-export-analytics">Export Report (CSV)</button>
			</div>

			<!-- Ticket Stats -->
			<div style="background: white; padding: 20px; border-radius: 5px; margin: 20px 0;">
				<h2>Ticket Statistics (Last 30 Days)</h2>
				<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px;">
					<div style="background: #f0f0f0; padding: 15px; border-radius: 3px;">
						<div style="font-size: 24px; font-weight: bold; color: #0073aa;">
							<?php echo esc_html( $ticket_stats['total_tickets'] ); ?>
						</div>
						<div>Total Tickets</div>
					</div>
					<div style="background: #f0f0f0; padding: 15px; border-radius: 3px;">
						<div style="font-size: 24px; font-weight: bold; color: #0073aa;">
							<?php echo esc_html( $ticket_stats['avg_response_hours'] ); ?>h
						</div>
						<div>Avg Response Time</div>
					</div>
				</div>

				<?php if ( ! empty( $ticket_stats['by_status'] ) ) : ?>
					<h3>Tickets by Status</h3>
					<table class="wp-list-table widefat fixed striped">
						<thead>
							<tr>
								<th>Status</th>
								<th>Count</th>
							</tr>
						</thead>
						<tbody>
							<?php foreach ( $ticket_stats['by_status'] as $status ) : ?>
								<tr>
									<td><?php echo esc_html( $status->status ); ?></td>
									<td><?php echo esc_html( $status->count ); ?></td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				<?php endif; ?>
			</div>

			<!-- Partner Stats -->
			<div style="background: white; padding: 20px; border-radius: 5px; margin: 20px 0;">
				<h2>Partner Statistics</h2>
				<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px;">
					<div style="background: #f0f0f0; padding: 15px; border-radius: 3px;">
						<div style="font-size: 24px; font-weight: bold; color: #28a745;">
							<?php echo esc_html( $partner_stats['total_partners'] ); ?>
						</div>
						<div>Total Partners</div>
					</div>
					<div style="background: #f0f0f0; padding: 15px; border-radius: 3px;">
						<div style="font-size: 24px; font-weight: bold; color: #28a745;">
							<?php echo esc_html( $partner_stats['new_partners'] ); ?>
						</div>
						<div>New (30 Days)</div>
					</div>
					<div style="background: #f0f0f0; padding: 15px; border-radius: 3px;">
						<div style="font-size: 24px; font-weight: bold; color: #28a745;">
							<?php echo esc_html( $partner_stats['conversion_rate'] ); ?>%
						</div>
						<div>Conversion Rate</div>
					</div>
				</div>

				<?php if ( ! empty( $partner_stats['top_partners'] ) ) : ?>
					<h3>Top Partners by Ticket Volume</h3>
					<table class="wp-list-table widefat fixed striped">
						<thead>
							<tr>
								<th>Partner</th>
								<th>Tickets</th>
							</tr>
						</thead>
						<tbody>
							<?php foreach ( $partner_stats['top_partners'] as $partner ) : ?>
								<tr>
									<td><?php echo esc_html( $partner->name ); ?></td>
									<td><?php echo esc_html( $partner->ticket_count ); ?></td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				<?php endif; ?>
			</div>

			<!-- Team Performance -->
			<div style="background: white; padding: 20px; border-radius: 5px; margin: 20px 0;">
				<h2>Team Performance</h2>
				<?php if ( ! empty( $team_stats ) ) : ?>
					<table class="wp-list-table widefat fixed striped">
						<thead>
							<tr>
								<th>Team Member</th>
								<th>Responses</th>
								<th>Closed Tickets</th>
								<th>Avg Response (Hours)</th>
							</tr>
						</thead>
						<tbody>
							<?php foreach ( $team_stats as $member ) : ?>
								<tr>
									<td>
										<strong><?php echo esc_html( $member['name'] ); ?></strong><br>
										<small><?php echo esc_html( $member['email'] ); ?></small>
									</td>
									<td><?php echo esc_html( $member['responses'] ); ?></td>
									<td><?php echo esc_html( $member['closed_tickets'] ); ?></td>
									<td><?php echo esc_html( $member['avg_response_hours'] ); ?></td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				<?php else : ?>
					<p><em>No team performance data available</em></p>
				<?php endif; ?>
			</div>
		</div>

		<script>
		document.getElementById('psp-export-analytics')?.addEventListener('click', function() {
			fetch(ajaxurl, {
				method: 'POST',
				headers: {'Content-Type': 'application/x-www-form-urlencoded'},
				body: new URLSearchParams({action: 'psp_export_analytics'})
			})
			.then(r => r.blob())
			.then(blob => {
				const url = window.URL.createObjectURL(blob);
				const a = document.createElement('a');
				a.href = url;
				a.download = 'analytics.csv';
				a.click();
			});
		});
		</script>
		<?php
	}
}

// Initialize analytics
Analytics_Dashboard::init();
