<?php
/**
 * Enhanced Utilities Class - Production-Ready Best Practices
 * 
 * Features:
 * - Strict type checking and validation
 * - Safe array/string operations with fallbacks
 * - Advanced caching with TTL management
 * - Input validation & sanitization (WordPress standard)
 * - Performance monitoring and debugging
 * - Full docstrings and error handling
 * - Version tracking
 *
 * @package PSP
 * @version 3.2.5
 */

namespace PSP\Utilities;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * EnhancedUtils Class - Comprehensive utility methods for PoolSafe Portal
 */
class EnhancedUtils {

	/**
	 * Class version
	 */
	const VERSION = '3.2.5';

	/**
	 * Cache for frequently accessed data
	 *
	 * @var array
	 */
	private static $cache = array();

	/**
	 * Performance metrics
	 *
	 * @var array
	 */
	private static $metrics = array();

	/**
	 * Safely get array value with type casting
	 *
	 * @param array  $arr    Array to search in
	 * @param string $key    Key to retrieve
	 * @param mixed  $default Default value if not found
	 * @param string $type   Expected type ('string', 'int', 'bool', 'array', 'float')
	 * @return mixed Typed value or default
	 *
	 * @example
	 *   $email = EnhancedUtils::get_array_value($_POST, 'email', '', 'string');
	 *   $id = EnhancedUtils::get_array_value($data, 'user_id', 0, 'int');
	 *   $enabled = EnhancedUtils::get_array_value($config, 'enabled', false, 'bool');
	 */
	public static function get_array_value( $arr, $key, $default = null, $type = null ) {
		if ( ! is_array( $arr ) || ! isset( $arr[ $key ] ) ) {
			return $default;
		}

		$value = $arr[ $key ];

		if ( null === $type ) {
			return $value;
		}

		return self::cast_value( $value, $type, $default );
	}

	/**
	 * Type-safe value casting with strict validation
	 *
	 * @param mixed  $value   Value to cast
	 * @param string $type    Type to cast to
	 * @param mixed  $default Default if cast fails
	 * @return mixed
	 */
	private static function cast_value( $value, $type, $default = null ) {
		switch ( strtolower( $type ) ) {
			case 'string':
				return is_scalar( $value ) ? (string) $value : $default;

			case 'int':
			case 'integer':
				return is_numeric( $value ) ? (int) $value : $default;

			case 'bool':
			case 'boolean':
				if ( is_bool( $value ) ) {
					return $value;
				}
				if ( is_string( $value ) ) {
					return in_array( strtolower( $value ), array( 'true', '1', 'yes', 'on' ) );
				}
				return ! empty( $value ) ? true : $default;

			case 'array':
				if ( is_array( $value ) ) {
					return $value;
				}
				if ( is_string( $value ) ) {
					$parts = array_map( 'trim', explode( ',', $value ) );
					return array_filter( $parts );
				}
				return $default;

			case 'float':
			case 'double':
				return is_numeric( $value ) ? (float) $value : $default;

			default:
				return $value;
		}
	}

	/**
	 * Safely sanitize and validate email address
	 *
	 * @param mixed $email Email to validate
	 * @param bool  $strict Use strict RFC5322 validation
	 * @return string|false Sanitized email or false if invalid
	 *
	 * @example
	 *   $email = EnhancedUtils::validate_email($_POST['email']);
	 *   if (!$email) { wp_die('Invalid email'); }
	 */
	public static function validate_email( $email, $strict = false ) {
		if ( ! is_scalar( $email ) ) {
			return false;
		}

		$email = sanitize_email( (string) $email );

		if ( empty( $email ) ) {
			return false;
		}

		if ( $strict ) {
			// RFC5322 strict validation via filter
			return filter_var( $email, FILTER_VALIDATE_EMAIL ) ? $email : false;
		}

		// WordPress standard validation
		return is_email( $email ) ? $email : false;
	}

	/**
	 * Safely merge arrays recursively
	 *
	 * @param array $base      Base array
	 * @param array $override  Override array (values override base)
	 * @param bool  $recursive Recursive merge (true) or shallow (false)
	 * @return array Merged array
	 *
	 * @example
	 *   $defaults = array('color' => 'blue', 'size' => 'large');
	 *   $custom = array('color' => 'red');
	 *   $result = EnhancedUtils::merge_arrays($defaults, $custom);\n   // Result: ['color' => 'red', 'size' => 'large']
	 */
	public static function merge_arrays( $base, $override, $recursive = true ) {
		if ( ! is_array( $base ) ) {
			$base = array();
		}
		if ( ! is_array( $override ) ) {
			return $base;
		}

		if ( ! $recursive ) {
			return array_merge( $base, $override );
		}

		foreach ( $override as $key => $value ) {
			if ( is_array( $value ) && isset( $base[ $key ] ) && is_array( $base[ $key ] ) ) {
				$base[ $key ] = self::merge_arrays( $base[ $key ], $value, true );
			} else {
				$base[ $key ] = $value;
			}
		}

		return $base;
	}

	/**
	 * Safe JSON encode with error handling and fallback
	 *
	 * @param mixed $data  Data to encode
	 * @param int   $flags JSON_* flags (default: JSON_UNESCAPED_SLASHES)
	 * @return string JSON string or '{}' on error
	 *
	 * @example
	 *   $json = EnhancedUtils::json_encode($user_data);\n   echo $json; // Safe output
	 */
	public static function json_encode( $data, $flags = JSON_UNESCAPED_SLASHES ) {
		// WordPress wp_json_encode() is the recommended method
		$json = wp_json_encode( $data, $flags );

		if ( false === $json ) {
			self::debug_log( 'JSON encoding failed: ' . json_last_error_msg(), 'json_encode' );
			return '{}';
		}

		return $json;
	}

	/**
	 * Safe JSON decode with error handling
	 *
	 * @param string $json   JSON string to decode
	 * @param bool   $assoc  Return as associative array (true) or object (false)
	 * @return mixed|null Decoded data or null if invalid
	 *
	 * @example
	 *   $data = EnhancedUtils::json_decode($json_string, true);\n   if ($data) { // Use $data safely }
	 */
	public static function json_decode( $json, $assoc = true ) {
		if ( ! is_string( $json ) || empty( $json ) ) {
			return null;
		}

		$decoded = json_decode( $json, $assoc );

		if ( null === $decoded && json_last_error() !== JSON_ERROR_NONE ) {
			self::debug_log( 'JSON decoding failed: ' . json_last_error_msg(), 'json_decode' );
			return null;
		}

		return $decoded;
	}

	/**
	 * Safely format file size for display
	 *
	 * @param int $bytes File size in bytes
	 * @return string Formatted size (e.g., "2.5 MB")
	 *
	 * @example
	 *   echo EnhancedUtils::format_file_size(2621440); // Output: "2.50 MB"
	 */
	public static function format_file_size( $bytes ) {
		$bytes = (int) $bytes;
		if ( $bytes <= 0 ) {
			return '0 B';
		}

		$units = array( 'B', 'KB', 'MB', 'GB', 'TB', 'PB' );
		$size  = $bytes;

		foreach ( $units as $unit ) {
			if ( $size < 1024 ) {
				return number_format( $size, 2 ) . ' ' . $unit;
			}
			$size = $size / 1024;
		}

		return number_format( $size * 1024, 2 ) . ' PB';
	}

	/**
	 * Get cached value or compute and cache
	 *
	 * Uses in-memory cache (session-based) for performance
	 *
	 * @param string   $key      Cache key
	 * @param callable $callback Function to compute value if not cached
	 * @param int      $ttl      Time to live in seconds (0 = session only)
	 * @return mixed
	 *
	 * @example
	 *   $user_data = EnhancedUtils::cached('user_123', function() {\n     return get_userdata(123);\n   }, 3600);
	 */
	public static function cached( $key, $callback, $ttl = 0 ) {
		if ( ! is_string( $key ) || empty( $key ) || ! is_callable( $callback ) ) {
			return call_user_func( $callback );
		}

		// Check in-memory cache
		if ( isset( self::$cache[ $key ] ) ) {
			$entry = self::$cache[ $key ];
			// If TTL is 0 (session only) or cache hasn't expired
			if ( 0 === $entry['ttl'] || time() < $entry['expires'] ) {
				self::record_metric( 'cache_hit', $key );
				return $entry['value'];
			} else {
				// Expired cache entry
				unset( self::$cache[ $key ] );
				self::record_metric( 'cache_expired', $key );
			}
		}

		// Compute and cache
		try {
			$value = call_user_func( $callback );

			self::$cache[ $key ] = array(
				'value'   => $value,
				'ttl'     => $ttl,
				'expires' => time() + $ttl,
			);

			self::record_metric( 'cache_miss', $key );
			return $value;
		} catch ( \Exception $e ) {
			self::debug_log( 'Cache callback error: ' . $e->getMessage(), 'cached' );
			return null;
		}
	}

	/**
	 * Clear cache by key pattern
	 *
	 * @param string $pattern Key pattern (supports wildcards with *)
	 * @return int Number of cleared entries
	 *
	 * @example
	 *   EnhancedUtils::clear_cache('user_*'); // Clear all user_* keys
	 *   EnhancedUtils::clear_cache();           // Clear all cache
	 */
	public static function clear_cache( $pattern = '*' ) {
		if ( '*' === $pattern ) {
			$count = count( self::$cache );
			self::$cache = array();
			return $count;
		}

		$count = 0;
		foreach ( array_keys( self::$cache ) as $key ) {
			if ( fnmatch( $pattern, $key ) ) {
				unset( self::$cache[ $key ] );
				$count++;
			}
		}

		return $count;
	}

	/**
	 * Get cache statistics
	 *
	 * @return array Cache stats including size, entries, hit rate
	 */
	public static function get_cache_stats() {
		$entries = count( self::$cache );
		$size    = 0;

		foreach ( self::$cache as $entry ) {
			$size += strlen( wp_json_encode( $entry['value'] ) );
		}

		return array(
			'entries' => $entries,
			'size'    => self::format_file_size( $size ),
			'metrics' => self::$metrics,
		);
	}

	/**
	 * Record performance metric
	 *
	 * @param string $metric Metric name
	 * @param mixed  $value  Metric value
	 * @return void
	 */
	private static function record_metric( $metric, $value = null ) {
		if ( ! isset( self::$metrics[ $metric ] ) ) {
			self::$metrics[ $metric ] = 0;
		}
		self::$metrics[ $metric ]++;
	}

	/**
	 * Build HTML attributes string from array
	 *
	 * @param array $attributes Attributes array (key => value)
	 * @return string Safe HTML attributes string
	 *
	 * @example
	 *   $attrs = EnhancedUtils::build_attributes([\n     'class' => 'btn btn-primary',\n     'data-id' => '123',\n     'disabled' => true,\n   ]);\n   // Result: 'class="btn btn-primary" data-id="123" disabled'
	 */
	public static function build_attributes( $attributes ) {
		if ( ! is_array( $attributes ) || empty( $attributes ) ) {
			return '';
		}

		$parts = array();

		foreach ( $attributes as $key => $value ) {
			// Skip null/false values
			if ( null === $value || false === $value ) {
				continue;
			}

			// Boolean attributes (no value needed)
			if ( true === $value ) {
				$parts[] = esc_attr( $key );
			} else {
				// Key="value" attributes
				$parts[] = sprintf( '%s="%s"', esc_attr( $key ), esc_attr( (string) $value ) );
			}
		}

		return implode( ' ', $parts );
	}

	/**
	 * Safely get POST/GET/REQUEST parameter
	 *
	 * @param string $param   Parameter name
	 * @param mixed  $default Default value if not found
	 * @param string $type    Expected type for casting
	 * @return mixed Sanitized and typed value
	 *
	 * @example
	 *   $user_id = EnhancedUtils::get_request_param('user_id', 0, 'int');
	 *   $action = EnhancedUtils::get_request_param('action', '', 'string');
	 */
	public static function get_request_param( $param, $default = null, $type = 'string' ) {
		if ( ! isset( $_REQUEST[ $param ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return $default;
		}

		// Always sanitize input
		$value = sanitize_text_field( $_REQUEST[ $param ] ); // phpcs:ignore WordPress.Security.NonceVerification

		return self::cast_value( $value, $type, $default );
	}

	/**
	 * Generate a unique string ID
	 *
	 * @param string $prefix Optional prefix for the ID
	 * @param int    $length Length of random part (default: 8)
	 * @return string Unique ID
	 *
	 * @example
	 *   $ticket_id = EnhancedUtils::generate_id('ticket_', 12);
	 *   // Result: "ticket_a3f8k2m9x1p4"
	 */
	public static function generate_id( $prefix = '', $length = 8 ) {
		$length = max( 4, min( 32, (int) $length ) );
		$chars  = '0123456789abcdefghijklmnopqrstuvwxyz';
		$random = substr( str_shuffle( str_repeat( $chars, ceil( $length / strlen( $chars ) ) ) ), 0, $length );

		return $prefix ? "{$prefix}{$random}" : $random;
	}

	/**
	 * Convert array keys from snake_case to camelCase
	 *
	 * @param array $array Input array
	 * @return array Array with camelCased keys
	 *
	 * @example
	 *   $input = ['user_name' => 'John', 'user_email' => 'john@example.com'];
	 *   $output = EnhancedUtils::to_camel_case_keys($input);\n   // Result: ['userName' => 'John', 'userEmail' => 'john@example.com']
	 */
	public static function to_camel_case_keys( $array ) {
		if ( ! is_array( $array ) || empty( $array ) ) {
			return $array;
		}

		$result = array();

		foreach ( $array as $key => $value ) {
			$camel_key            = lcfirst( str_replace( ' ', '', ucwords( str_replace( '_', ' ', (string) $key ) ) ) );
			$result[ $camel_key ] = is_array( $value ) ? self::to_camel_case_keys( $value ) : $value;
		}

		return $result;
	}

	/**
	 * Convert array keys from camelCase to snake_case
	 *
	 * @param array $array Input array
	 * @return array Array with snake_cased keys
	 */
	public static function to_snake_case_keys( $array ) {
		if ( ! is_array( $array ) || empty( $array ) ) {
			return $array;
		}

		$result = array();

		foreach ( $array as $key => $value ) {
			$snake_key            = strtolower( preg_replace( '/([a-z])([A-Z])/', '$1_$2', (string) $key ) );
			$result[ $snake_key ] = is_array( $value ) ? self::to_snake_case_keys( $value ) : $value;
		}

		return $result;
	}

	/**
	 * Check if request is AJAX
	 *
	 * @return bool True if AJAX request, false otherwise
	 */
	public static function is_ajax() {
		return defined( 'DOING_AJAX' ) && DOING_AJAX;
	}

	/**
	 * Check if request is REST API
	 *
	 * @return bool True if REST API request, false otherwise
	 */
	public static function is_rest() {
		return defined( 'REST_REQUEST' ) && REST_REQUEST;
	}

	/**
	 * Log debug message (only in WP_DEBUG mode)
	 *
	 * @param mixed  $message Message to log
	 * @param string $context Optional context/source
	 * @return bool True if logged, false otherwise
	 *
	 * @example
	 *   EnhancedUtils::debug_log('User login attempt', 'auth');
	 */
	public static function debug_log( $message, $context = '' ) {
		if ( ! WP_DEBUG || ! WP_DEBUG_LOG ) {
			return false;
		}


		$prefix = $context ? "[{$context}] " : '[PSP] ';
		$log_message = $prefix . ( is_string( $message ) ? $message : wp_json_encode( $message ) );

		error_log( $log_message );

		return true;
	}

	/**
	 * Get class version
	 *
	 * @return string Version string
	 */
	public static function get_version() {
		return self::VERSION;
	}

	/**
	 * Advanced rate limiting with key-based throttling
	 *
	 * @param string $key      Unique key for rate limiting (user ID, IP, etc.)
	 * @param int    $limit    Maximum calls allowed
	 * @param int    $window   Time window in seconds
	 * @return bool Whether the action is allowed
	 *
	 * @example
	 *   if ( EnhancedUtils::rate_limit( 'user_' . $user_id, 5, 60 ) ) {
	 *       // Allow action - less than 5 calls per 60 seconds
	 *   }
	 */
	public static function rate_limit( $key, $limit = 10, $window = 60 ) {
		$transient_key = 'psp_rl_' . md5( $key );
		$current_count = (int) get_transient( $transient_key );

		if ( $current_count >= $limit ) {
			return false;
		}

		set_transient( $transient_key, $current_count + 1, $window );
		return true;
	}

	/**
	 * Safe file operations with permission checks
	 *
	 * @param string $filepath Path to file
	 * @param string $operation Operation (read, write, delete, exists)
	 * @return mixed File contents or boolean
	 */
	public static function file_operation( $filepath, $operation = 'read' ) {
		if ( ! is_string( $filepath ) ) {
			return false;
		}

		switch ( $operation ) {
			case 'read':
				return is_readable( $filepath ) ? file_get_contents( $filepath ) : false;

			case 'write':
				return wp_is_writable( dirname( $filepath ) );

			case 'delete':
				return is_writable( dirname( $filepath ) ) && unlink( $filepath );

			case 'exists':
				return file_exists( $filepath );

			default:
				return false;
		}
	}

	/**
	 * Generate secure random token
	 *
	 * @param int $length Token length
	 * @return string Random token
	 */
	public static function generate_token( $length = 32 ) {
		if ( function_exists( 'random_bytes' ) ) {
			return bin2hex( random_bytes( $length / 2 ) );
		}
		return bin2hex( openssl_random_pseudo_bytes( $length / 2 ) );
	}

	/**
	 * Batch operations with chunking for memory efficiency
	 *
	 * @param array    $items      Items to process
	 * @param callable $callback   Processing function
	 * @param int      $chunk_size Chunk size for batching
	 * @return array Results
	 */
	public static function batch_process( $items, $callback, $chunk_size = 100 ) {
		if ( ! is_array( $items ) || ! is_callable( $callback ) ) {
			return array();
		}

		$results = array();
		$chunks = array_chunk( $items, $chunk_size );

		foreach ( $chunks as $chunk ) {
			$results = array_merge( $results, array_map( $callback, $chunk ) );
		}

		return $results;
	}

	/**
	 * Deep array merge (recursive)
	 *
	 * @param array $array1 Base array
	 * @param array $array2 Array to merge
	 * @return array Merged array
	 */
	public static function deep_merge( $array1, $array2 ) {
		if ( ! is_array( $array1 ) || ! is_array( $array2 ) ) {
			return $array1;
		}

		foreach ( $array2 as $key => $value ) {
			if ( is_array( $value ) && isset( $array1[ $key ] ) && is_array( $array1[ $key ] ) ) {
				$array1[ $key ] = self::deep_merge( $array1[ $key ], $value );
			} else {
				$array1[ $key ] = $value;
			}
		}

		return $array1;
	}

	/**
	 * Check if string matches pattern (with regex support)
	 *
	 * @param string $string  String to check
	 * @param string $pattern Pattern (can be regex or wildcard)
	 * @return bool Match result
	 */
	public static function pattern_match( $string, $pattern ) {
		if ( strpos( $pattern, '*' ) !== false ) {
			// Wildcard pattern
			$regex = str_replace( '\*', '.*', preg_quote( $pattern, '/' ) );
			return (bool) preg_match( '/^' . $regex . '$/', $string );
		}
		// Regex pattern
		return (bool) preg_match( $pattern, $string );
	}

	/**
	 * Get request metadata (IP, user agent, etc.)
	 *
	 * @return array Request metadata
	 */
	public static function get_request_metadata() {
		return array(
			'ip'         => self::get_client_ip(),
			'user_agent' => isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '',
			'method'     => isset( $_SERVER['REQUEST_METHOD'] ) ? sanitize_key( $_SERVER['REQUEST_METHOD'] ) : 'GET',
			'timestamp'  => current_time( 'mysql' ),
			'is_https'   => is_ssl(),
			'referer'    => isset( $_SERVER['HTTP_REFERER'] ) ? esc_url_raw( wp_unslash( $_SERVER['HTTP_REFERER'] ) ) : '',
		);
	}

	/**
	 * Get client IP address (with proxy awareness)
	 *
	 * @return string Client IP address
	 */
	public static function get_client_ip() {
		$ip_keys = array(
			'HTTP_CF_CONNECTING_IP',  // Cloudflare
			'HTTP_X_FORWARDED_FOR',   // Proxy
			'HTTP_X_FORWARDED',
			'HTTP_FORWARDED_FOR',
			'HTTP_FORWARDED',
			'HTTP_CLIENT_IP',
			'REMOTE_ADDR',            // Default
		);

		foreach ( $ip_keys as $key ) {
			if ( ! empty( $_SERVER[ $key ] ) ) {
				$ips = explode( ',', sanitize_text_field( wp_unslash( $_SERVER[ $key ] ) ) );
				$ip  = trim( $ips[0] );
				if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) {
					return $ip;
				}
			}
		}

		return '127.0.0.1';
	}
}

