<?php
namespace PSP;

/**
 * REST API Handler for PoolSafe Portal
 * Provides all necessary endpoints for frontend communication
 */
class REST {

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );

		// Lightweight private caching for GET endpoints to reduce DB chatter per user
		add_filter( 'rest_request_before_callbacks', array( __CLASS__, 'maybe_serve_cache' ), 10, 3 );
		add_filter( 'rest_post_dispatch', array( __CLASS__, 'maybe_store_cache' ), 10, 3 );
	}

	/**
	 * Determine if the request should be cached (GET, our namespace, authenticated user).
	 */
	private static function should_cache_request( $request ) {
		if ( ! $request instanceof \WP_REST_Request ) {
			return false;
		}

		if ( $request->get_method() !== 'GET' ) {
			return false;
		}

		$route = $request->get_route();
		if ( strpos( $route, '/psp/v1/' ) !== 0 ) {
			return false;
		}

		return is_user_logged_in();
	}

	/**
	 * Serve cached REST response when available.
	 */
	public static function maybe_serve_cache( $result, $server, $request ) {
		if ( ! self::should_cache_request( $request ) ) {
			return $result;
		}

		$user_id = get_current_user_id();
		$key     = self::build_cache_key( $request, $user_id );
		$cached  = wp_cache_get( $key, 'psp_rest' );

		if ( false === $cached ) {
			return $result;
		}

		$response = new \WP_REST_Response( $cached['data'], $cached['status'] );
		$response->set_headers( $cached['headers'] ?? array() );

		return self::attach_cache_headers( $response, $cached['etag'] ?? null );
	}

	/**
	 * Store REST response in object cache for short TTL.
	 */
	public static function maybe_store_cache( $response, $server, $request ) {
		if ( ! self::should_cache_request( $request ) ) {
			return $response;
		}

		$response = rest_ensure_response( $response );

		// Only cache successful responses
		$status = (int) $response->get_status();
		if ( $status < 200 || $status >= 300 ) {
			return $response;
		}

		$data   = $response->get_data();
		$etag   = wp_hash( wp_json_encode( $data ) );
		$key    = self::build_cache_key( $request, get_current_user_id() );
		$ttl    = 60; // seconds

		wp_cache_set(
			$key,
			array(
				'data'    => $data,
				'headers' => $response->get_headers(),
				'status'  => $status,
				'etag'    => $etag,
			),
			'psp_rest',
			$ttl
		);

		return self::attach_cache_headers( $response, $etag );
	}

	private static function build_cache_key( $request, $user_id ) {
		$params = $request->get_params();
		return 'psp_rest:' . $user_id . ':' . md5( $request->get_route() . '|' . wp_json_encode( $params ) );
	}

	private static function attach_cache_headers( $response, $etag ) {
		if ( ! $response instanceof \WP_REST_Response ) {
			return $response;
		}

		$response->header( 'Cache-Control', 'private, max-age=60' );
		if ( $etag ) {
			$response->header( 'ETag', $etag );
		}

		return $response;
	}

	public static function register_routes() {
		// Health Check
		register_rest_route(
			'psp/v1',
			'/health',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'health_check' ),
				'permission_callback' => '__return_true',
			)
		);

		// PARTNERS / COMPANIES ENDPOINTS
		// GET /psp/v1/partners - List all partners (for admin/support)
		register_rest_route(
			'psp/v1',
			'/partners',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'get_partners' ),
				'permission_callback' => array( __CLASS__, 'can_view_partners' ),
			)
		);

		// GET /psp/v1/companies - List companies (same as partners)
		register_rest_route(
			'psp/v1',
			'/companies',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'get_companies' ),
				'permission_callback' => array( __CLASS__, 'can_view_partners' ),
			)
		);

		// GET /psp/v1/companies/{id} - Get single company details
		register_rest_route(
			'psp/v1',
			'/companies/(?P<id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'get_company' ),
				'permission_callback' => array( __CLASS__, 'can_view_partners' ),
				'args'                => array(
					'id' => array(
						'type'              => 'integer',
						'required'          => true,
						'sanitize_callback' => 'absint',
					),
				),
			)
		);

		// GET /psp/v1/partners/{id}/contacts - Get company contacts
		register_rest_route(
			'psp/v1',
			'/partners/(?P<id>\d+)/contacts',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'get_partner_contacts' ),
				'permission_callback' => array( __CLASS__, 'can_view_partners' ),
				'args'                => array(
					'id' => array(
						'type'              => 'integer',
						'required'          => true,
						'sanitize_callback' => 'absint',
					),
				),
			)
		);

		// POST /psp/v1/partners/{id}/contacts - Add contact to partner
		register_rest_route(
			'psp/v1',
			'/partners/(?P<id>\d+)/contacts',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'add_partner_contact' ),
				'permission_callback' => array( __CLASS__, 'can_manage_partners' ),
				'args'                => array(
					'id' => array(
						'type'              => 'integer',
						'required'          => true,
						'sanitize_callback' => 'absint',
					),
				),
			)
		);

		// DELETE /psp/v1/partners/{id}/contacts/{contact_id}
		register_rest_route(
			'psp/v1',
			'/partners/(?P<id>\d+)/contacts/(?P<contact_id>\d+)',
			array(
				'methods'             => 'DELETE',
				'callback'            => array( __CLASS__, 'delete_partner_contact' ),
				'permission_callback' => array( __CLASS__, 'can_manage_partners' ),
				'args'                => array(
					'id'         => array(
						'type'              => 'integer',
						'required'          => true,
						'sanitize_callback' => 'absint',
					),
					'contact_id' => array(
						'type'              => 'integer',
						'required'          => true,
						'sanitize_callback' => 'absint',
					),
				),
			)
		);

		// PATCH /psp/v1/partners/{id}/company-users/primary - Set primary user
		register_rest_route(
			'psp/v1',
			'/partners/(?P<id>\d+)/company-users/primary',
			array(
				'methods'             => 'PATCH',
				'callback'            => array( __CLASS__, 'set_primary_user' ),
				'permission_callback' => array( __CLASS__, 'can_manage_partners' ),
				'args'                => array(
					'id' => array(
						'type'              => 'integer',
						'required'          => true,
						'sanitize_callback' => 'absint',
					),
				),
			)
		);

		// TICKETS ENDPOINTS
		// GET /psp/v1/tickets - Get all tickets
		register_rest_route(
			'psp/v1',
			'/tickets',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'get_tickets' ),
				'permission_callback' => array( __CLASS__, 'can_view_tickets' ),
			)
		);

		// GET /psp/v1/contacts - Contacts for current user's company
		register_rest_route(
			'psp/v1',
			'/contacts',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'get_contacts' ),
				'permission_callback' => array( __CLASS__, 'can_view_partners' ),
			)
		);

		// POST /psp/v1/tickets - Create ticket
		register_rest_route(
			'psp/v1',
			'/tickets',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'create_ticket' ),
				'permission_callback' => array( __CLASS__, 'can_create_ticket' ),
			)
		);

		// GET /psp/v1/tickets/{id} - Get single ticket
		register_rest_route(
			'psp/v1',
			'/tickets/(?P<id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'get_ticket' ),
				'permission_callback' => array( __CLASS__, 'can_view_tickets' ),
				'args'                => array(
					'id' => array(
						'type'              => 'integer',
						'required'          => true,
						'sanitize_callback' => 'absint',
					),
				),
			)
		);

		// PUT/PATCH /psp/v1/tickets/{id} - Update ticket
		register_rest_route(
			'psp/v1',
			'/tickets/(?P<id>\d+)',
			array(
				'methods'             => array( 'PUT', 'PATCH' ),
				'callback'            => array( __CLASS__, 'update_ticket' ),
				'permission_callback' => array( __CLASS__, 'can_manage_tickets' ),
				'args'                => array(
					'id' => array(
						'type'              => 'integer',
						'required'          => true,
						'sanitize_callback' => 'absint',
					),
				),
			)
		);

		// SERVICES ENDPOINT
		register_rest_route(
			'psp/v1',
			'/services',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'get_services' ),
				'permission_callback' => array( __CLASS__, 'can_view_services' ),
			)
		);

		// STATS ENDPOINT
		register_rest_route(
			'psp/v1',
			'/stats',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'get_stats' ),
				'permission_callback' => array( __CLASS__, 'can_view_dashboard' ),
			)
		);

		// USERS ENDPOINT
		register_rest_route(
			'psp/v1',
			'/users',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'get_users' ),
				'permission_callback' => array( __CLASS__, 'can_view_partners' ),
			)
		);

		// PATCH /psp/v1/users/{id}/notification-prefs - Save notification preferences
		register_rest_route(
			'psp/v1',
			'/users/(?P<id>\d+)/notification-prefs',
			array(
				'methods'             => 'PATCH',
				'callback'            => array( __CLASS__, 'save_notification_prefs' ),
				'permission_callback' => array( __CLASS__, 'can_manage_partners' ),
				'args'                => array(
					'id' => array(
						'type'              => 'integer',
						'required'          => true,
						'sanitize_callback' => 'absint',
					),
				),
			)
		);

		// DASHBOARD WIDGETS
		register_rest_route(
			'psp/v1',
			'/dashboard-widgets',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'save_dashboard_widgets' ),
				'permission_callback' => array( __CLASS__, 'can_view_dashboard' ),
			)
		);

		// Partner map
		register_rest_route(
			'psp/v1',
			'/partners/map',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'get_partner_map' ),
				'permission_callback' => '__return_true',
			)
		);

		// GET /psp/v1/partners/me - Get current user's partner
		register_rest_route(
			'psp/v1',
			'/partners/me',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'get_current_user_partner' ),
				'permission_callback' => array( __CLASS__, 'can_view_partners' ),
			)
		);

		// POST /psp/v1/partners/import - Import partners from CSV
		register_rest_route(
			'psp/v1',
			'/partners/import',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'import_partners' ),
				'permission_callback' => array( __CLASS__, 'can_manage_partners' ),
			)
		);

		// POST /psp/v1/tickets/export - Export tickets to CSV
		register_rest_route(
			'psp/v1',
			'/tickets/export',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'export_tickets' ),
				'permission_callback' => array( __CLASS__, 'can_view_tickets' ),
			)
		);

		// POST /psp/v1/tickets/import - Import tickets from CSV
		register_rest_route(
			'psp/v1',
			'/tickets/import',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'import_tickets' ),
				'permission_callback' => array( __CLASS__, 'can_manage_tickets' ),
			)
		);

		// GET /psp/v1/service-records - Get service records
		register_rest_route(
			'psp/v1',
			'/service-records',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'get_service_records' ),
				'permission_callback' => array( __CLASS__, 'can_view_partners' ),
			)
		);

		// GET /psp/v1/support/metrics - Get support metrics
		register_rest_route(
			'psp/v1',
			'/support/metrics',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'get_support_metrics' ),
				'permission_callback' => array( __CLASS__, 'can_manage_partners' ),
			)
		);

		// POST /psp/v1/tickets/{id}/comments - Add comment to ticket
		register_rest_route(
			'psp/v1',
			'/tickets/(?P<id>\d+)/comments',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'add_ticket_comment' ),
				'permission_callback' => array( __CLASS__, 'can_create_ticket' ),
				'args'                => array(
					'id' => array(
						'type'              => 'integer',
						'required'          => true,
						'sanitize_callback' => 'absint',
					),
				),
			)
		);

		// GET /psp/v1/dashboard/stats - Dashboard statistics
		register_rest_route(
			'psp/v1',
			'/dashboard/stats',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'get_dashboard_stats' ),
				'permission_callback' => array( __CLASS__, 'can_view_dashboard' ),
			)
		);

		// GET /psp/v1/services - Service records (alias for service-records)
		register_rest_route(
			'psp/v1',
			'/services',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'get_service_records' ),
				'permission_callback' => array( __CLASS__, 'can_view_partners' ),
			)
		);

		// POST /psp/v1/services - Create service record
		register_rest_route(
			'psp/v1',
			'/services',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'create_service_record' ),
				'permission_callback' => array( __CLASS__, 'can_create_ticket' ),
			)
		);
	}

	// ===== HEALTH CHECK =====
	public static function health_check( $request ) {
		return rest_ensure_response(
			array(
				'status'  => 'ok',
				'version' => '2.5.0',
				'timestamp' => current_time( 'mysql' ),
			)
		);
	}

	// ===== PERMISSION CALLBACKS =====
	/**
	 * Check if user can view dashboard
	 *
	 * @return bool True if user is authenticated
	 */
	public static function can_view_dashboard() {
		try {
			if ( ! function_exists( 'is_user_logged_in' ) ) {
				error_log( '[PSP REST] is_user_logged_in() not available' );
				return false;
			}
			return is_user_logged_in();
		} catch ( \Exception $e ) {
			error_log( '[PSP REST] can_view_dashboard check failed: ' . $e->getMessage() );
			return false;
		}
	}

	/**
	 * Check if user can view partners/companies
	 *
	 * @return bool True if user is authenticated
	 */
	public static function can_view_partners() {
		try {
			if ( ! function_exists( 'is_user_logged_in' ) ) {
				error_log( '[PSP REST] is_user_logged_in() not available for partner view' );
				return false;
			}
			return is_user_logged_in();
		} catch ( \Exception $e ) {
			error_log( '[PSP REST] can_view_partners check failed: ' . $e->getMessage() );
			return false;
		}
	}

	/**
	 * Check if user can manage partners/companies
	 *
	 * @return bool True if user has manage_options or support capabilities
	 */
	public static function can_manage_partners() {
		try {
			if ( ! function_exists( 'current_user_can' ) ) {
				error_log( '[PSP REST] current_user_can() not available for partner management' );
				return false;
			}
			
			$has_permission = current_user_can( 'manage_options' ) || 
				              current_user_can( 'psp_support' ) || 
				              current_user_can( 'pool_safe_support' );
			
			if ( ! $has_permission ) {
				error_log( '[PSP REST] User attempted partner management without permission (User ID: ' . get_current_user_id() . ')' );
			}
			
			return $has_permission;
		} catch ( \Exception $e ) {
			error_log( '[PSP REST] can_manage_partners check failed: ' . $e->getMessage() );
			return false;
		}
	}

	/**
	 * Check if user can view tickets
	 *
	 * @return bool True if user is authenticated
	 */
	public static function can_view_tickets() {
		try {
			if ( ! function_exists( 'is_user_logged_in' ) ) {
				error_log( '[PSP REST] is_user_logged_in() not available for ticket view' );
				return false;
			}
			return is_user_logged_in();
		} catch ( \Exception $e ) {
			error_log( '[PSP REST] can_view_tickets check failed: ' . $e->getMessage() );
			return false;
		}
	}

	/**
	 * Check if user can create tickets
	 *
	 * @return bool True if user is authenticated
	 */
	public static function can_create_ticket() {
		try {
			if ( ! function_exists( 'is_user_logged_in' ) ) {
				error_log( '[PSP REST] is_user_logged_in() not available for ticket creation' );
				return false;
			}
			return is_user_logged_in();
		} catch ( \Exception $e ) {
			error_log( '[PSP REST] can_create_ticket check failed: ' . $e->getMessage() );
			return false;
		}
	}

	/**
	 * Check if user can manage tickets
	 *
	 * @return bool True if user has manage_options or support capabilities
	 */
	public static function can_manage_tickets() {
		try {
			if ( ! function_exists( 'current_user_can' ) ) {
				error_log( '[PSP REST] current_user_can() not available for ticket management' );
				return false;
			}
			
			$has_permission = current_user_can( 'manage_options' ) || 
				              current_user_can( 'psp_support' ) || 
				              current_user_can( 'pool_safe_support' );
			
			if ( ! $has_permission ) {
				error_log( '[PSP REST] User attempted ticket management without permission (User ID: ' . get_current_user_id() . ')' );
			}
			
			return $has_permission;
		} catch ( \Exception $e ) {
			error_log( '[PSP REST] can_manage_tickets check failed: ' . $e->getMessage() );
			return false;
		}
	}

	/**
	 * Check if user can view services
	 *
	 * @return bool True if user is authenticated
	 */
	public static function can_view_services() {
		try {
			if ( ! function_exists( 'is_user_logged_in' ) ) {
				error_log( '[PSP REST] is_user_logged_in() not available for service view' );
				return false;
			}
			return is_user_logged_in();
		} catch ( \Exception $e ) {
			error_log( '[PSP REST] can_view_services check failed: ' . $e->getMessage() );
			return false;
		}
	}

	// ===== PARTNERS / COMPANIES =====
	public static function get_partners( $request ) {
		// Query all partner (company) posts
		$args = array(
			'post_type'      => 'psp_company',
			'posts_per_page' => -1,
			'orderby'        => 'title',
			'order'          => 'ASC',
		);

		$posts = get_posts( $args );
		$partners = array();

		foreach ( $posts as $post ) {
			$partners[] = self::format_partner( $post );
		}

		return rest_ensure_response( $partners );
	}

	public static function get_companies( $request ) {
		// Same as get_partners
		return self::get_partners( $request );
	}

	public static function get_company( $request ) {
		$id   = $request['id'];
		$post = get_post( $id );

		if ( ! $post || 'psp_company' !== $post->post_type ) {
			return new \WP_Error(
				'company_not_found',
				'Company not found',
				array( 'status' => 404 )
			);
		}

		return rest_ensure_response( array( 'success' => true, 'data' => self::format_partner( $post ) ) );
	}

	public static function get_partner_contacts( $request ) {
		$partner_id = $request['id'];
		$partner    = get_post( $partner_id );

		if ( ! $partner || 'psp_company' !== $partner->post_type ) {
			return new \WP_Error(
				'partner_not_found',
				'Partner not found',
				array( 'status' => 404 )
			);
		}

		// Query psp_contact posts for this company
		$args = array(
			'post_type'      => 'psp_contact',
			'posts_per_page' => -1,
			'meta_query'     => array(
				array(
					'key'   => 'psp_company_id',
					'value' => $partner_id,
					'compare' => '=',
				),
			),
		);

		$posts    = get_posts( $args );
		$contacts = array();

		foreach ( $posts as $post ) {
			$contacts[] = array(
				'id'    => $post->ID,
				'name'  => $post->post_title,
				'email' => get_post_meta( $post->ID, 'psp_email', true ),
				'phone' => get_post_meta( $post->ID, 'psp_phone', true ),
				'role'  => get_post_meta( $post->ID, 'psp_role', true ),
				'isPrimary' => get_post_meta( $post->ID, 'psp_is_primary', true ),
			);
		}

		return rest_ensure_response( $contacts );
	}

	public static function get_contacts( $request ) {
		$user_id = get_current_user_id();
		$company_id = get_user_meta( $user_id, 'psp_company_id', true );

		if ( ! $company_id ) {
			return rest_ensure_response( array( 'success' => true, 'data' => array(), 'total' => 0 ) );
		}

		$args = array(
			'post_type'      => 'psp_contact',
			'posts_per_page' => 50,
			'meta_query'     => array(
				array(
					'key'   => 'psp_company_id',
					'value' => $company_id,
				),
			),
		);

		$posts    = get_posts( $args );
		$contacts = array_map( function( $post ) {
			return array(
				'id'    => $post->ID,
				'name'  => $post->post_title,
				'role'  => get_post_meta( $post->ID, 'psp_role', true ),
				'email' => get_post_meta( $post->ID, 'psp_email', true ),
				'phone' => get_post_meta( $post->ID, 'psp_phone', true ),
			);
		}, $posts );

		return rest_ensure_response( array(
			'success' => true,
			'data'    => $contacts,
			'total'   => count( $contacts ),
		) );
	}

	public static function add_partner_contact( $request ) {
		$partner_id = $request['id'];
		$params = $request->get_json_params();

		$partner = get_post( $partner_id );
		if ( ! $partner || 'psp_company' !== $partner->post_type ) {
			return new \WP_Error(
				'partner_not_found',
				'Partner not found',
				array( 'status' => 404 )
			);
		}

		$name  = sanitize_text_field( $params['name'] ?? '' );
		$email = sanitize_email( $params['email'] ?? '' );
		$phone = sanitize_text_field( $params['phone'] ?? '' );
		$role  = sanitize_text_field( $params['role'] ?? '' );
		$is_primary = ! empty( $params['is_primary'] );

		if ( ! $name || ! $email ) {
			return new \WP_Error(
				'invalid_data',
				'Name and email are required',
				array( 'status' => 400 )
			);
		}

		// Create contact post
		$contact_id = wp_insert_post(
			array(
				'post_type'   => 'psp_contact',
				'post_title'  => $name,
				'post_status' => 'publish',
			)
		);

		if ( is_wp_error( $contact_id ) ) {
			return $contact_id;
		}

		// Add metadata
		update_post_meta( $contact_id, 'psp_company_id', $partner_id );
		update_post_meta( $contact_id, 'psp_email', $email );
		update_post_meta( $contact_id, 'psp_phone', $phone );
		update_post_meta( $contact_id, 'psp_role', $role );
		update_post_meta( $contact_id, 'psp_is_primary', $is_primary );

		return rest_ensure_response(
			array(
				'id'    => $contact_id,
				'name'  => $name,
				'email' => $email,
				'phone' => $phone,
				'role'  => $role,
				'isPrimary' => $is_primary,
			)
		);
	}

	public static function delete_partner_contact( $request ) {
		$partner_id = $request['id'];
		$contact_id = $request['contact_id'];

		$contact = get_post( $contact_id );
		if ( ! $contact || 'psp_contact' !== $contact->post_type ) {
			return new \WP_Error(
				'contact_not_found',
				'Contact not found',
				array( 'status' => 404 )
			);
		}

		// Verify contact belongs to partner
		$company_id = get_post_meta( $contact_id, 'psp_company_id', true );
		if ( intval( $company_id ) !== intval( $partner_id ) ) {
			return new \WP_Error(
				'unauthorized',
				'Contact does not belong to this partner',
				array( 'status' => 403 )
			);
		}

		wp_delete_post( $contact_id, true );

		return rest_ensure_response( array( 'deleted' => true ) );
	}

	public static function set_primary_user( $request ) {
		$partner_id = $request['id'];
		$params     = $request->get_json_params();
		$user_id    = intval( $params['user_id'] ?? 0 );

		if ( ! $user_id ) {
			return new \WP_Error(
				'invalid_user',
				'User ID is required',
				array( 'status' => 400 )
			);
		}

		update_user_meta( $user_id, 'psp_primary_for_company', $partner_id );

		return rest_ensure_response( array( 'updated' => true ) );
	}

	// ===== TICKETS =====
	public static function get_tickets( $request ) {
		// Check company auth first
		$company_user = \PSP\Company_Auth::validate_session();
		
		if ( $company_user ) {
			return self::get_company_tickets( $request, $company_user );
		}

		// Fall back to WordPress tickets (Custom Post Types)
		$page     = max( 1, (int) $request->get_param( 'page' ) );
		$per_page = max( 1, min( 100, (int) $request->get_param( 'per_page' ) ?: 25 ) );
		$fields   = $request->get_param( '_fields' );

		$query = new \WP_Query(
			array(
				'post_type'      => 'psp_ticket',
				'posts_per_page' => $per_page,
				'paged'          => $page,
				'no_found_rows'  => false,
			)
		);

		$posts   = $query->posts;
		$tickets = array();
		foreach ( $posts as $post ) {
			$tickets[] = self::maybe_filter_fields( self::format_ticket( $post ), $fields );
		}

		$response = array(
			'success'   => true,
			'data'      => $tickets,
			'total'     => (int) $query->found_posts,
			'page'      => $page,
			'per_page'  => $per_page,
		);

		return rest_ensure_response( $response );
	}

	private static function get_company_tickets( $request, $company_user ) {
		global $wpdb;
		
		$page = max( 1, (int) $request->get_param( 'page' ) ?: 1 );
		$per_page = max( 1, min( 100, (int) $request->get_param( 'per_page' ) ?: 20 ) );
		$status = sanitize_text_field( $request->get_param( 'status' ) ?: '' );
		$offset = ( $page - 1 ) * $per_page;

		$tickets_table = $wpdb->prefix . 'psp_tickets';
		$where = array();
		$where_values = array();

		if ( $company_user['type'] === 'company' ) {
			$partner_id = self::get_partner_id_for_company( $company_user['id'] );
			$where[] = 'partner_id = %d';
			$where_values[] = $partner_id;
		}

		if ( $status ) {
			$where[] = 'status = %s';
			$where_values[] = $status;
		}

		$where_sql = $where ? 'WHERE ' . implode( ' AND ', $where ) : '';
		
		$query = "SELECT t.id, t.ticket_number, t.title as subject, t.status, t.priority, 
				  DATE_FORMAT(t.updated_at, '%%Y-%%m-%%d %%H:%%i') as updated,
				  c.name as created_by_contact
				  FROM $tickets_table t
				  LEFT JOIN {$wpdb->prefix}psp_company_contacts c ON t.created_by_contact_id = c.id
				  $where_sql 
				  ORDER BY t.created_at DESC 
				  LIMIT %d OFFSET %d";

		$where_values[] = $per_page;
		$where_values[] = $offset;

		$results = $wpdb->get_results( $wpdb->prepare( $query, $where_values ), ARRAY_A );

		return rest_ensure_response( $results );
	}

	public static function get_ticket( $request ) {
		$id   = $request['id'];
		$post = get_post( $id );

		if ( ! $post || 'psp_ticket' !== $post->post_type ) {
			return new \WP_Error(
				'ticket_not_found',
				'Ticket not found',
				array( 'status' => 404 )
			);
		}

		return rest_ensure_response( array( 'success' => true, 'data' => self::format_ticket( $post ) ) );
	}

	public static function create_ticket( $request ) {
		// Check company auth first
		$company_user = \PSP\Company_Auth::validate_session();
		
		if ( $company_user ) {
			return self::create_company_ticket( $request, $company_user );
		}

		// Fall back to WordPress tickets
		$params = $request->get_json_params();

		$title = sanitize_text_field( $params['title'] ?? $params['subject'] ?? '' );
		$description = wp_kses_post( $params['description'] ?? '' );
		$priority = sanitize_text_field( $params['priority'] ?? 'normal' );
		$category = sanitize_text_field( $params['category'] ?? '' );

		if ( ! $title ) {
			return new \WP_Error(
				'invalid_title',
				'Title is required',
				array( 'status' => 400 )
			);
		}

		$ticket_id = wp_insert_post(
			array(
				'post_type'    => 'psp_ticket',
				'post_title'   => $title,
				'post_content' => $description,
				'post_author'  => get_current_user_id(),
				'post_status'  => 'publish',
			)
		);

		if ( is_wp_error( $ticket_id ) ) {
			return $ticket_id;
		}

		update_post_meta( $ticket_id, 'psp_priority', $priority );
		update_post_meta( $ticket_id, 'psp_category', $category );
		update_post_meta( $ticket_id, 'psp_status', 'open' );

		return rest_ensure_response( self::format_ticket( get_post( $ticket_id ) ) );
	}

	private static function create_company_ticket( $request, $company_user ) {
		global $wpdb;

		if ( $company_user['type'] !== 'company' ) {
			return new \WP_Error( 'forbidden', 'Only partners can create tickets', array( 'status' => 403 ) );
		}

		$params = $request->get_json_params();
		$subject = sanitize_text_field( $params['subject'] ?? $params['title'] ?? '' );
		$description = wp_kses_post( $params['description'] ?? '' );
		$priority = sanitize_text_field( $params['priority'] ?? 'medium' );

		if ( ! $subject ) {
			return new \WP_Error( 'invalid_subject', 'Subject is required', array( 'status' => 400 ) );
		}

		$partner_id = self::get_partner_id_for_company( $company_user['id'] );
		$ticket_number = 'TKT-' . strtoupper( wp_generate_password( 8, false ) );

		$tickets_table = $wpdb->prefix . 'psp_tickets';
		$inserted = $wpdb->insert( $tickets_table, array(
			'ticket_number' => $ticket_number,
			'title' => $subject,
			'description' => $description,
			'partner_id' => $partner_id,
			'created_by_user_id' => 0,
			'created_by_contact_id' => $company_user['contact_id'] ?? null,
			'status' => 'open',
			'priority' => $priority,
			'created_at' => current_time( 'mysql' ),
			'updated_at' => current_time( 'mysql' ),
		), array( '%s', '%s', '%s', '%d', '%d', '%d', '%s', '%s', '%s', '%s' ) );

		if ( ! $inserted ) {
			return new \WP_Error( 'db_error', 'Failed to create ticket', array( 'status' => 500 ) );
		}

		// Clear cache
		wp_cache_delete( 'psp_dashboard_stats_company_' . $company_user['id'], 'psp' );

		return rest_ensure_response( array(
			'success' => true,
			'ticket_id' => $wpdb->insert_id,
			'ticket_number' => $ticket_number,
		) );
	}

	public static function update_ticket( $request ) {
		$id     = $request['id'];
		$params = $request->get_json_params();

		$post = get_post( $id );
		if ( ! $post || 'psp_ticket' !== $post->post_type ) {
			return new \WP_Error(
				'ticket_not_found',
				'Ticket not found',
				array( 'status' => 404 )
			);
		}

		if ( isset( $params['title'] ) ) {
			wp_update_post(
				array(
					'ID'         => $id,
					'post_title' => sanitize_text_field( $params['title'] ),
				)
			);
		}

		if ( isset( $params['status'] ) ) {
			update_post_meta( $id, 'psp_status', sanitize_text_field( $params['status'] ) );
		}

		if ( isset( $params['priority'] ) ) {
			update_post_meta( $id, 'psp_priority', sanitize_text_field( $params['priority'] ) );
		}

		return rest_ensure_response( self::format_ticket( get_post( $id ) ) );
	}

	// ===== SERVICES =====
	public static function get_services( $request ) {
		$args = array(
			'post_type'      => 'psp_service',
			'posts_per_page' => -1,
		);

		$posts    = get_posts( $args );
		$services = array();

		foreach ( $posts as $post ) {
			$services[] = array(
				'id'    => $post->ID,
				'title' => $post->post_title,
				'description' => $post->post_content,
			);
		}

		return rest_ensure_response( $services );
	}

	// ===== STATS =====
	public static function get_stats( $request ) {
		$ticket_args = array(
			'post_type'      => 'psp_ticket',
			'posts_per_page' => -1,
		);
		$total_tickets = count( get_posts( $ticket_args ) );

		$open_tickets = count(
			get_posts(
				array_merge(
					$ticket_args,
					array(
						'meta_query' => array(
							array(
								'key'   => 'psp_status',
								'value' => 'open',
							),
						),
					)
				)
			)
		);

		$partner_args = array(
			'post_type'      => 'psp_company',
			'posts_per_page' => -1,
		);
		$total_partners = count( get_posts( $partner_args ) );

		return rest_ensure_response(
			array(
				'total_tickets'   => $total_tickets,
				'open_tickets'    => $open_tickets,
				'total_partners'  => $total_partners,
			)
		);
	}

	// ===== USERS =====
	public static function get_users( $request ) {
		$args  = array(
			'role' => 'pool_safe_partner',
		);
		$users = get_users( $args );
		$list  = array();

		foreach ( $users as $user ) {
			$list[] = array(
				'id'           => $user->ID,
				'name'         => $user->display_name,
				'email'        => $user->user_email,
				'company_id'   => get_user_meta( $user->ID, 'psp_partner_id', true ),
			);
		}

		return rest_ensure_response( $list );
	}

	public static function save_notification_prefs( $request ) {
		$user_id = $request['id'];
		$params  = $request->get_json_params();

		update_user_meta( $user_id, 'psp_notification_prefs', $params );

		return rest_ensure_response( array( 'updated' => true ) );
	}

	// ===== DASHBOARD WIDGETS =====
	public static function save_dashboard_widgets( $request ) {
		$params  = $request->get_json_params();
		$widgets = $params['widgets'] ?? array();
		$user_id = get_current_user_id();

		update_user_meta( $user_id, 'psp_dashboard_widgets', $widgets );

		return rest_ensure_response( array( 'saved' => true ) );
	}

	// ===== PARTNER MAP =====
	public static function get_partner_map( $request ) {
		// Return partner location data for map
		$args = array(
			'post_type'      => 'psp_company',
			'posts_per_page' => -1,
		);

		$posts     = get_posts( $args );
		$locations = array();

		foreach ( $posts as $post ) {
			$lat  = get_post_meta( $post->ID, 'psp_latitude', true );
			$long = get_post_meta( $post->ID, 'psp_longitude', true );

			if ( $lat && $long ) {
				$locations[] = array(
					'id'   => $post->ID,
					'name' => $post->post_title,
					'lat'  => floatval( $lat ),
					'lng'  => floatval( $long ),
				);
			}
		}

		return rest_ensure_response( $locations );
	}

	// ===== HELPERS =====
	private static function format_partner( $post ) {
		return array(
			'id'                   => $post->ID,
			'companyName'          => $post->post_title,
			'managementCompany'    => get_post_meta( $post->ID, 'psp_management_company', true ),
			'streetAddress'        => get_post_meta( $post->ID, 'psp_street_address', true ),
			'city'                 => get_post_meta( $post->ID, 'psp_city', true ),
			'state'                => get_post_meta( $post->ID, 'psp_state', true ),
			'zip'                  => get_post_meta( $post->ID, 'psp_zip', true ),
			'country'              => get_post_meta( $post->ID, 'psp_country', true ),
			'phoneNumber'          => get_post_meta( $post->ID, 'psp_phone', true ),
			'companyEmail'         => get_post_meta( $post->ID, 'psp_email', true ),
			'numberOfLoungeUnits'  => get_post_meta( $post->ID, 'psp_units', true ),
			'units'                => get_post_meta( $post->ID, 'psp_units', true ),
			'operationType'        => get_post_meta( $post->ID, 'psp_operation_type', true ),
			'seasonalOpenDate'     => get_post_meta( $post->ID, 'psp_seasonal_open', true ),
			'seasonalCloseDate'    => get_post_meta( $post->ID, 'psp_seasonal_close', true ),
			'topColour'            => get_post_meta( $post->ID, 'psp_top_color', true ),
		);
	}

	private static function format_ticket( $post ) {
		return array(
			'id'          => $post->ID,
			'title'       => $post->post_title,
			'subject'     => $post->post_title,
			'description' => $post->post_content,
			'status'      => get_post_meta( $post->ID, 'psp_status', true ) ?: 'open',
			'priority'    => get_post_meta( $post->ID, 'psp_priority', true ) ?: 'normal',
			'category'    => get_post_meta( $post->ID, 'psp_category', true ),
			'author'      => get_the_author_meta( 'display_name', $post->post_author ),
			'created'     => $post->post_date,
			'created_at'  => $post->post_date,
			'updated_at'  => $post->post_modified,
		);
	}

	private static function maybe_filter_fields( array $data, $fields ) {
		if ( empty( $fields ) ) {
			return $data;
		}

		if ( is_string( $fields ) ) {
			$fields = array_map( 'trim', explode( ',', $fields ) );
		}

		if ( ! is_array( $fields ) ) {
			return $data;
		}

		return array_intersect_key( $data, array_flip( $fields ) );
	}

	// ===== ADDITIONAL ENDPOINTS =====

	public static function get_current_user_partner( $request ) {
		$user_id = get_current_user_id();
		if ( ! $user_id ) {
			return new \WP_Error(
				'not_logged_in',
				'User not logged in',
				array( 'status' => 401 )
			);
		}

		$partner_id = get_user_meta( $user_id, 'psp_partner_id', true );
		if ( ! $partner_id ) {
			return rest_ensure_response( null );
		}

		$post = get_post( $partner_id );
		if ( ! $post || 'psp_company' !== $post->post_type ) {
			return rest_ensure_response( null );
		}

		return rest_ensure_response( self::format_partner( $post ) );
	}

	public static function import_partners( $request ) {
		// CSV import stub
		return rest_ensure_response(
			array(
				'imported' => 0,
				'message' => 'Partner import feature coming soon',
			)
		);
	}

	public static function export_tickets( $request ) {
		// CSV export stub
		return rest_ensure_response(
			array(
				'exported' => 0,
				'message' => 'Ticket export feature coming soon',
			)
		);
	}

	public static function import_tickets( $request ) {
		// CSV import stub
		return rest_ensure_response(
			array(
				'imported' => 0,
				'message' => 'Ticket import feature coming soon',
			)
		);
	}

	public static function get_service_records( $request ) {
		// Check company auth first
		$company_user = \PSP\Company_Auth::validate_session();
		
		if ( $company_user ) {
			return self::get_company_service_records( $request, $company_user );
		}

		// Fall back to WordPress service records (Custom Post Types)
		$args = array(
			'post_type'      => 'psp_service_record',
			'posts_per_page' => -1,
		);

		$posts = get_posts( $args );
		$records = array();

		foreach ( $posts as $post ) {
			$records[] = array(
				'id'      => $post->ID,
				'title'   => $post->post_title,
				'date'    => $post->post_date,
				'partner' => get_post_meta( $post->ID, 'psp_partner_id', true ),
				'type'    => get_post_meta( $post->ID, 'psp_record_type', true ),
			);
		}

		return rest_ensure_response( $records );
	}

	private static function get_company_service_records( $request, $company_user ) {
		global $wpdb;
		
		$page = max( 1, (int) $request->get_param( 'page' ) ?: 1 );
		$per_page = max( 1, min( 100, (int) $request->get_param( 'per_page' ) ?: 20 ) );
		$offset = ( $page - 1 ) * $per_page;

		$services_table = $wpdb->prefix . 'psp_service_records';
		$where = '';
		$where_values = array();

		if ( $company_user['type'] === 'company' ) {
			$partner_id = self::get_partner_id_for_company( $company_user['id'] );
			$where = 'WHERE partner_id = %d';
			$where_values[] = $partner_id;
		}

		$query = "SELECT s.id, s.service_date as date, s.service_type as type, s.status, 
				  COALESCE((SELECT CONCAT(first_name, ' ', last_name) FROM {$wpdb->prefix}psp_users WHERE id = s.technician_id), 'Unassigned') as technician,
				  c.name as scheduled_by_contact
				  FROM $services_table s
				  LEFT JOIN {$wpdb->prefix}psp_company_contacts c ON s.created_by_contact_id = c.id
				  $where 
				  ORDER BY s.service_date DESC 
				  LIMIT %d OFFSET %d";

		$where_values[] = $per_page;
		$where_values[] = $offset;

		$results = empty( $where ) 
			? $wpdb->get_results( $wpdb->prepare( $query, $per_page, $offset ), ARRAY_A )
			: $wpdb->get_results( $wpdb->prepare( $query, $where_values ), ARRAY_A );

		return rest_ensure_response( $results );
	}

	public static function get_support_metrics( $request ) {
		$ticket_args = array(
			'post_type'      => 'psp_ticket',
			'posts_per_page' => -1,
		);
		$total_tickets = count( get_posts( $ticket_args ) );

		$open_count = count(
			get_posts(
				array_merge(
					$ticket_args,
					array(
						'meta_query' => array(
							array(
								'key'   => 'psp_status',
								'value' => 'open',
							),
						),
					)
				)
			)
		);

		$closed_count = count(
			get_posts(
				array_merge(
					$ticket_args,
					array(
						'meta_query' => array(
							array(
								'key'   => 'psp_status',
								'value' => 'closed',
							),
						),
					)
				)
			)
		);

		return rest_ensure_response(
			array(
				'total_tickets'  => $total_tickets,
				'open_tickets'   => $open_count,
				'closed_tickets' => $closed_count,
				'open_percentage' => $total_tickets > 0 ? round( ( $open_count / $total_tickets ) * 100, 2 ) : 0,
			)
		);
	}

	public static function add_ticket_comment( $request ) {
		$ticket_id = $request['id'];
		$params    = $request->get_json_params();

		$post = get_post( $ticket_id );
		if ( ! $post || 'psp_ticket' !== $post->post_type ) {
			return new \WP_Error(
				'ticket_not_found',
				'Ticket not found',
				array( 'status' => 404 )
			);
		}

		$comment_text = wp_kses_post( $params['comment'] ?? '' );
		if ( ! $comment_text ) {
			return new \WP_Error(
				'empty_comment',
				'Comment cannot be empty',
				array( 'status' => 400 )
			);
		}

		$comment_id = wp_insert_comment(
			array(
				'comment_post_ID'      => $ticket_id,
				'comment_author'       => get_the_author_meta( 'display_name', get_current_user_id() ),
				'comment_author_email' => get_the_author_meta( 'user_email', get_current_user_id() ),
				'comment_content'      => $comment_text,
				'comment_approved'     => 1,
				'user_id'              => get_current_user_id(),
			)
		);

		if ( is_wp_error( $comment_id ) ) {
			return $comment_id;
		}

		return rest_ensure_response(
			array(
				'id'      => $comment_id,
				'ticket'  => $ticket_id,
				'author'  => get_the_author_meta( 'display_name', get_current_user_id() ),
				'content' => $comment_text,
				'date'    => current_time( 'mysql' ),
			)
		);
	}

	/**
	 * Get dashboard statistics
	 * Works with both WordPress auth and company auth
	 */
	public static function get_dashboard_stats( $request ) {
		// Check company auth first
		$company_user = \PSP\Company_Auth::validate_session();
		
		if ( $company_user ) {
			return self::get_company_dashboard_stats( $company_user );
		}
		
		// Fall back to WordPress auth
		if ( ! is_user_logged_in() ) {
			return new \WP_Error( 'unauthorized', 'Authentication required', array( 'status' => 401 ) );
		}

		return self::get_wp_dashboard_stats( get_current_user_id() );
	}

	private static function get_company_dashboard_stats( $company_user ) {
		global $wpdb;

		$cache_key = 'psp_dashboard_stats_company_' . $company_user['id'];
		$cached = wp_cache_get( $cache_key, 'psp' );
		if ( false !== $cached ) {
			return rest_ensure_response( $cached );
		}

		$tickets_table = $wpdb->prefix . 'psp_tickets';
		$services_table = $wpdb->prefix . 'psp_service_records';
		$partner_id = self::get_partner_id_for_company( $company_user['id'] );

		if ( $company_user['type'] === 'support' ) {
			// Support sees all stats
			$tickets = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $tickets_table WHERE status IN ('open', 'pending')" );
			$pending = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $tickets_table WHERE status = 'pending'" );
			$completed = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $tickets_table WHERE status IN ('resolved', 'closed')" );
			$services = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $services_table WHERE service_date >= CURDATE()" );
		} else {
			// Company sees only their stats
			$tickets = (int) $wpdb->get_var( $wpdb->prepare(
				"SELECT COUNT(*) FROM $tickets_table WHERE partner_id = %d AND status IN ('open', 'pending')",
				$partner_id
			) );
			$pending = (int) $wpdb->get_var( $wpdb->prepare(
				"SELECT COUNT(*) FROM $tickets_table WHERE partner_id = %d AND status = 'pending'",
				$partner_id
			) );
			$completed = (int) $wpdb->get_var( $wpdb->prepare(
				"SELECT COUNT(*) FROM $tickets_table WHERE partner_id = %d AND status IN ('resolved', 'closed')",
				$partner_id
			) );
			$services = (int) $wpdb->get_var( $wpdb->prepare(
				"SELECT COUNT(*) FROM $services_table WHERE partner_id = %d AND service_date >= CURDATE()",
				$partner_id
			) );
		}

		$stats = array(
			'tickets' => $tickets,
			'pending' => $pending,
			'completed' => $completed,
			'services' => $services,
		);

		wp_cache_set( $cache_key, $stats, 'psp', 300 ); // Cache 5 minutes
		return rest_ensure_response( $stats );
	}

	private static function get_wp_dashboard_stats( $user_id ) {
		// WordPress user dashboard stats
		$ticket_args = array(
			'post_type' => 'psp_ticket',
			'fields' => 'ids',
			'posts_per_page' => -1,
		);

		$total_tickets = count( get_posts( $ticket_args ) );
		$open_count = count( get_posts( array_merge( $ticket_args, array(
			'meta_query' => array( array( 'key' => 'psp_status', 'value' => 'open' ) )
		) ) ) );
		$closed_count = count( get_posts( array_merge( $ticket_args, array(
			'meta_query' => array( array( 'key' => 'psp_status', 'value' => 'closed' ) )
		) ) ) );

		return rest_ensure_response( array(
			'tickets' => $open_count,
			'pending' => 0,
			'completed' => $closed_count,
			'services' => 0,
		) );
	}

	/**
	 * Create service record
	 */
	public static function create_service_record( $request ) {
		global $wpdb;

		// Check company auth first
		$company_user = \PSP\Company_Auth::validate_session();
		
		if ( ! $company_user && ! is_user_logged_in() ) {
			return new \WP_Error( 'unauthorized', 'Authentication required', array( 'status' => 401 ) );
		}

		$params = $request->get_json_params();
		$type = sanitize_text_field( $params['type'] ?? '' );
		$date = sanitize_text_field( $params['date'] ?? '' );
		$notes = wp_kses_post( $params['notes'] ?? '' );

		if ( ! $type || ! $date ) {
			return new \WP_Error( 'missing_data', 'Type and date required', array( 'status' => 400 ) );
		}

		if ( $company_user ) {
			$partner_id = self::get_partner_id_for_company( $company_user['id'] );
		} else {
			$partner_id = get_user_meta( get_current_user_id(), 'psp_partner_id', true );
		}

		if ( ! $partner_id ) {
			return new \WP_Error( 'no_partner', 'No partner association found', array( 'status' => 400 ) );
		}

		$services_table = $wpdb->prefix . 'psp_service_records';
		$inserted = $wpdb->insert( $services_table, array(
			'partner_id' => $partner_id,
			'service_date' => $date,
			'service_type' => $type,
			'notes' => $notes,
			'description' => $notes,
			'created_by_contact_id' => $company_user['contact_id'] ?? null,
			'status' => 'scheduled',
		), array( '%d', '%s', '%s', '%s', '%s', '%d', '%s' ) );

		if ( ! $inserted ) {
			return new \WP_Error( 'db_error', 'Failed to create service', array( 'status' => 500 ) );
		}

		// Clear cache
		if ( $company_user ) {
			wp_cache_delete( 'psp_dashboard_stats_company_' . $company_user['id'], 'psp' );
		}

		return rest_ensure_response( array(
			'success' => true,
			'service_id' => $wpdb->insert_id,
		) );
	}

	/**
	 * Map company ID to partner ID
	 * Handles migration between old and new auth systems
	 */
	private static function get_partner_id_for_company( $company_id ) {
		global $wpdb;
		
		// Check mapping table
		$mapping_table = $wpdb->prefix . 'psp_company_partner_map';
		if ( $wpdb->get_var( "SHOW TABLES LIKE '$mapping_table'" ) ) {
			$partner_id = $wpdb->get_var( $wpdb->prepare(
				"SELECT partner_id FROM $mapping_table WHERE company_id = %d",
				$company_id
			) );
			if ( $partner_id ) {
				return (int) $partner_id;
			}
		}

		// Match by company name
		$companies_table = $wpdb->prefix . 'psp_companies';
		$partners_table = $wpdb->prefix . 'psp_partners';
		
		$company_name = $wpdb->get_var( $wpdb->prepare(
			"SELECT company_name FROM $companies_table WHERE id = %d",
			$company_id
		) );

		if ( $company_name ) {
			$partner_id = $wpdb->get_var( $wpdb->prepare(
				"SELECT id FROM $partners_table WHERE company_name = %s LIMIT 1",
				$company_name
			) );
			if ( $partner_id ) {
				return (int) $partner_id;
			}
		}

		// Fallback: use company_id directly
		return (int) $company_id;
	}
}
