/**
 * PoolSafe Portal Settings Page JavaScript
 * Handles tab switching, backups, and dynamic behavior
 * @since 1.1.0
 */

jQuery(document).ready(function ($) {
    /**
     * Tab Navigation
     */
    $('.nav-tab').on('click', function (e) {
        e.preventDefault();

        var tab = $(this).attr('href');
        var tabId = tab.substring(1); // Remove #

        // Hide all tabs
        $('.psp-settings-tab').removeClass('active').slideUp(200);

        // Show selected tab
        $(tab).addClass('active').slideDown(200);

        // Update active tab indicator
        $('.nav-tab').removeClass('nav-tab-active');
        $(this).addClass('nav-tab-active');

        // Update URL hash for bookmarking
        window.location.hash = tab;

        // Store preference
        localStorage.setItem('psp_settings_tab', tabId);
    });

    /**
     * Restore previously selected tab on page load
     */
    var savedTab = localStorage.getItem('psp_settings_tab');
    if (savedTab) {
        var tabLink = $('a[href="#' + savedTab + '"]');
        if (tabLink.length) {
            tabLink.trigger('click');
        }
    } else if (window.location.hash) {
        // Use URL hash if no saved tab
        var hashTab = $('a[href="' + window.location.hash + '"]');
        if (hashTab.length) {
            hashTab.trigger('click');
        }
    }

    /**
     * Initialize WordPress color pickers for branding fields
     */
    if ($.fn.wpColorPicker) {
        $('.psp-color-field').wpColorPicker();
    }

    /**
     * Backup Settings
     */
    $('#psp-backup-settings').on('click', function (e) {
        e.preventDefault();

        var $btn = $(this);
        var $status = $('#psp-backup-status');
        var originalText = $btn.text();

        // Show loading
        $btn.prop('disabled', true);
        $status.html('<span class="psp-loading"></span>Creating backup...');

        $.ajax({
            url: pspSettings.ajax_url,
            method: 'POST',
            data: {
                action: 'psp_backup_settings',
                nonce: pspSettings.nonce
            },
            dataType: 'json',
            timeout: 30000,
            success: function (response) {
                if (response.success) {
                    $status
                        .html('✓ Backup created: ' + escapeHtml(response.data.filename))
                        .css('color', 'green');

                    // Auto-clear after 5 seconds
                    setTimeout(function () {
                        $status.html('');
                        $btn.prop('disabled', false).text(originalText);
                    }, 5000);
                } else {
                    var errorMsg = response.data || 'Unknown error';
                    $status
                        .html('✗ Backup failed: ' + escapeHtml(errorMsg))
                        .css('color', 'var(--psp-danger)');

                    $btn.prop('disabled', false).text(originalText);
                }
            },
            error: function (xhr, status, error) {
                var errorMsg = 'Request failed: ' + escapeHtml(error);
                $status
                    .html('✗ ' + errorMsg)
                    .css('color', '#d32f2f');

                $btn.prop('disabled', false).text(originalText);
            }
        });
    });

    /**
     * Form Validation
     */
    $('#psp-settings-form').on('submit', function (e) {
        var $form = $(this);
        var isValid = true;

        // Validate email fields
        $form.find('input[type="email"]').each(function () {
            var email = $(this).val().trim();
            if (email && !isValidEmail(email)) {
                $(this).css('border-color', '#d32f2f').focus();
                isValid = false;
            }
        });

        // Validate required fields
        $form.find('input[required]').each(function () {
            if (!$(this).val().trim()) {
                $(this).css('border-color', '#d32f2f').focus();
                isValid = false;
            }
        });

        if (!isValid) {
            e.preventDefault();
            alert('Please correct the errors in the form.');
        }

        return isValid;
    });

    /**
     * Clear validation errors on input
     */
    $('#psp-settings-form').find('input, select').on('change', function () {
        $(this).css('border-color', '');
    });

    /**
     * Test Connections (optional feature)
     */
    $('.psp-test-connection').on('click', function (e) {
        e.preventDefault();

        var service = $(this).data('service');
        var $status = $(this).closest('tr').find('.psp-connection-status');

        $status.html('<span class="psp-loading"></span>Testing...');

        $.ajax({
            url: pspSettings.ajax_url,
            method: 'POST',
            data: {
                action: 'psp_test_connection',
                nonce: pspSettings.nonce,
                service: service
            },
            dataType: 'json',
            timeout: 15000,
            success: function (response) {
                if (response.success && response.data.connected) {
                    $status
                        .html('✓ Connected (Last: ' + escapeHtml(response.data.last_tested) + ')')
                        .css('color', 'green');
                } else {
                    var error = response.data.error || 'Connection failed';
                    $status
                        .html('✗ ' + escapeHtml(error))
                        .css('color', '#d32f2f');
                }
            },
            error: function () {
                $status
                    .html('✗ Test failed')
                    .css('color', '#d32f2f');
            }
        });
    });

    /**
     * Password Field Toggle (show/hide)
     */
    $('input[type="password"]').each(function () {
        var $input = $(this);

        // Add toggle button
        var $toggle = $('<button type="button" class="button" style="margin-left: 10px;">Show</button>');

        $toggle.on('click', function (e) {
            e.preventDefault();

            if ('password' === $input.attr('type')) {
                $input.attr('type', 'text');
                $toggle.text('Hide');
            } else {
                $input.attr('type', 'password');
                $toggle.text('Show');
            }
        });

        $input.after($toggle);
    });

    /**
     * CSV Delimiter Preview
     */
    $('#psp_csv_delimiter').on('change', function () {
        var delimiter = $(this).val();
        updateCsvPreview(delimiter);
    });

    /**
     * Sync Frequency Info
     */
    $('#psp_hubspot_sync_frequency').on('change', function () {
        var frequency = $(this).val();
        var descriptions = {
            'hourly': 'Every hour (high API usage)',
            'daily': 'Once per day (recommended)',
            'weekly': 'Once per week (minimal API usage)'
        };

        $(this).closest('tr').find('.description').text(descriptions[frequency] || '');
    });

    /**
     * Utility Functions
     */

    /**
     * Validate email address
     */
    function isValidEmail(email) {
        var re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }

    /**
     * Escape HTML special characters
     */
    function escapeHtml(text) {
        var map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return text.replace(/[&<>"']/g, function (m) {
            return map[m];
        });
    }

    /**
     * Update CSV preview based on delimiter
     */
    function updateCsvPreview(delimiter) {
        var sample = 'Name' + delimiter + 'Email' + delimiter + 'Company';
        console.log('CSV Format: ' + sample);
    }

    /**
     * Show/hide advanced options
     */
    $('.psp-show-advanced').on('click', function (e) {
        e.preventDefault();
        $(this).closest('.form-table').find('.psp-advanced').slideToggle();
    });

    /**
     * Keyboard Shortcuts
     */
    $(document).on('keydown', function (e) {
        // Ctrl+S / Cmd+S to submit form
        if ((e.ctrlKey || e.metaKey) && 'S' === String.fromCharCode(e.which)) {
            e.preventDefault();
            $('#psp-settings-form').find('input[type="submit"]').click();
        }
    });

    /**
     * Sticky Form Buttons
     */
    if ($('.psp-settings-actions').length) {
        var $actions = $('.psp-settings-actions');
        var originalOffset = $actions.offset().top;

        $(window).on('scroll', function () {
            var scrollTop = $(window).scrollTop();

            if (scrollTop > originalOffset) {
                $actions.css({
                    'position': 'fixed',
                    'bottom': '0',
                    'left': '0',
                    'right': '0',
                    'background': 'white',
                    'border-top': '1px solid #ddd',
                    'box-shadow': '0 -2px 5px rgba(0,0,0,0.1)',
                    'z-index': '999'
                });
            } else {
                $actions.css({
                    'position': 'static',
                    'box-shadow': 'none'
                });
            }
        });
    }

    /**
     * Auto-save Draft (optional)
     */
    var autoSaveDraft = function () {
        var formData = $('#psp-settings-form').serializeArray();
        localStorage.setItem('psp_settings_draft', JSON.stringify(formData));
    };

    // Auto-save every 30 seconds if form has changes
    var hasChanges = false;
    $('#psp-settings-form').on('change', function () {
        hasChanges = true;
    });

    setInterval(function () {
        if (hasChanges) {
            autoSaveDraft();
            hasChanges = false;
        }
    }, 30000);

    /**
     * Clear draft on successful submit
     */
    $('#psp-settings-form').on('success', function () {
        localStorage.removeItem('psp_settings_draft');
    });

});
