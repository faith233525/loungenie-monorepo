<?php
/**
 * PoolSafe Portal v3.0 - Enhanced Ticket System
 *
 * Company-centric ticketing with automatic contact association,
 * email thread tracking, and role-based visibility.
 *
 * @package PoolSafe_Portal
 * @subpackage Tickets_Enhancement
 * @version 3.0.0
 */

namespace PSP;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Tickets_Enhancement {

	/**
	 * Initialize ticket enhancements
	 */
	public static function init() {
		// Hook into ticket creation before status is set
		add_filter( 'wp_insert_post_data', array( __CLASS__, 'before_ticket_insert' ), 10, 2 );

		// Hook after ticket is inserted
		add_action( 'wp_insert_post', array( __CLASS__, 'after_ticket_insert' ), 10, 2 );

		// Add admin filters
		add_action( 'restrict_manage_posts', array( __CLASS__, 'add_ticket_filters' ) );
		add_filter( 'parse_query', array( __CLASS__, 'filter_tickets_by_company' ) );
	}

	/**
	 * Before ticket insert - prepare data
	 *
	 * @param array $data Post data
	 * @param array $postarr Post array (input)
	 * @return array Modified post data
	 */
	public static function before_ticket_insert( $data, $postarr ) {
		// Only process tickets
		if ( $data['post_type'] !== 'psp_ticket' ) {
			return $data;
		}

		return $data;
	}

	/**
	 * After ticket insert - link to company and handle contacts
	 *
	 * @param int $post_id Post ID
	 * @param WP_Post $post Post object
	 */
	public static function after_ticket_insert( $post_id, $post ) {
		// Only process tickets
		if ( $post->post_type !== 'psp_ticket' ) {
			return;
		}

		// Skip if already processed (prevent duplicate actions)
		if ( get_post_meta( $post_id, '_psp_ticket_processed', true ) ) {
			return;
		}

		// Get current user
		$user_id = get_current_user_id();
		$user = get_userdata( $user_id );

		if ( ! $user ) {
			return;
		}

		// 1. Find company based on user's company_id
		$company_id = get_user_meta( $user_id, 'psp_company_id', true );

		if ( ! $company_id ) {
			// Try to find company by email domain or other means
			$company_id = self::find_company_for_user( $user );
		}

		// 2. Link ticket to company
		if ( $company_id ) {
			update_post_meta( $post_id, 'psp_company_id', intval( $company_id ) );

			// 3. Handle contact association
			self::associate_contact_with_ticket( $post_id, $user_id, $company_id );

			// 4. Increment company ticket count (cache)
			self::increment_company_ticket_count( $company_id );
		}

		// 5. Set default status and metadata if not set
		if ( ! get_post_meta( $post_id, 'psp_status', true ) ) {
			update_post_meta( $post_id, 'psp_status', 'open' );
		}

		if ( ! get_post_meta( $post_id, 'psp_priority', true ) ) {
			update_post_meta( $post_id, 'psp_priority', 'medium' );
		}

		// Set source to portal if not specified
		if ( ! get_post_meta( $post_id, 'psp_source', true ) ) {
			update_post_meta( $post_id, 'psp_source', 'portal' );
		}

		// 6. Mark as processed
		update_post_meta( $post_id, '_psp_ticket_processed', true );

		// 7. Trigger notifications
		if ( class_exists( 'Email' ) ) {
			// Notify support team
			Email::notify_new_ticket( $post_id );
		}
	}

	/**
	 * Associate contact with ticket
	 *
	 * When a user submits a ticket, check if they're in the company's contacts.
	 * If not, automatically add them.
	 *
	 * @param int $ticket_id Ticket post ID
	 * @param int $user_id WordPress user ID
	 * @param int $company_id Company post ID
	 */
	private static function associate_contact_with_ticket( $ticket_id, $user_id, $company_id ) {
		// Check if user is already a contact for this company
		$existing_contact = Contacts::find_contact_by_email( $company_id, get_userdata( $user_id )->user_email );

		if ( ! $existing_contact ) {
			// Create contact automatically
			$contact_id = Contacts::create_or_get_contact( $user_id, $company_id, 'auto_from_ticket' );
		} else {
			$contact_id = $existing_contact;
		}

		// Link ticket to contact
		if ( $contact_id ) {
			update_post_meta( $ticket_id, 'psp_contact_id', intval( $contact_id ) );

			// Add contact to company's contact array if not already present
			$contact_ids = get_post_meta( $company_id, 'psp_contact_ids', true ) ?: array();
			if ( ! in_array( $contact_id, $contact_ids, true ) ) {
				$contact_ids[] = $contact_id;
				update_post_meta( $company_id, 'psp_contact_ids', $contact_ids );
			}
		}
	}

	/**
	 * Find company for user based on email or other attributes
	 *
	 * @param WP_User $user WordPress user
	 * @return int|null Company post ID or null
	 */
	private static function find_company_for_user( $user ) {
		// Try to find company by email domain matching
		$email_parts = explode( '@', $user->user_email );
		$domain = isset( $email_parts[1] ) ? $email_parts[1] : '';

		if ( ! empty( $domain ) ) {
			// Check if company has contact with same domain
			$contacts = Contacts::find_contacts_by_email_domain( $domain );
			if ( ! empty( $contacts ) ) {
				$company_id = get_post_meta( $contacts[0], 'psp_company_id', true );
				if ( $company_id ) {
					return $company_id;
				}
			}
		}

		return null;
	}

	/**
	 * Increment company ticket count
	 *
	 * @param int $company_id Company post ID
	 */
	private static function increment_company_ticket_count( $company_id ) {
		$count = intval( get_post_meta( $company_id, 'psp_tickets_count', true ) );
		update_post_meta( $company_id, 'psp_tickets_count', ++$count );
	}

	/**
	 * Add company filter to ticket admin list
	 */
	public static function add_ticket_filters() {
		global $typenow;

		if ( 'psp_ticket' !== $typenow ) {
			return;
		}

		// Get all companies
		$companies = get_posts(
			array(
				'post_type'      => 'psp_company',
				'posts_per_page' => -1,
				'orderby'        => 'title',
				'order'          => 'ASC',
			)
		);

		if ( empty( $companies ) ) {
			return;
		}

		$selected = isset( $_GET['psp_company_filter'] ) ? sanitize_text_field( wp_unslash( $_GET['psp_company_filter'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		?>
		<select name="psp_company_filter">
			<option value="">All Companies</option>
			<?php foreach ( $companies as $company ) : ?>
				<option value="<?php echo esc_attr( $company->ID ); ?>" <?php selected( $selected, $company->ID ); ?>>
					<?php echo esc_html( $company->post_title ); ?>
				</option>
			<?php endforeach; ?>
		</select>
		<?php
	}

	/**
	 * Filter tickets by company in admin list
	 *
	 * @param WP_Query $query Query object
	 */
	public static function filter_tickets_by_company( $query ) {
		global $typenow;

		if ( ! is_admin() || 'psp_ticket' !== $typenow || ! $query->is_main_query() ) {
			return;
		}

		if ( isset( $_GET['psp_company_filter'] ) && ! empty( $_GET['psp_company_filter'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$company_id = intval( sanitize_text_field( wp_unslash( $_GET['psp_company_filter'] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended

			$query->set( 'meta_key', 'psp_company_id' );
			$query->set( 'meta_value', $company_id );
		}
	}

	/**
	 * Get tickets for company with role-based filtering
	 *
	 * @param int $company_id Company post ID
	 * @param string $user_role User role (admin, support, partner)
	 * @return array Tickets
	 */
	public static function get_company_tickets_filtered( $company_id, $user_role = '' ) {
		if ( empty( $user_role ) ) {
			$user = wp_get_current_user();
			$user_role = isset( $user->roles[0] ) ? $user->roles[0] : 'subscriber';
		}

		$user_id = get_current_user_id();

		// Admin and support see all company tickets
		if ( in_array( $user_role, array( 'administrator', 'psp_support' ), true ) ) {
			return get_posts(
				array(
					'post_type'      => 'psp_ticket',
					'posts_per_page' => -1,
					'meta_key'       => 'psp_company_id',
					'meta_value'     => intval( $company_id ),
					'orderby'        => 'post_date',
					'order'          => 'DESC',
				)
			);
		}

		// Partner users see only tickets from their company
		$user_company_id = get_user_meta( $user_id, 'psp_company_id', true );

		if ( intval( $user_company_id ) !== intval( $company_id ) ) {
			return array(); // No access to other companies
		}

		// Return company tickets
		return get_posts(
			array(
				'post_type'      => 'psp_ticket',
				'posts_per_page' => -1,
				'meta_key'       => 'psp_company_id',
				'meta_value'     => intval( $company_id ),
				'orderby'        => 'post_date',
				'order'          => 'DESC',
			)
		);
	}

	/**
	 * Get all tickets for current user based on role
	 *
	 * @return array Tickets
	 */
	public static function get_user_tickets() {
		$user_id = get_current_user_id();
		$user = get_userdata( $user_id );
		$user_role = isset( $user->roles[0] ) ? $user->roles[0] : 'subscriber';

		// Admin and support see all tickets
		if ( in_array( $user_role, array( 'administrator', 'psp_support' ), true ) ) {
			return get_posts(
				array(
					'post_type'      => 'psp_ticket',
					'posts_per_page' => -1,
					'orderby'        => 'post_date',
					'order'          => 'DESC',
				)
			);
		}

		// Partner users see only tickets from their company
		$company_id = get_user_meta( $user_id, 'psp_company_id', true );

		if ( ! $company_id ) {
			return array();
		}

		return self::get_company_tickets_filtered( $company_id, $user_role );
	}

	/**
	 * Check if user can view ticket
	 *
	 * @param int $ticket_id Ticket post ID
	 * @param int $user_id WordPress user ID
	 * @return bool True if user can view ticket
	 */
	public static function can_user_view_ticket( $ticket_id, $user_id ) {
		$user = get_userdata( $user_id );
		$user_role = isset( $user->roles[0] ) ? $user->roles[0] : 'subscriber';

		// Admin and support can view all tickets
		if ( in_array( $user_role, array( 'administrator', 'psp_support' ), true ) ) {
			return true;
		}

		// Partner users can view tickets from their company
		$user_company_id = get_user_meta( $user_id, 'psp_company_id', true );
		$ticket_company_id = get_post_meta( $ticket_id, 'psp_company_id', true );

		return intval( $user_company_id ) === intval( $ticket_company_id );
	}
}

// Initialize ticket enhancements
Tickets_Enhancement::init();
