<?php
/**
 * Unified Data Access Layer
 *
 * Provides a single interface for accessing and manipulating portal data
 * across all modules. Reduces code duplication and improves cohesion.
 *
 * @package   PoolSafe Portal
 * @namespace PSP\Data
 * @version   3.2.5
 */

namespace PSP\Data;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Unified Data Access Layer Class
 *
 * Centralizes data operations for:
 * - Tickets
 * - Partners/Companies
 * - Contacts
 * - Users
 * - Notifications
 * - Activities
 * - Audit logs
 */
class UnifiedDataLayer {

    /**
     * Get single ticket by ID
     *
     * @param int $ticket_id Ticket ID
     * @return object|null Ticket data or null
     */
    public static function get_ticket( int $ticket_id ): ?object {
        try {
            if ( $ticket_id <= 0 ) {
                error_log( '[PSP Data] Invalid ticket ID: ' . $ticket_id );
                return null;
            }

            return get_post( $ticket_id );
        } catch ( \Exception $e ) {
            error_log( '[PSP Data] Get ticket failed: ' . $e->getMessage() );
            return null;
        }
    }

    /**
     * Get all tickets with filters
     *
     * @param array $filters Filters: status, company_id, assigned_to, limit, offset
     * @return array Array of ticket posts
     */
    public static function get_tickets( array $filters = array() ): array {
        try {
            $args = array(
                'post_type'      => 'psp_ticket',
                'posts_per_page' => $filters['limit'] ?? 20,
                'offset'         => $filters['offset'] ?? 0,
                'post_status'    => 'publish',
            );

            // Add status filter
            if ( ! empty( $filters['status'] ) ) {
                $args['meta_query'][] = array(
                    'key'   => 'psp_status',
                    'value' => $filters['status'],
                );
            }

            // Add company filter
            if ( ! empty( $filters['company_id'] ) ) {
                $args['meta_query'][] = array(
                    'key'   => 'psp_company_id',
                    'value' => $filters['company_id'],
                );
            }

            // Add assignment filter
            if ( ! empty( $filters['assigned_to'] ) ) {
                $args['meta_query'][] = array(
                    'key'   => 'psp_assigned_to',
                    'value' => $filters['assigned_to'],
                );
            }

            return get_posts( $args );
        } catch ( \Exception $e ) {
            error_log( '[PSP Data] Get tickets failed: ' . $e->getMessage() );
            return array();
        }
    }

    /**
     * Get partner/company by ID
     *
     * @param int $partner_id Partner ID
     * @return object|null Partner data or null
     */
    public static function get_partner( int $partner_id ): ?object {
        try {
            if ( $partner_id <= 0 ) {
                error_log( '[PSP Data] Invalid partner ID: ' . $partner_id );
                return null;
            }

            return get_post( $partner_id );
        } catch ( \Exception $e ) {
            error_log( '[PSP Data] Get partner failed: ' . $e->getMessage() );
            return null;
        }
    }

    /**
     * Get all partners with filters
     *
     * @param array $filters Filters: status, region, limit, offset
     * @return array Array of partner posts
     */
    public static function get_partners( array $filters = array() ): array {
        try {
            $args = array(
                'post_type'      => 'psp_company',
                'posts_per_page' => $filters['limit'] ?? 50,
                'offset'         => $filters['offset'] ?? 0,
                'post_status'    => 'publish',
            );

            return get_posts( $args );
        } catch ( \Exception $e ) {
            error_log( '[PSP Data] Get partners failed: ' . $e->getMessage() );
            return array();
        }
    }

    /**
     * Get contacts for a company
     *
     * @param int $company_id Company ID
     * @return array Array of contacts
     */
    public static function get_company_contacts( int $company_id ): array {
        try {
            if ( $company_id <= 0 ) {
                error_log( '[PSP Data] Invalid company ID: ' . $company_id );
                return array();
            }

            $args = array(
                'post_type'      => 'psp_contact',
                'posts_per_page' => -1,
                'meta_query'     => array(
                    array(
                        'key'   => 'psp_company_id',
                        'value' => $company_id,
                    ),
                ),
            );

            return get_posts( $args );
        } catch ( \Exception $e ) {
            error_log( '[PSP Data] Get company contacts failed: ' . $e->getMessage() );
            return array();
        }
    }

    /**
     * Get user's company ID
     *
     * @param int $user_id User ID
     * @return int|null Company ID or null
     */
    public static function get_user_company( int $user_id ): ?int {
        try {
            if ( $user_id <= 0 ) {
                error_log( '[PSP Data] Invalid user ID: ' . $user_id );
                return null;
            }

            $company_id = get_user_meta( $user_id, 'psp_company_id', true );
            return ! empty( $company_id ) ? (int) $company_id : null;
        } catch ( \Exception $e ) {
            error_log( '[PSP Data] Get user company failed: ' . $e->getMessage() );
            return null;
        }
    }

    /**
     * Get user company info
     *
     * @param int $user_id User ID
     * @return object|null Company post object or null
     */
    public static function get_user_company_info( int $user_id ): ?object {
        try {
            $company_id = self::get_user_company( $user_id );
            return $company_id ? self::get_partner( $company_id ) : null;
        } catch ( \Exception $e ) {
            error_log( '[PSP Data] Get user company info failed: ' . $e->getMessage() );
            return null;
        }
    }

    /**
     * Get user's tickets
     *
     * @param int $user_id User ID
     * @param array $filters Additional filters
     * @return array Array of tickets
     */
    public static function get_user_tickets( int $user_id, array $filters = array() ): array {
        try {
            if ( $user_id <= 0 ) {
                error_log( '[PSP Data] Invalid user ID: ' . $user_id );
                return array();
            }

            $company_id = self::get_user_company( $user_id );
            if ( ! $company_id ) {
                return array();
            }

            $filters['company_id'] = $company_id;
            return self::get_tickets( $filters );
        } catch ( \Exception $e ) {
            error_log( '[PSP Data] Get user tickets failed: ' . $e->getMessage() );
            return array();
        }
    }

    /**
     * Get notifications for user
     *
     * @param int $user_id User ID
     * @param array $filters Filters: unread_only, limit
     * @return array Array of notifications
     */
    public static function get_user_notifications( int $user_id, array $filters = array() ): array {
        try {
            if ( $user_id <= 0 ) {
                error_log( '[PSP Data] Invalid user ID: ' . $user_id );
                return array();
            }

            $args = array(
                'post_type'      => 'psp_notification',
                'posts_per_page' => $filters['limit'] ?? 20,
                'meta_query'     => array(
                    array(
                        'key'   => 'psp_user_id',
                        'value' => $user_id,
                    ),
                ),
            );

            if ( ! empty( $filters['unread_only'] ) ) {
                $args['meta_query'][] = array(
                    'key'   => 'psp_read',
                    'value' => 0,
                );
            }

            return get_posts( $args );
        } catch ( \Exception $e ) {
            error_log( '[PSP Data] Get user notifications failed: ' . $e->getMessage() );
            return array();
        }
    }

    /**
     * Log activity event
     *
     * @param int    $user_id User ID
     * @param string $action Action type
     * @param string $subject Subject/target
     * @param array  $data Additional data
     * @return int|bool Activity log ID or false
     */
    public static function log_activity( int $user_id, string $action, string $subject, array $data = array() ): int|bool {
        try {
            if ( ! function_exists( 'wp_insert_post' ) ) {
                error_log( '[PSP Data] wp_insert_post not available' );
                return false;
            }

            $post_data = array(
                'post_type'   => 'psp_activity',
                'post_status' => 'publish',
                'post_title'  => sprintf( '%s: %s', $action, $subject ),
                'post_author' => $user_id,
            );

            $activity_id = wp_insert_post( $post_data );

            if ( is_wp_error( $activity_id ) ) {
                error_log( '[PSP Data] Failed to log activity: ' . $activity_id->get_error_message() );
                return false;
            }

            // Store metadata
            update_post_meta( $activity_id, 'psp_action', $action );
            update_post_meta( $activity_id, 'psp_subject', $subject );
            update_post_meta( $activity_id, 'psp_data', wp_json_encode( $data ) );
            update_post_meta( $activity_id, 'psp_timestamp', current_time( 'mysql' ) );

            return $activity_id;
        } catch ( \Exception $e ) {
            error_log( '[PSP Data] Log activity failed: ' . $e->getMessage() );
            return false;
        }
    }

    /**
     * Create notification
     *
     * @param int    $user_id User ID
     * @param string $message Notification message
     * @param string $type Notification type (info, warning, error, success)
     * @param array  $data Additional data
     * @return int|bool Notification ID or false
     */
    public static function create_notification( int $user_id, string $message, string $type = 'info', array $data = array() ): int|bool {
        try {
            if ( ! function_exists( 'wp_insert_post' ) ) {
                error_log( '[PSP Data] wp_insert_post not available' );
                return false;
            }

            $post_data = array(
                'post_type'   => 'psp_notification',
                'post_status' => 'publish',
                'post_title'  => $message,
                'post_author' => $user_id,
            );

            $notif_id = wp_insert_post( $post_data );

            if ( is_wp_error( $notif_id ) ) {
                error_log( '[PSP Data] Failed to create notification: ' . $notif_id->get_error_message() );
                return false;
            }

            // Store metadata
            update_post_meta( $notif_id, 'psp_user_id', $user_id );
            update_post_meta( $notif_id, 'psp_type', $type );
            update_post_meta( $notif_id, 'psp_read', 0 );
            update_post_meta( $notif_id, 'psp_data', wp_json_encode( $data ) );

            return $notif_id;
        } catch ( \Exception $e ) {
            error_log( '[PSP Data] Create notification failed: ' . $e->getMessage() );
            return false;
        }
    }

    /**
     * Get dashboard statistics
     *
     * @param int $user_id User ID (optional, for company-specific stats)
     * @return array Dashboard statistics
     */
    public static function get_dashboard_stats( int $user_id = 0 ): array {
        try {
            $stats = array(
                'total_tickets'    => 0,
                'open_tickets'     => 0,
                'my_tickets'       => 0,
                'total_partners'   => 0,
                'unread_notifs'    => 0,
                'recent_activity'  => array(),
            );

            // Get company-specific stats if user provided
            if ( $user_id > 0 ) {
                $company_id = self::get_user_company( $user_id );
                if ( $company_id ) {
                    $stats['my_tickets'] = count( self::get_user_tickets( $user_id ) );
                    $stats['unread_notifs'] = count( 
                        self::get_user_notifications( $user_id, array( 'unread_only' => true ) )
                    );
                }
            }

            // Global stats
            $stats['total_tickets'] = wp_count_posts( 'psp_ticket' )->publish ?? 0;
            $stats['open_tickets'] = count( self::get_tickets( array( 'status' => 'open' ) ) );
            $stats['total_partners'] = wp_count_posts( 'psp_company' )->publish ?? 0;

            return $stats;
        } catch ( \Exception $e ) {
            error_log( '[PSP Data] Get dashboard stats failed: ' . $e->getMessage() );
            return array();
        }
    }

    /**
     * Get cached query results
     *
     * @param string $cache_key Cache key identifier
     * @param callable $callback Function to execute if not cached
     * @param int $ttl Cache time-to-live in seconds
     * @return mixed Cached result or callback result
     */
    public static function get_cached( string $cache_key, callable $callback, int $ttl = 3600 ) {
        try {
            // Try to get from WordPress transient cache
            $cached = get_transient( 'psp_' . $cache_key );
            if ( $cached !== false ) {
                return $cached;
            }

            // Execute callback if not cached
            $result = call_user_func( $callback );

            // Store in cache
            if ( $result !== null && $result !== false ) {
                set_transient( 'psp_' . $cache_key, $result, $ttl );
            }

            return $result;
        } catch ( \Exception $e ) {
            error_log( '[PSP Data] Cache retrieval failed: ' . $e->getMessage() );
            return call_user_func( $callback );
        }
    }

    /**
     * Clear cached query results
     *
     * @param string $cache_key Cache key identifier (empty for all)
     * @return void
     */
    public static function clear_cache( string $cache_key = '' ): void {
        try {
            if ( empty( $cache_key ) ) {
                // Clear all PSP caches
                wp_cache_flush();
            } else {
                delete_transient( 'psp_' . $cache_key );
            }
        } catch ( \Exception $e ) {
            error_log( '[PSP Data] Cache clearing failed: ' . $e->getMessage() );
        }
    }

    /**
     * Warm cache with critical data
     *
     * Called on plugin activation to pre-populate cache
     *
     * @return array Warming results
     */
    public static function warm_cache(): array {
        try {
            $results = array(
                'tickets_warmed' => 0,
                'partners_warmed' => 0,
                'stats_warmed' => 0,
                'errors' => array(),
            );

            // Warm tickets cache
            try {
                $tickets = self::get_tickets( array( 'status' => 'open', 'limit' => 100 ) );
                if ( ! empty( $tickets ) ) {
                    set_transient( 'psp_critical_tickets', $tickets, 3600 );
                    $results['tickets_warmed'] = count( $tickets );
                }
            } catch ( \Exception $e ) {
                $results['errors'][] = 'Ticket warming: ' . $e->getMessage();
            }

            // Warm partners cache
            try {
                $partners = self::get_partners( array( 'limit' => 100 ) );
                if ( ! empty( $partners ) ) {
                    set_transient( 'psp_critical_partners', $partners, 3600 );
                    $results['partners_warmed'] = count( $partners );
                }
            } catch ( \Exception $e ) {
                $results['errors'][] = 'Partner warming: ' . $e->getMessage();
            }

            // Warm dashboard stats
            try {
                $stats = self::get_dashboard_stats();
                if ( ! empty( $stats ) ) {
                    set_transient( 'psp_dashboard_stats', $stats, 1800 );
                    $results['stats_warmed'] = 1;
                }
            } catch ( \Exception $e ) {
                $results['errors'][] = 'Stats warming: ' . $e->getMessage();
            }

            error_log( '[PSP Data] Cache warming completed: ' . wp_json_encode( $results ) );
            return $results;
        } catch ( \Exception $e ) {
            error_log( '[PSP Data] Cache warming failed: ' . $e->getMessage() );
            return array( 'errors' => array( $e->getMessage() ) );
        }
    }

    /**
     * Get cache statistics
     *
     * Returns information about current cache state
     *
     * @return array Cache statistics
     */
    public static function get_cache_stats(): array {
        try {
            global $wpdb;

            // Count cached transients
            $cache_count = $wpdb->get_var(
                "SELECT COUNT(*) FROM {$wpdb->options} WHERE option_name LIKE '%transient_psp_%'"
            );

            return array(
                'total_cached' => (int) $cache_count,
                'cache_enabled' => true,
                'default_ttl' => 3600,
                'timestamp' => current_time( 'mysql' ),
            );
        } catch ( \Exception $e ) {
            error_log( '[PSP Data] Get cache stats failed: ' . $e->getMessage() );
            return array( 'cache_enabled' => false );
        }
    }

    /**
     * Paginate query results
     *
     * Helper for pagination without extra queries
     *
     * @param array $items Items to paginate
     * @param int $page Page number (1-based)
     * @param int $per_page Items per page
     * @return array Paginated results with metadata
     */
    public static function paginate( array $items, int $page = 1, int $per_page = 20 ): array {
        try {
            $total = count( $items );
            $offset = ( max( 1, $page ) - 1 ) * $per_page;
            $paginated = array_slice( $items, $offset, $per_page );

            return array(
                'items'       => $paginated,
                'page'        => $page,
                'per_page'    => $per_page,
                'total'       => $total,
                'total_pages' => ceil( $total / $per_page ),
                'has_next'    => $offset + $per_page < $total,
                'has_prev'    => $page > 1,
            );
        } catch ( \Exception $e ) {
            error_log( '[PSP Data] Pagination failed: ' . $e->getMessage() );
            return array( 'items' => $items, 'error' => true );
        }
    }

    /**
     * Batch get multiple items efficiently
     *
     * @param array $item_ids Array of IDs to retrieve
     * @param string $post_type Post type (psp_ticket, psp_company, etc)
     * @return array Array of posts indexed by ID
     */
    public static function batch_get( array $item_ids, string $post_type = 'psp_ticket' ): array {
        try {
            if ( empty( $item_ids ) ) {
                return array();
            }

            // Remove duplicates and validate
            $item_ids = array_filter( array_unique( array_map( 'intval', $item_ids ) ), fn( $id ) => $id > 0 );

            if ( empty( $item_ids ) ) {
                return array();
            }

            // Use batch query (more efficient than multiple get_post calls)
            $args = array(
                'post_type'      => $post_type,
                'post__in'       => $item_ids,
                'posts_per_page' => count( $item_ids ),
                'orderby'        => 'post__in',
            );

            $posts = get_posts( $args );
            
            // Index by ID for easy lookup
            $indexed = array();
            foreach ( $posts as $post ) {
                $indexed[ $post->ID ] = $post;
            }

            return $indexed;
        } catch ( \Exception $e ) {
            error_log( '[PSP Data] Batch get failed: ' . $e->getMessage() );
            return array();
        }
    }

    /**
     * Initialize the data layer
     *
     * @return void
     */
    public static function init(): void {
        try {
            // Register hooks if needed
            // This layer primarily provides query methods
        } catch ( \Exception $e ) {
            error_log( '[PSP Data] Initialization failed: ' . $e->getMessage() );
        }
    }
}
