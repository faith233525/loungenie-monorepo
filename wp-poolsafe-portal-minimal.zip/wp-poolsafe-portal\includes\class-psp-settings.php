<?php
/**
 * Settings management for PoolSafe Portal
 * Handles plugin settings for PoolSafe Portal plugin.
 *
 * @package PoolSafePortal
 */
namespace PSP;

namespace PSP;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Main settings handler for PoolSafe Portal plugin.
 */
namespace PSP;

class Settings {

	const OPTION_KEY = 'psp_settings';

	/**
	 * Register settings and fields with WordPress.
	 */
	public static function register(): void {
		// ...existing code...
	}

	/**
	 * Get plugin settings, merged with defaults.
	 *
	 * @return array Settings array.
	 */
	public static function get_settings(): array {
		$defaults = array(
			'map_tile_url'          => 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
			'map_attribution'       => '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
			'sla_urgent'            => 4,
			'sla_high'              => 24,
			'sla_medium'            => 72,
			'sla_low'               => 168,
			'sla_reminder_schedule' => '24,72',
			'login_page_slug'       => 'login',
			'primary_color'         => '#3b82f6',
			'primary_hover_color'   => '#2563eb',
			'lock_highlight_bg'     => '#fef3c7',
			'lock_highlight_border' => '#fbbf24',
			'logo_url'              => '',
			'favicon_url'           => '',
			'custom_css'            => '',
		);
		$opts     = get_option( self::OPTION_KEY, array() );
		if ( ! is_array( $opts ) ) {
			$opts = array();
		}
		return wp_parse_args( $opts, $defaults );
	}

	/**
	 * Render logo URL field.
	 *
	 * @return void
	 */
	public static function field_logo_url(): void {
		$opts = self::get_settings();
		echo '<input type="text" class="regular-text" name="' . esc_attr( self::OPTION_KEY ) . '[logo_url]" value="' . esc_attr( $opts['logo_url'] ) . '" placeholder="https://.../logo.png" />';
		echo '<p class="description">' . esc_html__( 'URL to a logo image (PNG, SVG, etc.) to display in the portal header.', 'psp' ) . '</p>';
	}

	/**
	 * Render favicon URL field.
	 *
	 * @return void
	 */
	public static function field_favicon_url(): void {
		$opts = self::get_settings();
		echo '<input type="text" class="regular-text" name="' . esc_attr( self::OPTION_KEY ) . '[favicon_url]" value="' . esc_attr( $opts['favicon_url'] ) . '" placeholder="https://.../favicon.ico" />';
		echo '<p class="description">' . esc_html__( 'URL to a favicon (ICO, PNG, SVG) for browser tabs.', 'psp' ) . '</p>';
	}

	/**
	 * Render custom CSS field.
	 *
	 * @return void
	 */
	public static function field_custom_css(): void {
		$opts = self::get_settings();
		echo '<textarea class="large-text" rows="4" name="' . esc_attr( self::OPTION_KEY ) . '[custom_css]">' . esc_textarea( $opts['custom_css'] ) . '</textarea>';
		echo '<p class="description">' . esc_html__( 'Custom CSS to apply to the portal (advanced).', 'psp' ) . '</p>';
	}

	/**
	 * Get SLA thresholds for priorities.
	 *
	 * @return array SLA thresholds.
	 */
	public static function get_sla_thresholds(): array {
		$o = self::get_settings();
		return array(
			'urgent' => intval( $o['sla_urgent'] ?? 4 ),
			'high'   => intval( $o['sla_high'] ?? 24 ),
			'medium' => intval( $o['sla_medium'] ?? 72 ),
			'low'    => intval( $o['sla_low'] ?? 168 ),
		);
	}

	/**
	 * Render map tile URL field.
	 *
	 * @return void
	 */
	public static function field_tile_url(): void {
		$opts = self::get_settings();
		echo '<input type="text" class="regular-text" name="' . esc_attr( self::OPTION_KEY ) . '[map_tile_url]" value="' . esc_attr( $opts['map_tile_url'] ) . '" placeholder="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />';
	}

	/**
	 * Render map attribution field.
	 *
	 * @return void
	 */
	public static function field_attribution(): void {
		$opts = self::get_settings();
		echo '<textarea class="large-text" rows="3" name="' . esc_attr( self::OPTION_KEY ) . '[map_attribution]">' . esc_textarea( $opts['map_attribution'] ) . '</textarea>';
	}

	/**
	 * Render SLA urgent field.
	 *
	 * @return void
	 */
	public static function field_sla_urgent(): void {
		$o = self::get_settings();
		echo '<input type="number" class="small-text" min="1" max="720" name="' . esc_attr( self::OPTION_KEY ) . '[sla_urgent]" value="' . esc_attr( intval( $o['sla_urgent'] ) ) . '" />';
		echo ' <span class="description">' . esc_html__( 'Hours to respond for Urgent priority', 'psp' ) . '</span>';
	}

	/**
	 * Render SLA high field.
	 *
	 * @return void
	 */
	public static function field_sla_high(): void {
		$o = self::get_settings();
		echo '<input type="number" class="small-text" min="1" max="720" name="' . esc_attr( self::OPTION_KEY ) . '[sla_high]" value="' . esc_attr( intval( $o['sla_high'] ) ) . '" />';
		echo ' <span class="description">' . esc_html__( 'Hours to respond for High priority', 'psp' ) . '</span>';
	}

	/**
	 * Render SLA medium field.
	 *
	 * @return void
	 */
	public static function field_sla_medium(): void {
		$o = self::get_settings();
		echo '<input type="number" class="small-text" min="1" max="720" name="' . esc_attr( self::OPTION_KEY ) . '[sla_medium]" value="' . esc_attr( intval( $o['sla_medium'] ) ) . '" />';
		echo ' <span class="description">' . esc_html__( 'Hours to respond for Medium priority', 'psp' ) . '</span>';
	}

	/**
	 * Render SLA low field.
	 *
	 * @return void
	 */
	public static function field_sla_low(): void {
		$o = self::get_settings();
		echo '<input type="number" class="small-text" min="1" max="720" name="' . esc_attr( self::OPTION_KEY ) . '[sla_low]" value="' . esc_attr( intval( $o['sla_low'] ) ) . '" />';
		echo ' <span class="description">' . esc_html__( 'Hours to respond for Low priority', 'psp' ) . '</span>';
	}

	/**
	 * Render SLA reminder schedule field.
	 *
	 * @return void
	 */
	public static function field_sla_reminder_schedule(): void {
		$o = self::get_settings();
		echo '<input type="text" class="regular-text" name="' . esc_attr( self::OPTION_KEY ) . '[sla_reminder_schedule]" value="' . esc_attr( $o['sla_reminder_schedule'] ) . '" placeholder="24,72" />';
		echo '<p class="description">' . esc_html__( 'Comma-separated hours after SLA breach to send reminder emails (e.g., 24,72).', 'psp' ) . '</p>';
	}

	/**
	 * Render login page slug field.
	 *
	 * @return void
	 */
	public static function field_login_page_slug(): void {
		$o = self::get_settings();
		echo '<input type="text" class="regular-text" name="' . esc_attr( self::OPTION_KEY ) . '[login_page_slug]" value="' . esc_attr( $o['login_page_slug'] ) . '" placeholder="login" />';
		echo '<p class="description">' . esc_html__( 'Page slug for the login page (default: login). Non-logged-in users will be redirected to this page. Both /login and /portal-login are accepted.', 'psp' ) . '</p>';
	}
}
