<?php
namespace PSP;

if (!defined('ABSPATH')) exit;

/**
 * Unified Portal Shortcode
 * Shows login or portal based on auth state
 */
class Portal {

    public static function init() {
        add_shortcode('poolsafe_portal', [self::class, 'render']);
        add_action('wp_enqueue_scripts', [self::class, 'enqueue_assets']);
    }

    public static function enqueue_assets() {
        global $post;
        if (!is_a($post, 'WP_Post') || !has_shortcode($post->post_content, 'poolsafe_portal')) {
            return;
        }

        $version = defined('WP_DEBUG') && WP_DEBUG ? time() : '3.3.0';
        $suffix = (defined('SCRIPT_DEBUG') && SCRIPT_DEBUG) ? '' : '.min';

        // Use portal-shortcode.css (the actual file that exists in css/)
        wp_enqueue_style('psp-portal', PSP_PLUGIN_URL . "css/portal-shortcode.css", [], $version);
        wp_enqueue_style('psp-notifications', PSP_PLUGIN_URL . "css/psp-notifications{$suffix}.css", [], $version);
        
        wp_enqueue_script('psp-notifications', PSP_PLUGIN_URL . "js/psp-notifications.js", [], $version, true);
        // Use psp-portal-app.js (the actual file that exists in js/)
        wp_enqueue_script('psp-portal', PSP_PLUGIN_URL . "js/psp-portal-app{$suffix}.js", ['jquery', 'psp-notifications'], $version, true);

        wp_localize_script('psp-portal', 'PSP_CONFIG', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'restUrl' => rest_url('psp/v1'),
            'nonce' => wp_create_nonce('psp_auth'),
            'restNonce' => wp_create_nonce('wp_rest'),
        ]);
    }

    public static function render($atts) {
        $user = Company_Auth::validate_session();
        
        ob_start();
        
        if ($user) {
            self::render_portal($user);
        } else {
            self::render_login();
        }
        
        return ob_get_clean();
    }

    private static function render_login() {
        ?>
        <div class="psp-auth-container" id="psp-auth">
            <div class="psp-auth-card">
                <div class="psp-auth-header">
                    <h1>PoolSafe Portal</h1>
                    <p>Partner & Support Access</p>
                </div>

                <div class="psp-auth-tabs">
                    <button class="psp-auth-tab active" data-tab="company">Partner Login</button>
                    <button class="psp-auth-tab" data-tab="support">Support Login</button>
                </div>

                <div class="psp-auth-content">
                    <!-- Company Login -->
                    <form id="psp-company-login" class="psp-auth-form active" data-tab-content="company">
                        <div class="psp-form-group">
                            <label for="company-username">Company Username</label>
                            <input type="text" id="company-username" name="username" required autocomplete="username">
                        </div>
                        <div class="psp-form-group">
                            <label for="company-password">Password</label>
                            <input type="password" id="company-password" name="password" required autocomplete="current-password">
                        </div>
                        <div class="psp-form-group">
                            <label class="psp-checkbox">
                                <input type="checkbox" name="remember" checked>
                                <span>Keep me logged in (7 days)</span>
                            </label>
                        </div>
                        <button type="submit" class="psp-btn psp-btn-primary psp-btn-block">
                            <span class="psp-btn-text">Sign In</span>
                            <span class="psp-btn-loader psp-hidden">
                                <span class="psp-spinner"></span> Signing in...
                            </span>
                        </button>
                        <div class="psp-form-message"></div>
                    </form>

                    <!-- Support Login -->
                    <div id="psp-support-login" class="psp-auth-form" data-tab-content="support">
                        <div class="psp-sso-info">
                            <p>Support users sign in with Microsoft 365</p>
                        </div>
                        <button type="button" id="psp-m365-login" class="psp-btn psp-btn-primary psp-btn-block">
                            <svg width="20" height="20" viewBox="0 0 21 21" fill="none">
                                <rect x="1" y="1" width="9" height="9" fill="#f25022"/>
                                <rect x="1" y="11" width="9" height="9" fill="#00a4ef"/>
                                <rect x="11" y="1" width="9" height="9" fill="#7fba00"/>
                                <rect x="11" y="11" width="9" height="9" fill="#ffb900"/>
                            </svg>
                            Sign in with Microsoft
                        </button>
                        <div class="psp-form-message"></div>
                    </div>
                </div>

                <div class="psp-auth-footer">
                    <p>Need help? Contact your administrator</p>
                </div>
            </div>
        </div>
        <?php
    }

    private static function render_portal($user) {
        $is_support = $user['type'] === 'support';
        $contacts = $is_support ? [] : Company_Auth::get_company_contacts($user['id']);
        ?>
        <div class="psp-portal" id="psp-portal" data-user-type="<?php echo esc_attr($user['type']); ?>" data-user-id="<?php echo esc_attr($user['id']); ?>">
            
            <!-- Header -->
            <header class="psp-header">
                <div class="psp-header-content">
                    <div class="psp-header-left">
                        <div class="psp-header-title">
                            <h1>PoolSafe Portal</h1>
                            <p><?php echo $is_support ? 'Support Dashboard' : esc_html($user['name']); ?></p>
                        </div>
                    </div>
                    <div class="psp-header-right">
                        <button id="psp-logout" class="psp-btn psp-btn-primary">
                            Logout
                        </button>
                    </div>
                </div>
            </header>

            <!-- Navigation -->
            <nav class="psp-nav" role="tablist" aria-label="Portal Navigation">
                <button class="psp-nav-item active" data-tab="dashboard" role="tab" aria-selected="true" aria-controls="tab-dashboard">
                    <span class="psp-tab-icon">📊</span>
                    <span class="psp-tab-label">Dashboard</span>
                </button>
                <button class="psp-nav-item" data-tab="videos" role="tab" aria-selected="false" aria-controls="tab-videos">
                    <span class="psp-tab-icon">🎥</span>
                    <span class="psp-tab-label">Videos</span>
                </button>
                <button class="psp-nav-item" data-tab="tickets" role="tab" aria-selected="false" aria-controls="tab-tickets">
                    <span class="psp-tab-icon">🎫</span>
                    <span class="psp-tab-label">Tickets</span>
                </button>
                <button class="psp-nav-item" data-tab="services" role="tab" aria-selected="false" aria-controls="tab-services">
                    <span class="psp-tab-icon">⚙️</span>
                    <span class="psp-tab-label">Services</span>
                </button>
                <button class="psp-nav-item" data-tab="partners" role="tab" aria-selected="false" aria-controls="tab-partners">
                    <span class="psp-tab-icon">🤝</span>
                    <span class="psp-tab-label"><?php echo $is_support ? 'Partners' : 'Contacts'; ?></span>
                </button>
            </nav>

            <!-- Content -->
            <main class="psp-main">
                
                <!-- Dashboard -->
                <section id="tab-dashboard" class="psp-tab-content active" role="tabpanel">
                    <div class="psp-welcome">
                        <h2>Welcome back, <?php echo esc_html(explode(' ', $user['name'])[0]); ?>! 👋</h2>
                        <p>Your portal overview is ready</p>
                    </div>

                    <div class="psp-stats">
                        <div class="psp-stat">
                            <div class="psp-stat-icon">🎫</div>
                            <div class="psp-stat-value" id="stat-tickets">0</div>
                            <div class="psp-stat-label">Open Tickets</div>
                        </div>
                        <div class="psp-stat">
                            <div class="psp-stat-icon">⏳</div>
                            <div class="psp-stat-value" id="stat-pending">0</div>
                            <div class="psp-stat-label">Pending</div>
                        </div>
                        <div class="psp-stat">
                            <div class="psp-stat-icon">✅</div>
                            <div class="psp-stat-value" id="stat-completed">0</div>
                            <div class="psp-stat-label">Completed</div>
                        </div>
                        <div class="psp-stat">
                            <div class="psp-stat-icon">📊</div>
                            <div class="psp-stat-value" id="stat-services">0</div>
                            <div class="psp-stat-label">Services</div>
                        </div>
                    </div>

                    <div id="dashboard-data"></div>
                </section>

                <!-- Tickets -->
                <section id="tab-tickets" class="psp-tab-content" role="tabpanel" hidden>
                    <div class="psp-section-header">
                        <h2>Support Tickets</h2>
                        <button class="psp-btn psp-btn-primary" onclick="PSPPortal.openModal('new-ticket')">
                            ＋ New Ticket
                        </button>
                    </div>
                    <div id="tickets-data"></div>
                </section>

                <!-- Services -->
                <section id="tab-services" class="psp-tab-content" role="tabpanel" hidden>
                    <div class="psp-section-header">
                        <h2>Service Records</h2>
                        <button class="psp-btn psp-btn-primary" onclick="PSPPortal.openModal('schedule-service')">
                            Schedule Service
                        </button>
                    </div>
                    <div id="services-data"></div>
                </section>

                <!-- Videos -->
                <section id="tab-videos" class="psp-tab-content" role="tabpanel" hidden aria-labelledby="videos-tab">
                    <div class="psp-section-header">
                        <h2>Training Videos</h2>
                        <p class="psp-section-description">Access training materials and tutorials</p>
                    </div>
                    <div id="videos-data" class="psp-lazy-content"></div>
                </section>

                <!-- Partners (Company Contacts for partners, All Companies for support) -->
                <section id="tab-partners" class="psp-tab-content" role="tabpanel" hidden aria-labelledby="partners-tab">
                    <div class="psp-section-header">
                        <h2><?php echo $is_support ? 'Partner Companies' : 'Company Contacts'; ?></h2>
                        <?php if ($is_support): ?>
                        <button class="psp-btn psp-btn-primary" onclick="PSPPortal.openModal('new-company')">
                            <span class="psp-btn-icon">＋</span>
                            Add Partner
                        </button>
                        <?php endif; ?>
                    </div>
                    <?php if (!$is_support && $contacts): ?>
                    <div class="psp-grid psp-grid-cols-1 psp-grid-cols-md-2 psp-grid-cols-lg-3">
                        <?php foreach ($contacts as $contact): ?>
                        <div class="psp-card">
                            <div class="psp-card-header">
                                <h3 class="psp-card-title"><?php echo esc_html($contact->name); ?></h3>
                                <?php if ($contact->is_primary): ?>
                                <span class="psp-badge psp-badge-primary">Primary</span>
                                <?php endif; ?>
                            </div>
                            <div class="psp-card-body">
                                <div class="psp-info-row">
                                    <span class="psp-info-icon">📧</span>
                                    <span class="psp-info-text"><?php echo esc_html($contact->email); ?></span>
                                </div>
                                <?php if ($contact->phone): ?>
                                <div class="psp-info-row">
                                    <span class="psp-info-icon">📞</span>
                                    <span class="psp-info-text"><?php echo esc_html($contact->phone); ?></span>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php else: ?>
                    <div id="partners-data" class="psp-lazy-content"></div>
                    <?php endif; ?>
                </section>

            </main>
        </div>

        <!-- Modal Container -->
        <div id="psp-modal" class="psp-modal psp-hidden" role="dialog" aria-hidden="true">
            <div class="psp-modal-overlay" role="presentation"></div>
            <div class="psp-modal-content" role="document">
                <button type="button" class="psp-modal-close" aria-label="Close">×</button>
                <div id="psp-modal-body"></div>
            </div>
        </div>
        <?php
    }
}
