<?php
/**
 * CSRF Protection Class
 * File: includes/class-psp-csrf-protection.php
 * 
 * Implements nonce-based CSRF protection for forms and AJAX.
 * 
 * @package PoolSafe_Portal
 * @subpackage Security
 * @since 3.0.0
 * @author PoolSafe Team
 */

class PSP_CSRF_Protection {

    const NONCE_ACTION = 'psp_csrf_nonce';
    const NONCE_FIELD = 'psp_nonce';
    const TOKEN_LIFETIME = 86400; // 24 hours

    /**
     * Initialize CSRF protection
     */
    public static function init() {
        add_action( 'wp_enqueue_scripts', [ __CLASS__, 'enqueue_nonce' ] );
        add_action( 'admin_enqueue_scripts', [ __CLASS__, 'enqueue_nonce' ] );
        add_action( 'wp_footer', [ __CLASS__, 'output_nonce_field' ] );
    }

    /**
     * Create a CSRF token
     *
     * @param string $action Action identifier
     * @return string CSRF token
     */
    public static function create_token( $action = '' ) {
        if ( empty( $action ) ) {
            $action = self::NONCE_ACTION;
        }

        return wp_create_nonce( $action );
    }

    /**
     * Verify CSRF token
     *
     * @param string $token Token to verify
     * @param string $action Action identifier
     * @return bool True if valid
     */
    public static function verify_token( $token, $action = '' ) {
        if ( empty( $action ) ) {
            $action = self::NONCE_ACTION;
        }

        // Check nonce from various sources
        $sources = [
            $_POST,
            $_GET,
            $_REQUEST,
        ];

        if ( ! empty( $token ) ) {
            $sources[] = [ self::NONCE_FIELD => $token ];
        }

        foreach ( $sources as $source ) {
            if ( isset( $source[ self::NONCE_FIELD ] ) ) {
                if ( wp_verify_nonce( $source[ self::NONCE_FIELD ], $action ) ) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Get CSRF token from request
     *
     * @return string|null Token if found
     */
    public static function get_token_from_request() {
        // Check POST
        if ( isset( $_POST[ self::NONCE_FIELD ] ) ) {
            return sanitize_text_field( $_POST[ self::NONCE_FIELD ] );
        }

        // Check GET
        if ( isset( $_GET[ self::NONCE_FIELD ] ) ) {
            return sanitize_text_field( $_GET[ self::NONCE_FIELD ] );
        }

        // Check headers
        $headers = getallheaders();
        if ( ! empty( $headers['X-CSRF-Token'] ) ) {
            return sanitize_text_field( $headers['X-CSRF-Token'] );
        }

        return null;
    }

    /**
     * Output nonce field in forms
     *
     * @param string $action Action identifier
     * @return void
     */
    public static function nonce_field( $action = '' ) {
        wp_nonce_field( empty( $action ) ? self::NONCE_ACTION : $action, self::NONCE_FIELD );
    }

    /**
     * Enqueue nonce for AJAX requests
     */
    public static function enqueue_nonce() {
        // Store nonce as JavaScript variable for AJAX
        wp_localize_script(
            'jquery',
            'pspCSRF',
            [
                'nonce' => self::create_token(),
                'field' => self::NONCE_FIELD,
            ]
        );
    }

    /**
     * Output nonce field in footer
     */
    public static function output_nonce_field() {
        if ( ! is_admin() ) {
            self::nonce_field();
        }
    }

    /**
     * Middleware: Verify CSRF token in requests
     *
     * @param bool $bypass_admin Skip verification for admin area
     * @return bool|WP_Error True if valid, WP_Error if invalid
     */
    public static function verify_request( $bypass_admin = true ) {
        // Skip verification for GET requests
        if ( 'GET' === $_SERVER['REQUEST_METHOD'] ) {
            return true;
        }

        // Optionally skip admin
        if ( $bypass_admin && is_admin() ) {
            return true;
        }

        // Skip for AJAX requests from WordPress (WordPress handles its own nonces)
        if ( defined( 'DOING_AJAX' ) && DOING_AJAX ) {
            return true;
        }

        // Get token from request
        $token = self::get_token_from_request();

        if ( empty( $token ) ) {
            self::log_failure( 'missing_token' );
            return new WP_Error(
                'csrf_token_missing',
                'Security token missing. Please try again.',
                [ 'status' => 403 ]
            );
        }

        // Verify token
        if ( ! self::verify_token( $token ) ) {
            self::log_failure( 'invalid_token' );
            return new WP_Error(
                'csrf_token_invalid',
                'Security token invalid. Please try again.',
                [ 'status' => 403 ]
            );
        }

        return true;
    }

    /**
     * Get CSRF token for AJAX header
     *
     * @return string Token
     */
    public static function get_ajax_header_token() {
        return self::create_token();
    }

    /**
     * Add CSRF token to form HTML
     *
     * @param string $form_html Form HTML
     * @param string $action Action identifier
     * @return string Modified form HTML
     */
    public static function add_to_form( $form_html, $action = '' ) {
        $nonce_field = sprintf(
            '<input type="hidden" name="%s" value="%s" />',
            self::NONCE_FIELD,
            self::create_token( $action )
        );

        // Insert before closing form tag
        return str_replace( '</form>', $nonce_field . '</form>', $form_html );
    }

    /**
     * Log CSRF failure
     *
     * @param string $reason Failure reason
     */
    public static function log_failure( $reason = 'unknown' ) {
        $log = [
            'timestamp' => current_time( 'mysql' ),
            'reason' => $reason,
            'url' => $_SERVER['REQUEST_URI'] ?? '',
            'ip' => PSP_Rate_Limiter::get_client_ip(),
            'user_id' => get_current_user_id(),
            'referer' => $_SERVER['HTTP_REFERER'] ?? '',
        ];

        do_action( 'psp_csrf_failure', $log );

        // Store in options
        $history = get_option( 'psp_csrf_failures', [] );
        $history[] = $log;

        // Keep last 100 failures
        if ( count( $history ) > 100 ) {
            $history = array_slice( $history, -100 );
        }

        update_option( 'psp_csrf_failures', $history );
    }

    /**
     * Get CSRF failure statistics
     *
     * @return array Statistics
     */
    public static function get_failure_stats() {
        $failures = get_option( 'psp_csrf_failures', [] );
        $stats = [
            'total' => count( $failures ),
            'by_reason' => [],
            'by_ip' => [],
            'recent' => [],
        ];

        foreach ( $failures as $failure ) {
            // Count by reason
            $reason = $failure['reason'] ?? 'unknown';
            $stats['by_reason'][ $reason ] = ( $stats['by_reason'][ $reason ] ?? 0 ) + 1;

            // Count by IP
            $ip = $failure['ip'] ?? 'unknown';
            $stats['by_ip'][ $ip ] = ( $stats['by_ip'][ $ip ] ?? 0 ) + 1;
        }

        // Get recent failures
        $stats['recent'] = array_slice( $failures, -10 );

        return $stats;
    }

    /**
     * Clean old CSRF failure logs
     *
     * @param int $days Keep records this many days old
     */
    public static function cleanup_logs( $days = 7 ) {
        $cutoff = strtotime( "-$days days" );
        $failures = get_option( 'psp_csrf_failures', [] );

        $failures = array_filter(
            $failures,
            function( $failure ) use ( $cutoff ) {
                $time = strtotime( $failure['timestamp'] ?? 'now' );
                return $time > $cutoff;
            }
        );

        update_option( 'psp_csrf_failures', array_values( $failures ) );
    }

    /**
     * Register WP-CLI commands
     */
    public static function register_cli_commands() {
        if ( ! class_exists( 'WP_CLI' ) ) {
            return;
        }

        WP_CLI::add_command( 'psp csrf verify', [ __CLASS__, 'cli_verify' ] );
        WP_CLI::add_command( 'psp csrf stats', [ __CLASS__, 'cli_stats' ] );
        WP_CLI::add_command( 'psp csrf cleanup', [ __CLASS__, 'cli_cleanup' ] );
    }

    /**
     * WP-CLI: Verify CSRF token
     *
     * @param array $args Positional arguments
     * @param array $assoc_args Associative arguments
     */
    public static function cli_verify( $args, $assoc_args ) {
        $token = $args[0] ?? null;

        if ( empty( $token ) ) {
            WP_CLI::error( 'Please provide a token to verify' );
        }

        $valid = self::verify_token( $token );

        if ( $valid ) {
            WP_CLI::success( 'Token is valid' );
        } else {
            WP_CLI::error( 'Token is invalid' );
        }
    }

    /**
     * WP-CLI: Show CSRF statistics
     *
     * @param array $args Positional arguments
     * @param array $assoc_args Associative arguments
     */
    public static function cli_stats( $args, $assoc_args ) {
        $stats = self::get_failure_stats();

        WP_CLI::log( 'CSRF Failure Statistics:' );
        WP_CLI::log( "Total Failures: {$stats['total']}" );
        WP_CLI::log( '' );

        if ( ! empty( $stats['by_reason'] ) ) {
            WP_CLI::log( 'By Reason:' );
            foreach ( $stats['by_reason'] as $reason => $count ) {
                WP_CLI::log( "  $reason: $count" );
            }
            WP_CLI::log( '' );
        }

        if ( ! empty( $stats['by_ip'] ) ) {
            WP_CLI::log( 'By IP (Top 10):' );
            arsort( $stats['by_ip'] );
            foreach ( array_slice( $stats['by_ip'], 0, 10 ) as $ip => $count ) {
                WP_CLI::log( "  $ip: $count" );
            }
        }
    }

    /**
     * WP-CLI: Cleanup CSRF logs
     *
     * @param array $args Positional arguments
     * @param array $assoc_args Associative arguments
     */
    public static function cli_cleanup( $args, $assoc_args ) {
        $days = $assoc_args['days'] ?? 7;
        
        self::cleanup_logs( intval( $days ) );
        WP_CLI::success( "CSRF logs older than $days days have been cleaned" );
    }
}
