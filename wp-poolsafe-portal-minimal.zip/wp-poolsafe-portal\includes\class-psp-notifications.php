<?php
namespace PSP;

use WP_Error;
use WP_Query;
use WP_REST_Request;
/**
 * Notifications CPT & meta + REST endpoints
 * Handles notifications for PoolSafe Portal plugin.
 *
 * @package PoolSafePortal
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Notifications {


	/**
	 * Register notification custom post type with error handling
	 * 
	 * Features:
	 * - Safe post type registration
	 * - Meta field validation
	 * - Comprehensive error logging
	 * - Graceful degradation
	 *
	 * @return void
	 */
	public static function register_cpt(): void {
		try {
			// Validate registration function exists
			if ( ! function_exists( 'register_post_type' ) ) {
				error_log( '[PSP Notifications] register_post_type function not available' );
				return;
			}

			$labels = array(
				'name'          => __( 'Notifications', 'psp' ),
				'singular_name' => __( 'Notification', 'psp' ),
			);

			// Register post type with error handling
			try {
				$result = register_post_type(
					'psp_notification',
					array(
						'labels'       => $labels,
						'public'       => false,
						'show_ui'      => true,
						'show_in_menu' => 'psp-admin',
						'supports'     => array( 'title', 'editor', 'custom-fields', 'author' ),
						'show_in_rest' => false,
						'menu_icon'    => 'dashicons-megaphone',
					)
				);

				if ( is_wp_error( $result ) ) {
					error_log( '[PSP Notifications] CPT registration failed: ' . $result->get_error_message() );
					return;
				}
			} catch ( \Exception $e ) {
				error_log( '[PSP Notifications] CPT registration exception: ' . $e->getMessage() );
				return;
			}

			// Register meta fields with error handling
			self::register_meta( 'target_user', 'integer' );
			self::register_meta( 'read', 'boolean' );
			self::register_meta( 'type', 'string' );
			self::register_meta( 'delivery_targets', 'string' ); // JSON array of user IDs actually notified
			self::register_meta( 'partner_id', 'integer' );

		} catch ( \Exception $e ) {
			error_log( '[PSP Notifications] CPT registration failed: ' . $e->getMessage() );
		}
	}

	/**
	 * Register meta field with error handling
	 *
	 * @param string $key Meta key name
	 * @param string $type Data type
	 * @return void
	 */
	private static function register_meta( string $key, string $type ): void {
		try {
			if ( ! function_exists( 'register_post_meta' ) ) {
				error_log( '[PSP Notifications] register_post_meta function not available' );
				return;
			}

			$result = register_post_meta(
				'psp_notification',
				'psp_' . $key,
				array(
					'type'          => $type,
					'single'        => true,
					'show_in_rest'  => false,
					'auth_callback' => function () {
						return is_user_logged_in();
					},
				)
			);

			if ( ! $result ) {
				error_log( '[PSP Notifications] Meta registration failed for: ' . $key );
			}

		} catch ( \Exception $e ) {
			error_log( '[PSP Notifications] Meta registration exception for ' . $key . ': ' . $e->getMessage() );
		}
	}

	/**
	 * Register REST API routes with comprehensive error handling
	 * 
	 * Features:
	 * - Multiple namespace support
	 * - Safe route registration
	 * - Permission validation
	 * - Error logging
	 * - Graceful degradation
	 *
	 * @return void
	 */
	public static function register_routes(): void {
		try {
			// Validate registration function exists
			if ( ! function_exists( 'register_rest_route' ) ) {
				error_log( '[PSP Notifications] register_rest_route function not available' );
				return;
			}

			$namespaces = array( 'poolsafe/v1', 'psp/v1' );

			foreach ( $namespaces as $namespace ) {
				try {
					// Main notifications endpoint (GET/POST)
					register_rest_route(
						$namespace,
						'/notifications',
						array(
							array(
								'methods'             => 'GET',
								'permission_callback' => array( __CLASS__, 'check_user_logged_in' ),
								'callback'            => array( __CLASS__, 'list_user' ),
							),
							array(
								'methods'             => 'POST',
								'permission_callback' => array( __CLASS__, 'check_can_publish' ),
								'args'                => array(
									'user_id' => array(
										'required' => true,
										'type'     => 'integer',
									),
									'title'   => array(
										'required' => true,
										'type'     => 'string',
									),
									'content' => array(
										'required' => false,
										'type'     => 'string',
									),
								),
								'callback'            => array( __CLASS__, 'create' ),
							),
						)
					);
				} catch ( \Exception $e ) {
					error_log( '[PSP Notifications] Failed to register /notifications route for ' . $namespace . ': ' . $e->getMessage() );
				}

				try {
					// Mark notification as read
					register_rest_route(
						$namespace,
						'/notifications/(?P<id>\\d+)/read',
						array(
							'methods'             => 'POST',
							'permission_callback' => array( __CLASS__, 'check_can_read' ),
							'callback'            => array( __CLASS__, 'mark_read' ),
						)
					);
				} catch ( \Exception $e ) {
					error_log( '[PSP Notifications] Failed to register /notifications/{id}/read route for ' . $namespace . ': ' . $e->getMessage() );
				}

				try {
					// Mark all notifications as read
					register_rest_route(
						$namespace,
						'/notifications/mark-all-read',
						array(
							'methods'             => 'POST',
							'permission_callback' => array( __CLASS__, 'check_user_logged_in' ),
							'callback'            => array( __CLASS__, 'mark_all_read' ),
						)
					);
				} catch ( \Exception $e ) {
					error_log( '[PSP Notifications] Failed to register /notifications/mark-all-read route for ' . $namespace . ': ' . $e->getMessage() );
				}
			}

		} catch ( \Exception $e ) {
			error_log( '[PSP Notifications] Route registration failed: ' . $e->getMessage() );
		}
	}

	/**
	 * Check if user is logged in (permission callback)
	 *
	 * @param WP_REST_Request $request Request object
	 * @return bool|WP_Error
	 */
	public static function check_user_logged_in( ?WP_REST_Request $request = null ): bool {
		try {
			return is_user_logged_in();
		} catch ( \Exception $e ) {
			error_log( '[PSP Notifications] Login check failed: ' . $e->getMessage() );
			return false;
		}
	}

	/**
	 * Check if user can publish notifications
	 *
	 * @param WP_REST_Request $request Request object
	 * @return bool|WP_Error
	 */
	public static function check_can_publish( ?WP_REST_Request $request = null ): bool {
		try {
			return current_user_can( 'publish_psp_tickets' ) || current_user_can( 'administrator' );
		} catch ( \Exception $e ) {
			error_log( '[PSP Notifications] Publish capability check failed: ' . $e->getMessage() );
			return false;
		}
	}

	/**
	 * Check if user can read notification
	 *
	 * @param WP_REST_Request $request Request object
	 * @return bool|WP_Error
	 */
	public static function check_can_read( WP_REST_Request $request ): bool {
		try {
			if ( ! is_user_logged_in() ) {
				return false;
			}

			// Validate request and ID
			if ( ! isset( $request['id'] ) ) {
				error_log( '[PSP Notifications] Read check: missing notification ID' );
				return false;
			}

			$pid   = intval( $request['id'] );
			$owner = intval( get_post_meta( $pid, 'psp_target_user', true ) );
			$current_user_id = get_current_user_id();

			if ( $current_user_id !== $owner ) {
				error_log( '[PSP Notifications] Read check: user ' . $current_user_id . ' cannot access notification ' . $pid );
				return false;
			}

			return true;

		} catch ( \Exception $e ) {
			error_log( '[PSP Notifications] Read capability check failed: ' . $e->getMessage() );
			return false;
		}
	}


	/**
	 * List notifications for current user with error handling
	 * 
	 * Features:
	 * - Safe user ID retrieval
	 * - Query error handling
	 * - Safe post processing
	 * - Error logging
	 * - Content filtering
	 *
	 * @param WP_REST_Request $req Request object
	 * @return WP_REST_Response|WP_Error
	 */
	public static function list_user( WP_REST_Request $req ) {
		try {
			$uid = get_current_user_id();
			if ( $uid <= 0 ) {
				error_log( '[PSP Notifications] List: invalid user ID' );
				return new \WP_Error( 'invalid_user', 'Invalid user', array( 'status' => 401 ) );
			}

			// Query user's notifications
			try {
				$q = new WP_Query( array(
					'post_type'      => 'psp_notification',
					'posts_per_page' => 50,
					'meta_query'     => array(
						array(
							'key'     => 'psp_target_user',
							'value'   => $uid,
							'compare' => '=',
						),
					),
					'orderby'        => 'date',
					'order'          => 'DESC',
				) );
			} catch ( \Exception $e ) {
				error_log( '[PSP Notifications] List query failed: ' . $e->getMessage() );
				return new \WP_Error( 'query_error', 'Failed to retrieve notifications', array( 'status' => 500 ) );
			}

			if ( ! isset( $q->posts ) || ! is_array( $q->posts ) ) {
				error_log( '[PSP Notifications] List: invalid query result' );
				return rest_ensure_response( array() );
			}

			$out = array();
			foreach ( $q->posts as $p ) {
				try {
					if ( ! isset( $p->ID ) ) {
						error_log( '[PSP Notifications] List: post missing ID' );
						continue;
					}

					$out[] = array(
						'id'        => intval( $p->ID ),
						'title'     => sanitize_text_field( get_the_title( $p ) ),
						'content'   => wp_kses_post( apply_filters( 'the_content', $p->post_content ) ),
						'read'      => (bool) get_post_meta( $p->ID, 'psp_read', true ),
						'createdAt' => get_post_time( 'c', true, $p ),
					);
				} catch ( \Exception $e ) {
					error_log( '[PSP Notifications] List: post processing failed: ' . $e->getMessage() );
					continue;
				}
			}

			return rest_ensure_response( $out );

		} catch ( \Exception $e ) {
			error_log( '[PSP Notifications] List notifications failed: ' . $e->getMessage() );
			return new \WP_Error( 'list_error', 'Failed to list notifications', array( 'status' => 500 ) );
		}
	}

	/**
	 * Create notification with error handling
	 * 
	 * Features:
	 * - Input validation
	 * - Safe post creation
	 * - Meta field management
	 * - Error logging
	 *
	 * @param WP_REST_Request $req Request object
	 * @return WP_REST_Response|WP_Error
	 */
	public static function create( WP_REST_Request $req ) {
		try {
			// Validate required fields
			$title = isset( $req['title'] ) ? sanitize_text_field( $req['title'] ) : '';
			$user_id = isset( $req['user_id'] ) ? intval( $req['user_id'] ) : 0;
			$content = isset( $req['content'] ) ? wp_kses_post( $req['content'] ) : '';

			if ( empty( $title ) ) {
				error_log( '[PSP Notifications] Create: missing title' );
				return new \WP_Error( 'invalid', 'Title is required', array( 'status' => 400 ) );
			}

			if ( $user_id <= 0 ) {
				error_log( '[PSP Notifications] Create: invalid user_id' );
				return new \WP_Error( 'invalid', 'Valid user_id is required', array( 'status' => 400 ) );
			}

			// Create post
			try {
				$post_id = wp_insert_post( array(
					'post_type'    => 'psp_notification',
					'post_title'   => $title,
					'post_content' => $content,
					'post_status'  => 'publish',
					'post_author'  => get_current_user_id(),
				), true );

				if ( is_wp_error( $post_id ) ) {
					error_log( '[PSP Notifications] Create post failed: ' . $post_id->get_error_message() );
					return $post_id;
				}

				if ( ! is_numeric( $post_id ) || $post_id <= 0 ) {
					error_log( '[PSP Notifications] Create: invalid post ID returned' );
					return new \WP_Error( 'create_error', 'Failed to create notification', array( 'status' => 500 ) );
				}
			} catch ( \Exception $e ) {
				error_log( '[PSP Notifications] Create post exception: ' . $e->getMessage() );
				return new \WP_Error( 'create_error', 'Failed to create notification', array( 'status' => 500 ) );
			}

			// Set meta fields
			try {
				update_post_meta( $post_id, 'psp_target_user', $user_id );
				update_post_meta( $post_id, 'psp_read', false );
			} catch ( \Exception $e ) {
				error_log( '[PSP Notifications] Create meta failed: ' . $e->getMessage() );
				// Continue despite meta failure
			}

			return rest_ensure_response( array( 'id' => intval( $post_id ) ) );

		} catch ( \Exception $e ) {
			error_log( '[PSP Notifications] Create notification failed: ' . $e->getMessage() );
			return new \WP_Error( 'create_error', 'Failed to create notification', array( 'status' => 500 ) );
		}
	}

	/**
	 * Mark notification as read with error handling
	 * 
	 * Features:
	 * - Safe post ID validation
	 * - Meta update error handling
	 * - Error logging
	 *
	 * @param WP_REST_Request $req Request object
	 * @return WP_REST_Response|WP_Error
	 */
	public static function mark_read( WP_REST_Request $req ) {
		try {
			$pid = isset( $req['id'] ) ? intval( $req['id'] ) : 0;

			if ( $pid <= 0 ) {
				error_log( '[PSP Notifications] Mark read: invalid notification ID' );
				return new \WP_Error( 'invalid', 'Invalid notification ID', array( 'status' => 400 ) );
			}

			// Verify notification exists
			if ( ! get_post( $pid ) ) {
				error_log( '[PSP Notifications] Mark read: notification not found - ' . $pid );
				return new \WP_Error( 'not_found', 'Notification not found', array( 'status' => 404 ) );
			}

			// Update meta
			try {
				update_post_meta( $pid, 'psp_read', true );
			} catch ( \Exception $e ) {
				error_log( '[PSP Notifications] Mark read: meta update failed: ' . $e->getMessage() );
				return new \WP_Error( 'update_error', 'Failed to mark as read', array( 'status' => 500 ) );
			}

			return rest_ensure_response( array( 'ok' => true ) );

		} catch ( \Exception $e ) {
			error_log( '[PSP Notifications] Mark read failed: ' . $e->getMessage() );
			return new \WP_Error( 'error', 'Failed to mark as read', array( 'status' => 500 ) );
		}
	}

	/**
	 * Mark all notifications for the current user as read.
	 */
	public static function mark_all_read( WP_REST_Request $req ) {
		if ( ! is_user_logged_in() ) {
			return new WP_Error( 'rest_forbidden', __( 'Authentication required.', 'psp' ), array( 'status' => 401 ) );
		}

		$uid    = get_current_user_id();
		$query  = new WP_Query(
			array(
				'post_type'      => 'psp_notification',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'meta_query'     => array(
					array(
						'key'     => 'psp_target_user',
						'value'   => $uid,
						'compare' => '=',
					),
				),
			)
		);

		$updated = 0;
		foreach ( $query->posts as $post_id ) {
			update_post_meta( $post_id, 'psp_read', true );
			$updated++;
		}

		return rest_ensure_response(
			array(
				'ok'      => true,
				'updated' => $updated,
			)
		);
	}

	/**
	 * High-level dispatch: choose recipients based on subscription prefs.
	 *
	 * @param int    $partner_id Related company/partner ID (optional)
	 * @param string $category   tickets|service_records|alerts|announcements
	 * @param string $title      Notification title
	 * @param string $content    HTML/plain content
	 * @param array  $extra_meta Additional meta key=>value pairs
	 */
	public static function dispatch( int $partner_id, string $category, string $title, string $content, array $extra_meta = array() ): array {
		$recipients    = array();
		$fallback_used = false;
		// Always send to all partner users (no opt-in/out)
		if ( class_exists( 'PSP_Company_Users' ) && $partner_id ) {
			$users = PSP_Company_Users::get_partner_users( $partner_id );
			foreach ( $users as $u ) {
				$recipients[] = $u->ID;
			}
			// Fallback to primary if none
			if ( empty( $recipients ) ) {
				$primary = PSP_Company_Users::get_primary( $partner_id );
				if ( $primary ) {
					$recipients[]  = $primary;
					$fallback_used = true;
				}
			}
		}
		// Global fallback to admin/support if still empty
		if ( empty( $recipients ) ) {
			$admins = get_users(
				array(
					'role__in' => array( 'administrator', 'psp_support' ),
					'fields'   => array( 'ID' ),
				)
			);
			foreach ( $admins as $a ) {
				$recipients[] = $a->ID;
			}
			$fallback_used = true;
		}
		$created = array();
		foreach ( array_unique( $recipients ) as $uid ) {
			$post_id = wp_insert_post(
				array(
					'post_type'    => 'psp_notification',
					'post_title'   => wp_strip_all_tags( $title ),
					'post_content' => wp_kses_post( $content ),
					'post_status'  => 'publish',
					'post_author'  => get_current_user_id() ?: $uid,
				)
			);
			if ( is_wp_error( $post_id ) ) {
				continue;
			}
			update_post_meta( $post_id, 'psp_target_user', $uid );
			update_post_meta( $post_id, 'psp_read', false );
			update_post_meta( $post_id, 'psp_type', sanitize_text_field( $category ) );
			if ( $partner_id ) {
				update_post_meta( $post_id, 'psp_partner_id', $partner_id );
			}
			foreach ( $extra_meta as $k => $v ) {
				update_post_meta( $post_id, 'psp_' . $k, $v );
			}
			$created[] = $post_id;
		}
		// Record delivery targets on first notification (for auditing)
		if ( ! empty( $created ) ) {
			update_post_meta(
				$created[0],
				'psp_delivery_targets',
				wp_json_encode(
					array(
						'user_ids'      => $recipients,
						'fallback_used' => $fallback_used,
						'category'      => $category,
					)
				)
			);
		}
		return array(
			'notification_ids' => $created,
			'recipient_ids'    => $recipients,
			'fallback_used'    => $fallback_used,
		);
	}
}
