<?php
/**
 * Breadcrumb & Context Navigation Helper
 * Provides industry-standard breadcrumb trails and context awareness
 */

namespace PSP;

if (!defined('ABSPATH')) {
    exit;
}

class Navigation_Helper {

    /**
     * Get breadcrumb trail
     * @param string $current_page Current page identifier
     * @param int $company_id Optional company ID for context
     * @return array Breadcrumb items
     */
    public static function get_breadcrumbs($current_page, $company_id = null) {
        $breadcrumbs = [
            ['label' => '🏠 Home', 'url' => '?page=dashboard']
        ];

        // Get company name if company_id provided
        $company_name = null;
        if ($company_id) {
            global $wpdb;
            $company = $wpdb->get_row($wpdb->prepare(
                "SELECT company_name FROM {$wpdb->prefix}psp_partners WHERE id = %d",
                $company_id
            ));
            $company_name = $company ? $company->company_name : null;
        }

        // Build breadcrumb trail based on current page
        switch ($current_page) {
            case 'dashboard':
                $breadcrumbs[] = ['label' => '📊 Dashboard', 'url' => null];
                break;

            case 'companies':
                if ($company_id && $company_name) {
                    $breadcrumbs[] = ['label' => '💼 Companies', 'url' => '?page=companies'];
                    $breadcrumbs[] = ['label' => $company_name, 'url' => null];
                } else {
                    $breadcrumbs[] = ['label' => '💼 Companies', 'url' => null];
                }
                break;

            case 'tickets':
                $breadcrumbs[] = ['label' => '🎫 Tickets', 'url' => '?page=tickets'];
                if ($company_id && $company_name) {
                    $breadcrumbs[] = ['label' => $company_name, 'url' => '?page=companies&id=' . intval($company_id)];
                }
                break;

            case 'service-records':
                $breadcrumbs[] = ['label' => '📅 Service Records', 'url' => '?page=service-records'];
                if ($company_id && $company_name) {
                    $breadcrumbs[] = ['label' => $company_name, 'url' => '?page=companies&id=' . intval($company_id)];
                }
                break;

            case 'notifications':
                $breadcrumbs[] = ['label' => '🔔 Notifications', 'url' => null];
                break;

            case 'users':
                $breadcrumbs[] = ['label' => '👥 Users', 'url' => '?page=users'];
                if ($company_id && $company_name) {
                    $breadcrumbs[] = ['label' => $company_name, 'url' => '?page=companies&id=' . intval($company_id)];
                }
                break;

            case 'settings':
                $breadcrumbs[] = ['label' => '⚙️ Settings', 'url' => null];
                break;
        }

        return $breadcrumbs;
    }

    /**
     * Render breadcrumb HTML
     * @param array $breadcrumbs Breadcrumb items
     * @return string HTML
     */
    public static function render_breadcrumbs($breadcrumbs) {
        if (empty($breadcrumbs)) {
            return '';
        }

        $html = '<nav class="psp-breadcrumbs" aria-label="Breadcrumb">';
        $html .= '<ol class="psp-breadcrumbs-list">';

        foreach ($breadcrumbs as $index => $crumb) {
            $is_last = ($index === count($breadcrumbs) - 1);

            if ($crumb['url']) {
                $html .= '<li class="psp-breadcrumb-item">';
                $html .= '<a href="' . esc_url($crumb['url']) . '" class="psp-breadcrumb-link">';
                $html .= esc_html($crumb['label']);
                $html .= '</a>';
                if (!$is_last) {
                    $html .= '<span class="psp-breadcrumb-separator">/</span>';
                }
                $html .= '</li>';
            } else {
                $html .= '<li class="psp-breadcrumb-item psp-breadcrumb-current" aria-current="page">';
                $html .= esc_html($crumb['label']);
                $html .= '</li>';
            }
        }

        $html .= '</ol>';
        $html .= '</nav>';

        return $html;
    }

    /**
     * Get context info (company name, etc)
     * @param int $company_id Company ID
     * @return array Context data
     */
    public static function get_context_info($company_id) {
        global $wpdb;

        $company = $wpdb->get_row($wpdb->prepare(
            "SELECT id, company_name FROM {$wpdb->prefix}psp_partners WHERE id = %d",
            $company_id
        ));

        if (!$company) {
            return null;
        }

        $ticket_count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}psp_tickets WHERE partner_id = %d",
            $company_id
        ));

        $service_count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}psp_service_records WHERE partner_id = %d",
            $company_id
        ));

        return [
            'id' => $company->id,
            'name' => $company->company_name,
            'tickets' => intval($ticket_count),
            'services' => intval($service_count),
        ];
    }

    /**
     * Render context header (shows company name with quick links)
     * @param array $context Context info
     * @return string HTML
     */
    public static function render_context_header($context) {
        if (!$context) {
            return '';
        }

        $html = '<div class="psp-context-header">';
        $html .= '<div class="psp-context-content">';
        $html .= '<h1 class="psp-context-title">🏢 ' . esc_html($context['name']) . '</h1>';
        $html .= '<div class="psp-context-links">';
        $html .= '<a href="?page=companies&id=' . intval($context['id']) . '" class="psp-context-link">View Profile</a>';
        $html .= '<a href="?page=tickets&company_id=' . intval($context['id']) . '" class="psp-context-link">Tickets (' . intval($context['tickets']) . ')</a>';
        $html .= '<a href="?page=service-records&company_id=' . intval($context['id']) . '" class="psp-context-link">Services (' . intval($context['services']) . ')</a>';
        $html .= '</div>';
        $html .= '</div>';
        $html .= '</div>';

        return $html;
    }

    /**
     * Get return URL (where user came from)
     * @return string Previous URL or default
     */
    public static function get_return_url($default = '?page=dashboard') {
        $referrer = isset($_SERVER['HTTP_REFERER']) ? esc_url_raw($_SERVER['HTTP_REFERER']) : '';
        $return = isset($_GET['return']) ? esc_url_raw($_GET['return']) : '';

        return $return ?: $referrer ?: $default;
    }
}
