<?php

namespace PSP;

/**
 * Input Fields & Form Helpers
 * 
 * Provides enhanced input field rendering with validation,
 * color picker support, phone formatting, and date validation.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Input_Fields {

	/**
	 * Initialize input field helpers and enqueue assets.
	 */
	public static function init(): void {
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_scripts' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_frontend_scripts' ) );
	}

	/**
	 * Enqueue admin scripts and styles for enhanced inputs.
	 */
	public static function enqueue_scripts(): void {
		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_script( 'wp-color-picker' );
		wp_enqueue_script(
			'psp-input-fields',
			plugins_url( 'js/input-fields.js', __FILE__ ),
			array( 'jquery', 'wp-color-picker' ),
			PSP_VERSION,
			true
		);
		wp_enqueue_style(
			'psp-input-fields',
			plugins_url( 'css/input-fields.css', __FILE__ ),
			array(),
			PSP_VERSION
		);
	}

	/**
	 * Enqueue frontend scripts for field validation.
	 */
	public static function enqueue_frontend_scripts(): void {
		wp_enqueue_script(
			'psp-input-validation',
			plugins_url( 'js/input-validation.js', dirname( __FILE__ ) ),
			array( 'jquery' ),
			PSP_VERSION,
			true
		);
	}

	/**
	 * Render color picker field with presets and custom option.
	 * 
	 * @param string $field_name Field name attribute.
	 * @param string $current_value Current color value (hex or preset key).
	 * @param string $label Field label.
	 * @return void
	 */
	public static function render_color_picker( string $field_name, string $current_value, string $label = 'Color' ): void {
		$colors = self::get_color_presets();
		$current_hex = $current_value;

		// If current value is a preset key, get its hex code
		if ( isset( $colors[ $current_value ] ) ) {
			$current_hex = $colors[ $current_value ]['hex'];
		}

		echo '<div class="psp-color-picker-wrapper">';
		echo '<label for="' . esc_attr( $field_name ) . '">' . esc_html( $label ) . '</label>';
		echo '<div class="psp-color-presets">';

		// Render preset color buttons
		foreach ( $colors as $key => $color_data ) {
			$is_selected = ( $current_value === $key ) ? ' selected' : '';
			echo '<button type="button" class="psp-color-preset' . esc_attr( $is_selected ) . '" data-color="' . esc_attr( $key ) . '" style="background-color: ' . esc_attr( $color_data['hex'] ) . ';" title="' . esc_attr( $color_data['name'] ) . '">';
			echo '<span class="psp-color-label">' . esc_html( $color_data['name'] ) . '</span>';
			echo '</button>';
		}

		echo '</div>';

		// Hidden input for preset or custom hex
		echo '<div class="psp-color-custom-wrapper">';
		echo '<label for="' . esc_attr( $field_name ) . '-picker">' . esc_html__( 'Custom Color', 'psp' ) . '</label>';
		echo '<input type="text" id="' . esc_attr( $field_name ) . '-picker" class="psp-color-picker-input" data-field-name="' . esc_attr( $field_name ) . '" value="' . esc_attr( $current_hex ) . '">';
		echo '</div>';

		// Actual form field (hidden, stores value)
		echo '<input type="hidden" id="' . esc_attr( $field_name ) . '" name="' . esc_attr( $field_name ) . '" value="' . esc_attr( $current_value ) . '" class="psp-color-field-value">';
		echo '</div>';
	}

	/**
	 * Render phone number field with formatting and validation.
	 * 
	 * @param string $field_name Field name attribute.
	 * @param string $current_value Current phone number.
	 * @param string $label Field label.
	 * @return void
	 */
	public static function render_phone_field( string $field_name, string $current_value, string $label = 'Phone' ): void {
		echo '<div class="psp-phone-wrapper">';
		echo '<label for="' . esc_attr( $field_name ) . '">' . esc_html( $label ) . '</label>';
		echo '<input type="tel" id="' . esc_attr( $field_name ) . '" name="' . esc_attr( $field_name ) . '" value="' . esc_attr( $current_value ) . '" class="psp-phone-input widefat" placeholder="(123) 456-7890" pattern="[0-9\-\+\(\)\s]+">';
		echo '<small class="psp-phone-format">' . esc_html__( 'Format: (123) 456-7890', 'psp' ) . '</small>';
		echo '</div>';
	}

	/**
	 * Render date field with min/max validation.
	 * 
	 * @param string $field_name Field name attribute.
	 * @param string $current_value Current date value (YYYY-MM-DD).
	 * @param string $label Field label.
	 * @param string|null $min_date Minimum date (YYYY-MM-DD).
	 * @param string|null $max_date Maximum date (YYYY-MM-DD).
	 * @return void
	 */
	public static function render_date_field( string $field_name, string $current_value, string $label = 'Date', ?string $min_date = null, ?string $max_date = null ): void {
		echo '<div class="psp-date-wrapper">';
		echo '<label for="' . esc_attr( $field_name ) . '">' . esc_html( $label ) . '</label>';
		echo '<input type="date" id="' . esc_attr( $field_name ) . '" name="' . esc_attr( $field_name ) . '" value="' . esc_attr( $current_value ) . '" class="psp-date-input widefat"';
		if ( $min_date ) {
			echo ' min="' . esc_attr( $min_date ) . '"';
		}
		if ( $max_date ) {
			echo ' max="' . esc_attr( $max_date ) . '"';
		}
		echo '>';
		echo '</div>';
	}

	/**
	 * Render date range fields with validation.
	 * 
	 * @param string $start_field Start date field name.
	 * @param string $end_field End date field name.
	 * @param string $start_value Current start date value.
	 * @param string $end_value Current end date value.
	 * @param string $label Field label group.
	 * @return void
	 */
	public static function render_date_range_fields( string $start_field, string $end_field, string $start_value, string $end_value, string $label = 'Date Range' ): void {
		echo '<fieldset class="psp-date-range-wrapper">';
		echo '<legend>' . esc_html( $label ) . '</legend>';
		echo '<div class="psp-date-range-row">';

		echo '<div class="psp-date-range-col">';
		self::render_date_field( $start_field, $start_value, __( 'Start Date', 'psp' ) );
		echo '</div>';

		echo '<div class="psp-date-range-col">';
		self::render_date_field( $end_field, $end_value, __( 'End Date', 'psp' ) );
		echo '</div>';

		echo '</div>';
		echo '<small class="psp-date-range-validation">' . esc_html__( 'Start date must be before end date', 'psp' ) . '</small>';
		echo '</fieldset>';
	}

	/**
	 * Render password field with strength indicator.
	 * 
	 * @param string $field_name Field name attribute.
	 * @param string $label Field label.
	 * @return void
	 */
	public static function render_password_field( string $field_name, string $label = 'Password' ): void {
		echo '<div class="psp-password-wrapper">';
		echo '<label for="' . esc_attr( $field_name ) . '">' . esc_html( $label ) . '</label>';
		echo '<div class="psp-password-input-group">';
		echo '<input type="password" id="' . esc_attr( $field_name ) . '" name="' . esc_attr( $field_name ) . '" class="psp-password-input widefat" required>';
		echo '<button type="button" class="psp-password-toggle" data-field="' . esc_attr( $field_name ) . '" title="' . esc_attr__( 'Show/Hide', 'psp' ) . '">👁</button>';
		echo '</div>';

		// Strength indicator
		echo '<div class="psp-password-strength">';
		echo '<div class="psp-strength-meter"></div>';
		echo '<small class="psp-strength-text"></small>';
		echo '</div>';

		// Requirements checklist
		echo '<div class="psp-password-requirements">';
		echo '<small>' . esc_html__( 'Requirements:', 'psp' ) . '</small>';
		echo '<ul>';
		echo '<li class="req-length"><span class="req-icon">◯</span> ' . esc_html__( 'At least 8 characters', 'psp' ) . '</li>';
		echo '<li class="req-uppercase"><span class="req-icon">◯</span> ' . esc_html__( 'One uppercase letter (A-Z)', 'psp' ) . '</li>';
		echo '<li class="req-number"><span class="req-icon">◯</span> ' . esc_html__( 'One number (0-9)', 'psp' ) . '</li>';
		echo '<li class="req-special"><span class="req-icon">◯</span> ' . esc_html__( 'One special character (!@#$%^&*)', 'psp' ) . '</li>';
		echo '</ul>';
		echo '</div>';

		echo '</div>';
	}

	/**
	 * Render enhanced select/dropdown field.
	 * 
	 * @param string $field_name Field name attribute.
	 * @param array $options Array of option key => label.
	 * @param string $current_value Current selected value.
	 * @param string $label Field label.
	 * @param bool $searchable Enable searchable for long lists.
	 * @return void
	 */
	public static function render_select_field( string $field_name, array $options, string $current_value, string $label = 'Select', bool $searchable = false ): void {
		$class = 'widefat';
		if ( $searchable && count( $options ) > 10 ) {
			$class .= ' psp-searchable-select';
		}

		echo '<div class="psp-select-wrapper">';
		echo '<label for="' . esc_attr( $field_name ) . '">' . esc_html( $label ) . '</label>';
		echo '<select id="' . esc_attr( $field_name ) . '" name="' . esc_attr( $field_name ) . '" class="' . esc_attr( $class ) . '">';
		echo '<option value="">' . esc_html__( '— Select —', 'psp' ) . '</option>';

		foreach ( $options as $key => $label_text ) {
			echo '<option value="' . esc_attr( $key ) . '"' . selected( $current_value, $key, false ) . '>' . esc_html( $label_text ) . '</option>';
		}

		echo '</select>';
		echo '</div>';
	}

	/**
	 * Render email field with validation.
	 * 
	 * @param string $field_name Field name attribute.
	 * @param string $current_value Current email value.
	 * @param string $label Field label.
	 * @return void
	 */
	public static function render_email_field( string $field_name, string $current_value, string $label = 'Email' ): void {
		echo '<div class="psp-email-wrapper">';
		echo '<label for="' . esc_attr( $field_name ) . '">' . esc_html( $label ) . '</label>';
		echo '<input type="email" id="' . esc_attr( $field_name ) . '" name="' . esc_attr( $field_name ) . '" value="' . esc_attr( $current_value ) . '" class="psp-email-input widefat" required>';
		echo '<small class="psp-email-validation"></small>';
		echo '</div>';
	}

	/**
	 * Get color presets with hex codes.
	 * 
	 * @return array Color presets [key => ['name' => '', 'hex' => '']]
	 */
	public static function get_color_presets(): array {
		return array(
			'classic_blue'        => array(
				'name' => __( 'Classic Blue', 'psp' ),
				'hex'  => '#0066CC',
			),
			'ice_blue'            => array(
				'name' => __( 'Ice Blue', 'psp' ),
				'hex'  => '#00B4D8',
			),
			'ducati_red'          => array(
				'name' => __( 'Ducati Red', 'psp' ),
				'hex'  => '#DC143C',
			),
			'yellow'              => array(
				'name' => __( 'Yellow', 'psp' ),
				'hex'  => '#FFD700',
			),
			'basf_4616_yellow'    => array(
				'name' => __( 'BASF 4616 Yellow', 'psp' ),
				'hex'  => '#f2d500',
			),
			'poolsafe_orange'     => array(
				'name' => __( 'PoolSafe Orange', 'psp' ),
				'hex'  => '#ff7f32',
			),
			'trojan_blue'         => array(
				'name' => __( 'Trojan Blue', 'psp' ),
				'hex'  => '#0077c8',
			),
			'lime_green'          => array(
				'name' => __( 'Lime Green', 'psp' ),
				'hex'  => '#32cd32',
			),
			'coral'               => array(
				'name' => __( 'Coral', 'psp' ),
				'hex'  => '#ff7f50',
			),
			'yellow_ice_blue'     => array(
				'name' => __( 'Yellow / Ice Blue', 'psp' ),
				'hex'  => '#ffd700',
			),
			'ice_blue_yellow'     => array(
				'name' => __( 'Ice Blue / Yellow', 'psp' ),
				'hex'  => '#00b4d8',
			),
			'ice_blue_yellow_alt' => array(
				'name' => __( 'Ice Blue / Yellow', 'psp' ),
				'hex'  => '#00b4d8',
			),
		);
	}

	/**
	 * Validate and format phone number.
	 * 
	 * @param string $phone Phone number.
	 * @return string Formatted phone number.
	 */
	public static function validate_phone( string $phone ): string {
		// Remove all non-numeric characters except + for international
		$phone = preg_replace( '/[^\d\+]/', '', $phone );

		// Format US phone (10 digits) as (XXX) XXX-XXXX
		if ( strlen( $phone ) === 10 && ! str_starts_with( $phone, '+' ) ) {
			$phone = '(' . substr( $phone, 0, 3 ) . ') ' . substr( $phone, 3, 3 ) . '-' . substr( $phone, 6 );
		}

		return $phone;
	}

	/**
	 * Validate email address format.
	 * 
	 * @param string $email Email address.
	 * @return bool True if valid.
	 */
	public static function validate_email( string $email ): bool {
		return is_email( $email ) !== false;
	}

	/**
	 * Validate date is not in future.
	 * 
	 * @param string $date Date value (YYYY-MM-DD).
	 * @return bool True if valid (not in future).
	 */
	public static function validate_date_not_future( string $date ): bool {
		$date_time = strtotime( $date );
		$now       = time();
		return $date_time <= $now;
	}

	/**
	 * Validate date range (start before end).
	 * 
	 * @param string $start_date Start date (YYYY-MM-DD).
	 * @param string $end_date End date (YYYY-MM-DD).
	 * @return bool True if valid.
	 */
	public static function validate_date_range( string $start_date, string $end_date ): bool {
		$start_time = strtotime( $start_date );
		$end_time   = strtotime( $end_date );
		return $start_time < $end_time;
	}

	/**
	 * Validate password strength.
	 * 
	 * @param string $password Password.
	 * @return array ['valid' => bool, 'errors' => []]
	 */
	public static function validate_password_strength( string $password ): array {
		$errors = array();

		if ( strlen( $password ) < 8 ) {
			$errors[] = __( 'Password must be at least 8 characters', 'psp' );
		}

		if ( ! preg_match( '/[A-Z]/', $password ) ) {
			$errors[] = __( 'Password must contain at least one uppercase letter', 'psp' );
		}

		if ( ! preg_match( '/[0-9]/', $password ) ) {
			$errors[] = __( 'Password must contain at least one number', 'psp' );
		}

		if ( ! preg_match( '/[!@#$%^&*\-_=+\[\]{};:\'",.<>?\/\\|`~]/', $password ) ) {
			$errors[] = __( 'Password must contain at least one special character (!@#$%^&*)', 'psp' );
		}

		return array(
			'valid'  => empty( $errors ),
			'errors' => $errors,
		);
	}

	/**
	 * Validate single field based on type.
	 * 
	 * @param string $type Field type (email, phone, date, password, etc).
	 * @param string $value Field value.
	 * @return array ['valid' => bool, 'error' => '']
	 */
	public static function validate_field( string $type, string $value ): array {
		switch ( $type ) {
			case 'email':
				if ( ! self::validate_email( $value ) ) {
					return array(
						'valid' => false,
						'error' => __( 'Invalid email address', 'psp' ),
					);
				}
				break;

			case 'phone':
				if ( empty( $value ) ) {
					return array(
						'valid' => false,
						'error' => __( 'Phone number is required', 'psp' ),
					);
				}
				if ( strlen( preg_replace( '/\D/', '', $value ) ) < 10 ) {
					return array(
						'valid' => false,
						'error' => __( 'Phone number must be at least 10 digits', 'psp' ),
					);
				}
				break;

			case 'date':
				if ( ! self::validate_date_not_future( $value ) ) {
					return array(
						'valid' => false,
						'error' => __( 'Date cannot be in the future', 'psp' ),
					);
				}
				break;
		}

		return array(
			'valid' => true,
			'error' => '',
		);
	}
}
