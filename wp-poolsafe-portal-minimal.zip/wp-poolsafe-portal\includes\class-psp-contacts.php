<?php
/**
 * PoolSafe Portal v3.0 - Contacts CPT
 *
 * Manages company contacts with automatic association from ticket submissions.
 *
 * @package PoolSafe_Portal
 * @subpackage Contacts
 * @version 3.0.0
 */

namespace PSP;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Contacts {

	/**
	 * Custom post type name
	 */
	const POST_TYPE = 'psp_contact';

	/**
	 * Initialize contacts CPT
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'register_cpt' ) );
		add_action( 'init', array( __CLASS__, 'register_meta' ) );
	}

	/**
	 * Register custom post type
	 */
	public static function register_cpt() {
		$labels = array(
			'name'               => __( 'Contacts', 'psp' ),
			'singular_name'      => __( 'Contact', 'psp' ),
			'menu_name'          => __( 'Contacts', 'psp' ),
			'all_items'          => __( 'All Contacts', 'psp' ),
			'add_new_item'       => __( 'New Contact', 'psp' ),
			'edit_item'          => __( 'Edit Contact', 'psp' ),
			'new_item'           => __( 'New Contact', 'psp' ),
			'view_item'          => __( 'View Contact', 'psp' ),
			'search_items'       => __( 'Search Contacts', 'psp' ),
			'not_found'          => __( 'No contacts found', 'psp' ),
			'not_found_in_trash' => __( 'No contacts in trash', 'psp' ),
		);

		$args = array(
			'labels'            => $labels,
			'description'       => __( 'Company contacts and users', 'psp' ),
			'public'            => false,
			'hierarchical'      => false,
			'show_ui'           => true,
			'show_in_menu'      => 'poolsafe-admin-page',
			'show_in_nav_menus' => false,
			'show_in_rest'      => true,
			'rest_base'         => 'contacts',
			'capabilities'      => array(
				'create_posts'       => 'manage_psp_contacts',
				'read_post'          => 'read_psp_contact',
				'read_private_posts' => 'read_private_psp_contacts',
				'edit_post'          => 'manage_psp_contacts',
				'edit_posts'         => 'manage_psp_contacts',
				'edit_others_posts'  => 'manage_psp_contacts',
				'publish_posts'      => 'manage_psp_contacts',
				'delete_post'        => 'manage_psp_contacts',
				'delete_posts'       => 'manage_psp_contacts',
				'delete_others_posts' => 'manage_psp_contacts',
			),
			'map_meta_cap'      => false,
			'supports'          => array( 'title', 'custom-fields' ),
			'menu_icon'         => 'dashicons-groups',
		);

		register_post_type( self::POST_TYPE, $args );
	}

	/**
	 * Register meta fields
	 */
	public static function register_meta() {
		// Linked WordPress user ID
		register_post_meta(
			self::POST_TYPE,
			'psp_user_id',
			array(
				'type'          => 'integer',
				'single'        => true,
				'show_in_rest'  => true,
				'auth_callback' => function () {
					return current_user_can( 'read_psp_contact' );
				},
			)
		);

		// Company ID
		register_post_meta(
			self::POST_TYPE,
			'psp_company_id',
			array(
				'type'          => 'integer',
				'single'        => true,
				'show_in_rest'  => true,
				'auth_callback' => function () {
					return current_user_can( 'read_psp_contact' );
				},
			)
		);

		// Contact email
		register_post_meta(
			self::POST_TYPE,
			'psp_email',
			array(
				'type'          => 'string',
				'single'        => true,
				'show_in_rest'  => true,
				'auth_callback' => function () {
					return current_user_can( 'read_psp_contact' );
				},
			)
		);

		// Contact phone
		register_post_meta(
			self::POST_TYPE,
			'psp_phone',
			array(
				'type'          => 'string',
				'single'        => true,
				'show_in_rest'  => true,
				'auth_callback' => function () {
					return current_user_can( 'read_psp_contact' );
				},
			)
		);

		// Contact role/title
		register_post_meta(
			self::POST_TYPE,
			'psp_role',
			array(
				'type'          => 'string',
				'single'        => true,
				'show_in_rest'  => true,
				'auth_callback' => function () {
					return current_user_can( 'read_psp_contact' );
				},
			)
		);

		// Primary contact flag
		register_post_meta(
			self::POST_TYPE,
			'psp_is_primary',
			array(
				'type'          => 'boolean',
				'single'        => true,
				'show_in_rest'  => true,
				'auth_callback' => function () {
					return current_user_can( 'read_psp_contact' );
				},
			)
		);

		// How contact was added (primary, secondary, auto_from_ticket)
		register_post_meta(
			self::POST_TYPE,
			'psp_source',
			array(
				'type'          => 'string',
				'single'        => true,
				'show_in_rest'  => true,
				'auth_callback' => function () {
					return current_user_can( 'read_psp_contact' );
				},
			)
		);

		// Date added
		register_post_meta(
			self::POST_TYPE,
			'psp_date_added',
			array(
				'type'          => 'string',
				'single'        => true,
				'show_in_rest'  => true,
				'auth_callback' => function () {
					return current_user_can( 'read_psp_contact' );
				},
			)
		);
	}

	/**
	 * Create or get contact for user+company
	 *
	 * @param int $user_id WordPress user ID
	 * @param int $company_id Company post ID
	 * @param string $source How contact was added (primary, secondary, auto_from_ticket)
	 * @return int Contact post ID
	 */
	public static function create_or_get_contact( $user_id, $company_id, $source = 'auto_from_ticket' ) {
		// Check if contact already exists
		$existing = get_posts(
			array(
				'post_type'  => self::POST_TYPE,
				'meta_query' => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query
					'relation' => 'AND',
					array(
						'key'   => 'psp_user_id',
						'value' => intval( $user_id ),
					),
					array(
						'key'   => 'psp_company_id',
						'value' => intval( $company_id ),
					),
				),
				'posts_per_page' => 1,
			)
		);

		if ( ! empty( $existing ) ) {
			return $existing[0]->ID;
		}

		// Get user data
		$user = get_userdata( $user_id );
		if ( ! $user ) {
			return 0;
		}

		// Create contact post
		$contact_id = wp_insert_post(
			array(
				'post_type'   => self::POST_TYPE,
				'post_status' => 'publish',
				'post_title'  => $user->display_name,
				'post_author' => get_current_user_id(),
			)
		);

		if ( is_wp_error( $contact_id ) ) {
			return 0;
		}

		// Set metadata
		update_post_meta( $contact_id, 'psp_user_id', intval( $user_id ) );
		update_post_meta( $contact_id, 'psp_company_id', intval( $company_id ) );
		update_post_meta( $contact_id, 'psp_email', sanitize_email( $user->user_email ) );
		update_post_meta( $contact_id, 'psp_source', sanitize_text_field( $source ) );
		update_post_meta( $contact_id, 'psp_date_added', current_time( 'mysql' ) );

		return $contact_id;
	}

	/**
	 * Get all contacts for a company
	 *
	 * @param int $company_id Company post ID
	 * @return array Contact posts
	 */
	public static function get_company_contacts( $company_id ) {
		return get_posts(
			array(
				'post_type'      => self::POST_TYPE,
				'posts_per_page' => -1,
				'meta_key'       => 'psp_company_id',
				'meta_value'     => intval( $company_id ),
				'orderby'        => array(
					'meta_value' => 'DESC', // Primary first
					'post_date'  => 'DESC', // Then by date
				),
			)
		);
	}

	/**
	 * Find contact by email for a company
	 *
	 * @param int $company_id Company post ID
	 * @param string $email Email address
	 * @return int|null Contact post ID or null
	 */
	public static function find_contact_by_email( $company_id, $email ) {
		$contacts = get_posts(
			array(
				'post_type'  => self::POST_TYPE,
				'meta_query' => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query
					'relation' => 'AND',
					array(
						'key'   => 'psp_company_id',
						'value' => intval( $company_id ),
					),
					array(
						'key'   => 'psp_email',
						'value' => sanitize_email( $email ),
					),
				),
				'posts_per_page' => 1,
			)
		);

		return ! empty( $contacts ) ? $contacts[0]->ID : null;
	}

	/**
	 * Add contact to company
	 *
	 * @param int $company_id Company post ID
	 * @param array $contact_data Contact information
	 * @return int Contact post ID
	 */
	public static function add_contact_to_company( $company_id, $contact_data ) {
		$contact_id = wp_insert_post(
			array(
				'post_type'   => self::POST_TYPE,
				'post_status' => 'publish',
				'post_title'  => sanitize_text_field( $contact_data['name'] ?? 'Unknown' ),
				'post_author' => get_current_user_id(),
			)
		);

		if ( is_wp_error( $contact_id ) ) {
			return 0;
		}

		// Set metadata
		update_post_meta( $contact_id, 'psp_company_id', intval( $company_id ) );
		update_post_meta( $contact_id, 'psp_email', sanitize_email( $contact_data['email'] ?? '' ) );
		update_post_meta( $contact_id, 'psp_phone', sanitize_text_field( $contact_data['phone'] ?? '' ) );
		update_post_meta( $contact_id, 'psp_role', sanitize_text_field( $contact_data['role'] ?? '' ) );
		update_post_meta( $contact_id, 'psp_is_primary', isset( $contact_data['is_primary'] ) ? (bool) $contact_data['is_primary'] : false );
		update_post_meta( $contact_id, 'psp_source', 'manual' );
		update_post_meta( $contact_id, 'psp_date_added', current_time( 'mysql' ) );

		// Link WordPress user if exists
		if ( ! empty( $contact_data['user_id'] ) ) {
			update_post_meta( $contact_id, 'psp_user_id', intval( $contact_data['user_id'] ) );
		}

		return $contact_id;
	}
}

// Initialize on WordPress init hook
Contacts::init();
