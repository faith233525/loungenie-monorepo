<?php
/**
 * PoolSafe Portal - Training Videos Custom Post Type
 *
 * Manages training video content with visibility controls for partners,
 * support staff, and administrators.
 *
 * @package PoolSafe_Portal
 * @subpackage Training_Videos
 * @version 1.3.0
 */

namespace PSP;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Training_Videos
 *
 * Handles the custom post type registration, metadata management,
 * and visibility filtering for training videos.
 */
class Training_Videos {

	/**
	 * Custom post type name
	 *
	 * @var string
	 */
	const POST_TYPE = 'psp_training_video';

	/**
	 * Custom post type slug
	 *
	 * @var string
	 */
	const POST_TYPE_SLUG = 'training-videos';

	/**
	 * Meta key for video URL
	 *
	 * @var string
	 */
	const META_VIDEO_URL = 'psp_video_url';

	/**
	 * Meta key for video thumbnail
	 *
	 * @var string
	 */
	const META_THUMBNAIL_URL = 'psp_video_thumbnail';

	/**
	 * Meta key for visibility type
	 *
	 * @var string
	 */
	const META_VISIBILITY_TYPE = 'psp_visibility_type';

	/**
	 * Meta key for visibility value
	 *
	 * @var string
	 */
	const META_VISIBILITY_VALUE = 'psp_visibility_value';

	/**
	 * Meta key for video duration (in seconds)
	 *
	 * @var string
	 */
	const META_DURATION = 'psp_video_duration';

	/**
	 * Meta key for upload date
	 *
	 * @var string
	 */
	const META_UPLOAD_DATE = 'psp_video_upload_date';

	/**
	 * Visibility types
	 *
	 * @var array
	 */
	public static $visibility_types = array(
		'all'                 => 'All Users',
		'property'            => 'Specific Property',
		'management_company'  => 'Management Company',
		'role'                => 'Specific Role',
	);

	/**
	 * Initialize the class and register hooks
	 */
	public function __construct() {
		add_action( 'init', array( $this, 'register_post_type' ) );
		add_action( 'init', array( $this, 'register_meta_fields' ) );
		add_action( 'rest_insert_' . self::POST_TYPE, array( $this, 'handle_rest_insert' ), 10, 2 );
		add_filter( 'rest_' . self::POST_TYPE . '_query', array( $this, 'filter_rest_query' ), 10, 2 );
	}

	/**
	 * Register the custom post type
	 */
	public function register_post_type() {
		$args = array(
			'labels'              => array(
				'name'          => 'Training Videos',
				'singular_name' => 'Training Video',
				'add_new_item'  => 'Add New Training Video',
				'edit_item'     => 'Edit Training Video',
			),
			'public'              => true,
			'publicly_queryable'  => false,
			'show_in_rest'        => true,
			'rest_base'           => 'training-videos',
			'rest_controller_class' => 'WP_REST_Posts_Controller',
			'has_archive'         => false,
			'hierarchical'        => false,
			'supports'            => array( 'title', 'editor', 'custom-fields' ),
		'capability_type'     => array( 'psp_training_video', 'psp_training_videos' ),
		'map_meta_cap'        => false,
		'menu_icon'           => 'dashicons-video-alt3',
			'show_in_menu'        => 'pool-safe-portal',
			'menu_position'       => 11,
		);

		register_post_type( self::POST_TYPE, $args );
	}

	/**
	 * Register post meta fields for REST API and direct access
	 */
	public function register_meta_fields() {
		$meta_fields = array(
			self::META_VIDEO_URL     => array(
				'type'       => 'string',
				'description' => 'URL to the training video (mp4, YouTube, or Vimeo)',
				'single'     => true,
				'show_in_rest' => true,
			),
			self::META_THUMBNAIL_URL => array(
				'type'       => 'string',
				'description' => 'URL to the video thumbnail image',
				'single'     => true,
				'show_in_rest' => true,
			),
			self::META_VISIBILITY_TYPE => array(
				'type'       => 'string',
				'description' => 'Type of visibility control (all, property, management_company, role)',
				'single'     => true,
				'show_in_rest' => true,
			),
			self::META_VISIBILITY_VALUE => array(
				'type'       => 'string',
				'description' => 'Value for visibility control (partner_id, company_id, or role name)',
				'single'     => true,
				'show_in_rest' => true,
			),
			self::META_DURATION => array(
				'type'       => 'number',
				'description' => 'Video duration in seconds',
				'single'     => true,
				'show_in_rest' => true,
			),
			self::META_UPLOAD_DATE => array(
				'type'       => 'string',
				'description' => 'Video upload date (ISO 8601 format)',
				'single'     => true,
				'show_in_rest' => true,
			),
		);

		foreach ( $meta_fields as $key => $args ) {
			register_meta( 'post', $key, $args );
		}
	}

	/**
	 * Handle REST API insert operations
	 *
	 * @param \WP_Post $post     The post object.
	 * @param \WP_REST_Request $request The request object.
	 */
	public function handle_rest_insert( $post, $request ) {
		$params = $request->get_json_params();

		if ( ! empty( $params['psp_video_upload_date'] ) ) {
			update_post_meta( $post->ID, self::META_UPLOAD_DATE, sanitize_text_field( $params['psp_video_upload_date'] ) );
		}
	}

	/**
	 * Filter REST query based on current user's visibility permissions
	 *
	 * @param array $prepared_args Query arguments.
	 * @param \WP_REST_Request $request The request object.
	 * @return array Modified query arguments.
	 */
	public function filter_rest_query( $prepared_args, $request ) {
		// Get current user
		$user = wp_get_current_user();
		if ( ! $user->ID ) {
			// Not logged in - no videos
			$prepared_args['post__in'] = array( 0 );
			return $prepared_args;
		}

		// Admin and support staff see all videos
		if ( in_array( 'administrator', (array) $user->roles, true ) || in_array( 'pool_safe_support', (array) $user->roles, true ) ) {
			return $prepared_args;
		}

		// Partners see only their videos
		if ( in_array( 'pool_safe_partner', (array) $user->roles, true ) ) {
			return $this->filter_partner_videos( $prepared_args, $user->ID );
		}

		// Other users see only 'all' visibility videos
		$prepared_args['meta_query'] = array(
			array(
				'key'   => self::META_VISIBILITY_TYPE,
				'value' => 'all',
			),
		);

		return $prepared_args;
	}

	/**
	 * Filter videos visible to a specific partner
	 *
	 * @param array $prepared_args Query arguments.
	 * @param int $user_id User ID.
	 * @return array Modified query arguments.
	 */
	private function filter_partner_videos( $prepared_args, $user_id ) {
		// Get partner ID from user meta
		$partner_id = get_user_meta( $user_id, 'psp_partner_id', true );

		if ( ! $partner_id ) {
			// User has no partner assigned - see only 'all' videos
			$prepared_args['meta_query'] = array(
				array(
					'key'   => self::META_VISIBILITY_TYPE,
					'value' => 'all',
				),
			);
			return $prepared_args;
		}

		// Get partner details
		$partner_post = get_post( $partner_id );
		if ( ! $partner_post ) {
			$prepared_args['post__in'] = array( 0 );
			return $prepared_args;
		}

		// Get partner's management company ID
		$management_company_id = get_post_meta( $partner_id, 'psp_management_company_id', true );

		// Build meta query for visible videos
		$meta_query = array(
			'relation' => 'OR',
			// All users can see
			array(
				'key'   => self::META_VISIBILITY_TYPE,
				'value' => 'all',
			),
			// Specific property
			array(
				'relation' => 'AND',
				array(
					'key'   => self::META_VISIBILITY_TYPE,
					'value' => 'property',
				),
				array(
					'key'   => self::META_VISIBILITY_VALUE,
					'value' => (string) $partner_id,
				),
			),
		);

		// Add management company filter if exists
		if ( $management_company_id ) {
			$meta_query[] = array(
				'relation' => 'AND',
				array(
					'key'   => self::META_VISIBILITY_TYPE,
					'value' => 'management_company',
				),
				array(
					'key'   => self::META_VISIBILITY_VALUE,
					'value' => (string) $management_company_id,
				),
			);
		}

		$prepared_args['meta_query'] = $meta_query;

		return $prepared_args;
	}

	/**
	 * Create a new training video
	 *
	 * @param array $args Arguments for post creation.
	 * @return int|bool Post ID on success, false on failure.
	 */
	public static function create( $args ) {
		$defaults = array(
			'post_type'   => self::POST_TYPE,
			'post_status' => 'publish',
			'post_title'  => '',
			'post_content' => '',
		);

		$args = wp_parse_args( $args, $defaults );

		// Create post
		$post_id = wp_insert_post( $args );
		if ( is_wp_error( $post_id ) ) {
			return false;
		}

		return $post_id;
	}

	/**
	 * Get video by ID with full metadata
	 *
	 * @param int $post_id Post ID.
	 * @return array|bool Video data or false if not found.
	 */
	public static function get( $post_id ) {
		$post = get_post( $post_id );
		if ( ! $post || self::POST_TYPE !== $post->post_type ) {
			return false;
		}

		return array(
			'id'                => $post->ID,
			'title'             => $post->post_title,
			'description'       => $post->post_content,
			'video_url'         => get_post_meta( $post->ID, self::META_VIDEO_URL, true ),
			'thumbnail'         => get_post_meta( $post->ID, self::META_THUMBNAIL_URL, true ),
			'visibility_type'   => get_post_meta( $post->ID, self::META_VISIBILITY_TYPE, true ),
			'visibility_value'  => get_post_meta( $post->ID, self::META_VISIBILITY_VALUE, true ),
			'duration'          => get_post_meta( $post->ID, self::META_DURATION, true ),
			'upload_date'       => get_post_meta( $post->ID, self::META_UPLOAD_DATE, true ),
			'date_created'      => $post->post_date,
			'date_modified'     => $post->post_modified,
		);
	}

	/**
	 * Update training video
	 *
	 * @param int $post_id Post ID.
	 * @param array $args Update arguments.
	 * @return bool True on success, false on failure.
	 */
	public static function update( $post_id, $args ) {
		$post = get_post( $post_id );
		if ( ! $post || self::POST_TYPE !== $post->post_type ) {
			return false;
		}

		// Update post data
		if ( ! empty( $args['title'] ) ) {
			wp_update_post(
				array(
					'ID'           => $post_id,
					'post_title'   => sanitize_text_field( $args['title'] ),
				)
			);
		}

		if ( ! empty( $args['description'] ) ) {
			wp_update_post(
				array(
					'ID'           => $post_id,
					'post_content' => wp_kses_post( $args['description'] ),
				)
			);
		}

		// Update meta fields
		if ( isset( $args['video_url'] ) ) {
			update_post_meta( $post_id, self::META_VIDEO_URL, sanitize_url( $args['video_url'] ) );
		}

		if ( isset( $args['thumbnail'] ) ) {
			update_post_meta( $post_id, self::META_THUMBNAIL_URL, sanitize_url( $args['thumbnail'] ) );
		}

		if ( isset( $args['visibility_type'] ) ) {
			update_post_meta( $post_id, self::META_VISIBILITY_TYPE, sanitize_text_field( $args['visibility_type'] ) );
		}

		if ( isset( $args['visibility_value'] ) ) {
			update_post_meta( $post_id, self::META_VISIBILITY_VALUE, sanitize_text_field( $args['visibility_value'] ) );
		}

		if ( isset( $args['duration'] ) ) {
			update_post_meta( $post_id, self::META_DURATION, intval( $args['duration'] ) );
		}

		return true;
	}

	/**
	 * Delete training video
	 *
	 * @param int $post_id Post ID.
	 * @param bool $force Force delete (default: true).
	 * @return bool True on success, false on failure.
	 */
	public static function delete( $post_id, $force = true ) {
		$post = get_post( $post_id );
		if ( ! $post || self::POST_TYPE !== $post->post_type ) {
			return false;
		}

		$result = wp_delete_post( $post_id, $force );
		return false !== $result;
	}

	/**
	 * Get all training videos visible to current user
	 *
	 * @param array $args Query arguments.
	 * @return array Array of video data.
	 */
	public static function get_visible_videos( $args = array() ) {
		$defaults = array(
			'post_type'   => self::POST_TYPE,
			'numberposts' => -1,
			'orderby'     => 'date',
			'order'       => 'DESC',
		);

		$args = wp_parse_args( $args, $defaults );

		$posts = get_posts( $args );
		$videos = array();

		foreach ( $posts as $post ) {
			$videos[] = self::get( $post->ID );
		}

		return $videos;
	}

	/**
	 * Check if current user can view a specific video
	 *
	 * @param int $post_id Post ID.
	 * @param int $user_id User ID (defaults to current user).
	 * @return bool True if user can view video, false otherwise.
	 */
	public static function user_can_view( $post_id, $user_id = 0 ) {
		if ( ! $user_id ) {
			$user_id = get_current_user_id();
		}

		if ( ! $user_id ) {
			return false;
		}

		$user = get_user_by( 'id', $user_id );
		if ( ! $user ) {
			return false;
		}

		// Admins and support staff can view all
		if ( in_array( 'administrator', (array) $user->roles, true ) || in_array( 'pool_safe_support', (array) $user->roles, true ) ) {
			return true;
		}

		// Get video
		$video = self::get( $post_id );
		if ( ! $video ) {
			return false;
		}

		$visibility_type = $video['visibility_type'];

		// All users can see
		if ( 'all' === $visibility_type ) {
			return true;
		}

		// Partners with specific visibility
		if ( in_array( 'pool_safe_partner', (array) $user->roles, true ) ) {
			$partner_id = get_user_meta( $user_id, 'psp_partner_id', true );

			if ( 'property' === $visibility_type && (string) $partner_id === $video['visibility_value'] ) {
				return true;
			}

			if ( 'management_company' === $visibility_type ) {
				$management_company_id = get_post_meta( $partner_id, 'psp_management_company_id', true );
				if ( (string) $management_company_id === $video['visibility_value'] ) {
					return true;
				}
			}

			if ( 'role' === $visibility_type && $video['visibility_value'] === 'pool_safe_partner' ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Format video duration for display
	 *
	 * @param int $seconds Duration in seconds.
	 * @return string Formatted duration (e.g., "5:32" or "1:23:45").
	 */
	public static function format_duration( $seconds ) {
		if ( ! $seconds ) {
			return '';
		}

		$seconds = intval( $seconds );
		$hours   = intdiv( $seconds, 3600 );
		$minutes = intdiv( $seconds % 3600, 60 );
		$secs    = $seconds % 60;

		if ( $hours > 0 ) {
			return sprintf( '%d:%02d:%02d', $hours, $minutes, $secs );
		} else {
			return sprintf( '%d:%02d', $minutes, $secs );
		}
	}

	/**
	 * Get video embed code for display
	 *
	 * @param string $video_url URL to the video.
	 * @return string HTML embed code.
	 */
	public static function get_embed_code( $video_url ) {
		if ( ! $video_url ) {
			return '';
		}

		// Check if YouTube URL
		if ( preg_match( '%(?:youtube(?:-nocookie)?\.com/(?:[^/]+/.+/|(?:v|e(?:mbed)?)/|.*[?&]v=)|youtu\.be/)([^"&?\s]{11})%i', $video_url, $match ) ) {
			$youtube_id = $match[1];
			return sprintf(
				'<iframe width="100%%" height="600" src="https://www.youtube.com/embed/%s" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>',
				esc_attr( $youtube_id )
			);
		}

		// Check if Vimeo URL
		if ( preg_match( '%vimeo\.com/(\d+)%i', $video_url, $match ) ) {
			$vimeo_id = $match[1];
			return sprintf(
				'<iframe src="https://player.vimeo.com/video/%s" width="100%%" height="600" frameborder="0" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen></iframe>',
				esc_attr( $vimeo_id )
			);
		}

		// Assume direct MP4 URL
		return sprintf(
			'<video width="100%%" height="600" controls style="background-color: #000;"><source src="%s" type="video/mp4">Your browser does not support the video tag.</video>',
			esc_url( $video_url )
		);
	}
}

// Initialize the class
new Training_Videos();
