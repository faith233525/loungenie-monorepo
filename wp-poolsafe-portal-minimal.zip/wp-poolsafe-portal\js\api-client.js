/**
 * PoolSafe Portal - Unified API Client
 * File: js/api-client.js
 * 
 * Centralized wrapper for all /wp-json/psp/v1 API calls
 * Handles error handling, nonce management, loading states
 * 
 * @package PoolSafe_Portal
 * @since 3.0.0
 */

class PSPApiClient {
    constructor(nonce) {
        this.baseUrl = '/wp-json/psp/v1';
        this.nonce = nonce || '';
        this.timeout = 30000; // 30 second timeout
        this.loadingCallbacks = [];
        this.cacheTTL = 120000; // 2 minutes
        this.cachePrefix = 'psp_cache_v1_';
    }

    /**
     * Set nonce for authenticated requests
     */
    setNonce(nonce) {
        this.nonce = nonce;
    }

    /**
     * Register callback for loading state changes
     */
    onLoadingStateChange(callback) {
        this.loadingCallbacks.push(callback);
    }

    /**
     * Emit loading state to all registered callbacks
     */
    _emitLoadingState(isLoading, message = '') {
        this.loadingCallbacks.forEach(cb => cb(isLoading, message));
    }

    /**
     * Build request headers
     */
    _getHeaders(additionalHeaders = {}) {
        return {
            'Content-Type': 'application/json',
            'X-WP-Nonce': this.nonce,
            ...additionalHeaders
        };
    }

    /**
     * Make API request with error handling
     */
    async _request(method, endpoint, data = null) {
        const url = this.baseUrl + endpoint;
        const options = {
            method,
            headers: this._getHeaders(),
            timeout: this.timeout
        };

        if (data && (method === 'POST' || method === 'PUT')) {
            options.body = JSON.stringify(data);
        }

        const isGet = method === 'GET';
        const cacheKey = isGet ? this._cacheKey(endpoint) : null;
        const now = Date.now();

        // Try cache for GET requests
        if (isGet && cacheKey) {
            const cached = this._readCache(cacheKey, now);
            if (cached) {
                this._emitLoadingState(false);
                this._logPerformance({ endpoint, method, duration: 0, payloadSize: JSON.stringify(cached.payload || {}).length, cached: true });
                return cached.payload;
            }
        }

        const start = performance.now();
        try {
            this._emitLoadingState(true, `${method} ${endpoint}`);

            const response = await Promise.race([
                fetch(url, options),
                new Promise((_, reject) =>
                    setTimeout(() => reject(new Error('Request timeout')), this.timeout)
                )
            ]);

            const result = await response.json();
            const duration = performance.now() - start;
            const payloadSize = JSON.stringify(result || {}).length;

            if (!response.ok) {
                throw {
                    status: response.status,
                    message: result.message || `HTTP ${response.status}`,
                    code: result.code || 'HTTP_ERROR'
                };
            }

            if (!result.success) {
                throw {
                    status: result.status || 400,
                    message: result.message || 'Request failed',
                    code: result.code || 'API_ERROR'
                };
            }

            this._emitLoadingState(false);

            // Cache successful GET responses (size < ~500KB)
            if (isGet && cacheKey && payloadSize < 500000) {
                this._writeCache(cacheKey, result, now);
            }

            this._logPerformance({ endpoint, method, duration, payloadSize });

            return result;

        } catch (error) {
            this._emitLoadingState(false);
            this._logPerformance({ endpoint, method, duration: performance.now() - start, error: error.message });
            throw {
                status: error.status || 0,
                message: error.message || 'Network error',
                code: error.code || 'NETWORK_ERROR'
            };
        }
    }

    _cacheKey(endpoint) {
        return `${this.cachePrefix}${endpoint}`;
    }

    _readCache(key, now) {
        try {
            const raw = sessionStorage.getItem(key);
            if (!raw) return null;
            const parsed = JSON.parse(raw);
            if (!parsed.timestamp || !parsed.payload) return null;
            if (now - parsed.timestamp > this.cacheTTL) {
                sessionStorage.removeItem(key);
                return null;
            }
            return parsed;
        } catch (e) {
            return null;
        }
    }

    _writeCache(key, payload, now) {
        try {
            const record = { timestamp: now, payload };
            sessionStorage.setItem(key, JSON.stringify(record));
        } catch (e) {
            // Ignore storage failures (quota, privacy mode)
        }
    }

    _logPerformance(entry) {
        const { endpoint, method, duration = 0, payloadSize = 0, error = null, cached = false } = entry;
        const slow = (!cached && (duration > 1000 || payloadSize > 200000));
        const record = {
            endpoint,
            method,
            duration: Number(duration.toFixed ? duration.toFixed(2) : duration),
            payloadSize,
            error,
            ts: new Date().toISOString(),
            cached
        };

        try {
            const existing = JSON.parse(sessionStorage.getItem('psp_perf_log') || '[]');
            existing.unshift(record);
            const trimmed = existing.slice(0, 20);
            sessionStorage.setItem('psp_perf_log', JSON.stringify(trimmed));
        } catch (e) {
            // ignore
        }

        if (slow) {
            console.warn('[PSP PERF]', method, endpoint, `${duration.toFixed(2)}ms`, `${(payloadSize / 1024).toFixed(1)}KB`, error ? `Error: ${error}` : '');
        }
    }

    /**
     * Health check
     */
    async health() {
        return this._request('GET', '/health');
    }

    /**
     * Authentication
     */
    async login(email, password) {
        return this._request('POST', '/auth/login', { email, password });
    }

    async logout() {
        return this._request('POST', '/auth/logout');
    }

    /**
     * Companies
     */
    async getCompanies(page = 1, perPage = 20, filters = {}) {
        let url = `/companies?page=${page}&per_page=${perPage}`;

        if (filters.status) url += `&status=${filters.status}`;
        if (filters.search) url += `&search=${encodeURIComponent(filters.search)}`;
        if (filters.type) url += `&type=${filters.type}`;

        return this._request('GET', url);
    }

    async getCompany(id) {
        return this._request('GET', `/companies/${id}`);
    }

    async createCompany(data) {
        return this._request('POST', '/companies', data);
    }

    async updateCompany(id, data) {
        return this._request('PUT', `/companies/${id}`, data);
    }

    async deleteCompany(id) {
        return this._request('DELETE', `/companies/${id}`);
    }

    /**
     * Tickets
     */
    async getTickets(page = 1, perPage = 20, filters = {}) {
        let url = `/tickets?page=${page}&per_page=${perPage}`;

        if (filters.status) url += `&status=${filters.status}`;
        if (filters.priority) url += `&priority=${filters.priority}`;
        if (filters.company_id) url += `&company_id=${filters.company_id}`;
        if (filters.assigned_to) url += `&assigned_to=${filters.assigned_to}`;
        if (filters.search) url += `&search=${encodeURIComponent(filters.search)}`;

        return this._request('GET', url);
    }

    async getTicket(id) {
        return this._request('GET', `/tickets/${id}`);
    }

    async createTicket(data) {
        return this._request('POST', '/tickets', data);
    }

    async updateTicket(id, data) {
        return this._request('PUT', `/tickets/${id}`, data);
    }

    /**
     * Operations
     */
    async getOperations(page = 1, perPage = 20, filters = {}) {
        let url = `/operations?page=${page}&per_page=${perPage}`;

        if (filters.status) url += `&status=${filters.status}`;
        if (filters.company_id) url += `&company_id=${filters.company_id}`;
        if (filters.from_date) url += `&from_date=${filters.from_date}`;
        if (filters.to_date) url += `&to_date=${filters.to_date}`;

        return this._request('GET', url);
    }

    async createOperation(data) {
        return this._request('POST', '/operations', data);
    }

    /**
     * Contacts
     */
    async getContacts(companyId, page = 1, perPage = 50) {
        return this._request('GET', `/contacts?company_id=${companyId}&page=${page}&per_page=${perPage}`);
    }

    async createContact(data) {
        return this._request('POST', '/contacts', data);
    }

    async updateContact(id, data) {
        return this._request('PUT', `/contacts/${id}`, data);
    }

    /**
     * Statistics
     */
    async getStats(filters = {}) {
        let url = '/stats';

        if (filters.from_date) url += `?from_date=${filters.from_date}`;
        if (filters.to_date) url += (url.includes('?') ? '&' : '?') + `to_date=${filters.to_date}`;

        return this._request('GET', url);
    }

    /**
     * Activity Log
     */
    async getActivity(page = 1, perPage = 50, filters = {}) {
        let url = `/activity?page=${page}&per_page=${perPage}`;

        if (filters.type) url += `&type=${filters.type}`;
        if (filters.user_id) url += `&user_id=${filters.user_id}`;
        if (filters.from_date) url += `&from_date=${filters.from_date}`;

        return this._request('GET', url);
    }

    /**
     * Bulk Operations
     */
    async bulkExport(type = 'companies', format = 'csv') {
        return this._request('GET', `/export?type=${type}&format=${format}`);
    }

    async bulkImport(type = 'companies', file) {
        const formData = new FormData();
        formData.append('file', file);
        formData.append('type', type);

        const options = {
            method: 'POST',
            headers: {
                'X-WP-Nonce': this.nonce
            },
            body: formData,
            timeout: this.timeout
        };

        try {
            this._emitLoadingState(true, `Importing ${type}`);
            const response = await fetch(this.baseUrl + '/import', options);
            const result = await response.json();

            if (!response.ok || !result.success) {
                throw {
                    status: response.status,
                    message: result.message || 'Import failed',
                    code: result.code || 'IMPORT_ERROR'
                };
            }

            this._emitLoadingState(false);
            return result;

        } catch (error) {
            this._emitLoadingState(false);
            throw error;
        }
    }
}

/**
 * UI Helper Functions
 */

const PSPUIHelpers = {
    /**
     * Show loading spinner
     */
    showLoading(message = 'Loading...') {
        const spinner = document.getElementById('psp-spinner') || this._createSpinner();
        spinner.querySelector('.psp-spinner-text').textContent = message;
        spinner.style.display = 'flex';
    },

    /**
     * Hide loading spinner
     */
    hideLoading() {
        const spinner = document.getElementById('psp-spinner');
        if (spinner) spinner.style.display = 'none';
    },

    /**
     * Create spinner element
     */
    _createSpinner() {
        const spinner = document.createElement('div');
        spinner.id = 'psp-spinner';
        spinner.innerHTML = `
            <div style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.2); z-index: 9999; display: flex; align-items: center; justify-content: center;">
                <div style="background: white; padding: 30px; border-radius: 8px; text-align: center;">
                    <div class="psp-spinner-icon" style="width: 40px; height: 40px; border: 4px solid #ddd; border-top: 4px solid #007cba; border-radius: 50%; animation: spin 1s linear infinite; margin: 0 auto 15px;"></div>
                    <p class="psp-spinner-text" style="margin: 0; color: #666;">Loading...</p>
                </div>
            </div>
            <style>
                @keyframes spin { to { transform: rotate(360deg); } }
            </style>
        `;
        document.body.appendChild(spinner);
        return spinner;
    },

    /**
     * Show error message
     */
    showError(message, duration = 5000) {
        this._showAlert('error', message, duration);
    },

    /**
     * Show success message
     */
    showSuccess(message, duration = 3000) {
        this._showAlert('success', message, duration);
    },

    /**
     * Show info message
     */
    showInfo(message, duration = 4000) {
        this._showAlert('info', message, duration);
    },

    /**
     * Show alert
     */
    _showAlert(type, message, duration) {
        const alert = document.createElement('div');
        alert.className = `alert alert-${type}`;
        alert.innerHTML = `
            <div style="position: fixed; top: 20px; right: 20px; max-width: 400px; padding: 16px; background: var(--psp-${type === 'success' ? 'success' : type === 'error' ? 'danger' : 'info'}); color: white; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.15); z-index: 10000; display: flex; justify-content: space-between; align-items: center;">
                <span>${message}</span>
                <button onclick="this.parentElement.remove()" style="background: none; border: none; color: white; font-size: 20px; cursor: pointer;">✕</button>
            </div>
        `;
        document.body.appendChild(alert.firstElementChild);

        if (duration > 0) {
            setTimeout(() => alert.firstElementChild?.remove(), duration);
        }
    },

    /**
     * Format date
     */
    formatDate(date) {
        return new Date(date).toLocaleDateString();
    },

    /**
     * Format datetime
     */
    formatDateTime(date) {
        return new Date(date).toLocaleString();
    },

    /**
     * Format currency
     */
    formatCurrency(amount) {
        return new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD'
        }).format(amount);
    }
};

// Initialize API client when DOM is ready
let pspApi = null;

document.addEventListener('DOMContentLoaded', function () {
    const nonce = document.querySelector('[data-nonce]')?.dataset.nonce || '';
    pspApi = new PSPApiClient(nonce);

    // Connect loading state to UI
    pspApi.onLoadingStateChange((isLoading, message) => {
        if (isLoading) {
            PSPUIHelpers.showLoading(message);
        } else {
            PSPUIHelpers.hideLoading();
        }
    });
});
