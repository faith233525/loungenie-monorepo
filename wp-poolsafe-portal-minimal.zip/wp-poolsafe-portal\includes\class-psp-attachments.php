<?php
/**
 * Attachment Handler
 *
 * @link       https://poolsafe.com
 * @since      1.0.0
 *
 * @package    PoolSafe_Portal
 * @subpackage PoolSafe_Portal/includes
 */

/**
 * Handle file attachments for tickets, ticket replies, and service records
 *
 * @since      1.0.0
 * @package    PoolSafe_Portal
 */
class PSP_Attachments {

	/**
	 * Allowed file extensions
	 *
	 * @var array
	 */
	private static $allowed_extensions = array( 'pdf', 'doc', 'docx', 'xls', 'xlsx', 'jpg', 'jpeg', 'png', 'gif', 'zip', 'txt' );

	/**
	 * Maximum file size in MB
	 *
	 * @var int
	 */
	private static $max_file_size = 10;

	/**
	 * Get upload directory path
	 *
	 * @return string
	 */
	public static function get_upload_dir() {
		$upload_dir = wp_upload_dir();
		$psp_dir    = $upload_dir['basedir'] . '/poolsafe-attachments';

		if ( ! is_dir( $psp_dir ) ) {
			wp_mkdir_p( $psp_dir );
		}

		return $psp_dir;
	}

	/**
	 * Upload a file attachment
	 *
	 * @param array $file The $_FILES array entry
	 * @param int   $ticket_id Optional. Ticket ID
	 * @param int   $ticket_reply_id Optional. Ticket reply ID
	 * @param int   $service_record_id Optional. Service record ID
	 * @return array|WP_Error File attachment data or error
	 */
	public static function upload( $file, $ticket_id = null, $ticket_reply_id = null, $service_record_id = null ) {
		global $wpdb;

		// Validate file exists
		if ( ! isset( $file['name'] ) || ! isset( $file['tmp_name'] ) ) {
			return new WP_Error( 'missing_file', __( 'File not provided.', 'poolsafe-portal' ) );
		}

		// Validate file size
		$file_size_mb = filesize( $file['tmp_name'] ) / ( 1024 * 1024 );
		if ( $file_size_mb > self::$max_file_size ) {
			return new WP_Error( 'file_too_large', sprintf( __( 'File size exceeds %d MB limit.', 'poolsafe-portal' ), self::$max_file_size ) );
		}

		// Validate file type
		$file_ext = strtolower( pathinfo( $file['name'], PATHINFO_EXTENSION ) );
		if ( ! in_array( $file_ext, self::$allowed_extensions, true ) ) {
			return new WP_Error( 'invalid_file_type', sprintf( __( 'File type .%s not allowed.', 'poolsafe-portal' ), esc_html( $file_ext ) ) );
		}

		// Get current user
		$current_user = PSP_Auth::get_current_user();
		if ( ! $current_user ) {
			return new WP_Error( 'not_logged_in', __( 'User not logged in.', 'poolsafe-portal' ) );
		}

		// Generate unique filename
		$file_name     = sanitize_file_name( $file['name'] );
		$file_name_arr = explode( '.', $file_name );
		$file_ext_from = array_pop( $file_name_arr );
		$file_base     = implode( '.', $file_name_arr );
		$file_new_name = $file_base . '-' . time() . '-' . wp_rand( 100, 999 ) . '.' . $file_ext_from;

		// Move file to uploads directory
		$upload_dir  = self::get_upload_dir();
		$upload_path = $upload_dir . '/' . $file_new_name;

		if ( ! move_uploaded_file( $file['tmp_name'], $upload_path ) ) {
			return new WP_Error( 'upload_failed', __( 'Failed to upload file.', 'poolsafe-portal' ) );
		}

		// Store attachment in database
		$inserted = $wpdb->insert(
			$wpdb->prefix . 'psp_attachments',
			array(
				'ticket_id'           => $ticket_id,
				'ticket_reply_id'     => $ticket_reply_id,
				'service_record_id'   => $service_record_id,
				'uploaded_by_user_id' => $current_user->id,
				'file_name'           => $file_name,
				'file_path'           => $file_new_name,
				'file_type'           => $file_ext,
				'file_size'           => filesize( $upload_path ),
				'mime_type'           => wp_check_filetype( $file_name )['type'],
			)
		);

		if ( ! $inserted ) {
			@unlink( $upload_path );
			return new WP_Error( 'db_error', __( 'Failed to save attachment record.', 'poolsafe-portal' ) );
		}

		return array(
			'id'        => $wpdb->insert_id,
			'name'      => $file_name,
			'path'      => $file_new_name,
			'size'      => filesize( $upload_path ),
			'mime_type' => wp_check_filetype( $file_name )['type'],
		);
	}

	/**
	 * Get attachments for a ticket
	 *
	 * @param int $ticket_id Ticket ID
	 * @return array
	 */
	public static function get_by_ticket( $ticket_id ) {
		global $wpdb;

		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}psp_attachments WHERE ticket_id = %d ORDER BY created_at DESC",
				$ticket_id
			)
		);
	}

	/**
	 * Get attachments for a ticket reply
	 *
	 * @param int $ticket_reply_id Ticket reply ID
	 * @return array
	 */
	public static function get_by_ticket_reply( $ticket_reply_id ) {
		global $wpdb;

		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}psp_attachments WHERE ticket_reply_id = %d ORDER BY created_at DESC",
				$ticket_reply_id
			)
		);
	}

	/**
	 * Get attachments for a service record
	 *
	 * @param int $service_record_id Service record ID
	 * @return array
	 */
	public static function get_by_service_record( $service_record_id ) {
		global $wpdb;

		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}psp_attachments WHERE service_record_id = %d ORDER BY created_at DESC",
				$service_record_id
			)
		);
	}

	/**
	 * Get attachment by ID
	 *
	 * @param int $attachment_id Attachment ID
	 * @return object|null
	 */
	public static function get( $attachment_id ) {
		global $wpdb;

		return $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}psp_attachments WHERE id = %d",
				$attachment_id
			)
		);
	}

	/**
	 * Download attachment
	 *
	 * @param int $attachment_id Attachment ID
	 * @return bool|WP_Error
	 */
	public static function download( $attachment_id ) {
		global $wpdb;

		$attachment = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}psp_attachments WHERE id = %d",
				$attachment_id
			)
		);

		if ( ! $attachment ) {
			return new WP_Error( 'not_found', __( 'Attachment not found.', 'poolsafe-portal' ) );
		}

		$upload_dir = self::get_upload_dir();
		$file_path  = $upload_dir . '/' . $attachment->file_path;

		if ( ! file_exists( $file_path ) ) {
			return new WP_Error( 'file_not_found', __( 'File not found on server.', 'poolsafe-portal' ) );
		}

		// Increment download count
		$wpdb->update(
			$wpdb->prefix . 'psp_attachments',
			array( 'download_count' => $attachment->download_count + 1 ),
			array( 'id' => $attachment_id )
		);

		return $file_path;
	}

	/**
	 * Delete attachment
	 *
	 * @param int $attachment_id Attachment ID
	 * @return bool|WP_Error
	 */
	public static function delete( $attachment_id ) {
		global $wpdb;

		$attachment = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}psp_attachments WHERE id = %d",
				$attachment_id
			)
		);

		if ( ! $attachment ) {
			return new WP_Error( 'not_found', __( 'Attachment not found.', 'poolsafe-portal' ) );
		}

		$upload_dir = self::get_upload_dir();
		$file_path  = $upload_dir . '/' . $attachment->file_path;

		if ( file_exists( $file_path ) ) {
			@unlink( $file_path );
		}

		$deleted = $wpdb->delete(
			$wpdb->prefix . 'psp_attachments',
			array( 'id' => $attachment_id )
		);

		return $deleted ? true : new WP_Error( 'delete_failed', __( 'Failed to delete attachment.', 'poolsafe-portal' ) );
	}

	/**
	 * Get allowed file extensions
	 *
	 * @return array
	 */
	public static function get_allowed_extensions() {
		return self::$allowed_extensions;
	}

	/**
	 * Get max file size in MB
	 *
	 * @return int
	 */
	public static function get_max_file_size() {
		return self::$max_file_size;
	}
}
