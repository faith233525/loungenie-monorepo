<?php
namespace PSP;

if (!defined('ABSPATH')) exit;

/**
 * Admin Interface for Company Management
 */
class Company_Admin {
    
    public static function init() {
        add_action('admin_menu', [self::class, 'add_menu']);
        add_action('rest_api_init', [self::class, 'register_routes']);
    }

    public static function add_menu() {
        add_menu_page(
            'Companies',
            'PSP Companies',
            'psp_manage_companies',
            'psp-companies',
            [self::class, 'render_page'],
            'dashicons-groups',
            30
        );

        add_submenu_page(
            'psp-companies',
            'Add Company',
            'Add New',
            'psp_manage_companies',
            'psp-company-new',
            [self::class, 'render_new_page']
        );

        add_submenu_page(
            'psp-companies',
            'Login Activity',
            'Login Activity',
            'psp_manage_companies',
            'psp-login-activity',
            [self::class, 'render_activity_page']
        );

        add_submenu_page(
            'psp-companies',
            'Settings',
            'M365 Settings',
            'manage_options',
            'psp-m365-settings',
            [self::class, 'render_settings_page']
        );
    }

    public static function register_routes() {
        register_rest_route('psp/v1', '/admin/companies', [
            'methods' => 'GET',
            'callback' => [self::class, 'get_companies'],
            'permission_callback' => function() {
                return current_user_can('psp_manage_companies');
            }
        ]);

        register_rest_route('psp/v1', '/admin/companies', [
            'methods' => 'POST',
            'callback' => [self::class, 'create_company'],
            'permission_callback' => function() {
                return current_user_can('psp_manage_companies');
            }
        ]);

        register_rest_route('psp/v1', '/admin/companies/(?P<id>\d+)', [
            'methods' => 'PUT',
            'callback' => [self::class, 'update_company'],
            'permission_callback' => function() {
                return current_user_can('psp_manage_companies');
            }
        ]);

        register_rest_route('psp/v1', '/admin/companies/(?P<id>\d+)/password', [
            'methods' => 'POST',
            'callback' => [self::class, 'reset_password'],
            'permission_callback' => function() {
                return current_user_can('psp_manage_companies');
            }
        ]);

        register_rest_route('psp/v1', '/admin/companies/(?P<id>\d+)/contacts', [
            'methods' => 'POST',
            'callback' => [self::class, 'add_contact'],
            'permission_callback' => function() {
                return current_user_can('psp_manage_companies');
            }
        ]);
    }

    public static function get_companies($request) {
        global $wpdb;
        $table = $wpdb->prefix . 'psp_companies';
        $contacts_table = $wpdb->prefix . 'psp_company_contacts';

        $companies = $wpdb->get_results("
            SELECT c.*, 
                   COUNT(ct.id) as contacts_count
            FROM $table c
            LEFT JOIN $contacts_table ct ON c.id = ct.company_id
            GROUP BY c.id
            ORDER BY c.company_name ASC
        ");

        return new \WP_REST_Response($companies, 200);
    }

    public static function create_company($request) {
        global $wpdb;
        
        $name = sanitize_text_field($request->get_param('name'));
        $username = sanitize_user($request->get_param('username'));
        $password = $request->get_param('password');
        
        // No complexity requirements - just hash it
        $password_hash = password_hash($password, PASSWORD_DEFAULT);

        $table = $wpdb->prefix . 'psp_companies';
        
        $result = $wpdb->insert($table, [
            'company_name' => $name,
            'username' => $username,
            'password_hash' => $password_hash,
            'status' => 'active',
            'created_at' => current_time('mysql')
        ]);

        if (!$result) {
            return new \WP_REST_Response([
                'error' => 'Failed to create company'
            ], 500);
        }

        $company_id = $wpdb->insert_id;

        // Add primary contact if provided
        $contact_name = sanitize_text_field($request->get_param('contact_name'));
        $contact_email = sanitize_email($request->get_param('contact_email'));
        $contact_phone = sanitize_text_field($request->get_param('contact_phone'));

        if ($contact_name && $contact_email) {
            $contacts_table = $wpdb->prefix . 'psp_company_contacts';
            $wpdb->insert($contacts_table, [
                'company_id' => $company_id,
                'name' => $contact_name,
                'email' => $contact_email,
                'phone' => $contact_phone,
                'is_primary' => 1,
                'created_at' => current_time('mysql')
            ]);
        }

        return new \WP_REST_Response([
            'success' => true,
            'id' => $company_id
        ], 201);
    }

    public static function reset_password($request) {
        global $wpdb;
        
        $id = (int) $request->get_param('id');
        $new_password = $request->get_param('password');
        
        $password_hash = password_hash($new_password, PASSWORD_DEFAULT);

        $table = $wpdb->prefix . 'psp_companies';
        $result = $wpdb->update($table, 
            ['password_hash' => $password_hash, 'updated_at' => current_time('mysql')],
            ['id' => $id],
            ['%s', '%s'],
            ['%d']
        );

        if ($result === false) {
            return new \WP_REST_Response(['error' => 'Failed to update password'], 500);
        }

        return new \WP_REST_Response(['success' => true], 200);
    }

    public static function add_contact($request) {
        global $wpdb;
        
        $company_id = (int) $request->get_param('id');
        $name = sanitize_text_field($request->get_param('name'));
        $email = sanitize_email($request->get_param('email'));
        $phone = sanitize_text_field($request->get_param('phone'));
        $is_primary = (int) $request->get_param('is_primary');

        $table = $wpdb->prefix . 'psp_company_contacts';
        
        // If setting as primary, unset others
        if ($is_primary) {
            $wpdb->update($table, ['is_primary' => 0], ['company_id' => $company_id]);
        }

        $result = $wpdb->insert($table, [
            'company_id' => $company_id,
            'name' => $name,
            'email' => $email,
            'phone' => $phone,
            'is_primary' => $is_primary,
            'created_at' => current_time('mysql')
        ]);

        if (!$result) {
            return new \WP_REST_Response(['error' => 'Failed to add contact'], 500);
        }

        return new \WP_REST_Response(['success' => true, 'id' => $wpdb->insert_id], 201);
    }

    public static function render_page() {
        ?>
        <div class="wrap">
            <h1>Manage Companies</h1>
            <div id="psp-companies-list"></div>
        </div>
        <script>
        jQuery(document).ready(function($) {
            $.get('<?php echo rest_url('psp/v1/admin/companies'); ?>', function(companies) {
                let html = '<table class="wp-list-table widefat fixed striped"><thead><tr>';
                html += '<th>Company Name</th><th>Username</th><th>Contacts</th><th>Last Login</th><th>Status</th><th>Actions</th>';
                html += '</tr></thead><tbody>';
                
                companies.forEach(function(c) {
                    html += `<tr>
                        <td><strong>${c.company_name}</strong></td>
                        <td><code>${c.username}</code></td>
                        <td>${c.contacts_count}</td>
                        <td>${c.last_login || 'Never'}</td>
                        <td>${c.status}</td>
                        <td>
                            <a href="admin.php?page=psp-company-edit&id=${c.id}" class="button">Edit</a>
                            <button class="button" onclick="resetPassword(${c.id})">Reset Password</button>
                        </td>
                    </tr>`;
                });
                
                html += '</tbody></table>';
                $('#psp-companies-list').html(html);
            });
        });

        function resetPassword(id) {
            const newPass = prompt('Enter new password for this company:');
            if (!newPass) return;

            jQuery.ajax({
                url: '<?php echo rest_url('psp/v1/admin/companies/'); ?>' + id + '/password',
                method: 'POST',
                headers: { 'X-WP-Nonce': '<?php echo wp_create_nonce('wp_rest'); ?>' },
                data: JSON.stringify({ password: newPass }),
                contentType: 'application/json',
                success: function() {
                    alert('Password updated successfully!');
                },
                error: function() {
                    alert('Failed to update password');
                }
            });
        }
        </script>
        <?php
    }

    public static function render_new_page() {
        ?>
        <div class="wrap">
            <h1>Add New Company</h1>
            <form id="new-company-form" method="post">
                <table class="form-table">
                    <tr>
                        <th><label for="company-name">Company Name</label></th>
                        <td><input type="text" id="company-name" name="name" class="regular-text" required></td>
                    </tr>
                    <tr>
                        <th><label for="username">Username</label></th>
                        <td><input type="text" id="username" name="username" class="regular-text" required></td>
                    </tr>
                    <tr>
                        <th><label for="password">Password</label></th>
                        <td>
                            <input type="text" id="password" name="password" class="regular-text" required>
                            <p class="description">Simple passwords allowed - securely hashed</p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="contact-name">Primary Contact Name</label></th>
                        <td><input type="text" id="contact-name" name="contact_name" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="contact-email">Primary Contact Email</label></th>
                        <td><input type="email" id="contact-email" name="contact_email" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th><label for="contact-phone">Primary Contact Phone</label></th>
                        <td><input type="tel" id="contact-phone" name="contact_phone" class="regular-text"></td>
                    </tr>
                </table>
                <?php submit_button('Create Company'); ?>
            </form>
        </div>
        <script>
        jQuery('#new-company-form').on('submit', function(e) {
            e.preventDefault();
            
            const formData = {
                name: jQuery('#company-name').val(),
                username: jQuery('#username').val(),
                password: jQuery('#password').val(),
                contact_name: jQuery('#contact-name').val(),
                contact_email: jQuery('#contact-email').val(),
                contact_phone: jQuery('#contact-phone').val()
            };

            jQuery.ajax({
                url: '<?php echo rest_url('psp/v1/admin/companies'); ?>',
                method: 'POST',
                headers: { 'X-WP-Nonce': '<?php echo wp_create_nonce('wp_rest'); ?>' },
                data: JSON.stringify(formData),
                contentType: 'application/json',
                success: function() {
                    alert('Company created successfully!');
                    window.location.href = 'admin.php?page=psp-companies';
                },
                error: function(xhr) {
                    alert('Failed to create company: ' + (xhr.responseJSON?.error || 'Unknown error'));
                }
            });
        });
        </script>
        <?php
    }

    public static function render_activity_page() {
        global $wpdb;
        $table = $wpdb->prefix . 'psp_login_log';
        $companies_table = $wpdb->prefix . 'psp_companies';

        $logs = $wpdb->get_results("
            SELECT l.*, c.company_name 
            FROM $table l
            LEFT JOIN $companies_table c ON l.company_id = c.id
            ORDER BY l.created_at DESC
            LIMIT 100
        ");

        ?>
        <div class="wrap">
            <h1>Login Activity</h1>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>Date/Time</th>
                        <th>Company</th>
                        <th>Result</th>
                        <th>IP Address</th>
                        <th>User Agent</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($logs as $log): ?>
                    <tr>
                        <td><?php echo esc_html($log->created_at); ?></td>
                        <td><?php echo esc_html($log->company_name ?? 'Unknown'); ?></td>
                        <td>
                            <span class="dashicons dashicons-<?php echo $log->success ? 'yes-alt' : 'dismiss'; ?>" 
                                  style="color: <?php echo $log->success ? 'green' : 'red'; ?>"></span>
                            <?php echo $log->success ? 'Success' : 'Failed'; ?>
                        </td>
                        <td><?php echo esc_html($log->ip_address); ?></td>
                        <td><?php echo esc_html(substr($log->user_agent, 0, 60)); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    public static function render_settings_page() {
        if (isset($_POST['save_m365_settings'])) {
            check_admin_referer('psp_m365_settings');
            
            update_option('psp_m365_client_id', sanitize_text_field($_POST['client_id']));
            update_option('psp_m365_client_secret', sanitize_text_field($_POST['client_secret']));
            update_option('psp_m365_tenant_id', sanitize_text_field($_POST['tenant_id']));
            
            echo '<div class="notice notice-success"><p>Settings saved!</p></div>';
        }

        $client_id = get_option('psp_m365_client_id', '');
        $client_secret = get_option('psp_m365_client_secret', '');
        $tenant_id = get_option('psp_m365_tenant_id', 'common');

        ?>
        <div class="wrap">
            <h1>Microsoft 365 SSO Settings</h1>
            <form method="post">
                <?php wp_nonce_field('psp_m365_settings'); ?>
                <table class="form-table">
                    <tr>
                        <th><label for="client-id">Application (client) ID</label></th>
                        <td>
                            <input type="text" id="client-id" name="client_id" value="<?php echo esc_attr($client_id); ?>" class="regular-text">
                            <p class="description">From Azure AD App Registration</p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="client-secret">Client Secret</label></th>
                        <td>
                            <input type="password" id="client-secret" name="client_secret" value="<?php echo esc_attr($client_secret); ?>" class="regular-text">
                            <p class="description">From Azure AD App Registration → Certificates & secrets</p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="tenant-id">Tenant ID</label></th>
                        <td>
                            <input type="text" id="tenant-id" name="tenant_id" value="<?php echo esc_attr($tenant_id); ?>" class="regular-text">
                            <p class="description">Use "common" for multi-tenant or specific tenant ID</p>
                        </td>
                    </tr>
                    <tr>
                        <th>Redirect URI</th>
                        <td>
                            <code><?php echo admin_url('admin-ajax.php?action=psp_m365_callback'); ?></code>
                            <p class="description">Add this to your Azure AD App Registration → Authentication → Redirect URIs</p>
                        </td>
                    </tr>
                </table>
                <?php submit_button('Save Settings', 'primary', 'save_m365_settings'); ?>
            </form>
        </div>
        <?php
    }
}
