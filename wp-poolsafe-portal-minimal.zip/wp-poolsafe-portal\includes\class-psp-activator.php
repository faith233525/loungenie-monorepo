<?php
/**
 * Plugin Activation Handler
 * 
 * Runs during plugin activation to:
 * - Create required database tables with proper indexes
 * - Register custom roles and capabilities
 * - Set up default options and configurations
 * - Initialize cron jobs and scheduled events
 * - Clear caches to ensure fresh data
 * 
 * Safe for shared hosting with proper error handling:
 * - Checks table existence before creation
 * - Handles existing indexes gracefully
 * - Logs all operations for debugging
 * - Validates database charset/collation
 * 
 * @package PoolSafe_Portal
 * @version 2.5.3
 * @since 1.0.0
 */

/**
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    PoolSafe_Portal
 * @subpackage PoolSafe_Portal/includes
 * @author     PoolSafe Team
 */
class PSP_Activator {

	/**
	 * Create necessary database tables and initialize plugin
	 * 
	 * Runs once during plugin activation. Safe for repeated calls due to
	 * IF NOT EXISTS clauses. All errors are logged, not thrown.
	 *
	 * @since    1.0.0
	 * @return   void
	 */
	public static function activate() {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		// Helper to safely execute dbDelta with logging to avoid hard failures on shared hosting
		$run_dbdelta = static function( $sql, $label = 'dbDelta' ) {
			try {
				require_once ABSPATH . 'wp-admin/includes/upgrade.php';
				dbDelta( $sql );
			} catch ( \Throwable $e ) {
				error_log( sprintf( '[PoolSafe Portal] %s failed: %s', $label, $e->getMessage() ) );
			}
		};

		// Helper to safely run schema alterations with logging
		$run_query = static function( $sql, $label = 'ALTER' ) use ( $wpdb ) {
			try {
				$wpdb->query( $sql );
			} catch ( \Throwable $e ) {
				error_log( sprintf( '[PoolSafe Portal] %s failed: %s', $label, $e->getMessage() ) );
			}
		};

		// 1. Portal Users Table (custom, not WordPress users)
		$sql_users = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}psp_users (
			id INT AUTO_INCREMENT PRIMARY KEY,
			email VARCHAR(191) NOT NULL UNIQUE,
			password_hash VARCHAR(255) NOT NULL,
			first_name VARCHAR(100),
			last_name VARCHAR(100),
			phone VARCHAR(20),
			role VARCHAR(50) NOT NULL DEFAULT 'subscriber',
			partner_id INT,
			status VARCHAR(20) NOT NULL DEFAULT 'active',
			last_login DATETIME,
			created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
			updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			
			INDEX idx_email (email),
			INDEX idx_role (role),
			INDEX idx_partner_id (partner_id),
			INDEX idx_status (status)
		) {$charset_collate};";

		// 2. Partners/Companies Table
		$sql_partners = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}psp_partners (
			id INT AUTO_INCREMENT PRIMARY KEY,
			company_name VARCHAR(191) NOT NULL,
			management_company VARCHAR(255),
			street_address VARCHAR(255),
			phone VARCHAR(20),
			email VARCHAR(255),
			city VARCHAR(100),
			state VARCHAR(50),
			zip VARCHAR(20),
			country VARCHAR(100),
			units INT,
			pool_colour VARCHAR(100),
			lock_type VARCHAR(100),
			master_code VARCHAR(100),
			sub_master_code VARCHAR(100),
			lock_part VARCHAR(100),
			key_code VARCHAR(100),
			primary_contact_user_id INT,
			secondary_contact_user_id INT,
			status VARCHAR(20) NOT NULL DEFAULT 'active',
			created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
			updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			
			INDEX idx_status (status),
			INDEX idx_company_name (company_name),
			INDEX idx_primary_contact (primary_contact_user_id),
			INDEX idx_secondary_contact (secondary_contact_user_id),
			
		FOREIGN KEY (primary_contact_user_id) REFERENCES {$wpdb->prefix}psp_users(id) ON DELETE SET NULL,
		FOREIGN KEY (secondary_contact_user_id) REFERENCES {$wpdb->prefix}psp_users(id) ON DELETE SET NULL
	) {$charset_collate};";

	// 3. Company Users Table (for partner portal users)
	$sql_company_users = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}psp_company_users (
		id INT AUTO_INCREMENT PRIMARY KEY,
		company_id INT NOT NULL,
		username VARCHAR(100) NOT NULL UNIQUE,
		password VARCHAR(255) NOT NULL,
		email VARCHAR(191) NOT NULL,
		first_name VARCHAR(100),
		last_name VARCHAR(100),
		role VARCHAR(50) NOT NULL DEFAULT 'user',
		status VARCHAR(20) NOT NULL DEFAULT 'active',
		last_login DATETIME,
		created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
		updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
		
		INDEX idx_company_id (company_id),
		INDEX idx_username (username),
		INDEX idx_email (email),
		INDEX idx_status (status),
		
		FOREIGN KEY (company_id) REFERENCES {$wpdb->prefix}psp_partners(id) ON DELETE CASCADE
	) {$charset_collate};";

	// 5. Tickets Table
		$sql_tickets = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}psp_tickets (
			id INT AUTO_INCREMENT PRIMARY KEY,
			ticket_number VARCHAR(50) NOT NULL UNIQUE,
			title VARCHAR(255) NOT NULL,
			description LONGTEXT,
			partner_id INT NOT NULL,
			created_by_user_id INT NOT NULL,
			created_by_contact_id BIGINT(20) UNSIGNED DEFAULT NULL COMMENT 'Which company contact created this',
			assigned_to_user_id INT,
			status VARCHAR(50) NOT NULL DEFAULT 'open',
			priority VARCHAR(20) NOT NULL DEFAULT 'medium',
			category VARCHAR(100),
			internal_notes LONGTEXT,
			resolved_at DATETIME,
			created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
			updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			
			INDEX idx_partner_id (partner_id),
			INDEX idx_status (status),
			INDEX idx_priority (priority),
			INDEX idx_assigned_to (assigned_to_user_id),
			INDEX idx_created_by (created_by_user_id),
			INDEX idx_created_by_contact (created_by_contact_id),
			INDEX idx_created_at (created_at),
			
			FOREIGN KEY (partner_id) REFERENCES {$wpdb->prefix}psp_partners(id) ON DELETE CASCADE,
			FOREIGN KEY (created_by_user_id) REFERENCES {$wpdb->prefix}psp_users(id) ON DELETE CASCADE,
			FOREIGN KEY (assigned_to_user_id) REFERENCES {$wpdb->prefix}psp_users(id) ON DELETE SET NULL
		) {$charset_collate};";

		// 6. Ticket Replies Table
		$sql_ticket_replies = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}psp_ticket_replies (
			id INT AUTO_INCREMENT PRIMARY KEY,
			ticket_id INT NOT NULL,
			reply_text LONGTEXT,
			user_id INT NOT NULL,
			is_internal TINYINT(1) DEFAULT 0,
			created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
			updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			
			INDEX idx_ticket_id (ticket_id),
			INDEX idx_user_id (user_id),
			INDEX idx_is_internal (is_internal),
			
			FOREIGN KEY (ticket_id) REFERENCES {$wpdb->prefix}psp_tickets(id) ON DELETE CASCADE,
			FOREIGN KEY (user_id) REFERENCES {$wpdb->prefix}psp_users(id) ON DELETE CASCADE
		) {$charset_collate};";

		// 5. Service Records Table
		$sql_service_records = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}psp_service_records (
			id INT AUTO_INCREMENT PRIMARY KEY,
			partner_id INT NOT NULL,
			service_date DATE NOT NULL,
			service_type VARCHAR(100),
			description LONGTEXT,
			technician_id INT,
			created_by_contact_id BIGINT(20) UNSIGNED DEFAULT NULL COMMENT 'Which company contact scheduled this',
			status VARCHAR(50) NOT NULL DEFAULT 'scheduled',
			notes LONGTEXT,
			created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
			updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			
			INDEX idx_partner_id (partner_id),
			INDEX idx_service_date (service_date),
			INDEX idx_status (status),
			INDEX idx_created_by_contact (created_by_contact_id),
			
			FOREIGN KEY (partner_id) REFERENCES {$wpdb->prefix}psp_partners(id) ON DELETE CASCADE,
			FOREIGN KEY (technician_id) REFERENCES {$wpdb->prefix}psp_users(id) ON DELETE SET NULL
		) {$charset_collate};";

		// 6. Notifications Table
		$sql_notifications = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}psp_notifications (
			id INT AUTO_INCREMENT PRIMARY KEY,
			title VARCHAR(255) NOT NULL,
			content LONGTEXT,
			target_user_id INT NOT NULL,
			created_by_user_id INT,
			is_read TINYINT(1) DEFAULT 0,
			type VARCHAR(50),
			priority VARCHAR(20) DEFAULT 'medium',
			partner_id INT,
			ticket_id INT,
			service_record_id INT,
			action_link VARCHAR(500),
			delivery_status VARCHAR(50) DEFAULT 'pending',
			delivery_timestamp DATETIME,
			email_delivery_status VARCHAR(50),
			retry_count INT DEFAULT 0,
			created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
			updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			
			INDEX idx_target_user (target_user_id),
			INDEX idx_partner (partner_id),
			INDEX idx_ticket (ticket_id),
			INDEX idx_type (type),
			INDEX idx_is_read (is_read),
			INDEX idx_created_at (created_at),
			
			FOREIGN KEY (target_user_id) REFERENCES {$wpdb->prefix}psp_users(id) ON DELETE CASCADE,
			FOREIGN KEY (partner_id) REFERENCES {$wpdb->prefix}psp_partners(id) ON DELETE SET NULL,
			FOREIGN KEY (ticket_id) REFERENCES {$wpdb->prefix}psp_tickets(id) ON DELETE SET NULL
		) {$charset_collate};";

		// 7. User Notification Preferences
		$sql_notification_prefs = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}psp_user_notification_preferences (
			id INT AUTO_INCREMENT PRIMARY KEY,
			user_id INT NOT NULL UNIQUE,
			notify_new_tickets TINYINT(1) DEFAULT 1,
			notify_ticket_replies TINYINT(1) DEFAULT 1,
			notify_status_changes TINYINT(1) DEFAULT 1,
			notify_service_records TINYINT(1) DEFAULT 1,
			notify_announcements TINYINT(1) DEFAULT 1,
			notify_system_alerts TINYINT(1) DEFAULT 1,
			email_frequency VARCHAR(20) DEFAULT 'immediate',
			notification_channel VARCHAR(20) DEFAULT 'both',
			quiet_hours_enabled TINYINT(1) DEFAULT 0,
			quiet_hours_start TIME DEFAULT '18:00:00',
			quiet_hours_end TIME DEFAULT '08:00:00',
			digest_enabled TINYINT(1) DEFAULT 0,
			created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
			updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			
			FOREIGN KEY (user_id) REFERENCES {$wpdb->prefix}psp_users(id) ON DELETE CASCADE
		) {$charset_collate};";

		// 8. Notification Queue Table
		$sql_notification_queue = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}psp_notification_queue (
			id INT AUTO_INCREMENT PRIMARY KEY,
			notification_id INT NOT NULL,
			user_id INT NOT NULL,
			channel VARCHAR(50),
			status VARCHAR(50) DEFAULT 'pending',
			attempts INT DEFAULT 0,
			last_error TEXT,
			scheduled_for DATETIME,
			sent_at DATETIME,
			created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
			updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			
			INDEX idx_status (status),
			INDEX idx_scheduled (scheduled_for),
			INDEX idx_notification (notification_id),
			
			FOREIGN KEY (notification_id) REFERENCES {$wpdb->prefix}psp_notifications(id) ON DELETE CASCADE,
			FOREIGN KEY (user_id) REFERENCES {$wpdb->prefix}psp_users(id) ON DELETE CASCADE
		) {$charset_collate};";

		// 9. Audit Log Table
		$sql_audit_log = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}psp_audit_log (
			id INT AUTO_INCREMENT PRIMARY KEY,
			user_id INT,
			action VARCHAR(100),
			resource_type VARCHAR(50),
			resource_id INT,
			old_values LONGTEXT,
			new_values LONGTEXT,
			ip_address VARCHAR(45),
			user_agent TEXT,
			created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
			
			INDEX idx_user_id (user_id),
			INDEX idx_action (action),
			INDEX idx_created_at (created_at)
		) {$charset_collate};";

		// 10. Profile Notes Table
		$sql_profile_notes = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}psp_profile_notes (
			id INT AUTO_INCREMENT PRIMARY KEY,
			user_id INT NOT NULL,
			created_by_user_id INT NOT NULL,
			note_text LONGTEXT,
			priority VARCHAR(20) DEFAULT 'medium',
			is_pinned TINYINT(1) DEFAULT 0,
			created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
			updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			
			INDEX idx_user_id (user_id),
			INDEX idx_created_by (created_by_user_id),
			INDEX idx_is_pinned (is_pinned),
			
			FOREIGN KEY (user_id) REFERENCES {$wpdb->prefix}psp_users(id) ON DELETE CASCADE,
			FOREIGN KEY (created_by_user_id) REFERENCES {$wpdb->prefix}psp_users(id) ON DELETE CASCADE
		) {$charset_collate};";

		// 11. Attachments Table
		$sql_attachments = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}psp_attachments (
			id INT AUTO_INCREMENT PRIMARY KEY,
			ticket_id INT,
			ticket_reply_id INT,
			service_record_id INT,
			uploaded_by_user_id INT NOT NULL,
			file_name VARCHAR(255) NOT NULL,
			file_path VARCHAR(500) NOT NULL,
			file_type VARCHAR(50),
			file_size INT,
			mime_type VARCHAR(100),
			download_count INT DEFAULT 0,
			created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
			updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			
			INDEX idx_ticket_id (ticket_id),
			INDEX idx_ticket_reply_id (ticket_reply_id),
			INDEX idx_service_record_id (service_record_id),
			INDEX idx_uploaded_by (uploaded_by_user_id),
			INDEX idx_created_at (created_at),
			
			FOREIGN KEY (ticket_id) REFERENCES {$wpdb->prefix}psp_tickets(id) ON DELETE CASCADE,
			FOREIGN KEY (ticket_reply_id) REFERENCES {$wpdb->prefix}psp_ticket_replies(id) ON DELETE CASCADE,
			FOREIGN KEY (service_record_id) REFERENCES {$wpdb->prefix}psp_service_records(id) ON DELETE CASCADE,
			FOREIGN KEY (uploaded_by_user_id) REFERENCES {$wpdb->prefix}psp_users(id) ON DELETE CASCADE
		) {$charset_collate};";

	require_once ABSPATH . 'wp-admin/includes/upgrade.php';

	$run_dbdelta( $sql_users, 'dbDelta psp_users' );
	$run_dbdelta( $sql_partners, 'dbDelta psp_partners' );
	$run_dbdelta( $sql_company_users, 'dbDelta psp_company_users' );
	$run_dbdelta( $sql_tickets, 'dbDelta psp_tickets' );
	$run_dbdelta( $sql_ticket_replies, 'dbDelta psp_ticket_replies' );
	$run_dbdelta( $sql_service_records, 'dbDelta psp_service_records' );
	$run_dbdelta( $sql_notifications, 'dbDelta psp_notifications' );
	$run_dbdelta( $sql_notification_prefs, 'dbDelta psp_notification_prefs' );
	$run_dbdelta( $sql_notification_queue, 'dbDelta psp_notification_queue' );
	$run_dbdelta( $sql_audit_log, 'dbDelta psp_audit_log' );
	$run_dbdelta( $sql_profile_notes, 'dbDelta psp_profile_notes' );
	$run_dbdelta( $sql_attachments, 'dbDelta psp_attachments' );

		// Partner Activity Tracking Table
		$sql_partner_activity = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}psp_partner_activity (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
			partner_id BIGINT UNSIGNED NOT NULL,
			staff_id BIGINT UNSIGNED NOT NULL,
			activity_type VARCHAR(50) NOT NULL,
			activity_date DATE NOT NULL,
			notes TEXT,
			created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
			
			INDEX idx_partner_id (partner_id),
			INDEX idx_staff_id (staff_id),
			INDEX idx_activity_date (activity_date),
			INDEX idx_activity_type (activity_type)
		) {$charset_collate};";
		
		dbDelta( $sql_partner_activity );

		// Add missing columns to psp_partners table for bulk import
		$table_name = $wpdb->prefix . 'psp_partners';
		
		// Check if table exists first
		if ( $wpdb->get_var( "SHOW TABLES LIKE '$table_name'" ) == $table_name ) {
			$columns = $wpdb->get_col( "DESCRIBE {$table_name}" );
			
			// Add columns that are missing
			if ( !in_array( 'management_company', $columns ) ) {
				$run_query( "ALTER TABLE {$table_name} ADD COLUMN management_company VARCHAR(255) AFTER company_name", 'ALTER psp_partners.management_company' );
			}
			if ( !in_array( 'street_address', $columns ) ) {
				$run_query( "ALTER TABLE {$table_name} ADD COLUMN street_address VARCHAR(255) AFTER address", 'ALTER psp_partners.street_address' );
			}
			if ( !in_array( 'units', $columns ) ) {
				$run_query( "ALTER TABLE {$table_name} ADD COLUMN units INT DEFAULT 0", 'ALTER psp_partners.units' );
			}
			if ( !in_array( 'pool_colour', $columns ) ) {
				$run_query( "ALTER TABLE {$table_name} ADD COLUMN pool_colour VARCHAR(100)", 'ALTER psp_partners.pool_colour' );
			}
			if ( !in_array( 'lock_type', $columns ) ) {
				$run_query( "ALTER TABLE {$table_name} ADD COLUMN lock_type VARCHAR(100)", 'ALTER psp_partners.lock_type' );
			}
			if ( !in_array( 'master_code', $columns ) ) {
				$run_query( "ALTER TABLE {$table_name} ADD COLUMN master_code VARCHAR(100)", 'ALTER psp_partners.master_code' );
			}
			if ( !in_array( 'sub_master_code', $columns ) ) {
				$run_query( "ALTER TABLE {$table_name} ADD COLUMN sub_master_code VARCHAR(100)", 'ALTER psp_partners.sub_master_code' );
			}
			if ( !in_array( 'lock_part', $columns ) ) {
				$run_query( "ALTER TABLE {$table_name} ADD COLUMN lock_part VARCHAR(100)", 'ALTER psp_partners.lock_part' );
			}
			if ( !in_array( 'key_code', $columns ) ) {
				$run_query( "ALTER TABLE {$table_name} ADD COLUMN key_code VARCHAR(100)", 'ALTER psp_partners.key_code' );
			}
		}

		// Ensure partner tables exist for bulk import safety (self-healing)
		self::ensure_partner_tables();

		// Store activation version
		update_option( 'psp_db_version', '1.0.1' );
		
		// ==========================================
		// CREATE VIDEO TABLES
		// ==========================================
		
		// Video Categories
		$sql_video_categories = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}psp_video_categories (
			id INT AUTO_INCREMENT PRIMARY KEY,
			name VARCHAR(100) NOT NULL,
			slug VARCHAR(100) NOT NULL,
			description TEXT,
			sort_order INT DEFAULT 0,
			created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
			
			UNIQUE KEY slug (slug),
			INDEX idx_sort (sort_order)
		) {$charset_collate};";
		
		// Videos
		$sql_videos = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}psp_videos (
			id INT AUTO_INCREMENT PRIMARY KEY,
			title VARCHAR(191) NOT NULL,
			description TEXT,
			video_url VARCHAR(500) NOT NULL,
			video_type VARCHAR(20) NOT NULL DEFAULT 'youtube',
			thumbnail_url VARCHAR(500),
			category_id INT,
			duration INT DEFAULT 0,
			access_level VARCHAR(20) DEFAULT 'all',
			status VARCHAR(20) DEFAULT 'published',
			created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
			updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			
			INDEX idx_category (category_id),
			INDEX idx_status (status),
			INDEX idx_access (access_level)
		) {$charset_collate};";
		
		// Video Views Tracking
		$sql_video_views = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}psp_video_views (
			id INT AUTO_INCREMENT PRIMARY KEY,
			video_id INT NOT NULL,
			user_id INT NOT NULL,
			duration_watched INT DEFAULT 0,
			completed TINYINT DEFAULT 0,
			viewed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
			
			INDEX idx_video (video_id),
			INDEX idx_user (user_id),
			INDEX idx_completed (completed)
		) {$charset_collate};";
		
		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		dbDelta( $sql_video_categories );
		dbDelta( $sql_videos );
		dbDelta( $sql_video_views );
		
		// Add default video category
		$existing_cat = $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}psp_video_categories" );
		if ( $existing_cat == 0 ) {
			$wpdb->insert( "{$wpdb->prefix}psp_video_categories", [
				'name' => 'Getting Started',
				'slug' => 'getting-started',
				'description' => 'Introduction and basics',
				'sort_order' => 1
			]);
		}
	}

	/**
	 * Ensure core partner tables exist (self-healing for imports).
	 * Safe to call at runtime before CSV imports or bulk operations.
	 */
	public static function ensure_partner_tables() {
		global $wpdb;
		$charset_collate = $wpdb->get_charset_collate();

		$tables = $wpdb->get_col( 'SHOW TABLES', 0 );
		$table_partners = $wpdb->prefix . 'psp_partners';
		$table_company_users = $wpdb->prefix . 'psp_company_users';

		$needs_partners = ! in_array( $table_partners, $tables, true );
		$needs_company_users = ! in_array( $table_company_users, $tables, true );

		if ( ! $needs_partners && ! $needs_company_users ) {
			return;
		}

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		if ( $needs_partners ) {
			$sql_partners = "CREATE TABLE IF NOT EXISTS {$table_partners} (
				id INT AUTO_INCREMENT PRIMARY KEY,
				company_name VARCHAR(191) NOT NULL,
				management_company VARCHAR(255),
				street_address VARCHAR(255),
				phone VARCHAR(20),
				email VARCHAR(255),
				city VARCHAR(100),
				state VARCHAR(50),
				zip VARCHAR(20),
				country VARCHAR(100),
				units INT,
				pool_colour VARCHAR(100),
				lock_type VARCHAR(100),
				master_code VARCHAR(100),
				sub_master_code VARCHAR(100),
				lock_part VARCHAR(100),
				key_code VARCHAR(100),
				primary_contact_user_id INT,
				secondary_contact_user_id INT,
				status VARCHAR(20) NOT NULL DEFAULT 'active',
				created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
				updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
				INDEX idx_status (status),
				INDEX idx_company_name (company_name),
				INDEX idx_primary_contact (primary_contact_user_id),
				INDEX idx_secondary_contact (secondary_contact_user_id)
			) {$charset_collate};";

			$run_dbdelta( $sql_partners, 'dbDelta psp_partners (self-heal)' );
		}

		if ( $needs_company_users ) {
			$sql_company_users = "CREATE TABLE IF NOT EXISTS {$table_company_users} (
				id INT AUTO_INCREMENT PRIMARY KEY,
				company_id INT NOT NULL,
				username VARCHAR(100) NOT NULL UNIQUE,
				password VARCHAR(255) NOT NULL,
				email VARCHAR(191) NOT NULL,
				first_name VARCHAR(100),
				last_name VARCHAR(100),
				role VARCHAR(50) NOT NULL DEFAULT 'user',
				status VARCHAR(20) NOT NULL DEFAULT 'active',
				last_login DATETIME,
				created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
				updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
				INDEX idx_company_id (company_id),
				INDEX idx_username (username),
				INDEX idx_email (email),
				INDEX idx_status (status)
			) {$charset_collate};";

			$run_dbdelta( $sql_company_users, 'dbDelta psp_company_users (self-heal)' );
		}
		
		// Initialize new company authentication tables
		if ( file_exists( PSP_PLUGIN_DIR . '/includes/class-psp-db-schema.php' ) ) {
			require_once PSP_PLUGIN_DIR . '/includes/class-psp-db-schema.php';
			\PSP\DB_Schema::create_tables();
		}
	}

}
