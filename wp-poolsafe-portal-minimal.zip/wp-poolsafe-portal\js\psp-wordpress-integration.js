/**
 * PoolSafe Portal - WordPress Integration JavaScript
 * 
 * Handles:
 * - Lazy loading images
 * - REST API communication with nonce verification
 * - Theme customizer integration
 * - Accessibility features
 * - Performance monitoring
 * 
 * @requires jQuery (WordPress standard)
 */

(function($, window, document) {
    'use strict';

    // Check if portal config exists
    if (!window.PORTAL_CONFIG) {
        console.warn('PORTAL_CONFIG not found. WordPress integration may not work properly.');
        return;
    }

    /**
     * PSP WordPress Integration Module
     */
    window.PSPWordPressIntegration = {
        
        /**
         * Initialize WordPress integration
         */
        init: function() {
            this.setupLazyLoading();
            this.setupRESTClient();
            this.setupAccessibility();
            this.setupThemeObserver();
            
            if (PORTAL_CONFIG.debug) {
                console.log('[PSP] WordPress integration initialized');
            }
        },

        /**
         * Setup lazy loading for images
         */
        setupLazyLoading: function() {
            if (!window.IntersectionObserver) {
                console.warn('[PSP] IntersectionObserver not supported, lazy loading disabled');
                return;
            }

            const images = document.querySelectorAll('[data-src]');
            if (images.length === 0) return;

            const imageObserver = new IntersectionObserver((entries, observer) => {
                entries.forEach((entry) => {
                    if (entry.isIntersecting) {
                        const img = entry.target;
                        const dataSrc = img.getAttribute('data-src');
                        
                        // Load image
                        img.src = dataSrc;
                        img.removeAttribute('data-src');
                        
                        // Add loaded class for animation
                        img.classList.add('psp-img-loaded');
                        
                        // Stop observing this image
                        observer.unobserve(img);
                        
                        if (PORTAL_CONFIG.debug) {
                            console.log('[PSP LAZY LOAD]', dataSrc);
                        }
                    }
                });
            }, {
                rootMargin: '50px'
            });

            images.forEach((img) => {
                imageObserver.observe(img);
            });
        },

        /**
         * Setup WordPress REST API client with nonce verification
         */
        setupRESTClient: function() {
            const nonce = document.querySelector('input[name="_wpnonce"]');
            const nonstringValue = nonce ? nonce.value : null;
            
            // Override fetch for WordPress REST API
            const originalFetch = window.fetch;
            window.fetch = function(resource, config) {
                // Check if this is a WordPress REST API call
                if (typeof resource === 'string' && resource.includes('/wp-json/')) {
                    config = config || {};
                    
                    // Add nonce header for WordPress REST
                    if (nonstringValue) {
                        config.headers = config.headers || {};
                        config.headers['X-WP-Nonce'] = nonstringValue;
                    }
                    
                    // Add credentials for WordPress
                    if (!config.credentials) {
                        config.credentials = 'same-origin';
                    }
                }
                
                return originalFetch.call(window, resource, config);
            };

            if (PORTAL_CONFIG.debug) {
                console.log('[PSP REST] Client configured with nonce protection');
            }
        },

        /**
         * Setup accessibility features
         */
        setupAccessibility: function() {
            // Add skip to content link if not present
            if (!document.querySelector('.skip-to-content')) {
                const skipLink = document.createElement('a');
                skipLink.href = '#main-content';
                skipLink.className = 'skip-to-content';
                skipLink.textContent = 'Skip to main content';
                document.body.insertBefore(skipLink, document.body.firstChild);
                
                // Style skip link
                skipLink.style.cssText = `
                    position: absolute;
                    top: -40px;
                    left: 0;
                    background: #000;
                    color: #fff;
                    padding: 8px;
                    z-index: 100;
                    text-decoration: none;
                `;
                
                // Show on focus
                skipLink.addEventListener('focus', function() {
                    this.style.top = '0';
                });
                skipLink.addEventListener('blur', function() {
                    this.style.top = '-40px';
                });
            }

            // Ensure buttons have proper focus states
            document.querySelectorAll('button:not([class*="psp"])').forEach((btn) => {
                btn.addEventListener('keydown', (e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                        btn.click();
                    }
                });
            });

            if (PORTAL_CONFIG.debug) {
                console.log('[PSP A11Y] Accessibility features enabled');
            }
        },

        /**
         * Watch for theme customizer changes
         */
        setupThemeObserver: function() {
            if (!window.wp || !window.wp.customize) {
                return;
            }

            const customize = window.wp.customize;

            // Watch for color changes
            customize('primary_color', (value) => {
                value.bind((newColor) => {
                    document.documentElement.style.setProperty('--psp-primary', newColor);
                });
            });

            customize('text_color', (value) => {
                value.bind((newColor) => {
                    document.documentElement.style.setProperty('--psp-fg', newColor);
                });
            });

            customize('background_color', (value) => {
                value.bind((newColor) => {
                    document.documentElement.style.setProperty('--psp-bg', newColor);
                });
            });

            if (PORTAL_CONFIG.debug) {
                console.log('[PSP THEME] Customizer observer active');
            }
        },

        /**
         * Make REST API call with proper WordPress integration
         */
        restAPI: {
            /**
             * GET request
             */
            get: function(endpoint, options) {
                const url = PORTAL_CONFIG.apiBase + endpoint;
                options = options || {};
                
                return fetch(url, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        ...options.headers
                    },
                    credentials: 'same-origin'
                }).then((response) => {
                    if (!response.ok) {
                        throw new Error(`REST API Error: ${response.status}`);
                    }
                    return response.json();
                });
            },

            /**
             * POST request
             */
            post: function(endpoint, data, options) {
                const url = PORTAL_CONFIG.apiBase + endpoint;
                options = options || {};
                
                return fetch(url, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        ...options.headers
                    },
                    body: JSON.stringify(data),
                    credentials: 'same-origin'
                }).then((response) => {
                    if (!response.ok) {
                        throw new Error(`REST API Error: ${response.status}`);
                    }
                    return response.json();
                });
            },

            /**
             * PUT request
             */
            put: function(endpoint, data, options) {
                const url = PORTAL_CONFIG.apiBase + endpoint;
                options = options || {};
                
                return fetch(url, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json',
                        ...options.headers
                    },
                    body: JSON.stringify(data),
                    credentials: 'same-origin'
                }).then((response) => {
                    if (!response.ok) {
                        throw new Error(`REST API Error: ${response.status}`);
                    }
                    return response.json();
                });
            },

            /**
             * DELETE request
             */
            delete: function(endpoint, options) {
                const url = PORTAL_CONFIG.apiBase + endpoint;
                options = options || {};
                
                return fetch(url, {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json',
                        ...options.headers
                    },
                    credentials: 'same-origin'
                }).then((response) => {
                    if (!response.ok) {
                        throw new Error(`REST API Error: ${response.status}`);
                    }
                    return response.status === 204 ? null : response.json();
                });
            }
        }
    };

    /**
     * WordPress Blocks Helper
     * Support for rendering portal blocks in Gutenberg editor
     */
    window.PSPBlocks = {
        /**
         * Register portal block
         */
        registerBlock: function(name, settings) {
            if (!window.wp || !window.wp.blocks) {
                console.warn('[PSP BLOCKS] WordPress Blocks API not available');
                return;
            }

            const { registerBlockType } = window.wp.blocks;
            const { createElement: el } = window.wp.element;
            const { __ } = window.wp.i18n;

            registerBlockType(name, {
                title: settings.title || 'PoolSafe Portal Block',
                description: settings.description || 'Display PoolSafe Portal content',
                category: 'widgets',
                icon: settings.icon || 'admin-home',
                attributes: settings.attributes || {},
                edit: settings.edit,
                save: settings.save,
                ...settings
            });

            if (PORTAL_CONFIG.debug) {
                console.log('[PSP BLOCKS] Registered block:', name);
            }
        }
    };

    /**
     * WordPress Options Helper
     */
    window.PSPOptions = {
        /**
         * Get option from WordPress
         */
        get: function(key, defaultValue) {
            if (!window.PORTAL_CONFIG.options) {
                return defaultValue;
            }
            return window.PORTAL_CONFIG.options[key] || defaultValue;
        },

        /**
         * Set option (requires wp_ajax call)
         */
        set: function(key, value) {
            if (!window.PORTAL_CONFIG.ajaxUrl) {
                console.error('[PSP OPTIONS] AJAX URL not configured');
                return Promise.reject('AJAX URL not configured');
            }

            return $.ajax({
                url: PORTAL_CONFIG.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'psp_set_option',
                    key: key,
                    value: value,
                    nonce: $('input[name="_wpnonce"]').val()
                }
            });
        }
    };

    /**
     * Initialize on WordPress DOM ready
     */
    $(document).ready(function() {
        window.PSPWordPressIntegration.init();
    });

})(jQuery, window, document);

/**
 * Lazy Loading Image Handler (non-jQuery fallback)
 */
document.addEventListener('DOMContentLoaded', function() {
    if (!window.IntersectionObserver || !window.PSPWordPressIntegration) {
        return;
    }

    // Add loaded class styling
    const style = document.createElement('style');
    style.textContent = `
        .psp-img-loaded {
            animation: fadeIn 0.3s ease-in-out;
        }
        
        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }
    `;
    document.head.appendChild(style);
});
