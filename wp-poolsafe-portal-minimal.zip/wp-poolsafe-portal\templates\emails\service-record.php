<?php
/**
 * Email Template - Service Record Notification
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 600px;
            margin: 0 auto;
            background-color: #f9f9f9;
        }
        .email-container {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 8px 8px 0 0;
            text-align: center;
        }
        .header h1 {
            margin: 0;
            font-size: 24px;
        }
        .content {
            padding: 20px;
        }
        .service-info {
            background-color: #fef3c7;
            border-left: 4px solid #f59e0b;
            padding: 15px;
            margin: 20px 0;
            border-radius: 4px;
        }
        .service-info p {
            margin: 8px 0;
        }
        .service-info strong {
            color: #b45309;
        }
        .button {
            display: inline-block;
            background-color: #667eea;
            color: white;
            padding: 12px 24px;
            text-decoration: none;
            border-radius: 4px;
            margin: 20px 0;
            font-weight: bold;
        }
        .button:hover {
            background-color: #5568d3;
        }
        .footer {
            text-align: center;
            color: #666;
            font-size: 12px;
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #eee;
        }
    </style>
</head>
<body>
    <div class="email-container">
        <div class="header">
            <h1>📅 Service Record Scheduled</h1>
        </div>

        <div class="content">
            <p>Hello <?php echo isset($recipient_name) ? esc_html($recipient_name) : 'there'; ?>,</p>

            <p>A service record has been scheduled for your company:</p>

            <div class="service-info">
                <p><strong>Service Type:</strong> <?php echo isset($service_type) ? esc_html($service_type) : '—'; ?></p>
                <p><strong>Scheduled Date:</strong> <?php echo isset($service_date) ? date_i18n('M d, Y', strtotime($service_date)) : '—'; ?></p>
                <p><strong>Status:</strong> <span style="text-transform: capitalize;"><?php echo isset($service_status) ? esc_html($service_status) : '—'; ?></span></p>
                <p><strong>Company:</strong> <?php echo isset($company_name) ? esc_html($company_name) : '—'; ?></p>
                <?php if (isset($service_description) && $service_description) : ?>
                    <p><strong>Notes:</strong> <?php echo esc_html($service_description); ?></p>
                <?php endif; ?>
            </div>

            <center>
                <a href="<?php echo isset($service_url) ? esc_url($service_url) : '#'; ?>" class="button">
                    View Service Record →
                </a>
            </center>

            <p>Please mark your calendar and ensure availability on the scheduled date.</p>
        </div>

        <div class="footer">
            <p>PoolSafe Portal | Support Team</p>
            <p>This is an automated email. Please do not reply directly to this message.</p>
        </div>
    </div>
</body>
</html>
