<?php
/**
 * PoolSafe Portal Video Management
 * Handles training video library and shortcode
 */

if (!defined('ABSPATH')) {
    exit;
}

class PSP_Videos {
    
    public function __construct() {
        add_shortcode('poolsafe_videos', [$this, 'render_video_library']);
        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('wp_ajax_psp_track_video_view', [$this, 'ajax_track_video_view']);
        add_action('wp_ajax_psp_save_video', [$this, 'ajax_save_video']);
        add_action('wp_ajax_psp_delete_video', [$this, 'ajax_delete_video']);
    }
    
    /**
     * Initialize video system
     */
    public static function init() {
        $instance = new self();
        add_action('admin_init', [$instance, 'create_tables']);
    }
    
    /**
     * Create database tables for videos
     */
    public function create_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // Videos table
        $table_videos = $wpdb->prefix . 'psp_videos';
        $sql_videos = "CREATE TABLE IF NOT EXISTS $table_videos (
            id INT AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(255) NOT NULL,
            description TEXT,
            video_url VARCHAR(500) NOT NULL,
            video_type ENUM('upload', 'youtube', 'vimeo') DEFAULT 'upload',
            thumbnail_url VARCHAR(500),
            category_id INT,
            duration INT DEFAULT 0,
            access_level VARCHAR(50) DEFAULT 'all',
            visibility_type ENUM('all', 'property', 'management_company', 'role') DEFAULT 'all',
            visibility_value VARCHAR(255),
            status ENUM('draft', 'published') DEFAULT 'published',
            sort_order INT DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) $charset_collate;";
        
        // Video categories
        $table_categories = $wpdb->prefix . 'psp_video_categories';
        $sql_categories = "CREATE TABLE IF NOT EXISTS $table_categories (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            slug VARCHAR(100) NOT NULL,
            description TEXT,
            sort_order INT DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        ) $charset_collate;";
        
        // Video views tracking
        $table_views = $wpdb->prefix . 'psp_video_views';
        $sql_views = "CREATE TABLE IF NOT EXISTS $table_views (
            id INT AUTO_INCREMENT PRIMARY KEY,
            video_id INT NOT NULL,
            user_id INT NOT NULL,
            viewed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            duration_watched INT DEFAULT 0,
            completed TINYINT(1) DEFAULT 0,
            INDEX idx_video_user (video_id, user_id)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql_videos);
        dbDelta($sql_categories);
        dbDelta($sql_views);
        
        // Add default category
        $existing = $wpdb->get_var("SELECT COUNT(*) FROM $table_categories");
        if ($existing == 0) {
            $wpdb->insert($table_categories, [
                'name' => 'Getting Started',
                'slug' => 'getting-started',
                'description' => 'Introduction and basics',
                'sort_order' => 1
            ]);
        }
    }
    
    /**
     * Render video library shortcode
     */
    public function render_video_library($atts) {
        // Check authentication
        if (!isset($_SESSION['psp_user'])) {
            return $this->render_login_prompt();
        }
        
        $user = $_SESSION['psp_user'];
        
        // Get videos and categories
        $categories = $this->get_categories();
        $videos = $this->get_user_videos($user);
        
        ob_start();
        include PSP_PLUGIN_DIR . 'views/video-library.php';
        return ob_get_clean();
    }
    
    /**
     * Get videos accessible to current user
     * Filters by:
     * - visibility_type: 'all' (everyone), 'property' (specific partner), 'management_company' (specific mgmt co), 'role' (pool_safe_partner/support/admin)
     * - visibility_value: partner ID, mgmt company name, or role name
     */
    private function get_user_videos($user) {
        global $wpdb;
        
        $table = $wpdb->prefix . 'psp_videos';
        
        // Get partner info if partner role
        $partner_id = $user['partner_id'] ?? null;
        $partner = null;
        if ($partner_id) {
            $partner = (object) array(
                'company_name'       => get_post_meta($partner_id, 'psp_company_name', true),
                'management_company' => get_post_meta($partner_id, 'psp_management_company', true),
            );
        }
        
        // Build safe WHERE clause using prepared statements
        $user_role = $user['role'] ?? 'partner';
        
        // Start building the query parts that will be prepared
        $base_query = "SELECT v.*, c.name as category_name 
                FROM $table v
                LEFT JOIN {$wpdb->prefix}psp_video_categories c ON v.category_id = c.id
                WHERE v.status = 'published' AND (";
        
        // Build visibility conditions array with prepare placeholders
        $conditions = [];
        $prepare_args = [];
        
        // Always show videos with visibility_type = 'all'
        $conditions[] = "v.visibility_type = 'all'";
        
        // Role-based visibility
        if ($user_role === 'admin' || $user_role === 'staff' || $user_role === 'administrator' || $user_role === 'pool_safe_support') {
            $conditions[] = "(v.visibility_type = 'role' AND v.visibility_value IN ('pool_safe_support', 'administrator'))";
        } elseif ($user_role === 'partner' || $user_role === 'pool_safe_partner') {
            $conditions[] = "(v.visibility_type = 'role' AND v.visibility_value = 'pool_safe_partner')";
        }
        
        // Property-specific visibility (partner sees videos for their property)
        if ($partner_id) {
            $conditions[] = "(v.visibility_type = 'property' AND v.visibility_value = %s)";
            $prepare_args[] = $partner_id;
        }
        
        // Management company visibility
        if ($partner && $partner->management_company) {
            $conditions[] = "(v.visibility_type = 'management_company' AND v.visibility_value = %s)";
            $prepare_args[] = $partner->management_company;
        }
        
        // Combine all conditions
        $base_query .= implode(' OR ', $conditions);
        $base_query .= ") ORDER BY v.category_id, v.sort_order";
        
        // If we have parameters, prepare the query; otherwise, execute directly
        if (!empty($prepare_args)) {
            $sql = $wpdb->prepare($base_query, ...$prepare_args);
        } else {
            $sql = $base_query;
        }
        
        return $wpdb->get_results($sql);
    }
    
    /**
     * Get all categories
     */
    private function get_categories() {
        global $wpdb;
        
        $table = $wpdb->prefix . 'psp_video_categories';
        return $wpdb->get_results("SELECT * FROM $table ORDER BY sort_order");
    }
    
    /**
     * Render login prompt
     */
    private function render_login_prompt() {
        return '<div class="psp-video-login-prompt">
            <p>Please <a href="' . home_url('/partner-portal') . '">log in</a> to access training videos.</p>
        </div>';
    }
    
    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        add_submenu_page(
            'poolsafe-portal',
            'Training Videos',
            'Training Videos',
            'manage_options',
            'poolsafe-videos',
            [$this, 'render_admin_page']
        );
    }
    
    /**
     * Render admin page
     */
    public function render_admin_page() {
        $categories = $this->get_categories();
        $videos = $this->get_all_videos();
        
        include PSP_PLUGIN_DIR . 'admin/videos-admin.php';
    }
    
    /**
     * Get all videos for admin
     */
    private function get_all_videos() {
        global $wpdb;
        
        $table = $wpdb->prefix . 'psp_videos';
        $sql = "SELECT v.*, c.name as category_name,
                (SELECT COUNT(*) FROM {$wpdb->prefix}psp_video_views WHERE video_id = v.id) as view_count
                FROM $table v
                LEFT JOIN {$wpdb->prefix}psp_video_categories c ON v.category_id = c.id
                ORDER BY v.created_at DESC";
        
        return $wpdb->get_results($sql);
    }
    
    /**
     * AJAX: Track video view
     */
    public function ajax_track_video_view() {
        check_ajax_referer('psp_video_nonce', 'nonce');
        
        if (!isset($_SESSION['psp_user'])) {
            wp_send_json_error('Not authenticated');
        }
        
        // Safe input handling with isset() checks
        $video_id = isset($_POST['video_id']) ? absint($_POST['video_id']) : 0;
        $duration = isset($_POST['duration']) ? absint($_POST['duration']) : 0;
        $completed = isset($_POST['completed']) ? 1 : 0;
        
        if (!$video_id) {
            wp_send_json_error('Invalid video ID');
        }
        
        global $wpdb;
        $table = $wpdb->prefix . 'psp_video_views';
        
        $wpdb->insert($table, [
            'video_id' => $video_id,
            'user_id' => absint($_SESSION['psp_user']['id']),
            'duration_watched' => $duration,
            'completed' => $completed
        ]);
        
        wp_send_json_success();
    }
    
    /**
     * AJAX: Save video
     */
    public function ajax_save_video() {
        check_ajax_referer('psp_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }
        
        global $wpdb;
        $table = $wpdb->prefix . 'psp_videos';
        
        // Safe input handling with isset() checks and proper sanitization
        $data = [
            'title' => isset($_POST['title']) ? sanitize_text_field($_POST['title']) : '',
            'description' => isset($_POST['description']) ? wp_kses_post($_POST['description']) : '',
            'video_url' => isset($_POST['video_url']) ? esc_url_raw($_POST['video_url']) : '',
            'video_type' => isset($_POST['video_type']) ? sanitize_text_field($_POST['video_type']) : 'youtube',
            'category_id' => isset($_POST['category_id']) ? absint($_POST['category_id']) : 0,
            'access_level' => isset($_POST['access_level']) ? sanitize_text_field($_POST['access_level']) : 'all',
            'status' => isset($_POST['status']) ? sanitize_text_field($_POST['status']) : 'draft'
        ];
        
        if (isset($_POST['id']) && !empty($_POST['id'])) {
            $video_id = absint($_POST['id']);
            $wpdb->update($table, $data, ['id' => $video_id]);
            wp_send_json_success('Video updated');
        } else {
            $wpdb->insert($table, $data);
            wp_send_json_success('Video added');
        }
    }
    
    /**
     * AJAX: Delete video
     */
    public function ajax_delete_video() {
        check_ajax_referer('psp_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }
        
        global $wpdb;
        $table = $wpdb->prefix . 'psp_videos';
        
        $video_id = isset($_POST['id']) ? absint($_POST['id']) : 0;
        
        if (!$video_id) {
            wp_send_json_error('Invalid video ID');
        }
        
        $wpdb->delete($table, ['id' => $video_id]);
        
        wp_send_json_success('Video deleted');
    }
}
