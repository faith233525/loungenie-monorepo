<?php
namespace PSP;

/**
 * Field Helpers
 * 
 * Provides dropdown options and field configurations
 * for consistent use across admin and portal
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Field_Helpers {

	/**
	 * Get US States dropdown options
	 */
	public static function get_us_states(): array {
		return array(
			'AL' => 'Alabama', 'AK' => 'Alaska', 'AZ' => 'Arizona', 'AR' => 'Arkansas', 'CA' => 'California',
			'CO' => 'Colorado', 'CT' => 'Connecticut', 'DE' => 'Delaware', 'FL' => 'Florida', 'GA' => 'Georgia',
			'HI' => 'Hawaii', 'ID' => 'Idaho', 'IL' => 'Illinois', 'IN' => 'Indiana', 'IA' => 'Iowa',
			'KS' => 'Kansas', 'KY' => 'Kentucky', 'LA' => 'Louisiana', 'ME' => 'Maine', 'MD' => 'Maryland',
			'MA' => 'Massachusetts', 'MI' => 'Michigan', 'MN' => 'Minnesota', 'MS' => 'Mississippi', 'MO' => 'Missouri',
			'MT' => 'Montana', 'NE' => 'Nebraska', 'NV' => 'Nevada', 'NH' => 'New Hampshire', 'NJ' => 'New Jersey',
			'NM' => 'New Mexico', 'NY' => 'New York', 'NC' => 'North Carolina', 'ND' => 'North Dakota', 'OH' => 'Ohio',
			'OK' => 'Oklahoma', 'OR' => 'Oregon', 'PA' => 'Pennsylvania', 'RI' => 'Rhode Island', 'SC' => 'South Carolina',
			'SD' => 'South Dakota', 'TN' => 'Tennessee', 'TX' => 'Texas', 'UT' => 'Utah', 'VT' => 'Vermont',
			'VA' => 'Virginia', 'WA' => 'Washington', 'WV' => 'West Virginia', 'WI' => 'Wisconsin', 'WY' => 'Wyoming'
		);
	}

	/**
	 * Get countries dropdown options
	 */
	public static function get_countries(): array {
		return array(
			'USA'                      => 'United States',
			'CAN'                      => 'Canada',
			'MEX'                      => 'Mexico',
			'JAM'                      => 'Jamaica',
			'BHS'                      => 'Bahamas',
			'TCA'                      => 'Turks & Caicos',
			'GBR'                      => 'United Kingdom',
			'__other__'                => 'Other/International',
		);
	}

	/**
	 * Get venue type options
	 */
	public static function get_venue_types(): array {
		return array(
			'hotel'      => 'Hotel',
			'resort'     => 'Resort',
			'waterpark'  => 'Waterpark',
			'surf_park'  => 'Surf Park',
			'custom'     => 'Custom',
		);
	}

	/**
	 * Get top colour options
	 */
	public static function get_top_colours(): array {
		return array(
			'Ice Blue',
			'Classic Blue',
			'BASF 4616 Yellow',
			'PoolSafe Orange',
			'Trojan Blue',
			'Lime Green',
			'Coral',
			'Yellow / Ice Blue',
			'Ice Blue / Yellow',
			'Ducati Red',
			'Yellow',
		);
	}

	/**
	 * Get lock type options
	 */
	public static function get_lock_types(): array {
		return array(
			'L&F'    => 'L&F Lock',
			'MAKE'   => 'MAKE Lock',
			'Custom' => 'Custom',
		);
	}

	/**
	 * Get operation type options
	 */
	public static function get_operation_types(): array {
		return array(
			'year_round' => 'Year Round',
			'seasonal'   => 'Seasonal',
		);
	}

	/**
	 * Get partner-visible fields (read-only)
	 */
	public static function get_partner_visible_fields(): array {
		return array(
			'company_name',
			'management_company',
			'street_address',
			'city',
			'state',
			'zip',
			'country',
			'company_email',
			'phone',
			'venue_type',
			'units',
			'top_colour',
			'installation_date',
			'operation_type',
			'seasonal_open_date',
			'seasonal_close_date',
			'is_active',
			'has_fb_call_button',
		);
	}

	/**
	 * Get support/admin-only fields
	 */
	public static function get_support_only_fields(): array {
		return array(
			'lock_type',
			'lock_make',
			'master_code',
			'sub_master_code',
			'lock_part',
			'key',
			'admin_password',
			'purchase_type',
			'revenue_share_details',
			'contract_reference',
		);
	}

	/**
	 * Get field labels
	 */
	public static function get_field_labels(): array {
		return array(
			'company_name'          => 'Company Name',
			'management_company'    => 'Management Company',
			'street_address'        => 'Street Address',
			'city'                  => 'City',
			'state'                 => 'State/Province',
			'zip'                   => 'Zip/Postal Code',
			'country'               => 'Country',
			'company_email'         => 'Company Email',
			'phone'                 => 'Phone Number',
			'venue_type'            => 'Venue Type',
			'units'                 => 'Number of Lounge Units',
			'top_colour'            => 'Top Colour',
			'installation_date'     => 'Installation Date',
			'operation_type'        => 'Operation Type',
			'seasonal_open_date'    => 'Season Open Date',
			'seasonal_close_date'   => 'Season Close Date',
			'is_active'             => 'Currently Active',
			'has_fb_call_button'    => 'F&B Call Button',
			'lock_type'             => 'Lock Type',
			'lock_make'             => 'Lock Make',
			'master_code'           => 'Master Code',
			'sub_master_code'       => 'Sub Master Code',
			'lock_part'             => 'Lock Part',
			'key'                   => 'Key',
			'primary_contact_name'  => 'Primary Contact Name',
			'primary_contact_email' => 'Primary Contact Email',
			'primary_contact_phone' => 'Primary Contact Phone',
		);
	}
}
