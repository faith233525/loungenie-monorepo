<?php
/**
 * Unified Portal API Wrapper
 *
 * Provides a consistent, streamlined interface for all portal API operations.
 * Eliminates duplication and ensures uniform response formats across the application.
 *
 * @package   PoolSafe Portal
 * @namespace PSP\API
 * @version   3.2.5
 */

namespace PSP\API;

use PSP\Data\UnifiedDataLayer;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Unified Portal API Wrapper
 *
 * Provides consistent API interface for:
 * - Ticket operations
 * - Partner management
 * - User data
 * - Notifications
 * - Dashboard queries
 */
class UnifiedAPIWrapper {

    /**
     * Standard success response format
     *
     * @param mixed $data Response data
     * @param string $message Optional message
     * @return array Standard response array
     */
    public static function success( $data, string $message = '' ): array {
        return array(
            'success' => true,
            'message' => $message,
            'data'    => $data,
            'timestamp' => current_time( 'mysql' ),
        );
    }

    /**
     * Standard error response format
     *
     * @param string $message Error message
     * @param string $code Error code
     * @param int $http_code HTTP status code
     * @return array Standard error response
     */
    public static function error( string $message, string $code = 'error', int $http_code = 400 ): array {
        return array(
            'success'   => false,
            'message'   => $message,
            'code'      => $code,
            'http_code' => $http_code,
            'timestamp' => current_time( 'mysql' ),
        );
    }

    /**
     * Get user dashboard data
     *
     * Unified endpoint providing all dashboard information
     *
     * @param int $user_id User ID
     * @return array Unified dashboard response
     */
    public static function get_user_dashboard( int $user_id ): array {
        try {
            if ( ! is_user_logged_in() || get_current_user_id() !== $user_id ) {
                return self::error( 'Unauthorized access', 'unauthorized', 403 );
            }

            $stats = UnifiedDataLayer::get_dashboard_stats( $user_id );
            $company = UnifiedDataLayer::get_user_company_info( $user_id );
            $recent_tickets = UnifiedDataLayer::get_user_tickets( $user_id, array( 'limit' => 5 ) );
            $notifications = UnifiedDataLayer::get_user_notifications( $user_id, array( 'unread_only' => true ) );

            return self::success( array(
                'user_id'         => $user_id,
                'company'         => $company,
                'statistics'      => $stats,
                'recent_tickets'  => array_map( array( __CLASS__, 'format_ticket' ), $recent_tickets ),
                'notifications'   => array_map( array( __CLASS__, 'format_notification' ), $notifications ),
            ), 'Dashboard data retrieved successfully' );
        } catch ( \Exception $e ) {
            error_log( '[PSP API] Get dashboard failed: ' . $e->getMessage() );
            return self::error( 'Failed to retrieve dashboard data', 'dashboard_error', 500 );
        }
    }

    /**
     * Get user tickets
     *
     * Unified endpoint for ticket retrieval
     *
     * @param int $user_id User ID
     * @param array $filters Query filters
     * @return array Unified response
     */
    public static function get_user_tickets( int $user_id, array $filters = array() ): array {
        try {
            if ( ! is_user_logged_in() || get_current_user_id() !== $user_id ) {
                return self::error( 'Unauthorized access', 'unauthorized', 403 );
            }

            $tickets = UnifiedDataLayer::get_user_tickets( $user_id, $filters );
            return self::success( 
                array_map( array( __CLASS__, 'format_ticket' ), $tickets ),
                'Tickets retrieved successfully'
            );
        } catch ( \Exception $e ) {
            error_log( '[PSP API] Get user tickets failed: ' . $e->getMessage() );
            return self::error( 'Failed to retrieve tickets', 'tickets_error', 500 );
        }
    }

    /**
     * Get single ticket
     *
     * @param int $user_id User ID (for authorization)
     * @param int $ticket_id Ticket ID
     * @return array Unified response
     */
    public static function get_ticket( int $user_id, int $ticket_id ): array {
        try {
            if ( ! is_user_logged_in() || get_current_user_id() !== $user_id ) {
                return self::error( 'Unauthorized access', 'unauthorized', 403 );
            }

            $ticket = UnifiedDataLayer::get_ticket( $ticket_id );
            if ( ! $ticket ) {
                return self::error( 'Ticket not found', 'not_found', 404 );
            }

            return self::success( 
                self::format_ticket( $ticket ),
                'Ticket retrieved successfully'
            );
        } catch ( \Exception $e ) {
            error_log( '[PSP API] Get ticket failed: ' . $e->getMessage() );
            return self::error( 'Failed to retrieve ticket', 'ticket_error', 500 );
        }
    }

    /**
     * Get partner/company info
     *
     * @param int $partner_id Partner ID
     * @return array Unified response
     */
    public static function get_partner( int $partner_id ): array {
        try {
            if ( ! is_user_logged_in() ) {
                return self::error( 'Unauthorized access', 'unauthorized', 403 );
            }

            $partner = UnifiedDataLayer::get_partner( $partner_id );
            if ( ! $partner ) {
                return self::error( 'Partner not found', 'not_found', 404 );
            }

            $contacts = UnifiedDataLayer::get_company_contacts( $partner_id );

            return self::success( array(
                'partner'  => self::format_partner( $partner ),
                'contacts' => array_map( array( __CLASS__, 'format_contact' ), $contacts ),
            ), 'Partner data retrieved successfully' );
        } catch ( \Exception $e ) {
            error_log( '[PSP API] Get partner failed: ' . $e->getMessage() );
            return self::error( 'Failed to retrieve partner', 'partner_error', 500 );
        }
    }

    /**
     * Get all partners with pagination
     *
     * @param int $page Page number (1-based)
     * @param int $per_page Items per page
     * @return array Unified response
     */
    public static function get_partners( int $page = 1, int $per_page = 20 ): array {
        try {
            if ( ! is_user_logged_in() ) {
                return self::error( 'Unauthorized access', 'unauthorized', 403 );
            }

            $offset = ( $page - 1 ) * $per_page;
            $partners = UnifiedDataLayer::get_partners( array(
                'limit'  => $per_page,
                'offset' => $offset,
            ) );

            return self::success( array(
                'items'       => array_map( array( __CLASS__, 'format_partner' ), $partners ),
                'page'        => $page,
                'per_page'    => $per_page,
                'total_count' => wp_count_posts( 'psp_company' )->publish ?? 0,
            ), 'Partners retrieved successfully' );
        } catch ( \Exception $e ) {
            error_log( '[PSP API] Get partners failed: ' . $e->getMessage() );
            return self::error( 'Failed to retrieve partners', 'partners_error', 500 );
        }
    }

    /**
     * Format ticket for API response
     *
     * @param object|array $ticket Post object or array
     * @return array Formatted ticket data
     */
    public static function format_ticket( $ticket ): array {
        try {
            if ( is_array( $ticket ) ) {
                // Handle array input
                return array(
                    'id'           => $ticket['ID'] ?? 0,
                    'title'        => $ticket['post_title'] ?? '',
                    'content'      => $ticket['post_content'] ?? '',
                    'status'       => $ticket['psp_status'] ?? 'new',
                    'priority'     => $ticket['psp_priority'] ?? 'normal',
                    'company_id'   => $ticket['psp_company_id'] ?? 0,
                    'assigned_to'  => $ticket['psp_assigned_to'] ?? 0,
                    'created'      => $ticket['post_date'] ?? '',
                    'modified'     => $ticket['post_modified'] ?? '',
                );
            }

            // Handle post object input
            return array(
                'id'           => (int) $ticket->ID,
                'title'        => (string) $ticket->post_title,
                'content'      => (string) $ticket->post_content,
                'status'       => (string) get_post_meta( $ticket->ID, 'psp_status', true ) ?: 'new',
                'priority'     => (string) get_post_meta( $ticket->ID, 'psp_priority', true ) ?: 'normal',
                'company_id'   => (int) get_post_meta( $ticket->ID, 'psp_company_id', true ) ?: 0,
                'assigned_to'  => (int) get_post_meta( $ticket->ID, 'psp_assigned_to', true ) ?: 0,
                'created'      => (string) $ticket->post_date,
                'modified'     => (string) $ticket->post_modified,
            );
        } catch ( \Exception $e ) {
            error_log( '[PSP API] Format ticket failed: ' . $e->getMessage() );
            return array();
        }
    }

    /**
     * Format partner for API response
     *
     * @param object|array $partner Post object or array
     * @return array Formatted partner data
     */
    public static function format_partner( $partner ): array {
        try {
            if ( is_array( $partner ) ) {
                // Handle array input
                return array(
                    'id'          => $partner['ID'] ?? 0,
                    'name'        => $partner['post_title'] ?? '',
                    'description' => $partner['post_content'] ?? '',
                    'contact'     => $partner['psp_contact_email'] ?? '',
                    'phone'       => $partner['psp_contact_phone'] ?? '',
                    'website'     => $partner['psp_website'] ?? '',
                    'region'      => $partner['psp_region'] ?? '',
                    'status'      => $partner['post_status'] ?? 'draft',
                );
            }

            // Handle post object input
            return array(
                'id'          => (int) $partner->ID,
                'name'        => (string) $partner->post_title,
                'description' => (string) $partner->post_content,
                'contact'     => (string) get_post_meta( $partner->ID, 'psp_contact_email', true ) ?: '',
                'phone'       => (string) get_post_meta( $partner->ID, 'psp_contact_phone', true ) ?: '',
                'website'     => (string) get_post_meta( $partner->ID, 'psp_website', true ) ?: '',
                'region'      => (string) get_post_meta( $partner->ID, 'psp_region', true ) ?: '',
                'status'      => (string) $partner->post_status,
            );
        } catch ( \Exception $e ) {
            error_log( '[PSP API] Format partner failed: ' . $e->getMessage() );
            return array();
        }
    }

    /**
     * Format contact for API response
     *
     * @param object|array $contact Post object or array
     * @return array Formatted contact data
     */
    public static function format_contact( $contact ): array {
        try {
            if ( is_array( $contact ) ) {
                // Handle array input
                return array(
                    'id'         => $contact['ID'] ?? 0,
                    'name'       => $contact['post_title'] ?? '',
                    'email'      => $contact['psp_email'] ?? '',
                    'phone'      => $contact['psp_phone'] ?? '',
                    'role'       => $contact['psp_role'] ?? '',
                    'is_primary' => (bool) ( $contact['psp_is_primary'] ?? false ),
                );
            }

            // Handle post object input
            return array(
                'id'         => (int) $contact->ID,
                'name'       => (string) $contact->post_title,
                'email'      => (string) get_post_meta( $contact->ID, 'psp_email', true ) ?: '',
                'phone'      => (string) get_post_meta( $contact->ID, 'psp_phone', true ) ?: '',
                'role'       => (string) get_post_meta( $contact->ID, 'psp_role', true ) ?: '',
                'is_primary' => (bool) get_post_meta( $contact->ID, 'psp_is_primary', true ),
            );
        } catch ( \Exception $e ) {
            error_log( '[PSP API] Format contact failed: ' . $e->getMessage() );
            return array();
        }
    }

    /**
     * Format notification for API response
     *
     * @param object|array $notification Post object or array
     * @return array Formatted notification data
     */
    public static function format_notification( $notification ): array {
        try {
            if ( is_array( $notification ) ) {
                // Handle array input
                return array(
                    'id'      => $notification['ID'] ?? 0,
                    'message' => $notification['post_title'] ?? '',
                    'type'    => $notification['psp_type'] ?? 'info',
                    'read'    => (bool) ( $notification['psp_read'] ?? false ),
                    'created' => $notification['post_date'] ?? '',
                );
            }

            // Handle post object input
            return array(
                'id'      => (int) $notification->ID,
                'message' => (string) $notification->post_title,
                'type'    => (string) get_post_meta( $notification->ID, 'psp_type', true ) ?: 'info',
                'read'    => (bool) get_post_meta( $notification->ID, 'psp_read', true ),
                'created' => (string) $notification->post_date,
            );
        } catch ( \Exception $e ) {
            error_log( '[PSP API] Format notification failed: ' . $e->getMessage() );
            return array();
        }
    }

    /**
     * Initialize the API wrapper
     *
     * @return void
     */
    public static function init(): void {
        try {
            // Register hooks if needed for API initialization
            // Add cache clearing on relevant post updates
            add_action( 'save_post_psp_ticket', array( __CLASS__, 'clear_ticket_cache' ), 10, 1 );
            add_action( 'save_post_psp_company', array( __CLASS__, 'clear_partner_cache' ), 10, 1 );
            add_action( 'save_post_psp_contact', array( __CLASS__, 'clear_contact_cache' ), 10, 1 );
            add_action( 'save_post_psp_notification', array( __CLASS__, 'clear_notification_cache' ), 10, 1 );
        } catch ( \Exception $e ) {
            error_log( '[PSP API Wrapper] Initialization failed: ' . $e->getMessage() );
        }
    }

    /**
     * Clear ticket cache on update
     *
     * @param int $post_id Post ID
     * @return void
     */
    public static function clear_ticket_cache( int $post_id ): void {
        try {
            UnifiedDataLayer::clear_cache( 'tickets_' . $post_id );
            UnifiedDataLayer::clear_cache( 'all_tickets' );
        } catch ( \Exception $e ) {
            error_log( '[PSP API] Clear ticket cache failed: ' . $e->getMessage() );
        }
    }

    /**
     * Clear partner cache on update
     *
     * @param int $post_id Post ID
     * @return void
     */
    public static function clear_partner_cache( int $post_id ): void {
        try {
            UnifiedDataLayer::clear_cache( 'partners_' . $post_id );
            UnifiedDataLayer::clear_cache( 'all_partners' );
        } catch ( \Exception $e ) {
            error_log( '[PSP API] Clear partner cache failed: ' . $e->getMessage() );
        }
    }

    /**
     * Clear contact cache on update
     *
     * @param int $post_id Post ID
     * @return void
     */
    public static function clear_contact_cache( int $post_id ): void {
        try {
            $company_id = get_post_meta( $post_id, 'psp_company_id', true );
            if ( $company_id ) {
                UnifiedDataLayer::clear_cache( 'contacts_company_' . $company_id );
            }
            UnifiedDataLayer::clear_cache( 'contacts_' . $post_id );
        } catch ( \Exception $e ) {
            error_log( '[PSP API] Clear contact cache failed: ' . $e->getMessage() );
        }
    }

    /**
     * Clear notification cache on update
     *
     * @param int $post_id Post ID
     * @return void
     */
    public static function clear_notification_cache( int $post_id ): void {
        try {
            $user_id = get_post_meta( $post_id, 'psp_user_id', true );
            if ( $user_id ) {
                UnifiedDataLayer::clear_cache( 'notifications_user_' . $user_id );
            }
        } catch ( \Exception $e ) {
            error_log( '[PSP API] Clear notification cache failed: ' . $e->getMessage() );
        }
    }

    /**
     * Add pagination metadata to response
     *
     * @param array $items Items to paginate
     * @param int $page Page number
     * @param int $per_page Items per page
     * @return array Paginated response
     */
    public static function paginate_response( array $items, int $page = 1, int $per_page = 20 ): array {
        try {
            $paginated = UnifiedDataLayer::paginate( $items, $page, $per_page );
            return self::success( $paginated, 'Paginated results' );
        } catch ( \Exception $e ) {
            error_log( '[PSP API] Pagination response failed: ' . $e->getMessage() );
            return self::error( 'Failed to paginate results', 'pagination_error', 500 );
        }
    }

    /**
     * Filter fields from response
     *
     * @param array $item Item data
     * @param array|null $fields Fields to include (null = all)
     * @return array Filtered item
     */
    public static function filter_fields( array $item, ?array $fields = null ): array {
        try {
            if ( $fields === null ) {
                return $item;
            }

            $filtered = array();
            foreach ( $fields as $field ) {
                if ( isset( $item[ $field ] ) ) {
                    $filtered[ $field ] = $item[ $field ];
                }
            }

            return $filtered;
        } catch ( \Exception $e ) {
            error_log( '[PSP API] Field filtering failed: ' . $e->getMessage() );
            return $item;
        }
    }

    /**
     * Compress response with field filtering
     *
     * @param array $items Items to compress
     * @param array|null $fields Fields to include
     * @return array Compressed items
     */
    public static function compress_response( array $items, ?array $fields = null ): array {
        try {
            if ( $fields === null ) {
                return $items;
            }

            return array_map(
                fn( $item ) => self::filter_fields( $item, $fields ),
                $items
            );
        } catch ( \Exception $e ) {
            error_log( '[PSP API] Response compression failed: ' . $e->getMessage() );
            return $items;
        }
    }

    /**
     * Batch get with response formatting
     *
     * @param array $ids Item IDs
     * @param string $post_type Post type
     * @param string $format_method Format method (format_ticket, format_partner, etc)
     * @return array Formatted responses
     */
    public static function batch_get_formatted( array $ids, string $post_type, string $format_method ): array {
        try {
            if ( ! method_exists( __CLASS__, $format_method ) ) {
                return array();
            }

            $items = UnifiedDataLayer::batch_get( $ids, $post_type );
            return array_map(
                fn( $item ) => self::$format_method( $item ),
                $items
            );
        } catch ( \Exception $e ) {
            error_log( '[PSP API] Batch get formatted failed: ' . $e->getMessage() );
            return array();
        }
    }
}
