<?php
/**
 * Training Videos Admin Page
 */

if (!defined('ABSPATH')) exit;

// Ensure variables are set
if (!isset($videos)) $videos = [];
if (!isset($categories)) $categories = [];

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_video'])) {
        global $wpdb;
        $table = $wpdb->prefix . 'psp_videos';
        
        $wpdb->insert($table, [
            'title' => sanitize_text_field($_POST['title']),
            'description' => wp_kses_post($_POST['description']),
            'video_url' => esc_url_raw($_POST['video_url']),
            'video_type' => sanitize_text_field($_POST['video_type']),
            'thumbnail_url' => esc_url_raw($_POST['thumbnail_url']),
            'category_id' => intval($_POST['category_id']),
            'access_level' => sanitize_text_field($_POST['access_level']),
            'duration' => intval($_POST['duration']),
            'status' => sanitize_text_field($_POST['status'])
        ]);
        
        echo '<div class="notice notice-success"><p>Video added successfully!</p></div>';
    }
    
    if (isset($_POST['add_category'])) {
        global $wpdb;
        $table = $wpdb->prefix . 'psp_video_categories';
        
        $wpdb->insert($table, [
            'name' => sanitize_text_field($_POST['category_name']),
            'slug' => sanitize_title($_POST['category_name']),
            'description' => sanitize_text_field($_POST['category_description'])
        ]);
        
        echo '<div class="notice notice-success"><p>Category added successfully!</p></div>';
    }
}

// Handle deletions
if (isset($_GET['delete_video'])) {
    global $wpdb;
    $wpdb->delete($wpdb->prefix . 'psp_videos', ['id' => intval($_GET['delete_video'])]);
    echo '<div class="notice notice-success"><p>Video deleted!</p></div>';
}
?>

<div class="wrap psp-videos-admin">
    <h1><i class="dashicons dashicons-video-alt3"></i> Training Videos Management</h1>
    
    <div class="psp-admin-tabs">
        <a href="#all-videos" class="nav-tab nav-tab-active">All Videos</a>
        <a href="#add-video" class="nav-tab">Add Video</a>
        <a href="#categories" class="nav-tab">Categories</a>
    </div>
    
    <!-- All Videos Tab -->
    <div id="all-videos" class="tab-content active">
        <h2>All Training Videos</h2>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th width="80">Thumbnail</th>
                    <th>Title</th>
                    <th>Category</th>
                    <th>Type</th>
                    <th>Views</th>
                    <th>Access</th>
                    <th>Status</th>
                    <th width="150">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($videos)): ?>
                    <tr>
                        <td colspan="8" style="text-align:center;">No videos yet. Add your first training video!</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($videos as $video): ?>
                    <tr>
                        <td>
                            <?php if ($video->thumbnail_url): ?>
                                <img src="<?php echo esc_url($video->thumbnail_url); ?>" width="80" height="60" style="object-fit:cover;border-radius:4px;">
                            <?php else: ?>
                                <div style="width:80px;height:60px;background:#ddd;border-radius:4px;display:flex;align-items:center;justify-content:center;">
                                    <span class="dashicons dashicons-video-alt3" style="font-size:30px;color:#666;"></span>
                                </div>
                            <?php endif; ?>
                        </td>
                        <td>
                            <strong><?php echo esc_html($video->title); ?></strong>
                            <?php if ($video->description): ?>
                                <br><small><?php echo wp_trim_words($video->description, 10); ?></small>
                            <?php endif; ?>
                        </td>
                        <td><?php echo esc_html($video->category_name ?: 'Uncategorized'); ?></td>
                        <td>
                            <span class="badge badge-<?php echo $video->video_type; ?>">
                                <?php echo ucfirst($video->video_type); ?>
                            </span>
                        </td>
                        <td><?php echo number_format($video->view_count); ?> views</td>
                        <td><?php echo ucfirst($video->access_level); ?></td>
                        <td>
                            <span class="status-<?php echo $video->status; ?>">
                                <?php echo ucfirst($video->status); ?>
                            </span>
                        </td>
                        <td>
                            <a href="<?php echo esc_url($video->video_url); ?>" target="_blank" class="button button-small">Preview</a>
                            <a href="?page=poolsafe-videos&delete_video=<?php echo $video->id; ?>" 
                               class="button button-small button-link-delete" 
                               onclick="return confirm('Delete this video?')">Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    
    <!-- Add Video Tab -->
    <div id="add-video" class="tab-content" style="display:none;">
        <h2>Add Training Video</h2>
        <form method="post" class="psp-admin-form">
            <table class="form-table">
                <tr>
                    <th><label for="title">Video Title *</label></th>
                    <td><input type="text" name="title" id="title" required class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="description">Description</label></th>
                    <td>
                        <textarea name="description" id="description" rows="4" class="large-text"></textarea>
                        <p class="description">Brief description of what the video covers.</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="video_type">Video Source *</label></th>
                    <td>
                        <select name="video_type" id="video_type" required>
                            <option value="youtube">YouTube URL</option>
                            <option value="vimeo">Vimeo URL</option>
                            <option value="upload">Direct Upload (MP4)</option>
                        </select>
                        <p class="description">Choose where your video is hosted.</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="video_url">Video URL *</label></th>
                    <td>
                        <input type="url" name="video_url" id="video_url" required class="regular-text">
                        <p class="description">
                            <strong>YouTube:</strong> https://www.youtube.com/watch?v=VIDEO_ID<br>
                            <strong>Vimeo:</strong> https://vimeo.com/VIDEO_ID<br>
                            <strong>Upload:</strong> Upload to WordPress Media Library and paste URL
                        </p>
                    </td>
                </tr>
                <tr>
                    <th><label for="thumbnail_url">Thumbnail URL</label></th>
                    <td>
                        <input type="url" name="thumbnail_url" id="thumbnail_url" class="regular-text">
                        <p class="description">Optional. Auto-generated from YouTube/Vimeo if left blank.</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="category_id">Category</label></th>
                    <td>
                        <select name="category_id" id="category_id">
                            <option value="">Select Category</option>
                            <?php foreach ($categories as $cat): ?>
                                <option value="<?php echo $cat->id; ?>"><?php echo esc_html($cat->name); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th><label for="duration">Duration (seconds)</label></th>
                    <td>
                        <input type="number" name="duration" id="duration" value="0" min="0">
                        <p class="description">Video length in seconds (e.g., 120 for 2 minutes).</p>
                    </td>
                </tr>
                <tr>
                    <th><label for="access_level">Access Level</label></th>
                    <td>
                        <select name="access_level" id="access_level">
                            <option value="all">All Partners</option>
                            <option value="partner">Partners Only</option>
                            <option value="admin">Admins Only</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th><label for="status">Status</label></th>
                    <td>
                        <select name="status" id="status">
                            <option value="published">Published</option>
                            <option value="draft">Draft</option>
                        </select>
                    </td>
                </tr>
            </table>
            
            <p class="submit">
                <button type="submit" name="add_video" class="button button-primary">Add Video</button>
            </p>
        </form>
    </div>
    
    <!-- Categories Tab -->
    <div id="categories" class="tab-content" style="display:none;">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:30px;">
            <div>
                <h2>Add Category</h2>
                <form method="post" class="psp-admin-form">
                    <table class="form-table">
                        <tr>
                            <th><label for="category_name">Category Name *</label></th>
                            <td><input type="text" name="category_name" id="category_name" required class="regular-text"></td>
                        </tr>
                        <tr>
                            <th><label for="category_description">Description</label></th>
                            <td><textarea name="category_description" id="category_description" rows="3" class="large-text"></textarea></td>
                        </tr>
                    </table>
                    <p class="submit">
                        <button type="submit" name="add_category" class="button button-primary">Add Category</button>
                    </p>
                </form>
            </div>
            
            <div>
                <h2>Existing Categories</h2>
                <table class="wp-list-table widefat striped">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Description</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($categories as $cat): ?>
                        <tr>
                            <td><strong><?php echo esc_html($cat->name); ?></strong></td>
                            <td><?php echo esc_html($cat->description); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<style>
.psp-videos-admin .psp-admin-tabs {
    border-bottom: 1px solid #ccc;
    margin-bottom: 20px;
}

.psp-videos-admin .nav-tab {
    margin-bottom: -1px;
}

.psp-videos-admin .tab-content {
    background: #fff;
    padding: 20px;
    border: 1px solid #ccc;
    border-top: none;
}

.psp-videos-admin .badge {
    display: inline-block;
    padding: 3px 8px;
    border-radius: 3px;
    font-size: 12px;
    font-weight: 500;
}

.badge-youtube { background: #ff0000; color: #fff; }
.badge-vimeo { background: #1ab7ea; color: #fff; }
.badge-upload { background: #0073aa; color: #fff; }

.status-published { color: #46b450; font-weight: 500; }
.status-draft { color: #999; }
</style>

<script>
jQuery(document).ready(function($) {
    // Tab switching
    $('.psp-admin-tabs .nav-tab').on('click', function(e) {
        e.preventDefault();
        var target = $(this).attr('href');
        
        $('.nav-tab').removeClass('nav-tab-active');
        $(this).addClass('nav-tab-active');
        
        $('.tab-content').hide();
        $(target).show();
    });
});
</script>
