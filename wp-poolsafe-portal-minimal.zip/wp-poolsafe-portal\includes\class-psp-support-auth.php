<?php
namespace PSP;

if (!defined('ABSPATH')) exit;

/**
 * Microsoft 365 SSO Authentication for Support Users
 */
class Support_Auth {
    
    private static $client_id;
    private static $client_secret;
    private static $tenant_id;
    private static $redirect_uri;

    public static function init() {
        self::$client_id = get_option('psp_m365_client_id');
        self::$client_secret = get_option('psp_m365_client_secret');
        self::$tenant_id = get_option('psp_m365_tenant_id', 'common');
        self::$redirect_uri = admin_url('admin-ajax.php?action=psp_m365_callback');

        add_action('wp_ajax_nopriv_psp_m365_callback', [self::class, 'handle_callback']);
        add_action('rest_api_init', [self::class, 'register_routes']);
    }

    public static function register_routes() {
        register_rest_route('psp/v1', '/auth/support/login-url', [
            'methods' => 'GET',
            'callback' => [self::class, 'get_login_url'],
            'permission_callback' => '__return_true',
        ]);
    }

    public static function get_login_url() {
        if (empty(self::$client_id)) {
            return new \WP_REST_Response([
                'error' => 'Microsoft 365 not configured'
            ], 500);
        }

        $state = bin2hex(random_bytes(16));
        set_transient('psp_m365_state_' . $state, true, 600);

        $params = [
            'client_id' => self::$client_id,
            'response_type' => 'code',
            'redirect_uri' => self::$redirect_uri,
            'response_mode' => 'query',
            'scope' => 'openid profile email User.Read',
            'state' => $state,
        ];

        $auth_url = 'https://login.microsoftonline.com/' . self::$tenant_id . '/oauth2/v2.0/authorize?' . http_build_query($params);

        return new \WP_REST_Response(['url' => $auth_url], 200);
    }

    public static function handle_callback() {
        $code = $_GET['code'] ?? null;
        $state = $_GET['state'] ?? null;

        if (!$code || !$state || !get_transient('psp_m365_state_' . $state)) {
            wp_die('Invalid OAuth state');
        }

        delete_transient('psp_m365_state_' . $state);

        $token_response = self::exchange_code_for_token($code);
        
        if (!$token_response) {
            wp_die('Failed to obtain access token');
        }

        $user_info = self::get_user_info($token_response['access_token']);
        
        if (!$user_info) {
            wp_die('Failed to get user info');
        }

        // Find or create WP user
        $wp_user = get_user_by('email', $user_info['email']);
        
        if (!$wp_user) {
            $user_id = wp_create_user(
                sanitize_user($user_info['email']),
                wp_generate_password(32),
                $user_info['email']
            );
            
            if (is_wp_error($user_id)) {
                wp_die('Failed to create user account');
            }
            
            $wp_user = get_user_by('id', $user_id);
            $wp_user->set_role('psp_support');
            
            wp_update_user([
                'ID' => $user_id,
                'display_name' => $user_info['name'],
                'first_name' => $user_info['given_name'] ?? '',
                'last_name' => $user_info['family_name'] ?? '',
            ]);
        }

        // Create PSP session
        $session = Company_Auth::create_session($wp_user->ID, 'support');

        // Redirect to portal
        $portal_url = home_url('/portal'); // Adjust as needed
        wp_redirect(add_query_arg('login', 'success', $portal_url));
        exit;
    }

    private static function exchange_code_for_token($code) {
        $token_url = 'https://login.microsoftonline.com/' . self::$tenant_id . '/oauth2/v2.0/token';

        $response = wp_remote_post($token_url, [
            'body' => [
                'client_id' => self::$client_id,
                'client_secret' => self::$client_secret,
                'code' => $code,
                'redirect_uri' => self::$redirect_uri,
                'grant_type' => 'authorization_code',
            ]
        ]);

        if (is_wp_error($response)) {
            return false;
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);
        return $body;
    }

    private static function get_user_info($access_token) {
        $response = wp_remote_get('https://graph.microsoft.com/v1.0/me', [
            'headers' => [
                'Authorization' => 'Bearer ' . $access_token,
            ]
        ]);

        if (is_wp_error($response)) {
            return false;
        }

        $user_info = json_decode(wp_remote_retrieve_body($response), true);
        
        return [
            'email' => $user_info['mail'] ?? $user_info['userPrincipalName'],
            'name' => $user_info['displayName'],
            'given_name' => $user_info['givenName'] ?? '',
            'family_name' => $user_info['surname'] ?? '',
        ];
    }
}
