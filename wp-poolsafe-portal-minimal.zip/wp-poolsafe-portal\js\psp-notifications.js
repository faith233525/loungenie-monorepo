/**
 * PoolSafe Portal - Unified Notification System
 * Toast notifications and modal alerts for all portal actions
 */

const PSPNotify = {
    container: null,

    init() {
        if (!this.container) {
            this.createContainer();
        }
    },

    createContainer() {
        const container = document.createElement('div');
        container.id = 'psp-toast-container';
        container.className = 'psp-toast-container';
        container.setAttribute('aria-live', 'polite');
        container.setAttribute('aria-atomic', 'true');
        document.body.appendChild(container);
        this.container = container;
    },

    /**
     * Show success toast
     * @param {string} message 
     * @param {number} duration - milliseconds (default 4000)
     */
    success(message, duration = 4000) {
        this.show(message, 'success', duration);
    },

    /**
     * Show error toast
     * @param {string} message 
     * @param {number} duration - milliseconds (default 6000)
     */
    error(message, duration = 6000) {
        this.show(message, 'error', duration);
    },

    /**
     * Show info toast
     * @param {string} message 
     * @param {number} duration - milliseconds (default 4000)
     */
    info(message, duration = 4000) {
        this.show(message, 'info', duration);
    },

    /**
     * Show warning toast
     * @param {string} message 
     * @param {number} duration - milliseconds (default 5000)
     */
    warning(message, duration = 5000) {
        this.show(message, 'warning', duration);
    },

    /**
     * Show toast notification
     * @param {string} message 
     * @param {string} type - success|error|info|warning
     * @param {number} duration 
     */
    show(message, type = 'info', duration = 4000) {
        if (!this.container) this.init();

        const toast = document.createElement('div');
        toast.className = `psp-toast psp-toast-${type}`;
        toast.setAttribute('role', 'alert');

        const icons = {
            success: '✓',
            error: '✕',
            info: 'ⓘ',
            warning: '⚠'
        };

        toast.innerHTML = `
      <div class="psp-toast-icon">${icons[type] || icons.info}</div>
      <div class="psp-toast-message">${this.escapeHtml(message)}</div>
      <button class="psp-toast-close" aria-label="Close notification">×</button>
    `;

        const closeBtn = toast.querySelector('.psp-toast-close');
        closeBtn.addEventListener('click', () => this.dismiss(toast));

        this.container.appendChild(toast);

        // Animate in
        requestAnimationFrame(() => {
            toast.classList.add('psp-toast-show');
        });

        // Auto dismiss
        if (duration > 0) {
            setTimeout(() => this.dismiss(toast), duration);
        }

        return toast;
    },

    /**
     * Dismiss a toast
     * @param {HTMLElement} toast 
     */
    dismiss(toast) {
        toast.classList.remove('psp-toast-show');
        toast.classList.add('psp-toast-hide');

        setTimeout(() => {
            if (toast.parentNode) {
                toast.parentNode.removeChild(toast);
            }
        }, 300);
    },

    /**
     * Show confirmation modal
     * @param {string} title 
     * @param {string} message 
     * @param {Function} onConfirm 
     * @param {Function} onCancel 
     */
    confirm(title, message, onConfirm, onCancel = null) {
        const modal = document.createElement('div');
        modal.className = 'psp-modal-overlay';
        modal.setAttribute('role', 'dialog');
        modal.setAttribute('aria-modal', 'true');
        modal.setAttribute('aria-labelledby', 'psp-confirm-title');

        modal.innerHTML = `
      <div class="psp-modal psp-confirm-modal">
        <div class="psp-modal-header">
          <h3 id="psp-confirm-title">${this.escapeHtml(title)}</h3>
        </div>
        <div class="psp-modal-body">
          <p>${this.escapeHtml(message)}</p>
        </div>
        <div class="psp-modal-footer">
          <button class="psp-btn psp-btn-ghost psp-confirm-cancel">Cancel</button>
          <button class="psp-btn psp-btn-primary psp-confirm-ok">Confirm</button>
        </div>
      </div>
    `;

        document.body.appendChild(modal);

        const okBtn = modal.querySelector('.psp-confirm-ok');
        const cancelBtn = modal.querySelector('.psp-confirm-cancel');

        const cleanup = () => {
            modal.classList.add('psp-modal-closing');
            setTimeout(() => {
                if (modal.parentNode) {
                    modal.parentNode.removeChild(modal);
                }
            }, 200);
        };

        okBtn.addEventListener('click', () => {
            cleanup();
            if (onConfirm) onConfirm();
        });

        cancelBtn.addEventListener('click', () => {
            cleanup();
            if (onCancel) onCancel();
        });

        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                cleanup();
                if (onCancel) onCancel();
            }
        });

        // Focus trap
        okBtn.focus();

        // Keyboard navigation
        modal.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                cleanup();
                if (onCancel) onCancel();
            } else if (e.key === 'Tab') {
                e.preventDefault();
                if (document.activeElement === okBtn) {
                    cancelBtn.focus();
                } else {
                    okBtn.focus();
                }
            }
        });

        return modal;
    },

    /**
     * Show alert modal
     * @param {string} title 
     * @param {string} message 
     * @param {string} type - success|error|info|warning
     */
    alert(title, message, type = 'info') {
        const modal = document.createElement('div');
        modal.className = 'psp-modal-overlay';
        modal.setAttribute('role', 'alertdialog');
        modal.setAttribute('aria-modal', 'true');
        modal.setAttribute('aria-labelledby', 'psp-alert-title');

        const icons = {
            success: '✓',
            error: '✕',
            info: 'ⓘ',
            warning: '⚠'
        };

        modal.innerHTML = `
      <div class="psp-modal psp-alert-modal psp-alert-${type}">
        <div class="psp-modal-header">
          <span class="psp-alert-icon">${icons[type] || icons.info}</span>
          <h3 id="psp-alert-title">${this.escapeHtml(title)}</h3>
        </div>
        <div class="psp-modal-body">
          <p>${this.escapeHtml(message)}</p>
        </div>
        <div class="psp-modal-footer">
          <button class="psp-btn psp-btn-primary psp-alert-ok">OK</button>
        </div>
      </div>
    `;

        document.body.appendChild(modal);

        const okBtn = modal.querySelector('.psp-alert-ok');
        okBtn.focus();

        const cleanup = () => {
            modal.classList.add('psp-modal-closing');
            setTimeout(() => {
                if (modal.parentNode) {
                    modal.parentNode.removeChild(modal);
                }
            }, 200);
        };

        okBtn.addEventListener('click', cleanup);

        modal.addEventListener('click', (e) => {
            if (e.target === modal) cleanup();
        });

        modal.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' || e.key === 'Enter') {
                cleanup();
            }
        });

        return modal;
    },

    escapeHtml(str) {
        const div = document.createElement('div');
        div.textContent = str;
        return div.innerHTML;
    }
};

// Auto-initialize on DOM ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => PSPNotify.init());
} else {
    PSPNotify.init();
}

// Expose globally
window.PSPNotify = PSPNotify;
