<?php
/**
 * Main Plugin Orchestrator Class
 *
 * Handles initialization, orchestration, and lifecycle management
 * for all PoolSafe Portal components with comprehensive error handling
 * and logging capabilities.
 *
 * @package   PoolSafe Portal
 * @namespace PSP
 * @version   3.2.5
 */

namespace PSP;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Plugin Class
 *
 * Main orchestrator for PoolSafe Portal. Responsible for:
 * - Registering custom post types (CPTs)
 * - Initializing plugin components with error handling
 * - Managing plugin lifecycle (activation/deactivation)
 * - Loading translations
 * - Setting up capabilities and roles
 * - Component dependency checking
 * - Performance monitoring
 * - Unified component registry and initialization
 */
class Plugin {

    /**
     * Plugin initialization status
     *
     * @var bool
     */
    private static $initialized = false;

    /**
     * Initialization errors
     *
     * @var array
     */
    private static $errors = array();

    /**
     * Registered components for centralized initialization
     *
     * @var array
     */
    private static $components = array();

    /**
     * Run all plugin initialization
     *
     * Sets up hooks for:
     * - Internationalization (i18n)
     * - Custom post type registration
     * - Capability registration
     * - Component initialization
     * - Error handling and recovery
     *
     * @return void
     */
    public function run(): void {
        try {
            // Load text domain for translations on plugins_loaded hook
            // This ensures translations are available before any init hooks run
            add_action(
                'plugins_loaded',
                function () {
                    try {
                        load_plugin_textdomain( 'psp', false, dirname( plugin_basename( PSP_PLUGIN_FILE ) ) . '/languages' );
                    } catch ( \Exception $e ) {
                        self::log_error( 'Failed to load text domain', $e );
                    }
                },
                1
            );

            // Register custom capabilities and roles with error handling
            add_action(
                'init',
                function () {
                    if ( class_exists( Roles::class ) ) {
                        try {
                            Roles::register_caps();
                        } catch ( \Exception $e ) {
                            self::log_error( 'Failed to register roles', $e );
                        }
                    }
                }
            );

            // Register custom post types with error handling
            add_action(
                'init',
                function () {
                    $cpts = array(
                        'Tickets'       => Tickets::class,
                        'Partners'      => Partners::class,
                        'Notifications' => Notifications::class,
                        'Calendar'      => Calendar::class,
                    );

                    foreach ( $cpts as $name => $class ) {
                        if ( class_exists( $class ) ) {
                            try {
                                call_user_func( array( $class, 'register_cpt' ) );
                            } catch ( \Exception $e ) {
                                self::log_error( "Failed to register CPT: {$name}", $e );
                            }
                        }
                    }
                }
            );

            // Initialize plugin components
            add_action( 'init', array( __CLASS__, 'init' ), 20 );

            // Run security initialization
            add_action( 'plugins_loaded', array( __CLASS__, 'init_security' ), 5 );

            // Initialize performance monitoring
            add_action( 'plugins_loaded', array( __CLASS__, 'init_performance' ), 5 );

            // Register and initialize all components
            add_action( 'plugins_loaded', array( __CLASS__, 'register_components' ), 8 );
            add_action( 'init', array( __CLASS__, 'init_all_components' ), 15 );

        } catch ( \Exception $e ) {
            self::log_error( 'Plugin run() failed', $e );
        }
    }

    /**
     * Register all plugin components for unified initialization
     *
     * Centralizes component registration for better maintainability
     * and lifecycle management.
     *
     * @return void
     */
    public static function register_components(): void {
        try {
            // Core components (always needed)
            self::register_component( 'Logger', 'PSP\Logging\Logger' );
            self::register_component( 'ConfigManager', 'PSP\Config\ConfigManager' );
            
            // Security components
            self::register_component( 'SecurityLayer', 'PSP\Security\SecurityLayer' );
            self::register_component( 'CSRFProtection', 'PSP\Security\CSRFProtection' );
            self::register_component( 'SecurityHeaders', 'PSP\Security\SecurityHeaders' );
            self::register_component( 'TwoFactorAuth', 'PSP_2FA' );
            self::register_component( 'AccessControl', 'PSP\Security\AccessControl' );
            
            // Performance components
            self::register_component( 'PerformanceOptimizer', 'PSP\Performance\PerformanceOptimizer' );
            self::register_component( 'CacheManager', 'PSP\Cache\CacheManager' );
            
            // API & REST components
            self::register_component( 'REST', 'PSP\REST' );
            self::register_component( 'PortalAPI', 'PSP_Portal_API' );
            self::register_component( 'RESTAPIStandards', 'PSP\API\RESTAPIStandards' );
            self::register_component( 'RateLimiter', 'PSP\API\RateLimiter' );
            
            // Data & Database components
            self::register_component( 'DBMigrator', 'PSP\Database\DBMigrator' );
            self::register_component( 'Tickets', 'PSP\Tickets' );
            self::register_component( 'Partners', 'PSP\Partners' );
            self::register_component( 'Contacts', 'PSP\Contacts' );
            
            // Frontend components
            self::register_component( 'Frontend', 'PSP\Frontend' );
            self::register_component( 'Shortcodes', 'PSP\Shortcodes' );
            self::register_component( 'Email', 'PSP\Email' );
            self::register_component( 'Notifications', 'PSP\Notifications' );
            
            // Admin & Management components
            self::register_component( 'Admin', 'PSP\Admin' );
            self::register_component( 'SettingsPage', 'PSP\Settings\SettingsPage' );
            self::register_component( 'BulkImport', 'PSP\Bulk\BulkImport' );
            
            // Analytics & Logging
            self::register_component( 'Analytics', 'PSP\Analytics\Analytics' );
            self::register_component( 'ActivityLogs', 'PSP\Logging\ActivityLogs' );
            self::register_component( 'AuditLogger', 'PSP\Logging\AuditLogger' );
            self::register_component( 'APILogger', 'PSP\Logging\APILogger' );
            
            // GDPR & Compliance
            self::register_component( 'GDPRExport', 'PSP\GDPR\GDPRExport' );
            self::register_component( 'GDPRDeletion', 'PSP\GDPR\GDPRDeletion' );
            self::register_component( 'GDPRConsent', 'PSP\GDPR\GDPRConsent' );
            
            // Enhancement & Utility components
            self::register_component( 'WordPressEnhancements', 'PSP\Enhancements\WordPressEnhancements' );
            self::register_component( 'VersionManager', 'PSP\Updates\VersionManager' );
            
            /**
             * Allow plugins/themes to register additional components
             *
             * @param array $components Reference to components array
             */
            do_action( 'psp_register_components', self::$components );
            
        } catch ( \Exception $e ) {
            self::log_error( 'Component registration failed', $e );
        }
    }

    /**
     * Register a component for initialization
     *
     * @param string $name Component identifier
     * @param string $class Full class name with namespace
     * @param array  $config Optional component configuration
     * @return void
     */
    public static function register_component( string $name, string $class, array $config = array() ): void {
        try {
            self::$components[ $name ] = array(
                'class'   => $class,
                'config'  => $config,
                'enabled' => true,
            );
        } catch ( \Exception $e ) {
            self::log_error( "Failed to register component: {$name}", $e );
        }
    }

    /**
     * Initialize all registered components
     *
     * Provides unified initialization sequence with proper error handling
     * and dependency management.
     *
     * @return void
     */
    public static function init_all_components(): void {
        try {
            foreach ( self::$components as $name => $component ) {
                if ( empty( $component['enabled'] ) ) {
                    continue;
                }

                $class = $component['class'];
                
                // Skip if class doesn't exist
                if ( ! class_exists( $class ) ) {
                    self::log_error( "Component class not found: {$class}" );
                    continue;
                }

                // Execute component initialization with error handling
                try {
                    if ( method_exists( $class, 'init' ) ) {
                        call_user_func( array( $class, 'init' ) );
                    } else {
                        self::log_error( "Component {$name} does not have init() method" );
                    }
                } catch ( \Exception $e ) {
                    self::log_error( "Component initialization failed: {$name}", $e );
                    // Continue with other components on error
                    continue;
                }
            }

            /**
             * Hook after all components are initialized
             */
            do_action( 'psp_all_components_initialized' );

        } catch ( \Exception $e ) {
            self::log_error( 'All components initialization failed', $e );
        }
    }

    /**
     * Get all registered components
     *
     * @return array Array of registered components
     */
    public static function get_components(): array {
        return self::$components;
    }

    /**
     * Get a specific component configuration
     *
     * @param string $name Component name
     * @return array|null Component config or null if not found
     */
    public static function get_component( string $name ): ?array {
        return self::$components[ $name ] ?? null;
    }

    /**
     * Enable/disable a component
     *
     * @param string $name Component name
     * @param bool   $enabled Enable or disable
     * @return bool Success status
     */
    public static function set_component_enabled( string $name, bool $enabled ): bool {
        try {
            if ( isset( self::$components[ $name ] ) ) {
                self::$components[ $name ]['enabled'] = $enabled;
                return true;
            }
            return false;
        } catch ( \Exception $e ) {
            self::log_error( "Failed to update component status: {$name}", $e );
            return false;
        }
    }

    /**
     * Initialize security layer
     *
     * @return void
     */
    public static function init_security(): void {
        try {
            if ( class_exists( 'PSP\Security\SecurityLayer' ) ) {
                \PSP\Security\SecurityLayer::init();
            }
        } catch ( \Exception $e ) {
            self::log_error( 'Security layer initialization failed', $e );
        }
    }

    /**
     * Initialize performance monitoring
     *
     * @return void
     */
    public static function init_performance(): void {
        try {
            if ( class_exists( 'PSP\Performance\PerformanceOptimizer' ) ) {
                \PSP\Performance\PerformanceOptimizer::init();
            }
        } catch ( \Exception $e ) {
            self::log_error( 'Performance optimizer initialization failed', $e );
        }
    }

    /**
     * Initialize plugin components (Legacy - now uses unified system)
     *
     * This method is kept for backward compatibility but now delegates
     * to the unified component initialization system.
     *
     * @return void
     */
    public static function init() {
        try {
            self::$initialized = true;
            
            // Legacy path for components not yet in registry
            // But most components are now managed through the registry
            
            // Register custom post type hooks if not already done
            add_action( 'init', array( __CLASS__, 'register_custom_post_types' ) );
            
            /**
             * Hook when main plugin initialization completes
             * Fired after unified component system is initialized
             */
            do_action( 'psp_plugin_initialized' );

        } catch ( \Exception $e ) {
            self::log_error( 'Plugin initialization failed', $e );
        }
    }

    /**
     * Register custom post types
     *
     * Centralized CPT registration to avoid duplication.
     *
     * @return void
     */
    public static function register_custom_post_types(): void {
        try {
            // Register CPTs through their respective classes
            $cpts = array(
                'Tickets'       => 'PSP\Tickets',
                'Partners'      => 'PSP\Partners',
                'Notifications' => 'PSP\Notifications',
                'Calendar'      => 'PSP\Calendar',
            );

            foreach ( $cpts as $name => $class ) {
                if ( class_exists( $class ) && method_exists( $class, 'register_cpt' ) ) {
                    try {
                        call_user_func( array( $class, 'register_cpt' ) );
                    } catch ( \Exception $e ) {
                        self::log_error( "Failed to register CPT: {$name}", $e );
                    }
                }
            }
        } catch ( \Exception $e ) {
            self::log_error( 'Custom post type registration failed', $e );
        }
    }

    /**
     * Check plugin dependencies
     *
     * Validates that all required PHP extensions and WordPress versions are met.
     *
     * @return array Array of missing dependencies
     */
    public static function check_dependencies(): array {
        $missing = array();

        // Check PHP version
        if ( version_compare( PHP_VERSION, PSP_MIN_PHP, '<' ) ) {
            $missing[] = sprintf( 'PHP %s or higher required (current: %s)', PSP_MIN_PHP, PHP_VERSION );
        }

        // Check WordPress version
        global $wp_version;
        if ( version_compare( $wp_version, PSP_MIN_WP, '<' ) ) {
            $missing[] = sprintf( 'WordPress %s or higher required (current: %s)', PSP_MIN_WP, $wp_version );
        }

        // Check required PHP extensions
        $required_extensions = array( 'json', 'curl', 'filter', 'hash' );
        foreach ( $required_extensions as $ext ) {
            if ( ! extension_loaded( $ext ) ) {
                $missing[] = sprintf( 'PHP extension "%s" is required but not installed', $ext );
            }
        }

        return $missing;
    }

    /**
     * Handle plugin activation
     *
     * Runs when plugin is activated in WordPress admin.
     * - Checks dependencies
     * - Adds custom capabilities
     * - Initializes database tables
     * - Schedules cron jobs
     *
     * @return void
     */
    public static function activate() {
        try {
            // Check dependencies first
            $missing = self::check_dependencies();
            if ( ! empty( $missing ) ) {
                deactivate_plugins( plugin_basename( PSP_PLUGIN_FILE ) );
                wp_die( 
                    'PoolSafe Portal could not be activated:<br>' . implode( '<br>', array_map( 'esc_html', $missing ) ),
                    'Plugin Activation Error',
                    array( 'back_link' => true )
                );
            }

            // Add custom capabilities to administrator role
            $admin_role = get_role( 'administrator' );
            if ( $admin_role ) {
                $capabilities = array(
                    'psp_support' => true,
                    'psp_manage_partners' => true,
                    'psp_manage_tickets' => true,
                    'psp_view_analytics' => true,
                    'psp_access_admin' => true,
                );

                foreach ( $capabilities as $cap => $grant ) {
                    if ( ! $admin_role->has_cap( $cap ) ) {
                        $admin_role->add_cap( $cap, $grant );
                    }
                }
            }

            // Record activation time
            update_option( 'psp_activated_at', current_time( 'mysql' ) );

            do_action( 'psp_plugin_activated' );

        } catch ( \Exception $e ) {
            self::log_error( 'Plugin activation failed', $e );
            deactivate_plugins( plugin_basename( PSP_PLUGIN_FILE ) );
        }
    }

    /**
     * Handle plugin deactivation
     *
     * Runs when plugin is deactivated in WordPress admin.
     * - Cleans up transients
     * - Stops scheduled cron jobs
     * - Logs deactivation
     *
     * @return void
     */
    public static function deactivate() {
        try {
            // Stop scheduled events
            wp_clear_scheduled_hook( 'psp_cleanup_logs' );
            wp_clear_scheduled_hook( 'psp_cache_cleanup' );
            wp_clear_scheduled_hook( 'psp_sync_partners' );

            // Log deactivation
            update_option( 'psp_deactivated_at', current_time( 'mysql' ) );

            do_action( 'psp_plugin_deactivated' );

        } catch ( \Exception $e ) {
            self::log_error( 'Plugin deactivation failed', $e );
        }
    }

    /**
     * Log initialization error
     *
     * @param string      $message Error message
     * @param \Exception  $exception Exception object
     * @return void
     */
    private static function log_error( string $message, \Exception $exception ): void {
        self::$errors[] = array(
            'message' => $message,
            'code'    => $exception->getCode(),
            'file'    => $exception->getFile(),
            'line'    => $exception->getLine(),
        );

        if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
            error_log( sprintf(
                '[PSP] %s: %s (File: %s, Line: %d)',
                $message,
                $exception->getMessage(),
                $exception->getFile(),
                $exception->getLine()
            ));
        }
    }

    /**
     * Get initialization errors
     *
     * @return array Array of errors encountered during initialization
     */
    public static function get_errors(): array {
        return self::$errors;
    }

    /**
     * Check if plugin initialized successfully
     *
     * @return bool Initialization status
     */
    public static function is_initialized(): bool {
        return self::$initialized;
    }
}
