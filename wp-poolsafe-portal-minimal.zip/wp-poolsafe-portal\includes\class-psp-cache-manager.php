<?php
namespace PSP;

/**
 * Cache Manager for Pool Safe Portal
 * Handles transient caching for frequently accessed data
 * Improves performance by reducing database queries
 *
 * @since 1.1.0
 */

if (!defined('ABSPATH')) {
	exit;
}

class Cache_Manager {

	// Cache key prefixes
	const CACHE_PREFIX = 'psp_cache_';
	const PARTNERS_CACHE_KEY = 'psp_cache_partners';
	const PARTNER_DETAIL_CACHE_KEY = 'psp_cache_partner_detail_';
	const TICKETS_CACHE_KEY = 'psp_cache_tickets_';
	const VIDEOS_CACHE_KEY = 'psp_cache_videos';
	const USER_ROLE_CACHE_KEY = 'psp_cache_user_role_';

	// Default cache durations (in seconds)
	const CACHE_DURATION_PARTNERS = 3600;     // 1 hour
	const CACHE_DURATION_PARTNER_DETAIL = 1800;  // 30 minutes
	const CACHE_DURATION_TICKETS = 600;       // 10 minutes
	const CACHE_DURATION_VIDEOS = 3600;       // 1 hour
	const CACHE_DURATION_USER_ROLE = 1800;    // 30 minutes

	/**
	 * Initialize cache manager hooks
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public static function init(): void {
		// Clear partner cache when partner is saved
		add_action('save_post_psp_partner', [ self::class, 'clear_partners_cache' ], 10, 1);
		
		// Clear ticket cache when ticket is saved
		add_action('save_post_psp_ticket', [ self::class, 'clear_tickets_cache' ], 10, 1);
		
		// Clear video cache when video is saved
		add_action('save_post_psp_video', [ self::class, 'clear_videos_cache' ], 10, 1);
		
		// Clear user role cache when user role changes
		add_action('set_user_role', [ self::class, 'clear_user_role_cache' ], 10, 2);
		
		// Phase 5: Register WP-CLI commands for cache management
		if (class_exists('WP_CLI')) {
			\WP_CLI::add_command('psp cache clear', [self::class, 'cli_clear_cache']);
			\WP_CLI::add_command('psp cache stats', [self::class, 'cli_cache_stats']);
		}
	}

	/**
	 * Get partners list with caching
	 *
	 * @since 1.1.0
	 * @param array $args Query arguments (filtering, pagination, etc).
	 * @return array Array of partner data.
	 */
	public static function get_partners_cached( array $args = [] ): array {
		$cache_key = self::PARTNERS_CACHE_KEY . md5(wp_json_encode($args));
		
		// Check if cached data exists
		$cached = wp_cache_get($cache_key);
		if ($cached !== false) {
			return $cached;
		}

		// If not cached, get from database
		$partners = self::fetch_partners($args);
		
		// Store in cache
		wp_cache_set($cache_key, $partners, '', self::CACHE_DURATION_PARTNERS);
		
		return $partners;
	}

	/**
	 * Get single partner with caching
	 *
	 * @since 1.1.0
	 * @param int $partner_id Partner post ID.
	 * @return array|null Partner data or null if not found.
	 */
	public static function get_partner_cached( int $partner_id ): ?array {
		$cache_key = self::PARTNER_DETAIL_CACHE_KEY . $partner_id;
		
		// Check if cached
		$cached = wp_cache_get($cache_key);
		if ($cached !== false) {
			return $cached;
		}

		// Get from database
		$partner = self::fetch_partner($partner_id);
		
		// Cache it
		if ($partner) {
			wp_cache_set($cache_key, $partner, '', self::CACHE_DURATION_PARTNER_DETAIL);
		}
		
		return $partner;
	}

	/**
	 * Get tickets with caching
	 *
	 * @since 1.1.0
	 * @param string $user_role User role (partner/support/admin).
	 * @param int $user_id User ID for filtering.
	 * @param array $args Additional query args.
	 * @return array Array of tickets.
	 */
	public static function get_tickets_cached( string $user_role, int $user_id, array $args = [] ): array {
		$cache_key = self::TICKETS_CACHE_KEY . "{$user_role}_{$user_id}_" . md5(wp_json_encode($args));
		
		$cached = wp_cache_get($cache_key);
		if ($cached !== false) {
			return $cached;
		}

		$tickets = self::fetch_tickets($user_role, $user_id, $args);
		wp_cache_set($cache_key, $tickets, '', self::CACHE_DURATION_TICKETS);
		
		return $tickets;
	}

	/**
	 * Get videos with caching
	 *
	 * @since 1.1.0
	 * @param array $args Query args.
	 * @return array Array of videos.
	 */
	public static function get_videos_cached( array $args = [] ): array {
		$cache_key = self::VIDEOS_CACHE_KEY . md5(wp_json_encode($args));
		
		$cached = wp_cache_get($cache_key);
		if ($cached !== false) {
			return $cached;
		}

		$videos = self::fetch_videos($args);
		wp_cache_set($cache_key, $videos, '', self::CACHE_DURATION_VIDEOS);
		
		return $videos;
	}

	/**
	 * Get user role with caching
	 *
	 * @since 1.1.0
	 * @param int $user_id User ID.
	 * @return string User role (administrator/psp_support/psp_partner/guest).
	 */
	public static function get_user_role_cached( int $user_id ): string {
		$cache_key = self::USER_ROLE_CACHE_KEY . $user_id;
		
		$cached = wp_cache_get($cache_key);
		if ($cached !== false) {
			return $cached;
		}

		$user = get_user_by('id', $user_id);
		if (!$user) {
			return 'guest';
		}

		$role = self::determine_user_role($user);
		wp_cache_set($cache_key, $role, '', self::CACHE_DURATION_USER_ROLE);
		
		return $role;
	}

	/**
	 * Clear all partners cache
	 *
	 * @since 1.1.0
	 * @param int $partner_id Partner post ID (unused, for hook compatibility).
	 * @return void
	 */
	public static function clear_partners_cache( int $partner_id = 0 ): void {
		// This would need to clear all partner cache keys
		// For now, WordPress will handle this with its object cache
		wp_cache_delete(self::PARTNERS_CACHE_KEY);
		
		// Also clear the specific partner cache
		if ($partner_id > 0) {
			wp_cache_delete(self::PARTNER_DETAIL_CACHE_KEY . $partner_id);
		}
	}

	/**
	 * Clear tickets cache
	 *
	 * @since 1.1.0
	 * @param int $ticket_id Ticket post ID (unused, for hook compatibility).
	 * @return void
	 */
	public static function clear_tickets_cache( int $ticket_id = 0 ): void {
		// Clear tickets cache for all user roles
		wp_cache_delete(self::TICKETS_CACHE_KEY);
	}

	/**
	 * Clear videos cache
	 *
	 * @since 1.1.0
	 * @param int $video_id Video post ID (unused, for hook compatibility).
	 * @return void
	 */
	public static function clear_videos_cache( int $video_id = 0 ): void {
		wp_cache_delete(self::VIDEOS_CACHE_KEY);
	}

	/**
	 * Clear user role cache
	 *
	 * @since 1.1.0
	 * @param int $user_id User ID.
	 * @param string $new_role New role assigned.
	 * @return void
	 */
	public static function clear_user_role_cache( int $user_id, string $new_role ): void {
		wp_cache_delete(self::USER_ROLE_CACHE_KEY . $user_id);
	}

	// ========== PRIVATE HELPER METHODS ==========

	/**
	 * Fetch partners from database (actual query)
	 *
	 * @since 1.1.0
	 * @param array $args Query args.
	 * @return array Partners data.
	 */
	private static function fetch_partners( array $args = [] ): array {
		// Placeholder - implement actual partner query
		return [];
	}

	/**
	 * Fetch single partner from database
	 *
	 * @since 1.1.0
	 * @param int $partner_id Partner post ID.
	 * @return array|null Partner data.
	 */
	private static function fetch_partner( int $partner_id ): ?array {
		$post = get_post($partner_id);
		if (!$post || 'psp_partner' !== $post->post_type) {
			return null;
		}

		return [
			'id' => $post->ID,
			'name' => $post->post_title,
			'description' => $post->post_content,
		];
	}

	/**
	 * Fetch tickets from database
	 *
	 * @since 1.1.0
	 * @param string $user_role User role.
	 * @param int $user_id User ID.
	 * @param array $args Query args.
	 * @return array Tickets data.
	 */
	private static function fetch_tickets( string $user_role, int $user_id, array $args = [] ): array {
		// Placeholder - implement actual ticket query
		return [];
	}

	/**
	 * Fetch videos from database
	 *
	 * @since 1.1.0
	 * @param array $args Query args.
	 * @return array Videos data.
	 */
	private static function fetch_videos( array $args = [] ): array {
		// Placeholder - implement actual video query
		return [];
	}

	/**
	 * Determine user role
	 *
	 * @since 1.1.0
	 * @param \WP_User $user WordPress user object.
	 * @return string Role name.
	 */
	private static function determine_user_role( \WP_User $user ): string {
		if (in_array('administrator', $user->roles, true)) {
			return 'administrator';
		}
		if (in_array('psp_support', $user->roles, true)) {
			return 'psp_support';
		}
		if (in_array('psp_partner', $user->roles, true)) {
			return 'psp_partner';
		}
		return 'guest';
	}

	// ========== PHASE 5: CACHE MANAGEMENT ==========

	/**
	 * Get comprehensive cache statistics
	 *
	 * @since 3.0.0
	 * @return array Cache statistics.
	 */
	public static function get_all_stats(): array {
		global $wpdb;
		
		// Count PSP transients
		$transient_count = $wpdb->get_var(
			"SELECT COUNT(*) FROM {$wpdb->options} 
			WHERE option_name LIKE '%psp_%' 
			AND option_name LIKE '%transient%'"
		);
		
		// Calculate transient storage size
		$transient_size = $wpdb->get_var(
			"SELECT SUM(CHAR_LENGTH(option_value)) FROM {$wpdb->options} 
			WHERE option_name LIKE '%psp_%' 
			AND option_name LIKE '%transient%'"
		);
		
		return [
			'transient_count' => intval($transient_count),
			'transient_size_kb' => round(intval($transient_size ?? 0) / 1024, 2),
			'timestamp' => current_time('mysql'),
		];
	}

	/**
	 * Clear all PSP caches
	 *
	 * @since 3.0.0
	 * @return int Number of items cleared.
	 */
	public static function clear_all_caches(): int {
		global $wpdb;
		
		// Delete all PSP transients
		$deleted = $wpdb->query(
			"DELETE FROM {$wpdb->options} 
			WHERE option_name LIKE '%psp_%' 
			AND option_name LIKE '%transient%'"
		);
		
		// Flush WordPress object cache
		wp_cache_flush();
		
		return intval($deleted);
	}

	/**
	 * WP-CLI: Clear cache command
	 *
	 * @since 3.0.0
	 * @param array $args CLI arguments.
	 * @param array $assoc_args CLI associative arguments.
	 * @return void
	 */
	public static function cli_clear_cache( array $args, array $assoc_args ): void {
		$deleted = self::clear_all_caches();
		\WP_CLI::success("Cleared $deleted cache entries");
	}

	/**
	 * WP-CLI: Cache statistics command
	 *
	 * @since 3.0.0
	 * @param array $args CLI arguments.
	 * @param array $assoc_args CLI associative arguments.
	 * @return void
	 */
	public static function cli_cache_stats( array $args, array $assoc_args ): void {
		$stats = self::get_all_stats();
		\WP_CLI::log('Cache Statistics:');
		\WP_CLI::log('  Transients: ' . $stats['transient_count']);
		\WP_CLI::log('  Size (KB): ' . $stats['transient_size_kb']);
		\WP_CLI::log('  Checked: ' . $stats['timestamp']);
	}
}
