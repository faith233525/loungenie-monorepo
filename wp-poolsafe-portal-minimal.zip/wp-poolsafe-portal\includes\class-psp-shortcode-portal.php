<?php
namespace PSP;

/**
 * WordPress-Integrated Portal Shortcode
 * 
 * Single-page portal that uses WordPress authentication exclusively.
 * Displays login/logout button, adapts to theme styling, fully responsive.
 *
 * @package PoolSafe_Portal
 * @since 3.3.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class Shortcode_Portal {

    /**
     * Initialize the shortcode
     */
    public static function init() {
        add_shortcode('poolsafe_portal', [self::class, 'render']);
        add_action('wp_enqueue_scripts', [self::class, 'enqueue_assets']);
    }

    /**
     * Enqueue shortcode-specific assets
     */
    public static function enqueue_assets() {
        // Only load on pages with the shortcode
        global $post;
        if (!is_a($post, 'WP_Post') || !has_shortcode($post->post_content, 'poolsafe_portal')) {
            return;
        }

        $plugin_url = PSP_PLUGIN_URL;
        $plugin_dir = PSP_PLUGIN_DIR;

        // Enqueue portal CSS (theme-aware, no inline styles)
        wp_enqueue_style(
            'psp-portal-shortcode',
            $plugin_url . 'css/portal-shortcode.css',
            [],
            time()
        );

        // Only load JS if user is logged in
        if (is_user_logged_in()) {
            wp_enqueue_script(
                'psp-portal-app',
                $plugin_url . 'js/psp-portal-app.js',
                ['jquery'],
                time(),
                true
            );

            // Portal configuration
            $current_user = wp_get_current_user();
            $user_role = self::get_user_portal_role($current_user);
            $company_id = (int) get_user_meta($current_user->ID, 'psp_company_id', true);

            wp_localize_script('psp-portal-app', 'PORTAL_CONFIG', [
                'apiUrl' => rest_url('psp/v1'),
                'nonce' => wp_create_nonce('wp_rest'),
                'user' => [
                    'id' => $current_user->ID,
                    'name' => $current_user->display_name ?: $current_user->user_login,
                    'email' => $current_user->user_email,
                    'role' => $user_role,
                    'company_id' => $company_id ?: null,
                ],
                'adminUrl' => admin_url(),
                'debug' => defined('PSP_DEBUG') ? PSP_DEBUG : false,
            ]);
        }
    }

    /**
     * Get portal role from WordPress user
     */
    private static function get_user_portal_role($user) {
        if (in_array('administrator', (array) $user->roles, true)) {
            return 'administrator';
        }
        if (in_array('pool_safe_support', (array) $user->roles, true) || 
            in_array('psp_support', (array) $user->roles, true)) {
            return 'pool_safe_support';
        }
        return 'pool_safe_partner';
    }

    /**
     * Render the portal shortcode
     */
    public static function render($atts) {
        $atts = shortcode_atts([
            'login_redirect' => '',
            'logout_redirect' => '',
        ], $atts, 'poolsafe_portal');

        ob_start();
        
        if (is_user_logged_in()) {
            self::render_portal_logged_in($atts);
        } else {
            self::render_login_form($atts);
        }

        return ob_get_clean();
    }

    /**
     * Render portal for logged-in users
     */
    private static function render_portal_logged_in($atts) {
        $current_user = wp_get_current_user();
        $user_role = self::get_user_portal_role($current_user);
        $logout_url = wp_logout_url($atts['logout_redirect'] ?: home_url());
        
        ?>
        <div class="psp-portal-wrapper" role="main" aria-label="PoolSafe Portal">
            
            <!-- Header with Login/Logout -->
            <div class="psp-portal-header">
                <div class="psp-header-content">
                    <div class="psp-header-left">
                        <span class="psp-logo-badge" aria-hidden="true"></span>
                        <div class="psp-title-group">
                            <h1 class="psp-header-title">PoolSafe Portal</h1>
                            <p class="psp-header-subtitle">Partner experience hub</p>
                        </div>
                    </div>
                    <div class="psp-header-right">
                        <div class="psp-user-meta">
                            <p class="psp-user-name"><?php echo esc_html($current_user->display_name ?: $current_user->user_login); ?></p>
                            <p class="psp-user-role"><?php echo esc_html(ucwords(str_replace('_', ' ', $user_role))); ?></p>
                        </div>
                        <a href="<?php echo esc_url($logout_url); ?>" class="psp-logout-button" aria-label="Logout from PoolSafe Portal">
                            Logout
                        </a>
                    </div>
                </div>
            </div>

            <!-- Tab Navigation -->
            <nav class="psp-tab-nav" role="tablist" aria-label="Portal sections">
                <ul class="psp-tab-list">
                    <li class="psp-tab-item">
                        <button class="psp-tab-button active" 
                                onclick="switchTab(event, 'dashboard')" 
                                role="tab"
                                aria-selected="true"
                                aria-controls="dashboard-panel"
                                id="tab-dashboard">
                            📊 Dashboard
                        </button>
                    </li>
                    <li class="psp-tab-item">
                        <button class="psp-tab-button" 
                                onclick="switchTab(event, 'tickets')" 
                                role="tab"
                                aria-selected="false"
                                aria-controls="tickets-panel"
                                id="tab-tickets">
                            🎫 Tickets
                        </button>
                    </li>
                    <li class="psp-tab-item">
                        <button class="psp-tab-button" 
                                onclick="switchTab(event, 'services')" 
                                role="tab"
                                aria-selected="false"
                                aria-controls="services-panel"
                                id="tab-services">
                            ⚙️ Services
                        </button>
                    </li>
                    <li class="psp-tab-item">
                        <button class="psp-tab-button" 
                                onclick="switchTab(event, 'partners')" 
                                role="tab"
                                aria-selected="false"
                                aria-controls="partners-panel"
                                id="tab-partners">
                            🤝 Partners
                        </button>
                    </li>
                    <!-- Profile/Admin tabs intentionally removed for streamlined UX -->
                </ul>
            </nav>

            <!-- Content Area -->
            <main class="psp-content-area">
                
                <!-- Dashboard Tab -->
                <div id="dashboard-panel" class="psp-tab-panel active" role="tabpanel" aria-labelledby="tab-dashboard">
                    <div class="psp-welcome-banner">
                        <h2>Welcome back, <?php echo esc_html(explode(' ', $current_user->display_name ?: $current_user->user_login)[0]); ?>! 👋</h2>
                        <p>Your dashboard is ready. Manage tickets, review services, and connect with our partner network.</p>
                    </div>

                    <div class="psp-stats-grid">
                        <div class="psp-stat-card">
                            <div class="psp-stat-icon" aria-hidden="true">📊</div>
                            <div class="psp-stat-label">Key Stats</div>
                            <div class="psp-stat-value" id="stat-key">0</div>
                        </div>
                        <div class="psp-stat-card">
                            <div class="psp-stat-icon" aria-hidden="true">🎫</div>
                            <div class="psp-stat-label">Open Tickets</div>
                            <div class="psp-stat-value" id="stat-open">0</div>
                        </div>
                        <div class="psp-stat-card">
                            <div class="psp-stat-icon" aria-hidden="true">⏳</div>
                            <div class="psp-stat-label">In Progress</div>
                            <div class="psp-stat-value" id="stat-progress">0</div>
                        </div>
                        <div class="psp-stat-card">
                            <div class="psp-stat-icon" aria-hidden="true">✅</div>
                            <div class="psp-stat-label">Closed This Month</div>
                            <div class="psp-stat-value" id="stat-closed">0</div>
                        </div>
                    </div>

                    <div id="dashboard-content">
                        <div class="loading" role="status" aria-live="polite">
                            <span class="spinner" aria-hidden="true"></span>
                            <span>Loading dashboard...</span>
                        </div>
                        <div class="content"></div>
                    </div>
                </div>

                <!-- Tickets Tab -->
                <div id="tickets-panel" class="psp-tab-panel" role="tabpanel" aria-labelledby="tab-tickets" hidden>
                    <div class="psp-section">
                        <div class="psp-section-header">
                            <h2 class="psp-section-title">🎫 Your Tickets</h2>
                            <div class="psp-section-actions">
                                <button class="psp-btn psp-btn-primary" onclick="alert('Ticket creation coming soon')" aria-label="Create new ticket">
                                    ＋ New Ticket
                                </button>
                            </div>
                        </div>
                        <div id="tickets-content">
                            <div class="loading" role="status" aria-live="polite">
                                <span class="spinner" aria-hidden="true"></span>
                                <span>Loading tickets...</span>
                            </div>
                            <div class="content"></div>
                        </div>
                    </div>
                </div>

                <!-- Services Tab -->
                <div id="services-panel" class="psp-tab-panel" role="tabpanel" aria-labelledby="tab-services" hidden>
                    <div class="psp-section">
                        <div class="psp-section-header">
                            <h2 class="psp-section-title">⚙️ Service Records</h2>
                            <div class="psp-section-actions">
                                <button class="psp-btn psp-btn-primary" onclick="alert('Service scheduling coming soon')" aria-label="Schedule service">
                                    Schedule Service
                                </button>
                            </div>
                        </div>
                        <div id="services-content">
                            <div class="loading" role="status" aria-live="polite">
                                <span class="spinner" aria-hidden="true"></span>
                                <span>Loading services...</span>
                            </div>
                            <div class="content"></div>
                        </div>
                    </div>
                </div>

                <!-- Partners Tab -->
                <div id="partners-panel" class="psp-tab-panel" role="tabpanel" aria-labelledby="tab-partners" hidden>
                    <div class="psp-section">
                        <div class="psp-section-header">
                            <h2 class="psp-section-title">🤝 Partner Companies</h2>
                        </div>
                        <div id="partners-content">
                            <div class="loading" role="status" aria-live="polite">
                                <span class="spinner" aria-hidden="true"></span>
                                <span>Loading partners...</span>
                            </div>
                            <div class="content"></div>
                        </div>
                    </div>
                </div>

                <!-- Profile Tab -->
                <div id="profile-panel" class="psp-tab-panel" role="tabpanel" aria-labelledby="tab-profile" hidden>
                    <div class="psp-section">
                        <div class="psp-section-header">
                            <h2 class="psp-section-title">👤 My Profile</h2>
                        </div>
                        <div id="profile-content">
                            <div class="loading" role="status" aria-live="polite">
                                <span class="spinner" aria-hidden="true"></span>
                                <span>Loading profile...</span>
                            </div>
                            <div class="content"></div>
                        </div>
                    </div>
                </div>

                <!-- Admin Tab -->
                <?php if (in_array($user_role, ['administrator', 'pool_safe_support'])): ?>
                <div id="admin-panel" class="psp-tab-panel" role="tabpanel" aria-labelledby="tab-admin" hidden>
                    <div class="psp-section">
                        <div class="psp-section-header">
                            <h2 class="psp-section-title">⚙️ Administration</h2>
                            <div class="psp-section-actions">
                                <button class="psp-btn psp-btn-primary" onclick="alert('CSV Import coming soon')" aria-label="Import CSV">
                                    📥 Import CSV
                                </button>
                                <button class="psp-btn psp-btn-primary" onclick="alert('User management coming soon')" aria-label="Manage users">
                                    👥 Manage Users
                                </button>
                            </div>
                        </div>
                        <div id="admin-content">
                            <div class="loading" role="status" aria-live="polite">
                                <span class="spinner" aria-hidden="true"></span>
                                <span>Loading admin panel...</span>
                            </div>
                            <div class="content"></div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

            </main>

            <script>
            function switchTab(event, tabName) {
                event.preventDefault();
                
                // Update ARIA attributes
                document.querySelectorAll('.psp-tab-button').forEach(btn => {
                    btn.classList.remove('active');
                    btn.setAttribute('aria-selected', 'false');
                });
                event.target.classList.add('active');
                event.target.setAttribute('aria-selected', 'true');
                
                // Update panels
                document.querySelectorAll('.psp-tab-panel').forEach(panel => {
                    panel.classList.remove('active');
                    panel.hidden = true;
                });
                const targetPanel = document.getElementById(tabName + '-panel');
                targetPanel.classList.add('active');
                targetPanel.hidden = false;
                
                // Load content if JS available
                if (window.loadTabContent) {
                    window.loadTabContent(tabName, false);
                }
            }
            </script>
        </div>
        <?php
    }

    /**
     * Render WordPress login form for logged-out users
     */
    private static function render_login_form($atts) {
        $redirect_to = $atts['login_redirect'] ?: get_permalink();
        
        ?>
        <div class="psp-login-wrapper" role="main" aria-label="Login to PoolSafe Portal">
            <div class="psp-login-container">
                <div class="psp-login-header">
                    <span class="psp-logo-badge" aria-hidden="true"></span>
                    <h1>PoolSafe Portal</h1>
                    <p>Please log in to access your portal</p>
                </div>
                
                <div class="psp-login-form">
                    <?php
                    wp_login_form([
                        'redirect' => esc_url($redirect_to),
                        'remember' => true,
                        'label_username' => __('Username or Email', 'psp'),
                        'label_password' => __('Password', 'psp'),
                        'label_remember' => __('Keep me logged in', 'psp'),
                        'label_log_in' => __('Log In', 'psp'),
                    ]);
                    ?>
                </div>

                <div class="psp-login-footer">
                    <p>
                        <a href="<?php echo esc_url(wp_lostpassword_url($redirect_to)); ?>">
                            <?php esc_html_e('Forgot password?', 'psp'); ?>
                        </a>
                    </p>
                    <?php if (get_option('users_can_register')): ?>
                    <p>
                        <a href="<?php echo esc_url(wp_registration_url()); ?>">
                            <?php esc_html_e('Register for an account', 'psp'); ?>
                        </a>
                    </p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php
    }
}
