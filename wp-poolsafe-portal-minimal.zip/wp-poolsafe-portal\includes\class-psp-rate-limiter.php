<?php

namespace PSP;

/**
 * Rate Limiter
 * 
 * Prevents abuse by limiting requests per user, IP, or endpoint.
 * Protects against brute force attacks and DoS attacks.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Rate_Limiter {

	/**
	 * Check if user has exceeded rate limit
	 * 
	 * @param string $action Action being limited (login, api_request, etc)
	 * @param int $max_attempts Maximum attempts allowed
	 * @param int $window_seconds Time window in seconds
	 * @param string $identifier Unique identifier (user_id, IP, email, etc)
	 * @return array ['allowed' => bool, 'attempts' => int, 'retry_after' => int]
	 */
	public static function check_limit( string $action, int $max_attempts, int $window_seconds, string $identifier = '' ): array {
		// Use IP if no identifier provided
		if ( ! $identifier ) {
			$identifier = Error_Handler::get_client_ip();
		}

		$key = self::get_cache_key( $action, $identifier );

		// Get current attempt count
		$attempts = (int) get_transient( $key );

		if ( $attempts >= $max_attempts ) {
			// Calculate retry_after time
			$retry_after = intval( get_option( $key . '_retry' ) );
			if ( $retry_after < time() ) {
				// Reset if window passed
				delete_transient( $key );
				delete_option( $key . '_retry' );
				$attempts = 0;
			} else {
				$retry_after = $retry_after - time();
				return array(
					'allowed'      => false,
					'attempts'     => $attempts,
					'retry_after'  => $retry_after,
					'max_attempts' => $max_attempts,
				);
			}
		}

		return array(
			'allowed'      => true,
			'attempts'     => $attempts,
			'retry_after'  => 0,
			'max_attempts' => $max_attempts,
		);
	}

	/**
	 * Record an attempt
	 * 
	 * @param string $action Action being limited
	 * @param int $window_seconds Time window in seconds
	 * @param string $identifier Unique identifier
	 * @return int Current attempt count
	 */
	public static function record_attempt( string $action, int $window_seconds, string $identifier = '' ): int {
		if ( ! $identifier ) {
			$identifier = Error_Handler::get_client_ip();
		}

		$key = self::get_cache_key( $action, $identifier );
		$attempts = (int) get_transient( $key ) + 1;

		// Set transient with expiration
		set_transient( $key, $attempts, $window_seconds );

		// Also set retry time
		if ( $attempts === 1 ) {
			update_option( $key . '_retry', time() + $window_seconds, false );
		}

		return $attempts;
	}

	/**
	 * Reset attempt counter for identifier
	 * 
	 * @param string $action Action to reset
	 * @param string $identifier Unique identifier
	 * @return void
	 */
	public static function reset_limit( string $action, string $identifier = '' ): void {
		if ( ! $identifier ) {
			$identifier = Error_Handler::get_client_ip();
		}

		$key = self::get_cache_key( $action, $identifier );
		delete_transient( $key );
		delete_option( $key . '_retry' );
	}

	/**
	 * Get cache key for rate limit tracking
	 * 
	 * @param string $action Action name
	 * @param string $identifier Unique identifier
	 * @return string Cache key
	 */
	private static function get_cache_key( string $action, string $identifier ): string {
		return 'psp_rate_limit_' . sanitize_key( $action ) . '_' . sanitize_key( $identifier );
	}

	/**
	 * Initialize rate limiting hooks
	 * 
	 * @return void
	 */
	public static function init(): void {
		// Rate limit login attempts
		add_action( 'rest_api_init', array( __CLASS__, 'init_login_limit' ) );
		
		// Rate limit general API requests
		add_action( 'rest_pre_dispatch', array( __CLASS__, 'check_api_limit' ), 10, 3 );
	}

	/**
	 * Check rate limit before login
	 * 
	 * @param string $email Email address attempting login
	 * @return array Rate limit status
	 */
	public static function check_login_limit( string $email ): array {
		return self::check_limit(
			'login',
			5,                    // Max 5 attempts
			15 * MINUTE_IN_SECONDS, // Per 15 minutes
			sanitize_email( $email )
		);
	}

	/**
	 * Record login attempt
	 * 
	 * @param string $email Email address
	 * @return int Attempt count
	 */
	public static function record_login_attempt( string $email ): int {
		return self::record_attempt(
			'login',
			15 * MINUTE_IN_SECONDS,
			sanitize_email( $email )
		);
	}

	/**
	 * Check rate limit for API requests
	 * 
	 * @param mixed $result REST request result
	 * @param \WP_REST_Server $server REST API server
	 * @param \WP_REST_Request $request REST request object
	 * @return mixed
	 */
	public static function check_api_limit( $result, \WP_REST_Server $server, \WP_REST_Request $request ) {
		// Skip rate limiting for health checks
		if ( strpos( $request->get_route(), '/health' ) !== false ) {
			return $result;
		}

		// Skip if user is admin
		if ( current_user_can( 'administrator' ) ) {
			return $result;
		}

		// Get user identifier
		$user_id = isset( $_SESSION['psp_user_id'] ) ? absint( $_SESSION['psp_user_id'] ) : 0;
		$identifier = $user_id > 0 ? 'user_' . $user_id : Error_Handler::get_client_ip();

		// Check limit
		$limit_check = self::check_limit(
			'api_request',
			100,                   // Max 100 requests
			HOUR_IN_SECONDS,       // Per hour
			$identifier
		);

		if ( ! $limit_check['allowed'] ) {
			return Error_Handler::rate_limited( $limit_check['retry_after'] );
		}

		// Record this attempt
		self::record_attempt(
			'api_request',
			HOUR_IN_SECONDS,
			$identifier
		);

		return $result;
	}

	/**
	 * Initialize login limiting (hook placeholder)
	 * 
	 * @return void
	 */
	public static function init_login_limit(): void {
		// Login limiting is handled in Auth class
		// This is just a placeholder for consistency
	}
}
