<?php
/**
 * Email Template - Status Change Notification
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 600px;
            margin: 0 auto;
            background-color: #f9f9f9;
        }
        .email-container {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 8px 8px 0 0;
            text-align: center;
        }
        .header h1 {
            margin: 0;
            font-size: 24px;
        }
        .content {
            padding: 20px;
        }
        .status-update {
            background-color: #ecfdf5;
            border-left: 4px solid #10b981;
            padding: 15px;
            margin: 20px 0;
            border-radius: 4px;
        }
        .status-update strong {
            color: #10b981;
        }
        .button {
            display: inline-block;
            background-color: #667eea;
            color: white;
            padding: 12px 24px;
            text-decoration: none;
            border-radius: 4px;
            margin: 20px 0;
            font-weight: bold;
        }
        .button:hover {
            background-color: #5568d3;
        }
        .footer {
            text-align: center;
            color: #666;
            font-size: 12px;
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #eee;
        }
    </style>
</head>
<body>
    <div class="email-container">
        <div class="header">
            <h1>✅ Ticket Status Updated</h1>
        </div>

        <div class="content">
            <p>Hello <?php echo isset($recipient_name) ? esc_html($recipient_name) : 'there'; ?>,</p>

            <p>The status of your ticket has been updated:</p>

            <p><strong>Ticket #<?php echo isset($ticket_number) ? esc_html($ticket_number) : '—'; ?>:</strong> <?php echo isset($ticket_title) ? esc_html($ticket_title) : '—'; ?></p>

            <div class="status-update">
                <p>
                    <strong>Previous Status:</strong> 
                    <span style="text-transform: capitalize;">
                        <?php echo isset($old_status) ? esc_html(str_replace('_', ' ', $old_status)) : '—'; ?>
                    </span>
                </p>
                <p>
                    <strong>New Status:</strong> 
                    <span style="color: #10b981; font-weight: bold; text-transform: capitalize;">
                        <?php echo isset($new_status) ? esc_html(str_replace('_', ' ', $new_status)) : '—'; ?>
                    </span>
                </p>
                <p><strong>Updated:</strong> <?php echo isset($updated_at) ? date_i18n('M d, Y @ g:i A', strtotime($updated_at)) : '—'; ?></p>
            </div>

            <center>
                <a href="<?php echo isset($ticket_url) ? esc_url($ticket_url) : '#'; ?>" class="button">
                    View Ticket →
                </a>
            </center>

            <p>Thank you for using PoolSafe Portal!</p>
        </div>

        <div class="footer">
            <p>PoolSafe Portal | Support Team</p>
            <p>This is an automated email. Please do not reply directly to this message.</p>
        </div>
    </div>
</body>
</html>
