<?php
/**
 * API Request Logging - Logs all REST API calls
 *
 * @package PSP
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class PSP_API_Logger {

	/**
	 * Initialize API logging
	 */
	public static function init() {
		add_filter( 'rest_pre_dispatch', array( __CLASS__, 'log_api_request' ), 10, 3 );
		add_filter( 'rest_post_dispatch', array( __CLASS__, 'log_api_response' ), 10, 2 );
	}

	/**
	 * Log incoming API request
	 *
	 * @param mixed             $dispatch Response object if already authenticated.
	 * @param WP_REST_Server    $server Server object.
	 * @param WP_REST_Request   $request Request object.
	 * @return mixed
	 */
	public static function log_api_request( $dispatch, $server, $request ) {
		$method = $request->get_method();
		$route  = $request->get_route();
		$user_id = self::get_current_user_id();

		// Skip logging for health checks
		if ( false !== strpos( $route, '/health' ) ) {
			return $dispatch;
		}

		// Store request details in transient for response logging
		$log_key = 'psp_api_log_' . wp_generate_password( 12, false );
		set_transient(
			$log_key,
			array(
				'method'     => $method,
				'route'      => $route,
				'user_id'    => $user_id,
				'timestamp'  => time(),
				'ip'         => self::get_client_ip(),
				'user_agent' => isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '',
			),
			5 * MINUTE_IN_SECONDS
		);

		return $dispatch;
	}

	/**
	 * Log API response
	 *
	 * @param WP_HTTP_Response  $response Response object.
	 * @param WP_REST_Server    $server Server object.
	 * @return WP_HTTP_Response
	 */
	public static function log_api_response( $response, $server ) {
		global $wp_rest_server;

		if ( ! isset( $wp_rest_server ) ) {
			return $response;
		}

		$request = $wp_rest_server->last_request ?? null;

		if ( ! $request ) {
			return $response;
		}

		$method   = $request->get_method();
		$route    = $request->get_route();
		$status   = $response->get_status() ?? 200;
		$user_id  = self::get_current_user_id();

		// Skip logging for health checks
		if ( false !== strpos( $route, '/health' ) ) {
			return $response;
		}

		// Determine action based on method and route
		$action = self::determine_action( $method, $route );

		// Log to database
		self::create_audit_log(
			array(
				'action'     => $action,
				'method'     => $method,
				'route'      => $route,
				'status'     => $status,
				'user_id'    => $user_id,
				'ip_address' => self::get_client_ip(),
				'user_agent' => isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '',
				'timestamp'  => current_time( 'mysql' ),
			)
		);

		return $response;
	}

	/**
	 * Create audit log entry
	 *
	 * @param array $data Log data.
	 * @return int|false Post ID or false on failure.
	 */
	private static function create_audit_log( $data ) {
		return wp_insert_post(
			array(
				'post_type'    => 'psp_audit_log',
				'post_title'   => sprintf( '[%s] %s %s', $data['status'], $data['method'], $data['route'] ),
				'post_content' => wp_json_encode( $data ),
				'post_status'  => 'publish',
			)
		);
	}

	/**
	 * Determine action from method and route
	 *
	 * @param string $method HTTP method.
	 * @param string $route API route.
	 * @return string Action name.
	 */
	private static function determine_action( $method, $route ) {
		$actions = array(
			'GET'    => 'api_read',
			'POST'   => 'api_create',
			'PATCH'  => 'api_update',
			'PUT'    => 'api_update',
			'DELETE' => 'api_delete',
		);

		return $actions[ $method ] ?? 'api_call';
	}

	/**
	 * Get current user ID from session
	 *
	 * @return int|null User ID or null if not logged in.
	 */
	private static function get_current_user_id() {
		if ( ! session_id() ) {
			session_start();
		}

		return isset( $_SESSION['psp_user_id'] ) ? intval( $_SESSION['psp_user_id'] ) : null;
	}

	/**
	 * Get client IP address
	 *
	 * @return string Client IP address.
	 */
	private static function get_client_ip() {
		$ip = '0.0.0.0';

		if ( ! empty( $_SERVER['HTTP_CF_CONNECTING_IP'] ) ) {
			$ip = sanitize_text_field( wp_unslash( $_SERVER['HTTP_CF_CONNECTING_IP'] ) );
		} elseif ( ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
			$ip = sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_FORWARDED_FOR'] ) );
			$ip = explode( ',', $ip );
			$ip = trim( $ip[0] );
		} elseif ( ! empty( $_SERVER['REMOTE_ADDR'] ) ) {
			$ip = sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) );
		}

		return $ip;
	}
}
