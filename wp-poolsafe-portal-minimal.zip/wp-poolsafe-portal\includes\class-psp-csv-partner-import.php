<?php
/**
 * Enhanced CSV Partner Import Handler
 * 
 * Handles comprehensive partner CSV import with user creation, metadata, and linking.
 * 
 * @package PoolSafePortal
 * @subpackage CSV
 * @since 2.5.0
 */

namespace PSP;

class CSV_Partner_Import {

	/**
	 * CSV fields mapping and required status
	 */
	const FIELD_MAPPING = array(
		'user_login'              => array( 'required' => true, 'type' => 'username', 'label' => 'Username' ),
		'user_pass'               => array( 'required' => true, 'type' => 'password', 'label' => 'Password' ),
		'units'                   => array( 'required' => true, 'type' => 'integer', 'label' => 'Number of Units' ),
		'number'                  => array( 'required' => false, 'type' => 'integer', 'label' => 'Unit Number' ),
		'display_name'            => array( 'required' => false, 'type' => 'string', 'label' => 'Display Name' ),
		'top_colour'              => array( 'required' => false, 'type' => 'string', 'label' => 'Top Color' ),
		'company_name'            => array( 'required' => true, 'type' => 'string', 'label' => 'Company Name' ),
		'management_company'      => array( 'required' => false, 'type' => 'string', 'label' => 'Management Company' ),
		'street_address'          => array( 'required' => false, 'type' => 'string', 'label' => 'Street Address' ),
		'city'                    => array( 'required' => false, 'type' => 'string', 'label' => 'City' ),
		'state'                   => array( 'required' => false, 'type' => 'string', 'label' => 'State' ),
		'zip'                     => array( 'required' => false, 'type' => 'string', 'label' => 'ZIP Code' ),
		'country'                 => array( 'required' => false, 'type' => 'string', 'label' => 'Country' ),
		'lock'                    => array( 'required' => false, 'type' => 'string', 'label' => 'Lock Type' ),
		'master_code'             => array( 'required' => false, 'type' => 'string', 'label' => 'Master Code' ),
		'sub_master_code'         => array( 'required' => false, 'type' => 'string', 'label' => 'Sub Master Code' ),
		'lock_part'               => array( 'required' => false, 'type' => 'string', 'label' => 'Lock Part' ),
		'key'                     => array( 'required' => false, 'type' => 'string', 'label' => 'Key' ),
		'primary_contact_name'    => array( 'required' => false, 'type' => 'string', 'label' => 'Primary Contact Name' ),
		'primary_contact_email'   => array( 'required' => false, 'type' => 'email', 'label' => 'Primary Contact Email' ),
		'secondary_contact_name'  => array( 'required' => false, 'type' => 'string', 'label' => 'Secondary Contact Name' ),
		'secondary_contact_email' => array( 'required' => false, 'type' => 'email', 'label' => 'Secondary Contact Email' ),
	);

	/**
	 * Parse and import CSV file
	 */
	public static function import_csv( $file_path ) {
		$results = array(
			'success'    => false,
			'imported'   => 0,
			'errors'     => 0,
			'details'    => array(),
			'company_map' => array(), // Track company_name to post_id mapping
		);

		// Validate file
		if ( ! file_exists( $file_path ) || ! is_readable( $file_path ) ) {
			$results['details'][] = 'Error: CSV file not found or not readable.';
			return $results;
		}

		// Read CSV with UTF-8 support
		$csv_data = self::read_csv_file( $file_path );
		if ( ! $csv_data ) {
			$results['details'][] = 'Error: Failed to read CSV file or file is empty.';
			return $results;
		}

		$headers = $csv_data[0];
		unset( $csv_data[0] );

		// Validate headers
		$header_validation = self::validate_headers( $headers );
		if ( ! $header_validation['valid'] ) {
			$results['details'][] = 'Error: Missing required columns: ' . implode( ', ', $header_validation['missing'] );
			return $results;
		}

		// Process each row
		foreach ( $csv_data as $row_num => $row_data ) {
			$row_num = $row_num + 1; // Adjust for 0-index + header row
			$result = self::process_row( $row_data, $headers, $results['company_map'] );

			if ( $result['success'] ) {
				$results['imported']++;
				$results['details'][] = "Row $row_num: ✓ Imported user '{$result['username']}' for '{$result['company']}'";
				
				// Track company mapping for linking
				if ( ! isset( $results['company_map'][ $result['company'] ] ) ) {
					$results['company_map'][ $result['company'] ] = array();
				}
				$results['company_map'][ $result['company'] ][] = $result['post_id'];
			} else {
				$results['errors']++;
				$results['details'][] = "Row $row_num: ✗ {$result['error']}";
			}
		}

		// Link partner posts under company
		self::link_partner_companies( $results['company_map'] );

		$results['success'] = $results['errors'] === 0;
		return $results;
	}

	/**
	 * Read CSV file with UTF-8 support
	 */
	private static function read_csv_file( $file_path ) {
		$csv_data = array();
		$handle = fopen( $file_path, 'r' );
		
		if ( ! $handle ) {
			return false;
		}

		// Set UTF-8 encoding
		stream_filter_prepend( $handle, 'convert.iconv.ISO-8859-1/UTF-8' );

		while ( ( $row = fgetcsv( $handle, 0, ',', '"' ) ) !== false ) {
			// Trim whitespace from each field
			$row = array_map( 'trim', $row );
			$csv_data[] = $row;
		}

		fclose( $handle );
		return ! empty( $csv_data ) ? $csv_data : false;
	}

	/**
	 * Validate CSV headers
	 */
	private static function validate_headers( $headers ) {
		$required_fields = array_filter(
			self::FIELD_MAPPING,
			function( $field ) {
				return $field['required'];
			}
		);

		$required_keys = array_keys( $required_fields );
		$headers_lower = array_map( 'strtolower', $headers );
		$missing = array();

		foreach ( $required_keys as $req_field ) {
			if ( ! in_array( $req_field, $headers_lower, true ) ) {
				$missing[] = $req_field;
			}
		}

		return array(
			'valid'   => empty( $missing ),
			'missing' => $missing,
		);
	}

	/**
	 * Process single CSV row
	 */
	private static function process_row( $row_data, $headers, &$company_map ) {
		// Create data mapping
		$headers_lower = array_map( 'strtolower', $headers );
		$data = array();

		foreach ( $row_data as $idx => $value ) {
			if ( isset( $headers_lower[ $idx ] ) ) {
				$data[ $headers_lower[ $idx ] ] = $value;
			}
		}

		// Validate and sanitize fields
		$validation = self::validate_row_data( $data );
		if ( ! $validation['valid'] ) {
			return array(
				'success' => false,
				'error'   => $validation['error'],
			);
		}

		$username = sanitize_user( $data['user_login'] );
		$password = $data['user_pass']; // Raw password for user creation
		$company_name = sanitize_text_field( $data['company_name'] );

		// Check if user exists
		$existing_user = get_user_by( 'login', $username );
		if ( $existing_user ) {
			$user_id = $existing_user->ID;
			$is_new = false;
		} else {
			// Create new user
			$user_id = wp_create_user( $username, $password, sanitize_email( $data['user_email'] ?? '' ) );
			if ( is_wp_error( $user_id ) ) {
				return array(
					'success' => false,
					'error'   => 'Failed to create user: ' . $user_id->get_error_message(),
				);
			}
			$is_new = true;
		}

		// Get or create partner post
		$partner_post = self::get_or_create_partner_post( $company_name, $user_id );
		if ( is_wp_error( $partner_post ) ) {
			return array(
				'success' => false,
				'error'   => 'Failed to create partner: ' . $partner_post->get_error_message(),
			);
		}

		// Add user as partner
		update_user_meta( $user_id, 'psp_partner_id', $partner_post );
		wp_update_user( array(
			'ID'           => $user_id,
			'display_name' => $data['display_name'] ?? $username,
			'user_email'   => $data['user_email'] ?? '',
		) );

		// Save all metadata
		self::save_partner_metadata( $user_id, $partner_post, $data );

		return array(
			'success'   => true,
			'username'  => $username,
			'company'   => $company_name,
			'post_id'   => $partner_post,
			'user_id'   => $user_id,
			'is_new'    => $is_new,
		);
	}

	/**
	 * Validate row data
	 */
	private static function validate_row_data( $data ) {
		// Check required fields
		foreach ( self::FIELD_MAPPING as $field => $config ) {
			if ( $config['required'] && empty( $data[ $field ] ) ) {
				return array(
					'valid' => false,
					'error' => "Missing required field: {$config['label']}",
				);
			}
		}

		// Validate username format
		if ( ! empty( $data['user_login'] ) ) {
			if ( ! preg_match( '/^[a-z0-9_-]+$/i', $data['user_login'] ) ) {
				return array(
					'valid' => false,
					'error' => 'Invalid username format (alphanumeric, underscore, hyphen only)',
				);
			}
		}

		// Validate password strength
		if ( ! empty( $data['user_pass'] ) && strlen( $data['user_pass'] ) < 6 ) {
			return array(
				'valid' => false,
				'error' => 'Password must be at least 6 characters',
			);
		}

		// Validate integer fields
		if ( ! empty( $data['units'] ) && ! is_numeric( $data['units'] ) ) {
			return array(
				'valid' => false,
				'error' => 'Units must be a number',
			);
		}

		if ( ! empty( $data['number'] ) && ! is_numeric( $data['number'] ) ) {
			return array(
				'valid' => false,
				'error' => 'Unit number must be a number',
			);
		}

		return array( 'valid' => true );
	}

	/**
	 * Get existing partner or create new one
	 */
	private static function get_or_create_partner_post( $company_name, $user_id ) {
		// Check if partner already exists
		$existing = new \WP_Query( array(
			'post_type'      => 'psp_partner',
			'title'          => $company_name,
			'posts_per_page' => 1,
			'fields'         => 'ids',
		) );

		if ( ! empty( $existing->posts ) ) {
			return $existing->posts[0];
		}

		// Create new partner post
		$post_id = wp_insert_post( array(
			'post_type'   => 'psp_partner',
			'post_title'  => $company_name,
			'post_status' => 'publish',
			'post_author' => $user_id,
		) );

		return $post_id;
	}

	/**
	 * Save all partner metadata
	 */
	private static function save_partner_metadata( $user_id, $post_id, $data ) {
		$metadata_fields = array(
			'units'                   => 'units',
			'number'                  => 'number',
			'top_colour'              => 'top_colour',
			'company_name'            => 'company_name',
			'management_company'      => 'management_company',
			'street_address'          => 'street_address',
			'city'                    => 'city',
			'state'                   => 'state',
			'zip'                     => 'zip',
			'country'                 => 'country',
			'lock'                    => 'lock',
			'master_code'             => 'master_code',
			'sub_master_code'         => 'sub_master_code',
			'lock_part'               => 'lock_part',
			'key'                     => 'key',
			'primary_contact_name'    => 'primary_contact_name',
			'primary_contact_email'   => 'primary_contact_email',
			'secondary_contact_name'  => 'secondary_contact_name',
			'secondary_contact_email' => 'secondary_contact_email',
		);

		foreach ( $metadata_fields as $csv_field => $meta_key ) {
			if ( ! empty( $data[ $csv_field ] ) ) {
				$value = $data[ $csv_field ];
				
				// Sanitize based on field type
				if ( in_array( $csv_field, array( 'units', 'number' ), true ) ) {
					$value = intval( $value );
				} elseif ( strpos( $csv_field, 'email' ) !== false ) {
					$value = sanitize_email( $value );
				} else {
					$value = sanitize_text_field( $value );
				}

				// Save to post meta for partner CPT (primary storage)
				update_post_meta( $post_id, 'psp_' . $meta_key, $value );
				
				// Also save to user meta for quick access
				update_user_meta( $user_id, 'psp_' . $meta_key, $value );
			}
		}

		// Link user to company post via company_id meta
		update_user_meta( $user_id, 'psp_company_id', $post_id );
		
		// Link company post to user as primary_user_id if not already set
		$current_primary = get_post_meta( $post_id, 'psp_primary_user_id', true );
		if ( empty( $current_primary ) ) {
			update_post_meta( $post_id, 'psp_primary_user_id', $user_id );
		}
	}

	/**
	 * Link partner posts under company
	 */
	private static function link_partner_companies( $company_map ) {
		foreach ( $company_map as $company_name => $post_ids ) {
			if ( count( $post_ids ) > 1 ) {
				// Multiple posts under same company - update parent relationship
				$main_post_id = $post_ids[0];
				
				// Add company metadata to main post
				update_post_meta( $main_post_id, 'psp_company_name', $company_name );
				
				// Link other posts as related
				for ( $i = 1; $i < count( $post_ids ); $i++ ) {
					update_post_meta( $post_ids[ $i ], 'psp_parent_company', $main_post_id );
				}
			}
		}
	}

	/**
	 * Generate CSV template
	 */
	public static function generate_template() {
		$headers = array();
		foreach ( self::FIELD_MAPPING as $field => $config ) {
			$headers[] = $field;
		}

		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=partner-import-template.csv' );
		header( 'Pragma: no-cache' );
		header( 'Expires: 0' );

		$output = fopen( 'php://output', 'w' );
		
		// BOM for UTF-8
		fprintf( $output, chr( 0xEF ) . chr( 0xBB ) . chr( 0xBF ) );
		
		// Headers
		fputcsv( $output, $headers, ',', '"' );
		
		// Example row
		$example = array(
			'testuser01',                // user_login
			'SecurePass123',             // user_pass
			'12',                        // units
			'101',                       // number
			'Test User',                 // display_name
			'#0066CC',                   // top_colour
			'Test Company LLC',          // company_name
			'Test Management Co',        // management_company
			'123 Main St',               // street_address
			'Chicago',                   // city
			'IL',                        // state
			'60601',                     // zip
			'USA',                       // country
			'AquaLock Pro',              // lock
			'1234MASTER',                // master_code
			'1234SUB',                   // sub_master_code
			'PART-001',                  // lock_part
			'KEY-001',                   // key
			'John Smith',                // primary_contact_name
			'john.smith@company.com',    // primary_contact_email
			'Jane Doe',                  // secondary_contact_name
			'jane.doe@company.com',      // secondary_contact_email
		);
		fputcsv( $output, $example, ',', '"' );
		
		fclose( $output );
		exit;
	}
}
