<?php

namespace PSP;

/**
 * GDPR Data Export
 * 
 * Allows users to export their personal data in machine-readable format.
 * Complies with GDPR Article 15 (Right of Access).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class GDPR_Export {

	/**
	 * Initialize GDPR export functionality
	 * 
	 * @return void
	 */
	public static function init(): void {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	/**
	 * Register REST API routes
	 * 
	 * @return void
	 */
	public static function register_routes(): void {
		// Export user data endpoint
		register_rest_route(
			'psp/v1',
			'/user/export-data',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'export_user_data' ),
				'permission_callback' => array( __CLASS__, 'check_auth' ),
			)
		);

		// List available exports
		register_rest_route(
			'psp/v1',
			'/user/exports',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'list_exports' ),
				'permission_callback' => array( __CLASS__, 'check_auth' ),
			)
		);

		// Delete export after download
		register_rest_route(
			'psp/v1',
			'/user/exports/(?P<id>\d+)',
			array(
				'methods'             => 'DELETE',
				'callback'            => array( __CLASS__, 'delete_export' ),
				'permission_callback' => array( __CLASS__, 'check_auth' ),
			)
		);
	}

	/**
	 * Check if user is authenticated
	 * 
	 * @return bool
	 */
	public static function check_auth(): bool {
		return ( isset( $_SESSION['psp_user_id'] ) && ! empty( $_SESSION['psp_user_id'] ) ) || is_user_logged_in();
	}

	/**
	 * Export user data as JSON
	 * 
	 * @param \WP_REST_Request $request REST request
	 * @return \WP_REST_Response
	 */
	public static function export_user_data( \WP_REST_Request $request ): \WP_REST_Response {
		global $wpdb;

		try {
			$user_id = absint( $_SESSION['psp_user_id'] );
			if ( $user_id === 0 ) {
				return Error_Handler::unauthorized();
			}

			// Collect all user data
			$export_data = array(
				'export_date'    => current_time( 'mysql' ),
				'user_profile'   => self::get_user_profile( $user_id ),
				'company_info'   => self::get_company_info( $user_id ),
				'tickets'        => self::get_user_tickets( $user_id ),
				'ticket_replies' => self::get_user_replies( $user_id ),
				'services'       => self::get_user_services( $user_id ),
				'activity_log'   => self::get_user_activity( $user_id ),
			);

			// Get format from query parameter (json or csv)
			$format = sanitize_text_field( $request->get_param( 'format' ) );
			$format = in_array( $format, array( 'csv', 'json' ), true ) ? $format : 'json';

			// Store export record
			$export_id = self::store_export( $user_id, $export_data, $format );

			// Log GDPR export request
			Audit_Logger::log_event(
				'gdpr_export_requested',
				wp_json_encode( array( 'format' => $format, 'export_id' => $export_id ) ),
				'gdpr',
				$user_id
			);

			// Generate file content
			if ( $format === 'csv' ) {
				$content = self::generate_csv( $export_data );
				$filename = 'poolsafe-data-' . current_time( 'Y-m-d' ) . '.csv';
				$mime_type = 'text/csv';
			} else {
				$content = wp_json_encode( $export_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE );
				$filename = 'poolsafe-data-' . current_time( 'Y-m-d' ) . '.json';
				$mime_type = 'application/json';
			}

			return Error_Handler::success(
				array(
					'filename'  => $filename,
					'format'    => $format,
					'size'      => strlen( $content ),
					'export_id' => $export_id,
					'url'       => rest_url( "psp/v1/user/exports/{$export_id}/download" ),
				),
				__( 'Data export generated successfully', 'psp' )
			);
		} catch ( \Exception $e ) {
			return Error_Handler::server_error(
				__( 'Failed to generate data export', 'psp' ),
				array( 'exception' => $e->getMessage() )
			);
		}
	}

	/**
	 * Get user profile data
	 * 
	 * @param int $user_id User ID
	 * @return array
	 */
	private static function get_user_profile( int $user_id ): array {
		$user = get_user_by( 'id', $user_id );
		if ( ! $user ) {
			return array();
		}

		return array(
			'id'              => $user->ID,
			'username'        => $user->user_login,
			'email'           => $user->user_email,
			'first_name'      => $user->first_name,
			'last_name'       => $user->last_name,
			'display_name'    => $user->display_name,
			'registered_date' => $user->user_registered,
			'roles'           => $user->roles,
		);
	}

	/**
	 * Get company information
	 * 
	 * @param int $user_id User ID
	 * @return array
	 */
	private static function get_company_info( int $user_id ): array {
		global $wpdb;

		// Find company this user belongs to
		$company_id = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT post_id FROM {$wpdb->postmeta} 
				WHERE meta_key = 'psp_primary_user_id' AND meta_value = %d",
				$user_id
			)
		);

		if ( ! $company_id ) {
			return array();
		}

		$post = get_post( $company_id );
		if ( ! $post ) {
			return array();
		}

		// Get company meta
		$company_data = array(
			'id'            => $post->ID,
			'name'          => $post->post_title,
			'email'         => get_post_meta( $post->ID, 'psp_company_email', true ),
			'phone'         => get_post_meta( $post->ID, 'psp_phone', true ),
			'address'       => get_post_meta( $post->ID, 'psp_street_address', true ),
			'city'          => get_post_meta( $post->ID, 'psp_city', true ),
			'state'         => get_post_meta( $post->ID, 'psp_state', true ),
			'zip'           => get_post_meta( $post->ID, 'psp_zip', true ),
			'venue_type'    => get_post_meta( $post->ID, 'psp_venue_type', true ),
			'created_date'  => $post->post_date,
		);

		return array_filter( $company_data );
	}

	/**
	 * Get user's tickets
	 * 
	 * @param int $user_id User ID
	 * @return array
	 */
	private static function get_user_tickets( int $user_id ): array {
		global $wpdb;

		$tickets = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}psp_tickets WHERE created_by = %d ORDER BY created_at DESC",
				$user_id
			),
			ARRAY_A
		);

		return $tickets ?: array();
	}

	/**
	 * Get user's ticket replies
	 * 
	 * @param int $user_id User ID
	 * @return array
	 */
	private static function get_user_replies( int $user_id ): array {
		global $wpdb;

		$replies = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}psp_ticket_replies WHERE created_by = %d ORDER BY created_at DESC",
				$user_id
			),
			ARRAY_A
		);

		return $replies ?: array();
	}

	/**
	 * Get user's service records
	 * 
	 * @param int $user_id User ID
	 * @return array
	 */
	private static function get_user_services( int $user_id ): array {
		global $wpdb;

		$services = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}psp_service_records WHERE technician_id = %d OR created_by = %d ORDER BY date DESC",
				$user_id,
				$user_id
			),
			ARRAY_A
		);

		return $services ?: array();
	}

	/**
	 * Get user's activity log
	 * 
	 * @param int $user_id User ID
	 * @return array
	 */
	private static function get_user_activity( int $user_id ): array {
		global $wpdb;

		$activities = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT post_date, post_excerpt FROM {$wpdb->posts} 
				WHERE post_type = 'psp_audit_log' AND post_author = %d 
				ORDER BY post_date DESC LIMIT 1000",
				$user_id
			),
			ARRAY_A
		);

		return $activities ?: array();
	}

	/**
	 * Store export record
	 * 
	 * @param int $user_id User ID
	 * @param array $data Export data
	 * @param string $format Export format (json or csv)
	 * @return int Export ID
	 */
	private static function store_export( int $user_id, array $data, string $format ): int {
		global $wpdb;

		$insert = $wpdb->insert(
			"{$wpdb->prefix}psp_gdpr_exports",
			array(
				'user_id'      => $user_id,
				'format'       => $format,
				'data'         => wp_json_encode( $data ),
				'created_at'   => current_time( 'mysql' ),
				'expires_at'   => gmdate( 'Y-m-d H:i:s', time() + 7 * DAY_IN_SECONDS ),
				'downloaded'   => 0,
			),
			array( '%d', '%s', '%s', '%s', '%s', '%d' )
		);

		return $insert ? $wpdb->insert_id : 0;
	}

	/**
	 * Generate CSV from export data
	 * 
	 * @param array $data Export data
	 * @return string CSV content
	 */
	private static function generate_csv( array $data ): string {
		$csv = "PoolSafe Portal - Personal Data Export\n";
		$csv .= "Export Date: " . $data['export_date'] . "\n\n";

		// User Profile
		$csv .= "USER PROFILE\n";
		foreach ( $data['user_profile'] as $key => $value ) {
			$csv .= ucfirst( str_replace( '_', ' ', $key ) ) . "," . $value . "\n";
		}

		$csv .= "\n\nCOMPANY INFORMATION\n";
		foreach ( $data['company_info'] as $key => $value ) {
			$csv .= ucfirst( str_replace( '_', ' ', $key ) ) . "," . $value . "\n";
		}

		$csv .= "\n\nTICKETS\n";
		if ( ! empty( $data['tickets'] ) ) {
			$csv .= "ID,Title,Description,Status,Priority,Created,Updated\n";
			foreach ( $data['tickets'] as $ticket ) {
				$csv .= $ticket['id'] . ',"' . $ticket['title'] . '","' . substr( $ticket['description'], 0, 100 ) . '",' . $ticket['status'] . ',' . $ticket['priority'] . ',' . $ticket['created_at'] . ',' . $ticket['updated_at'] . "\n";
			}
		}

		return $csv;
	}

	/**
	 * List user's exports
	 * 
	 * @return \WP_REST_Response
	 */
	public static function list_exports(): \WP_REST_Response {
		global $wpdb;

		$user_id = absint( $_SESSION['psp_user_id'] );
		if ( $user_id === 0 ) {
			return Error_Handler::unauthorized();
		}

		$exports = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id, format, created_at, expires_at, downloaded FROM {$wpdb->prefix}psp_gdpr_exports 
				WHERE user_id = %d ORDER BY created_at DESC",
				$user_id
			),
			ARRAY_A
		);

		return Error_Handler::success( $exports ?: array() );
	}

	/**
	 * Delete export
	 * 
	 * @param \WP_REST_Request $request REST request
	 * @return \WP_REST_Response
	 */
	public static function delete_export( \WP_REST_Request $request ): \WP_REST_Response {
		global $wpdb;

		$user_id = absint( $_SESSION['psp_user_id'] );
		$export_id = absint( $request->get_param( 'id' ) );

		if ( $user_id === 0 ) {
			return Error_Handler::unauthorized();
		}

		// Verify export belongs to user
		$export = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT id FROM {$wpdb->prefix}psp_gdpr_exports WHERE id = %d AND user_id = %d",
				$export_id,
				$user_id
			)
		);

		if ( ! $export ) {
			return Error_Handler::not_found( 'Export', $export_id );
		}

		// Delete export
		$wpdb->delete(
			"{$wpdb->prefix}psp_gdpr_exports",
			array( 'id' => $export_id ),
			array( '%d' )
		);

		Audit_Logger::log_event(
			'gdpr_export_deleted',
			wp_json_encode( array( 'export_id' => $export_id ) ),
			'gdpr',
			$user_id
		);

		return Error_Handler::success( null, __( 'Export deleted successfully', 'psp' ) );
	}
}
