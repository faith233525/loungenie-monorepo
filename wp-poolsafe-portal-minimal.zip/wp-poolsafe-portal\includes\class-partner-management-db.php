<?php

/**
 * PSP_Partner_Management - Database schema for partner profiles
 * Includes primary/secondary contacts, notes, status, custom fields
 */

namespace PSP;

/**
 * PSP_Partner_Management - Database schema for partner profiles
 * Includes primary/secondary contacts, notes, status, custom fields
 */
class Partner_Management_DB {
    // Class implementation goes here
}

function psp_create_partner_tables() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}psp_partners (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        company_name VARCHAR(255),
        management_company VARCHAR(255),
        street_address VARCHAR(255),
        city VARCHAR(100),
        state VARCHAR(50),
        zip VARCHAR(20),
        country VARCHAR(100),
        phone VARCHAR(50),
        units INT,
        pool_colour VARCHAR(100),
        lock_type VARCHAR(100),
        master_code VARCHAR(100),
        sub_master_code VARCHAR(100),
        lock_part VARCHAR(100),
        key_code VARCHAR(100),
        primary_contact_name VARCHAR(255),
        primary_contact_email VARCHAR(255),
        primary_contact_phone VARCHAR(50),
        secondary_contact_name VARCHAR(255),
        secondary_contact_email VARCHAR(255),
        notes TEXT,
        preferred_contact_method VARCHAR(20),
        next_service_date DATE,
        last_service_date DATE,
        status VARCHAR(50),
        custom_fields JSON,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) $charset_collate;";
    include_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta( $sql );
}
add_action( 'init', 'psp_create_partner_tables' );
