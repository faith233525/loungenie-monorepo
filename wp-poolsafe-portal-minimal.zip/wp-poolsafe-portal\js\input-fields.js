/**
 * Input Fields Enhancement - Admin/Backend
 * Color picker, phone formatting, date validation, password strength
 */

jQuery(document).ready(function ($) {
    // ===== COLOR PICKER =====
    initializeColorPicker();

    // ===== PHONE FORMATTING =====
    initializePhoneFormatting();

    // ===== DATE RANGE VALIDATION =====
    initializeDateRangeValidation();

    // ===== PASSWORD STRENGTH =====
    initializePasswordStrength();

    /**
     * Initialize color picker with presets and custom picker
     */
    function initializeColorPicker() {
        // WordPress color picker
        $('.psp-color-picker-input').wpColorPicker({
            change: function (event, ui) {
                updateColorField($(this));
            },
            clear: function () {
                updateColorField($(this));
            }
        });

        // Preset color buttons
        $(document).on('click', '.psp-color-preset', function (e) {
            e.preventDefault();
            const colorKey = $(this).data('color');
            const hexValue = $(this).css('background-color');

            // Remove previous selection
            $('.psp-color-preset').removeClass('selected');
            $(this).addClass('selected');

            // Update color picker input
            const fieldName = $(this).closest('.psp-color-picker-wrapper').find('.psp-color-picker-input').data('field-name');
            const pickerInput = $(this).closest('.psp-color-picker-wrapper').find('.psp-color-picker-input');
            const hiddenField = $(this).closest('.psp-color-picker-wrapper').find('.psp-color-field-value');

            pickerInput.val(hexValue).wpColorPicker('color', hexValue);
            hiddenField.val(colorKey);
        });
    }

    /**
     * Update the hidden color field value
     */
    function updateColorField($input) {
        const hexValue = $input.val();
        const hiddenField = $input.closest('.psp-color-picker-wrapper').find('.psp-color-field-value');
        // Check if value matches a preset, otherwise store hex
        hiddenField.val(hexValue);
    }

    /**
     * Initialize phone number formatting
     */
    function initializePhoneFormatting() {
        $(document).on('input', '.psp-phone-input', function () {
            let value = $(this).val();

            // Remove all non-numeric characters except + and -
            value = value.replace(/[^\d\+\-]/g, '');

            // Format US phone: (XXX) XXX-XXXX
            if (value.length >= 10 && !value.startsWith('+')) {
                const areaCode = value.substring(0, 3);
                const prefix = value.substring(3, 6);
                const lineNumber = value.substring(6, 10);
                value = '(' + areaCode + ') ' + prefix + '-' + lineNumber;
            }

            $(this).val(value);
        });

        // Validate on blur
        $(document).on('blur', '.psp-phone-input', function () {
            const value = $(this).val();
            const digitCount = value.replace(/\D/g, '').length;

            if (value && digitCount < 10) {
                $(this).closest('.psp-phone-wrapper').find('.psp-phone-format')
                    .html('<span style="color:red;">⚠ Phone must be at least 10 digits</span>');
            } else {
                $(this).closest('.psp-phone-wrapper').find('.psp-phone-format')
                    .html('Format: (123) 456-7890');
            }
        });
    }

    /**
     * Initialize date range validation
     */
    function initializeDateRangeValidation() {
        $(document).on('change', '.psp-date-range-wrapper input[type="date"]', function () {
            const wrapper = $(this).closest('.psp-date-range-wrapper');
            const startDate = wrapper.find('input[type="date"]').first().val();
            const endDate = wrapper.find('input[type="date"]').last().val();
            const validation = wrapper.find('.psp-date-range-validation');

            if (startDate && endDate && startDate >= endDate) {
                validation.html('<span style="color:red;">⚠ Start date must be before end date</span>');
            } else {
                validation.html('Start date must be before end date');
            }
        });
    }

    /**
     * Initialize password strength indicator
     */
    function initializePasswordStrength() {
        $(document).on('input', '.psp-password-input', function () {
            const password = $(this).val();
            const wrapper = $(this).closest('.psp-password-wrapper');

            // Check requirements
            const hasLength = password.length >= 8;
            const hasUpper = /[A-Z]/.test(password);
            const hasNumber = /[0-9]/.test(password);
            const hasSpecial = /[!@#$%^&*\-_=+\[\]{};:'",.< >?\/\\|`~]/.test(password);

            // Update requirement indicators
            wrapper.find('.req-length')[hasLength ? 'addClass' : 'removeClass']('met');
            wrapper.find('.req-uppercase')[hasUpper ? 'addClass' : 'removeClass']('met');
            wrapper.find('.req-number')[hasNumber ? 'addClass' : 'removeClass']('met');
            wrapper.find('.req-special')[hasSpecial ? 'addClass' : 'removeClass']('met');

            // Calculate strength
            let strength = 0;
            if (hasLength) strength++;
            if (hasUpper) strength++;
            if (hasNumber) strength++;
            if (hasSpecial) strength++;

            // Update strength meter
            const meter = wrapper.find('.psp-strength-meter');
            const text = wrapper.find('.psp-strength-text');

            meter.removeClass('weak medium strong');

            if (password.length === 0) {
                meter.css('width', '0%');
                text.text('');
            } else if (strength <= 1) {
                meter.addClass('weak').css('width', '25%');
                text.text('Weak').css('color', '#dc3545');
            } else if (strength <= 2) {
                meter.addClass('medium').css('width', '50%');
                text.text('Fair').css('color', '#ffc107');
            } else if (strength <= 3) {
                meter.addClass('strong').css('width', '75%');
                text.text('Good').css('color', '#17a2b8');
            } else {
                meter.addClass('strong').css('width', '100%');
                text.text('Strong').css('color', '#28a745');
            }
        });

        // Password show/hide toggle
        $(document).on('click', '.psp-password-toggle', function (e) {
            e.preventDefault();
            const fieldId = $(this).data('field');
            const input = $('#' + fieldId);
            const isPassword = input.attr('type') === 'password';

            input.attr('type', isPassword ? 'text' : 'password');
            $(this).text(isPassword ? '🙈' : '👁');
        });
    }
});
