// assets/js/psp-push.js
// Browser push notification registration and event logic for Pool Safe Portal

(function () {
  if (!('Notification' in window)) {
    return;
  }

  async function requestPushPermission() {
    if (Notification.permission === 'granted') {
      return true;
    }
    if (Notification.permission === 'denied') {
      return false;
    }
    const perm = await Notification.requestPermission();
    return perm === 'granted';
  }

  async function registerServiceWorker() {
    if (!('serviceWorker' in navigator)) {
      return null;
    }
    try {
      const reg = await navigator.serviceWorker.register('/psp-push-sw.js');
      return reg;
    } catch {
      return null;
    }
  }

  // Subscribe to push (placeholder, needs server integration for real push)
  async function subscribeToPush() {
    const reg = await registerServiceWorker();
    if (!reg) {
      return null;
    }
    // TODO: Integrate with server for push subscription
    // Example: reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: ... })
    return reg;
  }

  // Show a test notification (for demo)
  async function showTestNotification() {
    if (!(await requestPushPermission())) {
      return;
    }
    new Notification('Pool Safe Portal', {
      body: 'Push notifications enabled! You will receive ticket updates here.',
      icon: '/assets/img/psp-icon.png',
    });
  }

  // Expose to global for UI integration
  window.PSP_PUSH = {
    requestPushPermission,
    registerServiceWorker,
    subscribeToPush,
    showTestNotification,
  };
})();
