<?php

namespace PSP;

/**
 * Error Handler & Response Formatter
 * 
 * Standardizes all API error responses across the portal.
 * Provides consistent error format, logging, and user-friendly messages.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Error_Handler {

	/**
	 * HTTP Status Codes
	 */
	const OK                  = 200;
	const CREATED             = 201;
	const BAD_REQUEST         = 400;
	const UNAUTHORIZED        = 401;
	const FORBIDDEN           = 403;
	const NOT_FOUND           = 404;
	const CONFLICT            = 409;
	const UNPROCESSABLE       = 422;
	const TOO_MANY_REQUESTS   = 429;
	const SERVER_ERROR        = 500;
	const SERVICE_UNAVAILABLE = 503;

	/**
	 * Error codes for API responses
	 */
	const ERROR_INVALID_INPUT    = 'invalid_input';
	const ERROR_UNAUTHORIZED     = 'unauthorized';
	const ERROR_FORBIDDEN        = 'forbidden';
	const ERROR_NOT_FOUND        = 'not_found';
	const ERROR_CONFLICT         = 'conflict';
	const ERROR_RATE_LIMIT       = 'rate_limit_exceeded';
	const ERROR_SERVER           = 'server_error';
	const ERROR_VALIDATION       = 'validation_error';
	const ERROR_DATABASE         = 'database_error';
	const ERROR_EMAIL            = 'email_error';

	/**
	 * Log error to database and error log
	 * 
	 * @param string $error_code Error code identifier
	 * @param string $error_message Error message
	 * @param array $context Additional context data
	 * @param int $user_id User ID (optional)
	 * @param string $endpoint API endpoint (optional)
	 * @return void
	 */
	public static function log_error( string $error_code, string $error_message, array $context = array(), int $user_id = 0, string $endpoint = '' ): void {
		$log_data = array(
			'timestamp' => current_time( 'mysql' ),
			'code'      => $error_code,
			'message'   => $error_message,
			'context'   => wp_json_encode( $context ),
			'user_id'   => $user_id > 0 ? $user_id : 0,
			'endpoint'  => $endpoint,
			'ip'        => self::get_client_ip(),
		);

		// Log to error log file
		if ( defined( 'WP_DEBUG_LOG' ) && WP_DEBUG_LOG ) {
			error_log( '[PSP Error] ' . wp_json_encode( $log_data ) );
		}

		// Also store in audit log for critical errors
		if ( in_array( $error_code, array( self::ERROR_UNAUTHORIZED, self::ERROR_SERVER, self::ERROR_DATABASE ), true ) ) {
			Audit_Logger::log_event(
				'error_occurred',
				wp_json_encode( $log_data ),
				'error',
				$user_id
			);
		}
	}

	/**
	 * Return standardized success response
	 * 
	 * @param mixed $data Response data
	 * @param string $message Success message (optional)
	 * @param int $status HTTP status code
	 * @return \WP_REST_Response
	 */
	public static function success( $data = null, string $message = '', int $status = self::OK ): \WP_REST_Response {
		$response = array(
			'success' => true,
			'status'  => $status,
		);

		if ( $message ) {
			$response['message'] = $message;
		}

		if ( $data !== null ) {
			$response['data'] = $data;
		}

		return new \WP_REST_Response( $response, $status );
	}

	/**
	 * Return standardized error response
	 * 
	 * @param string $error_code Error code identifier
	 * @param string $error_message User-friendly error message
	 * @param int $status HTTP status code
	 * @param array $details Additional error details (field errors, etc)
	 * @param array $context Context for logging
	 * @return \WP_REST_Response
	 */
	public static function error( string $error_code, string $error_message, int $status = self::BAD_REQUEST, array $details = array(), array $context = array() ): \WP_REST_Response {
		$user_id = isset( $_SESSION['psp_user_id'] ) ? absint( $_SESSION['psp_user_id'] ) : 0;
		$endpoint = isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( $_SERVER['REQUEST_URI'] ) : '';

		// Log the error
		self::log_error( $error_code, $error_message, $context, $user_id, $endpoint );

		$response = array(
			'success' => false,
			'status'  => $status,
			'error'   => array(
				'code'    => $error_code,
				'message' => $error_message,
			),
		);

		// Include field-specific errors if provided
		if ( ! empty( $details ) ) {
			$response['error']['details'] = $details;
		}

		// In debug mode, include more context
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			$response['error']['context'] = $context;
		}

		return new \WP_REST_Response( $response, $status );
	}

	/**
	 * Return validation error with field-specific messages
	 * 
	 * @param array $field_errors Array of field => error message
	 * @return \WP_REST_Response
	 */
	public static function validation_error( array $field_errors ): \WP_REST_Response {
		$message = count( $field_errors ) === 1 
			? 'One required field is missing' 
			: count( $field_errors ) . ' fields have errors';

		return self::error(
			self::ERROR_VALIDATION,
			$message,
			self::UNPROCESSABLE,
			$field_errors
		);
	}

	/**
	 * Return unauthorized error
	 * 
	 * @param string $reason Reason for unauthorized (optional)
	 * @return \WP_REST_Response
	 */
	public static function unauthorized( string $reason = '' ): \WP_REST_Response {
		$message = $reason ?: __( 'You must be logged in to access this resource', 'psp' );
		return self::error(
			self::ERROR_UNAUTHORIZED,
			$message,
			self::UNAUTHORIZED
		);
	}

	/**
	 * Return forbidden error
	 * 
	 * @param string $reason Reason for forbidden (optional)
	 * @return \WP_REST_Response
	 */
	public static function forbidden( string $reason = '' ): \WP_REST_Response {
		$message = $reason ?: __( 'You do not have permission to access this resource', 'psp' );
		return self::error(
			self::ERROR_FORBIDDEN,
			$message,
			self::FORBIDDEN
		);
	}

	/**
	 * Return not found error
	 * 
	 * @param string $resource Resource type (e.g., "Ticket", "Company")
	 * @param mixed $id Resource ID
	 * @return \WP_REST_Response
	 */
	public static function not_found( string $resource = 'Resource', $id = '' ): \WP_REST_Response {
		$message = $id 
			? sprintf( __( '%s with ID %s not found', 'psp' ), $resource, $id )
			: sprintf( __( '%s not found', 'psp' ), $resource );

		return self::error(
			self::ERROR_NOT_FOUND,
			$message,
			self::NOT_FOUND
		);
	}

	/**
	 * Return conflict error (duplicate, already exists, etc)
	 * 
	 * @param string $message Conflict message
	 * @return \WP_REST_Response
	 */
	public static function conflict( string $message = '' ): \WP_REST_Response {
		$default_message = __( 'This resource already exists', 'psp' );
		return self::error(
			self::ERROR_CONFLICT,
			$message ?: $default_message,
			self::CONFLICT
		);
	}

	/**
	 * Return rate limit error
	 * 
	 * @param int $retry_after Seconds until can retry
	 * @return \WP_REST_Response
	 */
	public static function rate_limited( int $retry_after = 60 ): \WP_REST_Response {
		$message = sprintf(
			__( 'Too many requests. Please try again in %d seconds', 'psp' ),
			$retry_after
		);

		$response = self::error(
			self::ERROR_RATE_LIMIT,
			$message,
			self::TOO_MANY_REQUESTS
		);

		// Add retry-after header
		if ( function_exists( 'rest_get_server' ) ) {
			$server = rest_get_server();
			$server->send_header( 'Retry-After', (string) $retry_after );
		}

		return $response;
	}

	/**
	 * Return server error
	 * 
	 * @param string $message Error message
	 * @param array $context Context for logging
	 * @return \WP_REST_Response
	 */
	public static function server_error( string $message = '', array $context = array() ): \WP_REST_Response {
		$default_message = __( 'An unexpected server error occurred. Please try again later', 'psp' );
		return self::error(
			self::ERROR_SERVER,
			$message ?: $default_message,
			self::SERVER_ERROR,
			array(),
			$context
		);
	}

	/**
	 * Return database error
	 * 
	 * @param string $operation Operation that failed (insert, update, delete, select)
	 * @param array $context Context for logging
	 * @return \WP_REST_Response
	 */
	public static function database_error( string $operation = 'query', array $context = array() ): \WP_REST_Response {
		$message = sprintf(
			__( 'Database %s failed. Please try again or contact support', 'psp' ),
			$operation
		);

		return self::error(
			self::ERROR_DATABASE,
			$message,
			self::SERVER_ERROR,
			array(),
			$context
		);
	}

	/**
	 * Return email error
	 * 
	 * @param string $recipient Email recipient
	 * @param string $reason Reason email failed
	 * @return \WP_REST_Response
	 */
	public static function email_error( string $recipient = '', string $reason = '' ): \WP_REST_Response {
		$message = __( 'Failed to send email. Please try again or contact support', 'psp' );
		return self::error(
			self::ERROR_EMAIL,
			$message,
			self::SERVER_ERROR,
			array(),
			array(
				'recipient' => $recipient,
				'reason'    => $reason,
			)
		);
	}

	/**
	 * Get client IP address
	 * 
	 * @return string Client IP
	 */
	public static function get_client_ip(): string {
		if ( ! empty( $_SERVER['HTTP_CF_CONNECTING_IP'] ) ) {
			// Cloudflare
			return sanitize_text_field( $_SERVER['HTTP_CF_CONNECTING_IP'] );
		} elseif ( ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
			// Proxy
			$ips = explode( ',', sanitize_text_field( $_SERVER['HTTP_X_FORWARDED_FOR'] ) );
			return trim( $ips[0] );
		} elseif ( ! empty( $_SERVER['REMOTE_ADDR'] ) ) {
			return sanitize_text_field( $_SERVER['REMOTE_ADDR'] );
		}
		return 'unknown';
	}

	/**
	 * Catch uncaught exceptions and return proper error response
	 * 
	 * @param \Exception $exception Exception object
	 * @return void
	 */
	public static function handle_exception( \Exception $exception ): void {
		$message = $exception->getMessage() ?: __( 'An error occurred', 'psp' );
		$response = self::server_error(
			$message,
			array(
				'exception' => get_class( $exception ),
				'file'      => $exception->getFile(),
				'line'      => $exception->getLine(),
				'trace'     => $exception->getTraceAsString(),
			)
		);

		wp_send_json( $response->get_data(), $response->get_status() );
		exit;
	}

	/**
	 * Register error handler hooks
	 * 
	 * @return void
	 */
	public static function init(): void {
		// Set custom exception handler
		set_exception_handler( array( __CLASS__, 'handle_exception' ) );
	}
}
