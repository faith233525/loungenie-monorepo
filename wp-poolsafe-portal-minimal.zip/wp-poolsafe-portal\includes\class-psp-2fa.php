<?php
/**
 * Two-Factor Authentication Class
 * File: includes/class-psp-2fa.php
 * 
 * Implements TOTP-based two-factor authentication.
 * Supports Google Authenticator and similar apps.
 * 
 * @package PoolSafe_Portal
 * @subpackage Security
 * @since 3.0.0
 * @author PoolSafe Team
 */

class PSP_2FA {

    const USER_META_SECRET = 'psp_2fa_secret';
    const USER_META_BACKUP_CODES = 'psp_2fa_backup_codes';
    const USER_META_ENABLED = 'psp_2fa_enabled';
    const TOTP_DIGITS = 6;
    const TOTP_PERIOD = 30; // Seconds

    /**
     * Generate random secret for TOTP
     *
     * @return string Random secret (base32 encoded)
     */
    public static function generate_secret() {
        try {
            if ( ! function_exists( 'wp_rand' ) ) {
                error_log( '[PSP 2FA] wp_rand() not available' );
                return '';
            }
            
            $random = wp_rand( 0, 0xffffffff );
            $secret = base64_encode( wp_rand( 0, 0xffffffff ) . wp_rand( 0, 0xffffffff ) );
            
            if ( empty( $secret ) ) {
                error_log( '[PSP 2FA] Failed to generate secret' );
                return '';
            }
            
            return $secret;
        } catch ( \Exception $e ) {
            error_log( '[PSP 2FA] Secret generation failed: ' . $e->getMessage() );
            return '';
        }
    }

    /**
     * Generate QR code URL for secret
     *
     * @param int $user_id User ID
     * @param string $secret Secret to encode
     * @return string QR code URL
     */
    public static function get_qr_code_url( $user_id, $secret ) {
        try {
            if ( ! is_numeric( $user_id ) || $user_id <= 0 ) {
                error_log( '[PSP 2FA] Invalid user ID for QR code generation' );
                return '';
            }
            
            if ( empty( $secret ) ) {
                error_log( '[PSP 2FA] Empty secret provided for QR code' );
                return '';
            }
            
            $user = get_user_by( 'id', $user_id );
            
            if ( ! $user || ! isset( $user->user_email ) ) {
                error_log( '[PSP 2FA] User not found or invalid: ' . $user_id );
                return '';
            }

            $site_name = get_bloginfo( 'name' );
            if ( empty( $site_name ) ) {
                $site_name = 'WordPress Site';
            }
            
            $label = urlencode( "$site_name ({$user->user_email})" );
            
            return "https://chart.googleapis.com/chart?chs=200x200&chld=M|0&cht=qr&chl=otpauth://totp/$label%3Fsecret%3D$secret";
        } catch ( \Exception $e ) {
            error_log( '[PSP 2FA] QR code URL generation failed: ' . $e->getMessage() );
            return '';
        }
    }

    /**
     * Verify TOTP token
     *
     * @param int $user_id User ID
     * @param string $token Token to verify
     * @return bool True if token is valid
     */
    public static function verify_token( $user_id, $token ) {
        try {
            if ( ! is_numeric( $user_id ) || $user_id <= 0 ) {
                error_log( '[PSP 2FA] Invalid user ID for token verification' );
                return false;
            }
            
            if ( empty( $token ) ) {
                error_log( '[PSP 2FA] Empty token provided' );
                return false;
            }
            
            if ( ! function_exists( 'get_user_meta' ) ) {
                error_log( '[PSP 2FA] get_user_meta() not available' );
                return false;
            }
            
            $secret = get_user_meta( $user_id, self::USER_META_SECRET, true );
            
            if ( empty( $secret ) ) {
                error_log( '[PSP 2FA] No secret found for user: ' . $user_id );
                return false;
            }

            // Remove spaces
            $token = str_replace( ' ', '', $token );

            // Check if token is numeric and correct length
            if ( ! preg_match( '/^\d{6}$/', $token ) ) {
                error_log( '[PSP 2FA] Invalid token format' );
                return false;
            }

            // Verify token (allow for time drift ±30 seconds)
            return self::verify_totp( $secret, $token, 1 );
        } catch ( \Exception $e ) {
            error_log( '[PSP 2FA] Token verification failed: ' . $e->getMessage() );
            return false;
        }
    }

    /**
     * Verify TOTP token against secret
     *
     * @param string $secret Base32 encoded secret
     * @param string $token Token to verify
     * @param int $window Time window tolerance (in periods)
     * @return bool True if valid
     */
    private static function verify_totp( $secret, $token, $window = 1 ) {
        try {
            if ( empty( $secret ) || empty( $token ) ) {
                error_log( '[PSP 2FA] Empty secret or token in verify_totp' );
                return false;
            }
            
            if ( ! is_numeric( $window ) || $window < 0 ) {
                error_log( '[PSP 2FA] Invalid time window: ' . $window );
                $window = 1; // Default
            }
            
            $time = floor( time() / self::TOTP_PERIOD );

            // Check current and surrounding time windows
            for ( $i = -$window; $i <= $window; $i++ ) {
                $hmac = self::get_totp( $secret, $time + $i );
                if ( $hmac === $token ) {
                    return true;
                }
            }

            return false;
        } catch ( \Exception $e ) {
            error_log( '[PSP 2FA] TOTP verification error: ' . $e->getMessage() );
            return false;
        }
    }

    /**
     * Generate TOTP token
     *
     * @param string $secret Base32 encoded secret
     * @param int $time Time counter (default current time)
     * @return string 6-digit TOTP token
     */
    private static function get_totp( $secret, $time = null ) {
        if ( null === $time ) {
            $time = floor( time() / self::TOTP_PERIOD );
        }

        // Decode base32 secret
        $key = self::base32_decode( $secret );

        // Create time counter (big-endian)
        $counter = pack( 'N', 0 ) . pack( 'N', $time );

        // Generate HMAC
        $hmac = hash_hmac( 'sha1', $counter, $key, true );

        // Dynamic truncation
        $offset = ord( $hmac[19] ) & 0x0f;
        $code = unpack( 'N', substr( $hmac, $offset, 4 ) );
        $code = $code[1] & 0x7fffffff;

        return str_pad( $code % pow( 10, self::TOTP_DIGITS ), self::TOTP_DIGITS, '0', STR_PAD_LEFT );
    }

    /**
     * Decode base32 string
     *
     * @param string $input Base32 encoded string
     * @return string Decoded binary string
     */
    private static function base32_decode( $input ) {
        $input = strtoupper( $input );
        $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
        $output = '';
        $v = 0;
        $bits = 0;

        for ( $i = 0; $i < strlen( $input ); $i++ ) {
            $idx = strpos( $alphabet, $input[ $i ] );
            if ( false === $idx ) {
                continue;
            }

            $v = ( $v << 5 ) | $idx;
            $bits += 5;

            if ( $bits >= 8 ) {
                $bits -= 8;
                $output .= chr( ( $v >> $bits ) & 0xff );
            }
        }

        return $output;
    }

    /**
     * Generate backup codes
     *
     * @param int $count Number of codes to generate
     * @return array Generated backup codes
     */
    public static function generate_backup_codes( $count = 10 ) {
        try {
            if ( ! is_numeric( $count ) || $count <= 0 || $count > 50 ) {
                error_log( '[PSP 2FA] Invalid backup code count: ' . $count );
                $count = 10; // Default
            }
            
            if ( ! function_exists( 'wp_rand' ) ) {
                error_log( '[PSP 2FA] wp_rand() not available for backup codes' );
                return [];
            }
            
            $codes = [];

            for ( $i = 0; $i < $count; $i++ ) {
                $code = strtoupper( bin2hex( wp_rand() . wp_rand() ) );
                $code = substr( $code, 0, 8 );
                
                if ( empty( $code ) ) {
                    error_log( '[PSP 2FA] Failed to generate backup code ' . ( $i + 1 ) );
                    continue;
                }
                
                $codes[] = $code;
            }
            
            if ( count( $codes ) < $count ) {
                error_log( '[PSP 2FA] Only generated ' . count( $codes ) . ' of ' . $count . ' backup codes' );
            }

            return $codes;
        } catch ( \Exception $e ) {
            error_log( '[PSP 2FA] Backup code generation failed: ' . $e->getMessage() );
            return [];
        }
    }

    /**
     * Save backup codes for user
     *
     * @param int $user_id User ID
     * @param array $codes Backup codes
     */
    public static function save_backup_codes( $user_id, $codes ) {
        // Hash codes for storage
        $hashed = array_map(
            function( $code ) {
                return wp_hash_password( $code );
            },
            $codes
        );

        update_user_meta( $user_id, self::USER_META_BACKUP_CODES, $hashed );
    }

    /**
     * Verify and use backup code
     *
     * @param int $user_id User ID
     * @param string $code Backup code to verify
     * @return bool True if code is valid and used
     */
    public static function verify_backup_code( $user_id, $code ) {
        $codes = get_user_meta( $user_id, self::USER_META_BACKUP_CODES, true );
        
        if ( empty( $codes ) ) {
            return false;
        }

        // Find and verify code
        foreach ( $codes as $idx => $hashed ) {
            if ( wp_check_password( $code, $hashed ) ) {
                // Remove used code
                unset( $codes[ $idx ] );
                update_user_meta( $user_id, self::USER_META_BACKUP_CODES, array_values( $codes ) );
                return true;
            }
        }

        return false;
    }

    /**
     * Enable 2FA for user
     *
     * @param int $user_id User ID
     * @param string $secret TOTP secret
     * @param array $backup_codes Backup codes
     * @return bool Success
     */
    public static function enable( $user_id, $secret, $backup_codes ) {
        update_user_meta( $user_id, self::USER_META_SECRET, $secret );
        self::save_backup_codes( $user_id, $backup_codes );
        update_user_meta( $user_id, self::USER_META_ENABLED, true );

        do_action( 'psp_2fa_enabled', $user_id );

        return true;
    }

    /**
     * Disable 2FA for user
     *
     * @param int $user_id User ID
     * @return bool Success
     */
    public static function disable( $user_id ) {
        delete_user_meta( $user_id, self::USER_META_SECRET );
        delete_user_meta( $user_id, self::USER_META_BACKUP_CODES );
        delete_user_meta( $user_id, self::USER_META_ENABLED );

        do_action( 'psp_2fa_disabled', $user_id );

        return true;
    }

    /**
     * Check if 2FA is enabled for user
     *
     * @param int $user_id User ID
     * @return bool True if enabled
     */
    public static function is_enabled( $user_id ) {
        return (bool) get_user_meta( $user_id, self::USER_META_ENABLED, true );
    }

    /**
     * Get remaining backup codes count
     *
     * @param int $user_id User ID
     * @return int Number of remaining codes
     */
    public static function get_remaining_backup_codes( $user_id ) {
        $codes = get_user_meta( $user_id, self::USER_META_BACKUP_CODES, true );
        return empty( $codes ) ? 0 : count( $codes );
    }

    /**
     * Log 2FA event
     *
     * @param int $user_id User ID
     * @param string $event Event type (attempt, success, fail)
     * @param array $data Additional data
     */
    public static function log_event( $user_id, $event, $data = [] ) {
        $log_data = array_merge(
            [
                'user_id' => $user_id,
                'event'   => $event,
                'time'    => current_time( 'mysql' ),
                'ip'      => PSP_Rate_Limiter::get_client_ip(),
            ],
            $data
        );

        do_action( 'psp_2fa_event', $log_data );
    }

    /**
     * Register WP-CLI commands
     */
    public static function register_cli_commands() {
        if ( ! class_exists( 'WP_CLI' ) ) {
            return;
        }

        WP_CLI::add_command( 'psp 2fa enable', [ __CLASS__, 'cli_enable' ] );
        WP_CLI::add_command( 'psp 2fa disable', [ __CLASS__, 'cli_disable' ] );
        WP_CLI::add_command( 'psp 2fa status', [ __CLASS__, 'cli_status' ] );
    }

    /**
     * WP-CLI: Enable 2FA for user
     *
     * @param array $args Positional arguments
     * @param array $assoc_args Associative arguments
     */
    public static function cli_enable( $args, $assoc_args ) {
        if ( empty( $args[0] ) ) {
            WP_CLI::error( 'Please provide a user ID' );
        }

        $user_id = intval( $args[0] );
        $user = get_user_by( 'id', $user_id );

        if ( ! $user ) {
            WP_CLI::error( "User not found: $user_id" );
        }

        $secret = self::generate_secret();
        $codes = self::generate_backup_codes( 10 );

        self::enable( $user_id, $secret, $codes );

        WP_CLI::log( '2FA Enabled for user: ' . $user->user_login );
        WP_CLI::log( 'Secret: ' . $secret );
        WP_CLI::log( 'Backup Codes: ' );
        foreach ( $codes as $code ) {
            WP_CLI::log( "  - $code" );
        }
    }

    /**
     * WP-CLI: Disable 2FA for user
     *
     * @param array $args Positional arguments
     * @param array $assoc_args Associative arguments
     */
    public static function cli_disable( $args, $assoc_args ) {
        if ( empty( $args[0] ) ) {
            WP_CLI::error( 'Please provide a user ID' );
        }

        $user_id = intval( $args[0] );
        $user = get_user_by( 'id', $user_id );

        if ( ! $user ) {
            WP_CLI::error( "User not found: $user_id" );
        }

        self::disable( $user_id );
        WP_CLI::success( '2FA Disabled for user: ' . $user->user_login );
    }

    /**
     * WP-CLI: Check 2FA status
     *
     * @param array $args Positional arguments
     * @param array $assoc_args Associative arguments
     */
    public static function cli_status( $args, $assoc_args ) {
        if ( empty( $args[0] ) ) {
            WP_CLI::error( 'Please provide a user ID' );
        }

        $user_id = intval( $args[0] );
        $user = get_user_by( 'id', $user_id );

        if ( ! $user ) {
            WP_CLI::error( "User not found: $user_id" );
        }

        $enabled = self::is_enabled( $user_id );
        $codes = self::get_remaining_backup_codes( $user_id );

        WP_CLI::log( '2FA Status for: ' . $user->user_login );
        WP_CLI::log( '  Enabled: ' . ( $enabled ? 'Yes' : 'No' ) );
        WP_CLI::log( '  Backup Codes Remaining: ' . $codes );
    }
}
