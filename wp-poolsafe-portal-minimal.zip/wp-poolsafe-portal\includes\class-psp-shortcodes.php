<?php
/**
 * PoolSafe Portal - Shortcode Registration
 *
 * Unified shortcode system with role-based tab visibility and company-centric data model.
 * 
 * Main Shortcodes:
 * - [poolsafe_portal] - Unified portal with role-based tabs (Partners: 4 tabs, Support: 5 tabs)
 * - [poolsafe_login]  - Login form
 *
 * @package    PoolSafe_Portal
 * @subpackage PoolSafe_Portal/includes
 * @link       https://poolsafe.com
 * @since      1.0.0
 * @version    3.3.0
 * 
 * Features:
 * - Role-based tab visibility (pool_safe_partner vs pool_safe_support)
 * - Company-centric data filtering (all queries use company_id)
 * - CSP-compliant architecture (wp_localize_script for config)
 * - SPA-style navigation (no page reloads)
 */

namespace PSP;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Register all shortcodes for the portal
 *
 * @since      1.0.0
 * @package    PoolSafe_Portal
 */
class Shortcodes {

	/**
	 * Initialize shortcodes
	 *
	 * @since    1.0.0
	 * @return void
	 */
	public static function init(): void {
		// SINGLE UNIFIED PORTAL SHORTCODE
		// Usage: [poolsafe_portal]
		// Role-based tabs: Partners see Dashboard/Videos/Tickets/Services
		//                  Support sees Dashboard/Videos/Tickets/Services/Partners
		add_shortcode( 'poolsafe_portal', [ self::class, 'render_portal' ] );
		
		// Login shortcode for login pages
		add_shortcode( 'poolsafe_login', [ self::class, 'render_login' ] );
	}

	// ==================== MAIN PORTAL ====================

	/**
	 * Render main portal shortcode - SINGLE UNIFIED SPA
	 * Usage: [poolsafe_portal]
	 * 
	 * Role-based tab visibility:
	 * - Partners: Dashboard, Videos, Tickets, Services
	 * - Support/Admin: Dashboard, Videos, Tickets, Services, Partners (with CSV upload)
	 * - Admin (WordPress): Full unrestricted access to all features
	 * 
	 * All data (tickets, services, installs, updates) connected to company_id, not user
	 * Admin users bypass all restrictions when logged in through WordPress
	 *
	 * @since    3.3.0
	 */
	public static function render_portal( $atts ) {
		if ( ! is_user_logged_in() ) {
			return self::render_login( $atts );
		}

		// Get WordPress user
		$wp_user   = wp_get_current_user();
		$user_role = 'pool_safe_partner';
		$is_admin  = current_user_can( 'manage_options' );

		// Determine role - Admin gets full access
		if ( $is_admin ) {
			$user_role = 'administrator';
		} elseif ( in_array( 'pool_safe_support', (array) $wp_user->roles, true ) || in_array( 'psp_support', (array) $wp_user->roles, true ) ) {
			$user_role = 'pool_safe_support';
		}

		// Get company ID (ALL data tied to company, not user)
		$company_id = (int) get_user_meta( $wp_user->ID, 'psp_partner_id', true );
		if ( ! $company_id ) {
			$company_id = (int) get_user_meta( $wp_user->ID, 'psp_company_id', true );
		}

		// Build user context
		$portal_user = array(
			'id'           => $wp_user->ID,
			'name'         => $wp_user->display_name ?: $wp_user->user_login,
			'email'        => $wp_user->user_email,
			'role'         => $user_role,
			'company_id'   => $company_id ?: null,
			'company_name' => $company_id ? get_the_title( $company_id ) : '',
		);

		// Role-based tab visibility
		$visible_tabs = ['dashboard', 'videos', 'tickets', 'services'];
		$can_upload_csv = false;
		$is_unrestricted = false; // Admin flag
		
		if ( $user_role === 'pool_safe_support' || $user_role === 'administrator' ) {
			$visible_tabs[] = 'partners'; // Support sees partner management
			$can_upload_csv = true; // Support can upload CSV
		}
		
		// Admin users get unrestricted access
		if ( $is_admin ) {
			$is_unrestricted = true;
			$can_upload_csv = true;
		}

		$GLOBALS['psp_portal_current_user'] = $portal_user;
		$GLOBALS['psp_portal_user_role']    = $user_role;
		$GLOBALS['psp_portal_visible_tabs'] = $visible_tabs;
		$GLOBALS['psp_portal_config'] = array(
			'apiUrl'        => rest_url('psp/v1'),
			'ajaxUrl'       => admin_url('admin-ajax.php'),
			'nonce'         => wp_create_nonce('wp_rest'),
			'user'          => $portal_user,
			'userRole'      => $user_role,
			'companyId'     => $company_id,
			'visibleTabs'   => $visible_tabs,
			'canUploadCsv'  => $can_upload_csv,
			'isUnrestricted' => $is_unrestricted,
			'adminUrl'      => admin_url(),
			'isAdmin'       => $is_admin,
			'debug'         => defined('PSP_DEBUG') && PSP_DEBUG,
			'pluginUrl'     => PSP_PLUGIN_URL,
		);

		// Prepare config for JavaScript (CSP-compliant via wp_localize_script)
		$portal_config = array(
			'apiUrl'        => rest_url('psp/v1'),
			'nonce'         => wp_create_nonce('wp_rest'),
			'user'          => $portal_user,
			'userRole'      => $user_role,
			'companyId'     => $company_id,
			'visibleTabs'   => $visible_tabs,
			'canUploadCsv'  => $can_upload_csv,
			'isUnrestricted' => $is_unrestricted,
			'adminUrl'      => admin_url(),
			'isAdmin'       => $is_admin,
			'debug'         => defined('PSP_DEBUG') && PSP_DEBUG,
		);

		// Enqueue assets
		\PSP\Frontend::enqueue_assets();

		ob_start();
		include PSP_PLUGIN_DIR . 'views/unified-portal-clean.php';
		return ob_get_clean();
	}

	// ==================== AUTHENTICATION ====================

	/**
	 * Render login shortcode
	 * Usage: [poolsafe_login]
	 *
	 * @since    1.0.0
	 */
	public static function render_login( $atts ) {
		// Check if already logged in
		if ( self::is_logged_in() ) {
			return '<div class="psp-alert psp-alert-info">✓ Already logged in. <a href="' . esc_url( home_url( '/portal' ) ) . '">Go to Portal</a></div>';
		}

		ob_start();
		include PSP_PLUGIN_DIR . 'views/login.php';
		return ob_get_clean();
	}

	/**
	 * Check if user is logged in (WordPress admin login only)
	 * Admin users get full unrestricted portal access
	 *
	 * @since    1.0.0
	 */
	private static function is_logged_in() {
		return is_user_logged_in();
	}
}
