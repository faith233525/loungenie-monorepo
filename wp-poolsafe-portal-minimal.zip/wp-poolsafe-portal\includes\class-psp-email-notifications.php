<?php
/**
 * Email Notification System
 * Sends notifications for ticket updates, replies, and status changes
 */

if (!defined('ABSPATH')) {
    exit;
}

class PSP_Email_Notifications {
    
    private $from_email = 'noreply@poolsafe.local';
    private $from_name = 'PoolSafe Portal';
    
    public function __construct() {
        // Ticket created
        add_action('psp_ticket_created', [$this, 'notify_ticket_created'], 10, 2);
        
        // Reply added
        add_action('psp_ticket_reply_added', [$this, 'notify_reply_added'], 10, 3);
        
        // Ticket status changed
        add_action('psp_ticket_status_changed', [$this, 'notify_status_changed'], 10, 3);
        
        // Ticket assigned
        add_action('psp_ticket_assigned', [$this, 'notify_ticket_assigned'], 10, 3);
    }
    
    /**
     * Notify when ticket is created
     */
    public function notify_ticket_created($ticket_id, $ticket_data) {
        global $wpdb;
        
        $ticket = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}psp_tickets WHERE id = %d",
            $ticket_id
        ));
        
        if (!$ticket) return;
        
        // Notify support staff
        $this->notify_support_staff($ticket, 'ticket_created');
        
        // Notify company about confirmation
        $this->notify_company($ticket, 'ticket_created_confirmation');
    }
    
    /**
     * Notify when reply is added
     */
    public function notify_reply_added($ticket_id, $reply_id, $user) {
        global $wpdb;
        
        $ticket = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}psp_tickets WHERE id = %d",
            $ticket_id
        ));
        
        $reply = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}psp_ticket_replies WHERE id = %d",
            $reply_id
        ));
        
        if (!$ticket || !$reply) return;
        
        // Internal reply - only notify admins
        if ($reply->is_internal) {
            $this->notify_admin_team($ticket, 'internal_reply', $user);
        } else {
            // External reply - notify opposite party
            if ($user['role'] === 'admin' || $user['role'] === 'staff') {
                // Support replied - notify company
                $this->notify_company($ticket, 'support_reply', $reply, $user);
            } else {
                // Partner replied - notify support
                $this->notify_support_staff($ticket, 'partner_reply', $reply, $user);
            }
        }
    }
    
    /**
     * Notify when status changes
     */
    public function notify_status_changed($ticket_id, $old_status, $new_status) {
        global $wpdb;
        
        $ticket = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}psp_tickets WHERE id = %d",
            $ticket_id
        ));
        
        if (!$ticket) return;
        
        // Only notify on important transitions
        $important_transitions = [
            'open' => 'closed',
            'pending' => 'open',
            'on_hold' => 'open',
        ];
        
        if (isset($important_transitions[$old_status]) && 
            $important_transitions[$old_status] === $new_status) {
            $this->notify_company($ticket, 'ticket_status_changed', 
                null, null, $new_status);
        }
    }
    
    /**
     * Notify when ticket is assigned
     */
    public function notify_ticket_assigned($ticket_id, $assigned_user_id, $assigner_user) {
        global $wpdb;
        
        $ticket = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}psp_tickets WHERE id = %d",
            $ticket_id
        ));
        
        $assigned_user = $wpdb->get_row($wpdb->prepare(
            "SELECT email, name FROM {$wpdb->prefix}psp_company_users WHERE id = %d",
            $assigned_user_id
        ));
        
        if (!$ticket || !$assigned_user) return;
        
        $this->send_email(
            $assigned_user->email,
            'Ticket Assigned to You',
            $this->get_email_template('ticket_assigned', [
                'ticket_id' => $ticket->id,
                'subject' => $ticket->subject,
                'priority' => $ticket->priority,
                'assigned_by' => $assigner_user['name'],
                'assigned_to' => $assigned_user->name,
            ])
        );
    }
    
    /**
     * Notify support staff
     */
    private function notify_support_staff($ticket, $template, $reply = null, $user = null) {
        global $wpdb;
        
        // Get all support staff
        $staff = $wpdb->get_results(
            "SELECT email, name FROM {$wpdb->prefix}psp_company_users 
             WHERE role IN ('admin', 'staff') AND status = 'active'"
        );
        
        foreach ($staff as $member) {
            $email_data = [
                'ticket_id' => $ticket->id,
                'subject' => $ticket->subject,
                'priority' => $ticket->priority,
                'company_id' => $ticket->partner_id,
                'staff_member' => $member->name,
            ];
            
            if ($reply) {
                $email_data['reply_message'] = substr($reply->message, 0, 200) . '...';
                $email_data['reply_author'] = $user['name'] ?? 'Unknown';
            }
            
            $this->send_email(
                $member->email,
                "Ticket #{$ticket->id} - {$template}",
                $this->get_email_template($template, $email_data)
            );
        }
    }
    
    /**
     * Notify company/partner
     */
    private function notify_company($ticket, $template, $reply = null, $user = null, $new_status = null) {
        global $wpdb;
        
        // Get company email contacts
        $company = $wpdb->get_row($wpdb->prepare(
            "SELECT email FROM {$wpdb->prefix}psp_partners WHERE id = %d",
            $ticket->partner_id
        ));
        
        if (!$company || !$company->email) return;
        
        $email_data = [
            'ticket_id' => $ticket->id,
            'subject' => $ticket->subject,
            'priority' => $ticket->priority,
        ];
        
        if ($reply) {
            $email_data['reply_message'] = substr($reply->message, 0, 500);
            $email_data['reply_author'] = $user['name'] ?? 'Support Team';
        }
        
        if ($new_status) {
            $email_data['new_status'] = ucfirst($new_status);
        }
        
        $this->send_email(
            $company->email,
            "Ticket #{$ticket->id} Update",
            $this->get_email_template($template, $email_data)
        );
    }
    
    /**
     * Notify admin team
     */
    private function notify_admin_team($ticket, $template, $user) {
        global $wpdb;
        
        $admins = $wpdb->get_results(
            "SELECT email, name FROM {$wpdb->prefix}psp_company_users 
             WHERE role = 'admin' AND status = 'active'"
        );
        
        foreach ($admins as $admin) {
            $email_data = [
                'ticket_id' => $ticket->id,
                'subject' => $ticket->subject,
                'admin_name' => $admin->name,
                'from_user' => $user['name'],
            ];
            
            $this->send_email(
                $admin->email,
                "Internal Note on Ticket #{$ticket->id}",
                $this->get_email_template($template, $email_data)
            );
        }
    }
    
    /**
     * Get email template
     */
    private function get_email_template($template_name, $data = []) {
        $templates = [
            'ticket_created' => '
                <h2>New Support Ticket Created</h2>
                <p><strong>Ticket ID:</strong> #' . $data['ticket_id'] . '</p>
                <p><strong>Subject:</strong> ' . esc_html($data['subject']) . '</p>
                <p><strong>Priority:</strong> ' . esc_html($data['priority']) . '</p>
                <p>A new support ticket has been created and assigned to your queue.</p>
                <p><a href="' . admin_url('admin.php?page=portal&section=tickets&id=' . $data['ticket_id']) . '">View Ticket</a></p>
            ',
            
            'ticket_created_confirmation' => '
                <h2>Your Support Ticket Has Been Created</h2>
                <p>Thank you for contacting PoolSafe support.</p>
                <p><strong>Ticket ID:</strong> #' . $data['ticket_id'] . '</p>
                <p><strong>Subject:</strong> ' . esc_html($data['subject']) . '</p>
                <p>Your ticket has been received and will be reviewed shortly.</p>
                <p><a href="' . site_url('/?psp_portal=1&ticket_id=' . $data['ticket_id']) . '">View Ticket Online</a></p>
            ',
            
            'support_reply' => '
                <h2>New Reply on Ticket #' . $data['ticket_id'] . '</h2>
                <p>Hi there,</p>
                <p>A member of our support team has replied to your ticket:</p>
                <blockquote style="padding: 15px; background: #f5f5f5; border-left: 3px solid #667eea;">
                    ' . wp_kses_post($data['reply_message']) . '
                </blockquote>
                <p><strong>From:</strong> ' . esc_html($data['reply_author']) . '</p>
                <p><a href="' . site_url('/?psp_portal=1&ticket_id=' . $data['ticket_id']) . '">View Full Ticket</a></p>
            ',
            
            'partner_reply' => '
                <h2>Ticket #' . $data['ticket_id'] . ' - New Reply from ' . esc_html($data['reply_author']) . '</h2>
                <p>The company has replied to ticket #' . $data['ticket_id'] . ':</p>
                <blockquote style="padding: 15px; background: #f5f5f5; border-left: 3px solid #667eea;">
                    ' . wp_kses_post($data['reply_message']) . '
                </blockquote>
                <p><a href="' . admin_url('admin.php?page=portal&section=tickets&id=' . $data['ticket_id']) . '">View Ticket</a></p>
            ',
            
            'ticket_status_changed' => '
                <h2>Ticket Status Updated</h2>
                <p><strong>Ticket ID:</strong> #' . $data['ticket_id'] . '</p>
                <p><strong>Subject:</strong> ' . esc_html($data['subject']) . '</p>
                <p><strong>New Status:</strong> ' . esc_html($data['new_status']) . '</p>
                <p><a href="' . site_url('/?psp_portal=1&ticket_id=' . $data['ticket_id']) . '">View Ticket</a></p>
            ',
            
            'ticket_assigned' => '
                <h2>Ticket Assigned to You</h2>
                <p>Hi ' . esc_html($data['assigned_to']) . ',</p>
                <p>Ticket #' . $data['ticket_id'] . ' has been assigned to you:</p>
                <p><strong>Subject:</strong> ' . esc_html($data['subject']) . '</p>
                <p><strong>Priority:</strong> ' . esc_html($data['priority']) . '</p>
                <p><strong>Assigned by:</strong> ' . esc_html($data['assigned_by']) . '</p>
                <p><a href="' . admin_url('admin.php?page=portal&section=tickets&id=' . $data['ticket_id']) . '">View Ticket</a></p>
            ',
            
            'internal_reply' => '
                <h2>Internal Note Added to Ticket #' . $data['ticket_id'] . '</h2>
                <p>' . esc_html($data['from_user']) . ' added an internal note.</p>
                <p><a href="' . admin_url('admin.php?page=portal&section=tickets&id=' . $data['ticket_id']) . '">View Ticket</a></p>
            ',
        ];
        
        return isset($templates[$template_name]) ? $templates[$template_name] : '';
    }
    
    /**
     * Send email
     */
    private function send_email($to, $subject, $message) {
        $headers = [
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . $this->from_name . ' <' . $this->from_email . '>'
        ];
        
        $message = '
            <html>
            <head>
                <style>
                    body { font-family: Arial, sans-serif; color: #333; }
                    h2 { color: #667eea; }
                    a { color: #667eea; text-decoration: none; }
                    blockquote { margin: 20px 0; }
                </style>
            </head>
            <body>
                ' . $message . '
                <hr style="margin-top: 50px; border: none; border-top: 1px solid #e5e7eb;">
                <p style="color: #999; font-size: 12px;">
                    This is an automated message from PoolSafe Portal. Please do not reply to this email.
                </p>
            </body>
            </html>
        ';
        
        wp_mail($to, $subject, $message, $headers);
    }
}

// Initialize
new PSP_Email_Notifications();
