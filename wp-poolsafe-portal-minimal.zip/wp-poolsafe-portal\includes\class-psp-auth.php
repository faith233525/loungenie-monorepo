<?php
/**
 * Portal Authentication Wrapper
 *
 * @link       https://poolsafe.com
 * @since      1.0.0
 *
 * @package    PoolSafe_Portal
 * @subpackage PoolSafe_Portal/includes
 */

/**
 * Authentication class for portal users
 *
 * @since      1.0.0
 * @package    PoolSafe_Portal
 */
class PSP_Auth {

	/**
	 * Check if user is logged into the portal
	 *
	 * @since    1.0.0
	 * @return   bool
	 */
	public static function is_logged_in() {
		// Check if portal session exists
		if ( ! isset( $_SESSION['psp_user_id'] ) ) {
			return false;
		}

		// Check for session timeout (30 minutes of inactivity)
		if ( self::check_session_timeout() ) {
			self::logout();
			return false;
		}

		// Update last activity time
		$_SESSION['psp_last_activity'] = time();

		global $wpdb;

		// Verify user exists in database
		$user = $wpdb->get_row( $wpdb->prepare(
			"SELECT id FROM {$wpdb->prefix}psp_users WHERE id = %d AND status = 'active'",
			intval( $_SESSION['psp_user_id'] )
		) );

		return ! empty( $user );
	}

	/**
	 * Get current logged in user
	 *
	 * @since    1.0.0
	 * @return   object|null
	 */
	public static function get_current_user() {
		if ( ! self::is_logged_in() ) {
			return null;
		}

		global $wpdb;

		return $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}psp_users WHERE id = %d",
			intval( $_SESSION['psp_user_id'] )
		) );
	}

	/**
	 * Login user
	 *
	 * @since    1.0.0
	 * @param    string $email
	 * @param    string $password
	 * @return   bool
	 */
	public static function login( $email, $password ) {
		global $wpdb;

		$sanitized_email = sanitize_email( strtolower( (string) $email ) );
		if ( empty( $sanitized_email ) || empty( $password ) ) {
			return false;
		}

		$user = $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}psp_users WHERE email = %s AND status = 'active'",
			$sanitized_email
		) );

		if ( empty( $user ) ) {
			return false;
		}

		// Verify password
		if ( ! password_verify( $password, $user->password_hash ) ) {
			return false;
		}

		// Set session
		if ( ! session_id() ) {
			session_start();
		}

		// Prevent session fixation on successful login.
		session_regenerate_id( true );

		$_SESSION['psp_user_id']      = $user->id;
		$_SESSION['psp_user_email']   = $user->email;
		$_SESSION['psp_user_role']    = $user->role;
		$_SESSION['psp_last_activity'] = time(); // Set initial activity time

		// Update last login
		$wpdb->update(
			$wpdb->prefix . 'psp_users',
			array( 'last_login' => current_time( 'mysql' ) ),
			array( 'id' => $user->id ),
			array( '%s' ),
			array( '%d' )
		);

		return true;
	}

	/**
	 * Logout user
	 *
	 * @since    1.0.0
	 */
	public static function logout() {
		if ( ! session_id() ) {
			session_start();
		}

		unset( $_SESSION['psp_user_id'] );
		unset( $_SESSION['psp_user_email'] );
		unset( $_SESSION['psp_user_role'] );

		session_destroy();
	}

	/**
	 * Get current user role
	 *
	 * @since    1.0.0
	 * @return   string|null
	 */
	public static function get_current_user_role() {
		if ( ! isset( $_SESSION['psp_user_role'] ) ) {
			return null;
		}

		return $_SESSION['psp_user_role'];
	}

	/**
	 * Check if user has a specific role
	 *
	 * @since    1.0.0
	 * @param    string $role
	 * @return   bool
	 */
	public static function has_role( $role ) {
		return self::get_current_user_role() === $role;
	}

	/**
	 * Check if user has any of the specified roles
	 *
	 * @since    1.0.0
	 * @param    array $roles
	 * @return   bool
	 */
	public static function has_any_role( $roles ) {
		return in_array( self::get_current_user_role(), $roles, true );
	}

	/**
	 * Register new user
	 *
	 * @since    1.0.0
	 * @param    array $user_data
	 * @return   int|false
	 */
	public static function register_user( $user_data ) {
		global $wpdb;

		$email     = isset( $user_data['email'] ) ? sanitize_email( strtolower( (string) $user_data['email'] ) ) : '';
		$password  = isset( $user_data['password'] ) ? (string) $user_data['password'] : '';
		$first_name = isset( $user_data['first_name'] ) ? sanitize_text_field( $user_data['first_name'] ) : '';
		$last_name = isset( $user_data['last_name'] ) ? sanitize_text_field( $user_data['last_name'] ) : '';
		$phone = isset( $user_data['phone'] ) ? sanitize_text_field( $user_data['phone'] ) : '';
		$role = isset( $user_data['role'] ) ? sanitize_key( $user_data['role'] ) : 'subscriber';
		$partner_id = isset( $user_data['partner_id'] ) ? intval( $user_data['partner_id'] ) : null;

		// Validate inputs
		if ( ! is_email( $email ) || empty( $password ) ) {
			return false;
		}

		// Check if email already exists
		$existing = $wpdb->get_row( $wpdb->prepare(
			"SELECT id FROM {$wpdb->prefix}psp_users WHERE email = %s",
			$email
		) );

		if ( ! empty( $existing ) ) {
			return false;
		}

		// Hash password
		$password_hash = password_hash( $password, PASSWORD_BCRYPT );

		// Insert user
		$inserted = $wpdb->insert(
			$wpdb->prefix . 'psp_users',
			array(
				'email' => $email,
				'password_hash' => $password_hash,
				'first_name' => $first_name,
				'last_name' => $last_name,
				'phone' => $phone,
				'role' => $role,
				'partner_id' => $partner_id,
				'status' => 'active',
			),
			array( '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s' )
		);

		if ( ! $inserted ) {
			return false;
		}

		return $wpdb->insert_id;
	}

	/**
	 * Check if session has timed out (30 minutes of inactivity)
	 *
	 * @since    1.0.0
	 * @return   bool True if session has timed out
	 */
	private static function check_session_timeout() {
		$timeout = 30 * 60; // 30 minutes in seconds

		// If last activity time not set, session is invalid
		if ( ! isset( $_SESSION['psp_last_activity'] ) ) {
			return true;
		}

		// Check if timeout exceeded
		if ( ( time() - $_SESSION['psp_last_activity'] ) > $timeout ) {
			return true;
		}

		return false;
	}
}
