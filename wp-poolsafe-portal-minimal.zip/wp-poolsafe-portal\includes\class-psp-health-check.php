<?php
/**
 * Health Check Endpoint - API System Status Monitor
 *
 * Provides /psp/v3/health endpoint for monitoring:
 * - PHP version and extensions
 * - WordPress configuration
 * - Database connectivity
 * - API availability
 * - Performance metrics
 * - Error logs
 *
 * @package PSP
 * @version 3.3.0
 */

namespace PSP\API;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Health Check API Class
 *
 * Registers and handles the /psp/v3/health REST endpoint.
 */
class HealthCheck {

	/**
	 * REST API namespace
	 *
	 * @var string
	 */
	private $namespace = 'psp/v3';

	/**
	 * Initialize health check endpoint
	 *
	 * @return void
	 */
	public static function init() {
		$instance = new self();
		add_action( 'rest_api_init', array( $instance, 'register_health_endpoint' ) );
	}

	/**
	 * Register health check endpoint
	 *
	 * @return void
	 */
	public function register_health_endpoint() {
		register_rest_route(
			$this->namespace,
			'/health',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'get_health_status' ),
				'permission_callback' => '__return_true', // Public endpoint
			)
		);
	}

	/**
	 * Get comprehensive system health status
	 *
	 * @param \WP_REST_Request $request WordPress REST request object.
	 * @return \WP_REST_Response System health data.
	 */
	public function get_health_status( $request ) {
		try {
			$health_data = array(
				'timestamp'   => current_time( 'c' ),
				'status'      => 'healthy',
				'version'     => defined( 'PSP_VERSION' ) ? PSP_VERSION : '3.3.0',
				'php'         => $this->check_php_health(),
				'wordpress'   => $this->check_wordpress_health(),
				'database'    => $this->check_database_health(),
				'extensions'  => $this->check_required_extensions(),
				'api'         => $this->check_api_health(),
				'performance' => $this->get_performance_metrics(),
				'security'    => $this->check_security_status(),
			);

			// Determine overall status
			if ( ! $this->is_system_healthy( $health_data ) ) {
				$health_data['status'] = 'degraded';
			}

			return rest_ensure_response( $health_data );

		} catch ( \Exception $e ) {
			return new \WP_Error(
				'health_check_failed',
				'Failed to check system health: ' . $e->getMessage(),
				array( 'status' => 500 )
			);
		}
	}

	/**
	 * Check PHP health and configuration
	 *
	 * @return array PHP health information.
	 */
	private function check_php_health() {
		$memory_usage = function_exists( 'memory_get_usage' ) ? memory_get_usage() : 0;
		$memory_limit = wp_convert_hr_to_bytes( ini_get( 'memory_limit' ) );

		return array(
			'version'            => phpversion(),
			'minimum_version'    => '7.4',
			'meets_requirement'  => version_compare( phpversion(), '7.4', '>=' ),
			'memory_limit'       => size_format( $memory_limit ),
			'memory_usage'       => size_format( $memory_usage ),
			'memory_percentage'  => $memory_limit > 0 ? round( ( $memory_usage / $memory_limit ) * 100, 2 ) : 0,
			'max_execution_time' => ini_get( 'max_execution_time' ) . 's',
			'upload_max_size'    => size_format( wp_convert_hr_to_bytes( ini_get( 'upload_max_filesize' ) ) ),
		);
	}

	/**
	 * Check WordPress health and configuration
	 *
	 * @return array WordPress health information.
	 */
	private function check_wordpress_health() {
		global $wp_version;

		return array(
			'version'           => $wp_version,
			'minimum_version'   => '5.8',
			'meets_requirement' => version_compare( $wp_version, '5.8', '>=' ),
			'multisite'         => is_multisite(),
			'debug_mode'        => defined( 'WP_DEBUG' ) && WP_DEBUG,
			'site_url'          => site_url(),
			'home_url'          => home_url(),
			'admin_email'       => get_option( 'admin_email' ),
		);
	}

	/**
	 * Check database connectivity and health
	 *
	 * @return array Database health information.
	 */
	private function check_database_health() {
		global $wpdb;

		try {
			// Test database connection
			$db_check = $wpdb->get_var( 'SELECT 1' );
			$connected = ( '1' === $db_check );

			// Get database size
			$database_size = 0;
			$tables         = $wpdb->get_results( "SELECT TABLE_NAME, ROUND(((data_length + index_length) / 1024 / 1024), 2) AS size FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE()" );

			if ( $tables ) {
				foreach ( $tables as $table ) {
					$database_size += $table->size;
				}
			}

			return array(
				'connected'       => $connected,
				'host'            => $wpdb->dbhost,
				'name'            => $wpdb->dbname,
				'charset'         => $wpdb->charset,
				'collate'         => $wpdb->collate,
				'table_count'     => count( $wpdb->tables() ),
				'database_size'   => round( $database_size, 2 ) . ' MB',
				'last_error'      => empty( $wpdb->last_error ) ? 'None' : $wpdb->last_error,
			);

		} catch ( \Exception $e ) {
			return array(
				'connected' => false,
				'error'     => $e->getMessage(),
			);
		}
	}

	/**
	 * Check required PHP extensions
	 *
	 * @return array Extension status.
	 */
	private function check_required_extensions() {
		$required_extensions = array(
			'curl',
			'json',
			'mbstring',
			'openssl',
			'pdo',
			'pdo_mysql',
			'gd',
			'zip',
		);

		$extensions = array();

		foreach ( $required_extensions as $ext ) {
			$extensions[ $ext ] = array(
				'loaded'   => extension_loaded( $ext ),
				'version'  => phpversion( $ext ) ?: 'N/A',
			);
		}

		return $extensions;
	}

	/**
	 * Check API health and endpoint availability
	 *
	 * @return array API health information.
	 */
	private function check_api_health() {
		$api_endpoints = array(
			'psp/v3/health'   => 'Health Check',
			'psp/v3/stats'    => 'Dashboard Stats',
			'psp/v3/tickets'  => 'Tickets',
			'psp/v3/services' => 'Services',
		);

		$endpoints_status = array();

		foreach ( $api_endpoints as $route => $name ) {
			$response = rest_get_server()->dispatch(
				new \WP_REST_Request( 'OPTIONS', '/wp-json/' . $route )
			);

			$endpoints_status[ $route ] = array(
				'name'   => $name,
				'status' => is_wp_error( $response ) ? 'error' : 'available',
			);
		}

		return array(
			'endpoints'       => $endpoints_status,
			'rest_enabled'    => rest_api_enabled(),
			'cors_enabled'    => defined( 'REST_REQUEST' ),
		);
	}

	/**
	 * Get current performance metrics
	 *
	 * @return array Performance metrics.
	 */
	private function get_performance_metrics() {
		$metrics = array(
			'page_load_time'  => microtime( true ) - ( defined( 'WP_START_TIMESTAMP' ) ? WP_START_TIMESTAMP : $_SERVER['REQUEST_TIME_FLOAT'] ),
			'queries_count'   => defined( 'SAVEQUERIES' ) && SAVEQUERIES ? count( $GLOBALS['wpdb']->queries ) : 'N/A',
			'cache_enabled'   => wp_using_ext_object_cache(),
			'opcache_enabled' => function_exists( 'opcache_get_status' ) ? function_exists( 'opcache_is_script_preloaded' ) : false,
		);

		// Get Web Vitals if available
		if ( function_exists( 'get_transient' ) ) {
			$vitals = get_transient( 'psp_web_vitals' );
			if ( $vitals ) {
				$metrics['web_vitals'] = $vitals;
			}
		}

		return $metrics;
	}

	/**
	 * Check security status
	 *
	 * @return array Security status information.
	 */
	private function check_security_status() {
		return array(
			'ssl_enabled'              => is_ssl(),
			'https_forced'             => defined( 'FORCE_SSL_ADMIN' ) && FORCE_SSL_ADMIN,
			'two_factor_auth_enabled'  => class_exists( 'PSP\Auth\TwoFactor' ),
			'rate_limiting_enabled'    => class_exists( 'PSP\Security\RateLimiter' ),
			'csp_headers_enabled'      => class_exists( 'PSP\Performance\PerformanceEnhancements' ),
			'audit_logging_enabled'    => class_exists( 'PSP\Logging\AuditLog' ),
		);
	}

	/**
	 * Determine if system is healthy
	 *
	 * @param array $health_data Health status data.
	 * @return bool True if system is healthy.
	 */
	private function is_system_healthy( $health_data ) {
		// Check PHP version
		if ( ! $health_data['php']['meets_requirement'] ) {
			return false;
		}

		// Check WordPress version
		if ( ! $health_data['wordpress']['meets_requirement'] ) {
			return false;
		}

		// Check database connection
		if ( ! $health_data['database']['connected'] ) {
			return false;
		}

		// Check memory usage isn't too high (>90%)
		if ( $health_data['php']['memory_percentage'] > 90 ) {
			return false;
		}

		return true;
	}
}

// Initialize health check on plugins loaded
add_action( 'plugins_loaded', array( 'PSP\API\HealthCheck', 'init' ) );
