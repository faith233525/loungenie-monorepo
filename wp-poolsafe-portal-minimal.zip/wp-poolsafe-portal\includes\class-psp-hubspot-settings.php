<?php
/**
 * HubSpot Settings Admin Page
 *
 * @link       https://poolsafe.com
 * @since      1.0.0
 *
 * @package    PoolSafe_Portal
 * @subpackage PoolSafe_Portal/includes
 */

/**
 * Handle HubSpot settings page in WordPress admin
 *
 * @since      1.0.0
 * @package    PoolSafe_Portal
 */
class PSP_HubSpot_Settings {

	/**
	 * Initialize settings
	 *
	 * @since    1.0.0
	 */
	public static function init() {
		// Only initialize in WordPress admin
		if ( ! is_admin() ) {
			return;
		}

		add_action( 'admin_menu', array( __CLASS__, 'add_menu_page' ) );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
		add_action( 'wp_ajax_psp_test_hubspot', array( __CLASS__, 'test_hubspot_connection' ) );
	}

	/**
	 * Add menu page to WordPress admin
	 *
	 * @since    1.0.0
	 */
	public static function add_menu_page() {
		add_submenu_page(
			'poolsafe-portal',
			'HubSpot Integration',
			'HubSpot Integration',
			'manage_options',
			'psp-hubspot-settings',
			array( __CLASS__, 'render_settings_page' )
		);
	}

	/**
	 * Register settings
	 *
	 * @since    1.0.0
	 */
	public static function register_settings() {
		register_setting( 'psp_hubspot_settings', 'psp_hubspot_api_key' );
		register_setting( 'psp_hubspot_settings', 'psp_hubspot_enabled' );
		register_setting( 'psp_hubspot_settings', 'psp_hubspot_sync_tickets' );
		register_setting( 'psp_hubspot_settings', 'psp_hubspot_sync_services' );
		register_setting( 'psp_hubspot_settings', 'psp_hubspot_sync_partners' );
	}

	/**
	 * Render settings page
	 *
	 * @since    1.0.0
	 */
	public static function render_settings_page() {
		$api_key        = get_option( 'psp_hubspot_api_key' );
		$enabled        = get_option( 'psp_hubspot_enabled' );
		$sync_tickets   = get_option( 'psp_hubspot_sync_tickets' );
		$sync_services  = get_option( 'psp_hubspot_sync_services' );
		$sync_partners  = get_option( 'psp_hubspot_sync_partners' );
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'HubSpot Integration', 'poolsafe-portal' ); ?></h1>

			<div class="notice notice-info" style="margin-top: 20px;">
				<p>
					<?php esc_html_e( 'Connect your PoolSafe Portal to HubSpot CRM to automatically sync tickets, service records, and partner information.', 'poolsafe-portal' ); ?>
				</p>
			</div>

			<form method="post" action="options.php" style="max-width: 600px;">
				<?php settings_fields( 'psp_hubspot_settings' ); ?>

				<table class="form-table">
					<tr>
						<th scope="row">
							<label for="psp_hubspot_enabled">
								<?php esc_html_e( 'Enable HubSpot Integration', 'poolsafe-portal' ); ?>
							</label>
						</th>
						<td>
							<input 
								type="checkbox" 
								id="psp_hubspot_enabled" 
								name="psp_hubspot_enabled" 
								value="1"
								<?php checked( $enabled, '1' ); ?>
							/>
							<p class="description">
								<?php esc_html_e( 'Enable or disable HubSpot synchronization.', 'poolsafe-portal' ); ?>
							</p>
						</td>
					</tr>

					<tr>
						<th scope="row">
							<label for="psp_hubspot_api_key">
								<?php esc_html_e( 'HubSpot API Key', 'poolsafe-portal' ); ?>
							</label>
						</th>
						<td>
							<input 
								type="password" 
								id="psp_hubspot_api_key" 
								name="psp_hubspot_api_key" 
								value="<?php echo esc_attr( $api_key ); ?>"
								class="regular-text"
								placeholder="<?php esc_attr_e( 'Enter your HubSpot API key', 'poolsafe-portal' ); ?>"
							/>
							<p class="description">
								<?php 
									printf(
										/* translators: %s: HubSpot documentation link */
										esc_html__( 'Get your API key from %s', 'poolsafe-portal' ),
										'<a href="https://app.hubspot.com/personal-access-key" target="_blank">HubSpot Settings</a>'
									); 
								?>
							</p>
							<button type="button" id="psp_test_hubspot" class="button button-secondary" style="margin-top: 10px;">
								<?php esc_html_e( 'Test Connection', 'poolsafe-portal' ); ?>
							</button>
							<div id="psp_hubspot_test_result" style="margin-top: 10px; display: none;"></div>
						</td>
					</tr>

					<tr>
						<th scope="row"><?php esc_html_e( 'Sync Options', 'poolsafe-portal' ); ?></th>
						<td>
							<label>
								<input 
									type="checkbox" 
									name="psp_hubspot_sync_tickets" 
									value="1"
									<?php checked( $sync_tickets, '1' ); ?>
								/>
								<?php esc_html_e( 'Sync tickets to HubSpot deals', 'poolsafe-portal' ); ?>
							</label>
							<br/>
							<label style="margin-top: 8px; display: block;">
								<input 
									type="checkbox" 
									name="psp_hubspot_sync_services" 
									value="1"
									<?php checked( $sync_services, '1' ); ?>
								/>
								<?php esc_html_e( 'Sync service records to HubSpot deals', 'poolsafe-portal' ); ?>
							</label>
							<br/>
							<label style="margin-top: 8px; display: block;">
								<input 
									type="checkbox" 
									name="psp_hubspot_sync_partners" 
									value="1"
									<?php checked( $sync_partners, '1' ); ?>
								/>
								<?php esc_html_e( 'Sync partners to HubSpot companies', 'poolsafe-portal' ); ?>
							</label>
							<p class="description">
								<?php esc_html_e( 'Choose which data types to synchronize with HubSpot.', 'poolsafe-portal' ); ?>
							</p>
						</td>
					</tr>
				</table>

				<?php submit_button(); ?>
			</form>

			<h2 style="margin-top: 40px;">
				<?php esc_html_e( 'What Gets Synced', 'poolsafe-portal' ); ?>
			</h2>

			<h3><?php esc_html_e( 'Tickets → HubSpot Deals', 'poolsafe-portal' ); ?></h3>
			<ul style="margin-left: 20px;">
				<li><?php esc_html_e( 'Ticket title → Deal name', 'poolsafe-portal' ); ?></li>
				<li><?php esc_html_e( 'Ticket description → Deal description', 'poolsafe-portal' ); ?></li>
				<li><?php esc_html_e( 'Ticket status → Deal stage', 'poolsafe-portal' ); ?></li>
				<li><?php esc_html_e( 'Ticket priority → Deal priority', 'poolsafe-portal' ); ?></li>
				<li><?php esc_html_e( 'Assigned user → Deal contact association', 'poolsafe-portal' ); ?></li>
				<li><?php esc_html_e( 'Partner/company → Deal company association', 'poolsafe-portal' ); ?></li>
			</ul>

			<h3><?php esc_html_e( 'Service Records → HubSpot Deals', 'poolsafe-portal' ); ?></h3>
			<ul style="margin-left: 20px;">
				<li><?php esc_html_e( 'Service type + partner → Deal name', 'poolsafe-portal' ); ?></li>
				<li><?php esc_html_e( 'Service description → Deal description', 'poolsafe-portal' ); ?></li>
				<li><?php esc_html_e( 'Service status → Deal stage', 'poolsafe-portal' ); ?></li>
				<li><?php esc_html_e( 'Service date → Deal tracking', 'poolsafe-portal' ); ?></li>
			</ul>

			<h3><?php esc_html_e( 'Partners → HubSpot Companies', 'poolsafe-portal' ); ?></h3>
			<ul style="margin-left: 20px;">
				<li><?php esc_html_e( 'Company name', 'poolsafe-portal' ); ?></li>
				<li><?php esc_html_e( 'Phone number', 'poolsafe-portal' ); ?></li>
				<li><?php esc_html_e( 'Email address', 'poolsafe-portal' ); ?></li>
				<li><?php esc_html_e( 'Physical address (street, city, state, zip, country)', 'poolsafe-portal' ); ?></li>
			</ul>

			<h3><?php esc_html_e( 'Users → HubSpot Contacts', 'poolsafe-portal' ); ?></h3>
			<ul style="margin-left: 20px;">
				<li><?php esc_html_e( 'First name, last name', 'poolsafe-portal' ); ?></li>
				<li><?php esc_html_e( 'Email address', 'poolsafe-portal' ); ?></li>
				<li><?php esc_html_e( 'Phone number', 'poolsafe-portal' ); ?></li>
			</ul>

			<h2 style="margin-top: 40px;">
				<?php esc_html_e( 'Automatic Sync Events', 'poolsafe-portal' ); ?>
			</h2>
			<ul style="margin-left: 20px;">
				<li><?php esc_html_e( 'New ticket created', 'poolsafe-portal' ); ?></li>
				<li><?php esc_html_e( 'Ticket details updated', 'poolsafe-portal' ); ?></li>
				<li><?php esc_html_e( 'Ticket status changed', 'poolsafe-portal' ); ?></li>
				<li><?php esc_html_e( 'Ticket assigned to user', 'poolsafe-portal' ); ?></li>
				<li><?php esc_html_e( 'Service record created', 'poolsafe-portal' ); ?></li>
				<li><?php esc_html_e( 'Partner/company created', 'poolsafe-portal' ); ?></li>
				<li><?php esc_html_e( 'Partner info updated', 'poolsafe-portal' ); ?></li>
			</ul>
		</div>

		<script>
			document.getElementById('psp_test_hubspot').addEventListener('click', function() {
				const apiKey = document.getElementById('psp_hubspot_api_key').value;
				const resultDiv = document.getElementById('psp_hubspot_test_result');

				if (!apiKey) {
					resultDiv.innerHTML = '<div class="notice notice-error"><p><?php esc_html_e( 'Please enter an API key first.', 'poolsafe-portal' ); ?></p></div>';
					resultDiv.style.display = 'block';
					return;
				}

				resultDiv.innerHTML = '<p><?php esc_html_e( 'Testing connection...', 'poolsafe-portal' ); ?></p>';
				resultDiv.style.display = 'block';

				fetch(ajaxurl, {
					method: 'POST',
					headers: {
						'Content-Type': 'application/x-www-form-urlencoded',
					},
					body: new URLSearchParams({
						action: 'psp_test_hubspot',
						api_key: apiKey,
						nonce: '<?php echo wp_create_nonce( 'psp_test_hubspot' ); ?>'
					})
				})
				.then(response => response.json())
				.then(data => {
					if (data.success) {
						resultDiv.innerHTML = '<div class="notice notice-success"><p><?php esc_html_e( 'Connection successful! Your HubSpot API key is valid.', 'poolsafe-portal' ); ?></p></div>';
					} else {
						resultDiv.innerHTML = '<div class="notice notice-error"><p>' + data.data.message + '</p></div>';
					}
				})
				.catch(error => {
					resultDiv.innerHTML = '<div class="notice notice-error"><p><?php esc_html_e( 'Error testing connection.', 'poolsafe-portal' ); ?></p></div>';
					console.error(error);
				});
			});
		</script>
		<?php
	}

	/**
	 * Test HubSpot connection via AJAX
	 *
	 * @since    1.0.0
	 */
	public static function test_hubspot_connection() {
		// Verify nonce
		check_ajax_referer( 'psp_test_hubspot', 'nonce' );

		// Check capability
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Insufficient permissions.', 'poolsafe-portal' ) ) );
		}

		$api_key = isset( $_POST['api_key'] ) ? sanitize_text_field( $_POST['api_key'] ) : '';

		if ( ! $api_key ) {
			wp_send_json_error( array( 'message' => __( 'API key is required.', 'poolsafe-portal' ) ) );
		}

		$result = PSP_HubSpot::test_connection( $api_key );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}

		wp_send_json_success( array( 'message' => __( 'Connection successful!', 'poolsafe-portal' ) ) );
	}
}

// Initialize on admin_init
add_action( 'admin_init', array( 'PSP_HubSpot_Settings', 'init' ) );
