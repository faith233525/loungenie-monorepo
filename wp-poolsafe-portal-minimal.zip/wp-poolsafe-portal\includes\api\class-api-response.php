<?php
/**
 * API Response Normalizer
 *
 * Ensures all REST API endpoints return consistent, structured responses.
 * Provides user-friendly error messages and proper HTTP status codes.
 *
 * @package PoolSafe_Portal
 * @since 3.0.0
 */

namespace PSP;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class API_Response {

	/**
	 * Standard success response
	 */
	public static function success( $data = [], $message = '', $status = 200 ): \WP_REST_Response {
		$response = [
			'success' => true,
			'status'  => $status,
		];

		if ( ! empty( $message ) ) {
			$response['message'] = sanitize_text_field( $message );
		}

		if ( is_array( $data ) || is_object( $data ) ) {
			$response['data'] = $data;
		}

		return rest_ensure_response( $response )->set_status( $status );
	}

	/**
	 * Standard error response
	 */
	public static function error( $message = '', $code = 'error', $status = 400 ): \WP_Error {
		return new \WP_Error(
			sanitize_key( $code ),
			sanitize_text_field( $message ),
			[ 'status' => $status ]
		);
	}

	/**
	 * Not found error
	 */
	public static function not_found( $resource = 'Resource' ): \WP_Error {
		return self::error( "$resource not found", 'not_found', 404 );
	}

	/**
	 * Unauthorized error
	 */
	public static function unauthorized(): \WP_Error {
		return self::error( 'Authentication required', 'unauthorized', 401 );
	}

	/**
	 * Forbidden error
	 */
	public static function forbidden(): \WP_Error {
		return self::error( 'You do not have permission for this action', 'forbidden', 403 );
	}

	/**
	 * Invalid request error
	 */
	public static function invalid_request( $message = 'Invalid request parameters' ): \WP_Error {
		return self::error( $message, 'invalid_request', 400 );
	}

	/**
	 * Server error
	 */
	public static function server_error( $message = 'An unexpected error occurred' ): \WP_Error {
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			// In debug mode, show actual error
			return self::error( $message, 'server_error', 500 );
		} else {
			// In production, hide details
			return self::error( 'An unexpected error occurred. Please try again later.', 'server_error', 500 );
		}
	}

	/**
	 * Pagination response
	 */
	public static function paginated( $items, $total, $page = 1, $per_page = 25 ): \WP_REST_Response {
		$max_pages = ceil( $total / $per_page );

		return self::success( [
			'items'      => $items,
			'total'      => $total,
			'page'       => (int) $page,
			'per_page'   => (int) $per_page,
			'max_pages'  => (int) $max_pages,
			'has_next'   => $page < $max_pages,
			'has_prev'   => $page > 1,
		] );
	}

	/**
	 * Normalize ticket response
	 */
	public static function normalize_ticket( $post_id ): array {
		$post = get_post( $post_id );
		if ( ! $post ) {
			return [];
		}

		return [
			'id'           => $post->ID,
			'title'        => $post->post_title,
			'content'      => wp_kses_post( $post->post_content ),
			'status'       => get_post_meta( $post->ID, 'status', true ) ?: 'open',
			'priority'     => get_post_meta( $post->ID, 'priority', true ) ?: 'normal',
			'company_id'   => (int) get_post_meta( $post->ID, 'partner_id', true ),
			'created_at'   => $post->post_date,
			'updated_at'   => $post->post_modified,
			'created_by'   => $post->post_author,
		];
	}

	/**
	 * Normalize company response
	 */
	public static function normalize_company( Company $company ): array {
		return $company->to_array();
	}

	/**
	 * Normalize user response (never expose sensitive data)
	 */
	public static function normalize_user( \WP_User $user ): array {
		return [
			'id'    => $user->ID,
			'name'  => $user->display_name,
			'email' => $user->user_email,
			'role'  => $user->roles[0] ?? 'subscriber',
			'avatar' => get_avatar_url( $user->ID ),
		];
	}

	/**
	 * Validate required parameters
	 */
	public static function validate_required( array $params, array $required ): ?array {
		$missing = [];

		foreach ( $required as $param ) {
			if ( empty( $params[ $param ] ) ) {
				$missing[] = $param;
			}
		}

		if ( ! empty( $missing ) ) {
			return self::error(
				'Missing required parameters: ' . implode( ', ', $missing ),
				'invalid_request',
				400
			);
		}

		return null; // No errors
	}

	/**
	 * Validate parameter types
	 */
	public static function validate_types( array $params, array $types ): ?array {
		foreach ( $types as $param => $type ) {
			if ( ! isset( $params[ $param ] ) ) {
				continue;
			}

			$value = $params[ $param ];

			switch ( $type ) {
				case 'int':
				case 'integer':
					if ( ! is_int( $value ) && ! ctype_digit( (string) $value ) ) {
						return self::error(
							"Parameter '$param' must be an integer",
							'invalid_type',
							400
						);
					}
					break;

				case 'string':
					if ( ! is_string( $value ) ) {
						return self::error(
							"Parameter '$param' must be a string",
							'invalid_type',
							400
						);
					}
					break;

				case 'bool':
				case 'boolean':
					if ( ! is_bool( $value ) ) {
						return self::error(
							"Parameter '$param' must be a boolean",
							'invalid_type',
							400
						);
					}
					break;

				case 'array':
					if ( ! is_array( $value ) ) {
						return self::error(
							"Parameter '$param' must be an array",
							'invalid_type',
							400
						);
					}
					break;
			}
		}

		return null; // No errors
	}

	/**
	 * Validate enum values
	 */
	public static function validate_enum( array $params, array $enums ): ?array {
		foreach ( $enums as $param => $allowed_values ) {
			if ( ! isset( $params[ $param ] ) ) {
				continue;
			}

			if ( ! in_array( $params[ $param ], $allowed_values, true ) ) {
				return self::error(
					"Parameter '$param' must be one of: " . implode( ', ', $allowed_values ),
					'invalid_value',
					400
				);
			}
		}

		return null; // No errors
	}
}
