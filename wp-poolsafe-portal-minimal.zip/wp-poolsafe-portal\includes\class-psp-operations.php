<?php
/**
 * PoolSafe Portal v3.0 - Operations (Staff Visit Tracking) CPT
 *
 * Manages staff visit logging, service records, maintenance tracking.
 *
 * @package PoolSafe_Portal
 * @subpackage Operations
 * @version 3.0.0
 */

namespace PSP;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Operations {

	/**
	 * Custom post type name
	 */
	const POST_TYPE = 'psp_operation';

	/**
	 * Custom post type slug
	 */
	const POST_TYPE_SLUG = 'operations';

	/**
	 * Initialize operations CPT
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'register_cpt' ) );
		add_action( 'init', array( __CLASS__, 'register_meta' ) );
	}

	/**
	 * Register custom post type
	 */
	public static function register_cpt() {
		$labels = array(
			'name'                  => __( 'Operations', 'psp' ),
			'singular_name'         => __( 'Operation', 'psp' ),
			'menu_name'             => __( 'Operations', 'psp' ),
			'all_items'             => __( 'All Operations', 'psp' ),
			'add_new_item'          => __( 'New Operation', 'psp' ),
			'edit_item'             => __( 'Edit Operation', 'psp' ),
			'new_item'              => __( 'New Operation', 'psp' ),
			'view_item'             => __( 'View Operation', 'psp' ),
			'search_items'          => __( 'Search Operations', 'psp' ),
			'not_found'             => __( 'No operations found', 'psp' ),
			'not_found_in_trash'    => __( 'No operations in trash', 'psp' ),
		);

		$args = array(
			'labels'            => $labels,
			'description'       => __( 'Staff visit logs and service records', 'psp' ),
			'public'            => false,
			'hierarchical'      => false,
			'show_ui'           => true,
			'show_in_menu'      => 'poolsafe-admin-page',
			'show_in_nav_menus' => false,
			'show_in_rest'      => true,
			'rest_base'         => 'operations',
			'capabilities'      => array(
				'create_posts'       => 'create_psp_operation',
				'read_post'          => 'read_psp_operation',
				'read_private_posts' => 'read_private_psp_operations',
				'edit_post'          => 'edit_psp_operation',
				'edit_posts'         => 'edit_psp_operations',
				'edit_others_posts'  => 'edit_others_psp_operations',
				'publish_posts'      => 'publish_psp_operations',
				'delete_post'        => 'delete_psp_operation',
				'delete_posts'       => 'delete_psp_operations',
				'delete_others_posts' => 'delete_others_psp_operations',
			),
			'map_meta_cap'      => false,
			'supports'          => array( 'title', 'editor', 'author', 'custom-fields' ),
			'menu_icon'         => 'dashicons-clipboard',
		);

		register_post_type( self::POST_TYPE, $args );
	}

	/**
	 * Register meta fields for operations
	 */
	public static function register_meta() {
		// Company ID (required link to company)
		register_post_meta(
			self::POST_TYPE,
			'psp_company_id',
			array(
				'type'          => 'integer',
				'single'        => true,
				'show_in_rest'  => true,
				'auth_callback' => function () {
					return current_user_can( 'read_psp_operation' );
				},
			)
		);

		// Staff member who logged visit
		register_post_meta(
			self::POST_TYPE,
			'psp_user_id',
			array(
				'type'          => 'integer',
				'single'        => true,
				'show_in_rest'  => true,
				'auth_callback' => function () {
					return current_user_can( 'read_psp_operation' );
				},
			)
		);

		// Visit type
		register_post_meta(
			self::POST_TYPE,
			'psp_visit_type',
			array(
				'type'          => 'string',
				'single'        => true,
				'show_in_rest'  => true,
				'auth_callback' => function () {
					return current_user_can( 'read_psp_operation' );
				},
			)
		);

		// Visit date
		register_post_meta(
			self::POST_TYPE,
			'psp_visit_date',
			array(
				'type'          => 'string',
				'single'        => true,
				'show_in_rest'  => true,
				'auth_callback' => function () {
					return current_user_can( 'read_psp_operation' );
				},
			)
		);

		// Visit duration (in minutes)
		register_post_meta(
			self::POST_TYPE,
			'psp_visit_duration',
			array(
				'type'          => 'integer',
				'single'        => true,
				'show_in_rest'  => true,
				'auth_callback' => function () {
					return current_user_can( 'read_psp_operation' );
				},
			)
		);

		// Units visited (array)
		register_post_meta(
			self::POST_TYPE,
			'psp_units_visited',
			array(
				'type'         => 'array',
				'single'       => true,
				'show_in_rest' => array(
					'schema' => array(
						'type'  => 'array',
						'items' => array( 'type' => 'string' ),
					),
				),
				'auth_callback' => function () {
					return current_user_can( 'read_psp_operation' );
				},
			)
		);

		// Maintenance items (array)
		register_post_meta(
			self::POST_TYPE,
			'psp_maintenance_items',
			array(
				'type'         => 'array',
				'single'       => true,
				'show_in_rest' => array(
					'schema' => array(
						'type'  => 'array',
						'items' => array( 'type' => 'string' ),
					),
				),
				'auth_callback' => function () {
					return current_user_can( 'read_psp_operation' );
				},
			)
		);

		// Operation status
		register_post_meta(
			self::POST_TYPE,
			'psp_status',
			array(
				'type'          => 'string',
				'single'        => true,
				'show_in_rest'  => true,
				'auth_callback' => function () {
					return current_user_can( 'read_psp_operation' );
				},
			)
		);

		// Photos/attachments (array of attachment IDs)
		register_post_meta(
			self::POST_TYPE,
			'psp_photos',
			array(
				'type'         => 'array',
				'single'       => true,
				'show_in_rest' => array(
					'schema' => array(
						'type'  => 'array',
						'items' => array( 'type' => 'integer' ),
					),
				),
				'auth_callback' => function () {
					return current_user_can( 'read_psp_operation' );
				},
			)
		);
	}

	/**
	 * Create a new operation/visit record
	 *
	 * @param array $data Operation data
	 * @return int|WP_Error Post ID or error
	 */
	public static function create_operation( $data ) {
		// Validate required fields
		if ( empty( $data['company_id'] ) || empty( $data['visit_type'] ) ) {
			return new \WP_Error( 'missing_required_fields', __( 'Company ID and visit type are required', 'psp' ) );
		}

		// Create post
		$post_id = wp_insert_post(
			array(
				'post_type'   => self::POST_TYPE,
				'post_status' => 'publish',
				'post_title'  => sprintf(
					__( '%s - %s', 'psp' ),
					$data['visit_type'],
					isset( $data['visit_date'] ) ? $data['visit_date'] : current_time( 'Y-m-d' )
				),
				'post_content' => isset( $data['notes'] ) ? sanitize_textarea_field( $data['notes'] ) : '',
				'post_author'  => get_current_user_id(),
			)
		);

		if ( is_wp_error( $post_id ) ) {
			return $post_id;
		}

		// Set metadata
		update_post_meta( $post_id, 'psp_company_id', intval( $data['company_id'] ) );
		update_post_meta( $post_id, 'psp_user_id', get_current_user_id() );
		update_post_meta( $post_id, 'psp_visit_type', sanitize_text_field( $data['visit_type'] ) );
		update_post_meta( $post_id, 'psp_visit_date', sanitize_text_field( $data['visit_date'] ?? current_time( 'Y-m-d' ) ) );
		update_post_meta( $post_id, 'psp_visit_duration', intval( $data['visit_duration'] ?? 0 ) );
		update_post_meta( $post_id, 'psp_status', sanitize_text_field( $data['status'] ?? 'completed' ) );

		if ( ! empty( $data['units_visited'] ) ) {
			update_post_meta( $post_id, 'psp_units_visited', (array) $data['units_visited'] );
		}

		if ( ! empty( $data['maintenance_items'] ) ) {
			update_post_meta( $post_id, 'psp_maintenance_items', (array) $data['maintenance_items'] );
		}

		return $post_id;
	}

	/**
	 * Get operations for a company
	 *
	 * @param int $company_id Company post ID
	 * @param array $args Query arguments
	 * @return array Operations
	 */
	public static function get_company_operations( $company_id, $args = array() ) {
		$defaults = array(
			'posts_per_page' => 25,
			'paged'          => 1,
			'orderby'        => 'post_date',
			'order'          => 'DESC',
			'meta_key'       => 'psp_company_id',
			'meta_value'     => intval( $company_id ),
		);

		$query_args = wp_parse_args( $args, $defaults );
		$query_args['post_type'] = self::POST_TYPE;

		$query = new \WP_Query( $query_args );
		return $query->posts;
	}

	/**
	 * Get operation summary for company
	 *
	 * @param int $company_id Company post ID
	 * @return array Summary data
	 */
	public static function get_company_operations_summary( $company_id ) {
		$operations = self::get_company_operations( $company_id, array( 'posts_per_page' => 9999 ) );

		if ( empty( $operations ) ) {
			return array(
				'total'                => 0,
				'this_month'           => 0,
				'last_visit_date'      => null,
				'pending_followup'     => 0,
				'maintenance_items'    => array(),
			);
		}

		$this_month = 0;
		$pending_followup = 0;
		$all_maintenance = array();
		$last_visit_date = null;

		foreach ( $operations as $op ) {
			$visit_date = get_post_meta( $op->ID, 'psp_visit_date', true );

			// Check if this month
			if ( strtotime( $visit_date ) >= strtotime( 'first day of this month' ) ) {
				$this_month++;
			}

			// Set last visit date
			if ( ! $last_visit_date || strtotime( $visit_date ) > strtotime( $last_visit_date ) ) {
				$last_visit_date = $visit_date;
			}

			// Count pending
			$status = get_post_meta( $op->ID, 'psp_status', true );
			if ( $status === 'pending_followup' ) {
				$pending_followup++;
			}

			// Collect maintenance items
			$items = get_post_meta( $op->ID, 'psp_maintenance_items', true );
			if ( is_array( $items ) ) {
				$all_maintenance = array_merge( $all_maintenance, $items );
			}
		}

		return array(
			'total'               => count( $operations ),
			'this_month'          => $this_month,
			'last_visit_date'     => $last_visit_date,
			'pending_followup'    => $pending_followup,
			'maintenance_items'   => array_unique( $all_maintenance ),
		);
	}
}

// Initialize on WordPress init hook
Operations::init();
