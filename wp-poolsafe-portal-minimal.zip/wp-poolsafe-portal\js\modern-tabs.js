/**
 * Modern Tabbed Layout System v3.2.5
 * Handles tab switching, content loading, and state management
 */

(function () {
    'use strict';

    const DEBUG = window.PORTAL_CONFIG?.debug || false;
    const log = DEBUG ? console.log.bind(console, '[PSP-TABS]') : () => { };

    /**
     * Tab Manager Class
     * Handles tab navigation, content loading, and state
     */
    class TabManager {
        constructor() {
            this.currentTab = this.getActiveTab();
            this.loadedTabs = new Set();
            this.loadedContent = {};
            this.init();
        }

        init() {
            log('Initializing Tab Manager');

            // Set up tab button listeners
            document.querySelectorAll('.psp-tab-button').forEach(btn => {
                btn.addEventListener('click', (e) => this.handleTabClick(e));
                btn.addEventListener('keydown', (e) => this.handleTabKeydown(e));
            });

            // Load initial tab content
            if (this.currentTab) {
                setTimeout(() => this.loadTabContent(this.currentTab, true), 100);
            }

            // Load remaining content in background
            this.preloadTabs();
        }

        getActiveTab() {
            const urlParams = new URLSearchParams(window.location.search);
            const tab = urlParams.get('tab') || 'dashboard';
            return tab;
        }

        handleTabClick(event) {
            event.preventDefault();
            const tabName = this.extractTabName(event.currentTarget);
            this.switchTab(tabName);
        }

        handleTabKeydown(event) {
            const tabName = this.extractTabName(event.currentTarget);

            if (event.key === 'ArrowRight' || event.key === 'ArrowLeft') {
                event.preventDefault();
                const buttons = Array.from(document.querySelectorAll('.psp-tab-button'));
                const currentIndex = buttons.findIndex(b => b.classList.contains('active'));
                const newIndex = event.key === 'ArrowRight'
                    ? (currentIndex + 1) % buttons.length
                    : (currentIndex - 1 + buttons.length) % buttons.length;

                buttons[newIndex].click();
                buttons[newIndex].focus();
            } else if (event.key === 'Enter' || event.key === ' ') {
                event.preventDefault();
                this.switchTab(tabName);
            }
        }

        extractTabName(button) {
            const onclick = button.getAttribute('onclick');
            const match = onclick.match(/switchTab\([^,]+,\s*'([^']+)'/);
            return match ? match[1] : 'dashboard';
        }

        switchTab(tabName) {
            log('Switching to tab:', tabName);

            // Update URL
            window.history.replaceState({}, '', '?tab=' + tabName);

            // Update active button
            document.querySelectorAll('.psp-tab-button').forEach(btn => {
                btn.classList.remove('active');
            });
            const activeBtn = document.querySelector(`[onclick*="'${tabName}'"]`);
            if (activeBtn) activeBtn.classList.add('active');

            // Show active panel
            document.querySelectorAll('.psp-tab-panel').forEach(panel => {
                panel.classList.remove('active');
            });
            const panel = document.getElementById(tabName + '-panel');
            if (panel) {
                panel.classList.add('active');
                window.scrollTo({ top: 0, behavior: 'smooth' });
            }

            // Load content
            this.loadTabContent(tabName, false);
            this.currentTab = tabName;
        }

        loadTabContent(tabName, isInitial) {
            log('Loading content for tab:', tabName, 'initial:', isInitial);

            // Use existing global function if available
            if (typeof window.loadTabContent === 'function') {
                window.loadTabContent(tabName, isInitial);
            } else {
                this.loadContent(tabName);
            }
        }

        loadContent(tabName) {
            const api = window.PORTAL_CONFIG?.apiUrl || '/wp-json/psp/v1';
            const nonce = window.PORTAL_CONFIG?.nonce;

            const endpoints = {
                dashboard: `${api}/dashboard`,
                tickets: `${api}/tickets`,
                services: `${api}/services`,
                partners: `${api}/partners`,
                profile: `${api}/profile`,
                admin: `${api}/admin`
            };

            const endpoint = endpoints[tabName];
            if (!endpoint) return;

            const contentId = `${tabName}-content`;
            const loadingId = `${tabName}-loading`;
            const contentDiv = document.getElementById(contentId);
            const loadingDiv = document.getElementById(loadingId);

            if (!contentDiv) return;

            // Show loading state
            if (loadingDiv) loadingDiv.style.display = 'block';
            contentDiv.innerHTML = '';

            // Fetch content
            fetch(endpoint, {
                method: 'GET',
                headers: {
                    'X-WP-Nonce': nonce,
                    'Content-Type': 'application/json'
                },
                credentials: 'include'
            })
                .then(res => {
                    if (!res.ok) throw new Error(`HTTP ${res.status}`);
                    return res.json();
                })
                .then(data => {
                    this.renderContent(tabName, data, contentDiv);
                    if (loadingDiv) loadingDiv.style.display = 'none';
                    log('Content loaded for tab:', tabName);
                })
                .catch(err => {
                    log('Error loading content:', err);
                    if (loadingDiv) {
                        loadingDiv.innerHTML = '<p style="color: #ef4444; text-align: center;">Failed to load content. Please try again.</p>';
                    }
                });
        }

        renderContent(tabName, data, container) {
            // This will be replaced with actual content rendering
            // For now, show a placeholder
            switch (tabName) {
                case 'dashboard':
                    // Stats are already rendered, just hide loading
                    break;
                case 'tickets':
                    this.renderTickets(data, container);
                    break;
                case 'services':
                    this.renderServices(data, container);
                    break;
                case 'partners':
                    this.renderPartners(data, container);
                    break;
                case 'profile':
                    this.renderProfile(data, container);
                    break;
                case 'admin':
                    this.renderAdmin(data, container);
                    break;
            }
        }

        renderTickets(data, container) {
            if (!data || data.length === 0) {
                container.innerHTML = '<p style="text-align: center; color: #6b7280; padding: 40px;">No tickets yet.</p>';
                return;
            }

            const html = data.map(ticket => `
                <div style="padding: 16px; border-bottom: 1px solid #e5e7eb; cursor: pointer;" onclick="alert('Ticket details coming soon')">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                        <strong style="color: #111827;">${ticket.title || 'Untitled'}</strong>
                        <span style="font-size: 12px; padding: 4px 12px; border-radius: 9999px; background: ${this.getStatusColor(ticket.status)}; color: white;">
                            ${ticket.status || 'Pending'}
                        </span>
                    </div>
                    <p style="margin: 0; color: #6b7280; font-size: 14px;">${ticket.description || ''}</p>
                    <p style="margin: 8px 0 0 0; color: #9ca3af; font-size: 12px;">Created: ${new Date(ticket.created_at).toLocaleDateString()}</p>
                </div>
            `).join('');

            container.innerHTML = html;
        }

        renderServices(data, container) {
            if (!data || data.length === 0) {
                container.innerHTML = '<p style="text-align: center; color: #6b7280; padding: 40px;">No service records yet.</p>';
                return;
            }

            const html = data.map(service => `
                <div style="padding: 16px; border-bottom: 1px solid #e5e7eb; cursor: pointer;" onclick="alert('Service details coming soon')">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                        <strong style="color: #111827;">${service.type || 'Service'}</strong>
                        <span style="font-size: 12px; color: #6b7280;">${service.date || 'No date'}</span>
                    </div>
                    <p style="margin: 0; color: #6b7280; font-size: 14px;">Notes: ${service.notes || 'No notes'}</p>
                </div>
            `).join('');

            container.innerHTML = html;
        }

        renderPartners(data, container) {
            if (!data || data.length === 0) {
                container.innerHTML = '<p style="text-align: center; color: #6b7280; padding: 40px;">No partners assigned.</p>';
                return;
            }

            const html = `
                <table style="width: 100%; border-collapse: collapse;">
                    <thead>
                        <tr style="background: #f9fafb; border-bottom: 2px solid #e5e7eb;">
                            <th style="padding: 12px; text-align: left; font-weight: 600; color: #6b7280;">Company</th>
                            <th style="padding: 12px; text-align: left; font-weight: 600; color: #6b7280;">Contact</th>
                            <th style="padding: 12px; text-align: left; font-weight: 600; color: #6b7280;">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${data.map(partner => `
                            <tr style="border-bottom: 1px solid #e5e7eb;">
                                <td style="padding: 12px; color: #111827;">${partner.company || '-'}</td>
                                <td style="padding: 12px; color: #6b7280;">${partner.contact || '-'}</td>
                                <td style="padding: 12px;">
                                    <span style="font-size: 12px; padding: 4px 12px; border-radius: 9999px; background: #10b981; color: white;">
                                        ${partner.status || 'Active'}
                                    </span>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            `;

            container.innerHTML = html;
        }

        renderProfile(data, container) {
            const user = window.PORTAL_CONFIG?.user || {};

            const html = `
                <div style="max-width: 600px;">
                    <div style="padding: 20px; border: 1px solid #e5e7eb; border-radius: 8px;">
                        <h3 style="margin: 0 0 16px 0;">Account Information</h3>
                        
                        <div style="margin-bottom: 16px;">
                            <label style="display: block; font-weight: 600; color: #6b7280; font-size: 12px; margin-bottom: 4px;">Name</label>
                            <p style="margin: 0; color: #111827;">${user.name || 'Not provided'}</p>
                        </div>

                        <div style="margin-bottom: 16px;">
                            <label style="display: block; font-weight: 600; color: #6b7280; font-size: 12px; margin-bottom: 4px;">Email</label>
                            <p style="margin: 0; color: #111827;">${user.email || 'Not provided'}</p>
                        </div>

                        <div style="margin-bottom: 16px;">
                            <label style="display: block; font-weight: 600; color: #6b7280; font-size: 12px; margin-bottom: 4px;">Role</label>
                            <p style="margin: 0; color: #111827;">${user.role ? ucwords(user.role) : 'Not provided'}</p>
                        </div>

                        <div style="display: flex; gap: 12px; margin-top: 24px;">
                            <button class="btn-primary" onclick="alert('Edit profile coming soon')">Edit Profile</button>
                            <button class="btn-primary" onclick="alert('Change password coming soon')" style="background: #6b7280; background: linear-gradient(135deg, #6b7280 0%, #9ca3af 100%);">Change Password</button>
                        </div>
                    </div>
                </div>
            `;

            container.innerHTML = html;
        }

        renderAdmin(data, container) {
            const html = `
                <div style="max-width: 800px;">
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 24px;">
                        <div style="padding: 20px; background: #f3f4f6; border-radius: 8px;">
                            <h3 style="margin: 0 0 12px 0; font-size: 16px;">System Health</h3>
                            <p style="margin: 0; color: #6b7280; font-size: 14px;">All systems operational</p>
                        </div>
                        <div style="padding: 20px; background: #f3f4f6; border-radius: 8px;">
                            <h3 style="margin: 0 0 12px 0; font-size: 16px;">Last Updated</h3>
                            <p style="margin: 0; color: #6b7280; font-size: 14px;">${new Date().toLocaleString()}</p>
                        </div>
                    </div>
                </div>
            `;

            container.innerHTML = html;
        }

        getStatusColor(status) {
            const colors = {
                'open': '#3b82f6',
                'in-progress': '#f59e0b',
                'closed': '#10b981',
                'pending': '#ef4444',
                'resolved': '#10b981',
                'active': '#10b981',
                'inactive': '#9ca3af'
            };
            return colors[status?.toLowerCase()] || '#6b7280';
        }

        preloadTabs() {
            // Preload other tabs in background (after 2 seconds)
            setTimeout(() => {
                const tabs = ['dashboard', 'tickets', 'services', 'partners', 'profile'];
                tabs.forEach(tab => {
                    if (tab !== this.currentTab && !this.loadedTabs.has(tab)) {
                        this.loadTabContent(tab, false);
                        this.loadedTabs.add(tab);
                    }
                });
            }, 2000);
        }
    }

    // Global function for switching tabs
    window.switchTab = function (event, tabName) {
        event.preventDefault();

        // Update URL
        window.history.replaceState({}, '', '?tab=' + tabName);

        // Update buttons
        document.querySelectorAll('.psp-tab-button').forEach(btn => {
            btn.classList.remove('active');
        });
        event.target.classList.add('active');

        // Update panels
        document.querySelectorAll('.psp-tab-panel').forEach(panel => {
            panel.classList.remove('active');
        });
        const panel = document.getElementById(tabName + '-panel');
        if (panel) {
            panel.classList.add('active');
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }

        // Load content via global function if available
        if (window.loadTabContent) {
            window.loadTabContent(tabName, false);
        }
    };

    // Initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => {
            new TabManager();
        });
    } else {
        new TabManager();
    }

    // Helper function for uppercase first letter
    function ucwords(str) {
        return str.replace(/\b\w/g, l => l.toUpperCase());
    }

    log('Modern Tabs module loaded');
})();
