<?php
namespace PSP;

/**
 * PSP Settings Page
 * Manages API credentials, ticketing options, and plugin settings
 * Only accessible to support staff and administrators
 *
 * @since 1.1.0
 */

if (!defined('ABSPATH')) {
	exit;
}

class Settings_Page {

	/**
	 * Initialize the settings page
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public static function init() {
		add_action('admin_menu', [self::class, 'add_menu_page']);
		add_action('admin_init', [self::class, 'register_settings']);
		add_action('admin_enqueue_scripts', [self::class, 'enqueue_scripts']);
	}

	/**
	 * Add settings page to admin menu
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public static function add_menu_page() {
		// Check capability
		if (!current_user_can('psp_manage_settings')) {
			return;
		}

		add_submenu_page(
			'options-general.php',
			'PoolSafe Portal Settings',
			'PoolSafe Portal',
			'manage_options', // WordPress-level check, plugin checks actual capability
			'psp-settings',
			[self::class, 'render_page']
		);
	}

	/**
	 * Register settings
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public static function register_settings() {
		if (!current_user_can('psp_manage_settings')) {
			return;
		}

		// Register setting groups
		register_setting(
			'psp_outlook_settings',
			'psp_outlook_settings',
			[
				'type' => 'object',
				'sanitize_callback' => [self::class, 'sanitize_outlook_settings'],
			]
		);

		register_setting(
			'psp_hubspot_settings',
			'psp_hubspot_settings',
			[
				'type' => 'object',
				'sanitize_callback' => [self::class, 'sanitize_hubspot_settings'],
			]
		);

		register_setting(
			'psp_ticketing_settings',
			'psp_ticketing_settings',
			[
				'type' => 'object',
				'sanitize_callback' => [self::class, 'sanitize_ticketing_settings'],
			]
		);

		register_setting(
			'psp_csv_settings',
			'psp_csv_settings',
			[
				'type' => 'object',
				'sanitize_callback' => [self::class, 'sanitize_csv_settings'],
			]
		);

		register_setting(
			'psp_branding_settings',
			'psp_branding_settings',
			[
				'type' => 'object',
				'sanitize_callback' => [self::class, 'sanitize_branding_settings'],
			]
		);
	}

	/**
	 * Enqueue scripts and styles
	 *
	 * @since 1.1.0
	 * @param string $hook Hook name.
	 * @return void
	 */
	public static function enqueue_scripts($hook) {
		if ('settings_page_psp-settings' !== $hook) {
			return;
		}

		wp_enqueue_style(
			'psp-settings',
			plugin_dir_url(PSP_PLUGIN_FILE) . 'css/psp-settings.css',
			['wp-color-picker'],
			'1.1.0'
		);

		wp_enqueue_script(
			'psp-settings',
			plugin_dir_url(PSP_PLUGIN_FILE) . 'js/psp-settings.js',
			['jquery', 'wp-color-picker'],
			'1.1.0',
			true
		);

		wp_localize_script('psp-settings', 'pspSettings', [
			'nonce' => wp_create_nonce('psp_settings_nonce'),
			'ajax_url' => admin_url('admin-ajax.php'),
		]);
	}

	/**
	 * Render the settings page
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public static function render_page() {
		if (!current_user_can('psp_manage_settings')) {
			wp_die('Unauthorized');
		}

		// Get current settings
		$outlook_settings = get_option('psp_outlook_settings', []);
		$hubspot_settings = get_option('psp_hubspot_settings', []);
		$ticketing_settings = get_option('psp_ticketing_settings', []);
		$csv_settings = get_option('psp_csv_settings', []);
		$branding_settings = get_option('psp_branding_settings', []);

		// Get current user for audit logging
		$current_user = wp_get_current_user();
		?>
		<div class="wrap">
			<h1>PoolSafe Portal Settings</h1>
			<p class="description">
				Manage API credentials, ticketing options, and CSV import/export settings.
				All changes are audited and logged.
			</p>

			<?php self::render_alerts(); ?>

			<nav class="nav-tab-wrapper wp-clearfix">
				<a href="#outlook" class="nav-tab nav-tab-active">Outlook / Microsoft Graph</a>
				<a href="#hubspot" class="nav-tab">HubSpot CRM</a>
				<a href="#ticketing" class="nav-tab">Ticketing Options</a>
				<a href="#csv" class="nav-tab">CSV Import/Export</a>
				<a href="#branding" class="nav-tab">Branding</a>
				<a href="#audit" class="nav-tab">Audit Log</a>
			</nav>

			<form method="post" action="options.php" id="psp-settings-form">
				<?php wp_nonce_field('psp_settings_nonce'); ?>

				<!-- Outlook / Microsoft Graph Tab -->
				<div id="outlook" class="psp-settings-tab active">
					<h2>Outlook / Microsoft Graph API Credentials</h2>
					<p class="description">
						Configure credentials for Microsoft Graph API integration.
						Used for calendar sync and Outlook integration.
					</p>

					<table class="form-table">
						<tr>
							<th scope="row">
								<label for="psp_outlook_client_id">Client ID</label>
							</th>
							<td>
								<input 
									type="password" 
									name="psp_outlook_settings[client_id]" 
									id="psp_outlook_client_id"
									value="<?php echo esc_attr($outlook_settings['client_id'] ?? ''); ?>"
									class="regular-text"
									placeholder="Azure App Client ID"
								>
								<p class="description">
									Register app in Azure Portal → Get Client ID
								</p>
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="psp_outlook_client_secret">Client Secret</label>
							</th>
							<td>
								<input 
									type="password" 
									name="psp_outlook_settings[client_secret]" 
									id="psp_outlook_client_secret"
									value="<?php echo esc_attr($outlook_settings['client_secret'] ?? ''); ?>"
									class="regular-text"
									placeholder="Azure App Client Secret"
								>
								<p class="description">
									Keep this secure. Never share or commit to version control.
								</p>
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="psp_outlook_tenant_id">Tenant ID</label>
							</th>
							<td>
								<input 
									type="text" 
									name="psp_outlook_settings[tenant_id]" 
									id="psp_outlook_tenant_id"
									value="<?php echo esc_attr($outlook_settings['tenant_id'] ?? ''); ?>"
									class="regular-text"
									placeholder="Azure Tenant ID (directory)"
								>
								<p class="description">
									Organization ID from Azure Portal
								</p>
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="psp_outlook_redirect_uri">Redirect URI</label>
							</th>
							<td>
								<input 
									type="text" 
									name="psp_outlook_settings[redirect_uri]" 
									id="psp_outlook_redirect_uri"
									value="<?php echo esc_attr($outlook_settings['redirect_uri'] ?? home_url('/portal/auth/callback')); ?>"
									class="regular-text"
									placeholder="<?php echo home_url('/portal/auth/callback'); ?>"
								>
								<p class="description">
									Must match the Redirect URI configured in Azure Portal
								</p>
							</td>
						</tr>
						<tr>
							<th scope="row">Status</th>
							<td>
								<?php self::render_connection_status('outlook'); ?>
							</td>
						</tr>
					</table>
				</div>

				<!-- HubSpot Tab -->
				<div id="hubspot" class="psp-settings-tab" style="display: none;">
					<h2>HubSpot CRM Integration</h2>
					<p class="description">
						Configure HubSpot API credentials for CRM synchronization.
					</p>

					<table class="form-table">
						<tr>
							<th scope="row">
								<label for="psp_hubspot_api_key">API Key</label>
							</th>
							<td>
								<input 
									type="password" 
									name="psp_hubspot_settings[api_key]" 
									id="psp_hubspot_api_key"
									value="<?php echo esc_attr($hubspot_settings['api_key'] ?? ''); ?>"
									class="regular-text"
									placeholder="HubSpot API Key"
								>
								<p class="description">
									Get from HubSpot Settings → Integrations → API Key
								</p>
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="psp_hubspot_portal_id">Portal ID</label>
							</th>
							<td>
								<input 
									type="text" 
									name="psp_hubspot_settings[portal_id]" 
									id="psp_hubspot_portal_id"
									value="<?php echo esc_attr($hubspot_settings['portal_id'] ?? ''); ?>"
									class="regular-text"
									placeholder="HubSpot Portal ID"
								>
								<p class="description">
									Found in HubSpot account settings
								</p>
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="psp_hubspot_sync_enabled">Enable Sync</label>
							</th>
							<td>
								<input 
									type="checkbox" 
									name="psp_hubspot_settings[sync_enabled]" 
									id="psp_hubspot_sync_enabled"
									value="1"
									<?php checked($hubspot_settings['sync_enabled'] ?? 0); ?>
								>
								<label for="psp_hubspot_sync_enabled">
									Enable automatic synchronization with HubSpot
								</label>
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="psp_hubspot_sync_frequency">Sync Frequency</label>
							</th>
							<td>
								<select name="psp_hubspot_settings[sync_frequency]" id="psp_hubspot_sync_frequency">
									<option value="hourly" <?php selected($hubspot_settings['sync_frequency'] ?? 'hourly', 'hourly'); ?>>Hourly</option>
									<option value="daily" <?php selected($hubspot_settings['sync_frequency'] ?? 'hourly', 'daily'); ?>>Daily</option>
									<option value="weekly" <?php selected($hubspot_settings['sync_frequency'] ?? 'hourly', 'weekly'); ?>>Weekly</option>
								</select>
								<p class="description">How often to sync data with HubSpot</p>
							</td>
						</tr>
						<tr>
							<th scope="row">Status</th>
							<td>
								<?php self::render_connection_status('hubspot'); ?>
							</td>
						</tr>
					</table>
				</div>

				<!-- Ticketing Tab -->
				<div id="ticketing" class="psp-settings-tab" style="display: none;">
					<h2>Ticketing Options</h2>
					<p class="description">
						Configure ticket handling and notification settings.
					</p>

					<table class="form-table">
						<tr>
							<th scope="row">
								<label for="psp_ticketing_email">Support Email Address</label>
							</th>
							<td>
								<input 
									type="email" 
									name="psp_ticketing_settings[support_email]" 
									id="psp_ticketing_email"
									value="<?php echo esc_attr($ticketing_settings['support_email'] ?? get_option('admin_email')); ?>"
									class="regular-text"
									required
								>
								<p class="description">
									Email address where ticket notifications are sent
								</p>
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="psp_ticketing_default_notify">Default Notification</label>
							</th>
							<td>
								<select name="psp_ticketing_settings[default_notify]" id="psp_ticketing_default_notify">
									<option value="email" <?php selected($ticketing_settings['default_notify'] ?? 'email', 'email'); ?>>Email</option>
									<option value="dashboard" <?php selected($ticketing_settings['default_notify'] ?? 'email', 'dashboard'); ?>>Dashboard Only</option>
									<option value="both" <?php selected($ticketing_settings['default_notify'] ?? 'email', 'both'); ?>>Email & Dashboard</option>
								</select>
								<p class="description">How to notify users about new tickets</p>
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="psp_ticketing_auto_assign">Auto-assign to Group</label>
							</th>
							<td>
								<select name="psp_ticketing_settings[auto_assign_group]" id="psp_ticketing_auto_assign">
									<option value="">-- Disable Auto-Assign --</option>
									<?php
									// Get support staff users
									$support_users = get_users(['role' => 'psp_support']);
									foreach ($support_users as $user) {
										printf(
											'<option value="%d" %s>%s (%s)</option>',
											esc_attr($user->ID),
											selected($ticketing_settings['auto_assign_group'] ?? '', $user->ID),
											esc_html($user->display_name),
											esc_html($user->user_email)
										);
									}
									?>
								</select>
								<p class="description">Automatically assign new tickets to a team member</p>
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="psp_ticketing_sla_hours">Default SLA (Hours)</label>
							</th>
							<td>
								<input 
									type="number" 
									name="psp_ticketing_settings[sla_hours]" 
									id="psp_ticketing_sla_hours"
									value="<?php echo esc_attr($ticketing_settings['sla_hours'] ?? 24); ?>"
									min="1"
									max="168"
									class="small-text"
								>
								<p class="description">Response time SLA for new tickets (in hours)</p>
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="psp_ticketing_allow_attachments">Allow Attachments</label>
							</th>
							<td>
								<input 
									type="checkbox" 
									name="psp_ticketing_settings[allow_attachments]" 
									id="psp_ticketing_allow_attachments"
									value="1"
									<?php checked($ticketing_settings['allow_attachments'] ?? 1); ?>
								>
								<label for="psp_ticketing_allow_attachments">
									Allow users to attach files to tickets
								</label>
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="psp_ticketing_max_file_size">Max File Size (MB)</label>
							</th>
							<td>
								<input 
									type="number" 
									name="psp_ticketing_settings[max_file_size]" 
									id="psp_ticketing_max_file_size"
									value="<?php echo esc_attr($ticketing_settings['max_file_size'] ?? 10); ?>"
									min="1"
									max="100"
									class="small-text"
								>
								<p class="description">Maximum file size for attachments</p>
							</td>
						</tr>
					</table>
				</div>

				<!-- CSV Tab -->
				<div id="csv" class="psp-settings-tab" style="display: none;">
					<h2>CSV Import/Export Settings</h2>
					<p class="description">
						Configure CSV import/export behavior for partner data.
					</p>

					<table class="form-table">
						<tr>
							<th scope="row">
								<label for="psp_csv_delimiter">CSV Delimiter</label>
							</th>
							<td>
								<select name="psp_csv_settings[delimiter]" id="psp_csv_delimiter">
									<option value="," <?php selected($csv_settings['delimiter'] ?? ',', ','); ?>>Comma (,)</option>
									<option value=";" <?php selected($csv_settings['delimiter'] ?? ',', ';'); ?>>Semicolon (;)</option>
									<option value="\t" <?php selected($csv_settings['delimiter'] ?? ',', "\t"); ?>>Tab</option>
									<option value="|" <?php selected($csv_settings['delimiter'] ?? ',', '|'); ?>>Pipe (|)</option>
								</select>
								<p class="description">Character used to separate CSV fields</p>
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="psp_csv_encoding">CSV Encoding</label>
							</th>
							<td>
								<select name="psp_csv_settings[encoding]" id="psp_csv_encoding">
									<option value="UTF-8" <?php selected($csv_settings['encoding'] ?? 'UTF-8', 'UTF-8'); ?>>UTF-8</option>
									<option value="ISO-8859-1" <?php selected($csv_settings['encoding'] ?? 'UTF-8', 'ISO-8859-1'); ?>>ISO-8859-1</option>
									<option value="cp1252" <?php selected($csv_settings['encoding'] ?? 'UTF-8', 'cp1252'); ?>>Windows (cp1252)</option>
								</select>
								<p class="description">Character encoding for CSV files</p>
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="psp_csv_include_headers">Include Headers</label>
							</th>
							<td>
								<input 
									type="checkbox" 
									name="psp_csv_settings[include_headers]" 
									id="psp_csv_include_headers"
									value="1"
									<?php checked($csv_settings['include_headers'] ?? 1); ?>
								>
								<label for="psp_csv_include_headers">
									Include column headers in exported files
								</label>
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="psp_csv_auto_backup">Auto Backup Before Import</label>
							</th>
							<td>
								<input 
									type="checkbox" 
									name="psp_csv_settings[auto_backup]" 
									id="psp_csv_auto_backup"
									value="1"
									<?php checked($csv_settings['auto_backup'] ?? 1); ?>
								>
								<label for="psp_csv_auto_backup">
									Automatically backup data before importing CSV
								</label>
								<p class="description">Allows quick rollback if import has issues</p>
							</td>
						</tr>
						<tr>
							<th scope="row">
								<label for="psp_csv_batch_size">Batch Size for Import</label>
							</th>
							<td>
								<input 
									type="number" 
									name="psp_csv_settings[batch_size]" 
									id="psp_csv_batch_size"
									value="<?php echo esc_attr($csv_settings['batch_size'] ?? 100); ?>"
									min="10"
									max="1000"
									class="small-text"
								>
								<p class="description">Number of records to process at once (higher = faster but uses more memory)</p>
							</td>
						</tr>
					</table>
				</div>

				<!-- Branding Tab -->
				<div id="branding" class="psp-settings-tab" style="display: none;">
					<h2>Branding & Palette Overrides</h2>
					<p class="description">
						Set portal-specific colors and typography. Values entered here override WordPress theme presets.
						Leave a field empty to inherit from the active theme or the PoolSafe defaults.
					</p>

					<table class="form-table">
						<tr>
							<th scope="row"><label for="psp_branding_primary">Primary Color</label></th>
							<td>
								<input type="text" class="psp-color-field" name="psp_branding_settings[primary]" id="psp_branding_primary" value="<?php echo esc_attr($branding_settings['primary'] ?? ''); ?>" placeholder="#3AA6B9">
								<p class="description">Used for buttons, links, and highlights.</p>
							</td>
						</tr>
						<tr>
							<th scope="row"><label for="psp_branding_secondary">Secondary Color</label></th>
							<td>
								<input type="text" class="psp-color-field" name="psp_branding_settings[secondary]" id="psp_branding_secondary" value="<?php echo esc_attr($branding_settings['secondary'] ?? ''); ?>" placeholder="#1FA8D6">
								<p class="description">Accent color for gradients and secondary actions.</p>
							</td>
						</tr>
						<tr>
							<th scope="row"><label for="psp_branding_text">Text Color</label></th>
							<td>
								<input type="text" class="psp-color-field" name="psp_branding_settings[text]" id="psp_branding_text" value="<?php echo esc_attr($branding_settings['text'] ?? ''); ?>" placeholder="#111827">
								<p class="description">Default foreground color.</p>
							</td>
						</tr>
						<tr>
							<th scope="row"><label for="psp_branding_background">Background Color</label></th>
							<td>
								<input type="text" class="psp-color-field" name="psp_branding_settings[background]" id="psp_branding_background" value="<?php echo esc_attr($branding_settings['background'] ?? ''); ?>" placeholder="#ffffff">
								<p class="description">Portal canvas background.</p>
							</td>
						</tr>
						<tr>
							<th scope="row"><label for="psp_branding_border">Border Color</label></th>
							<td>
								<input type="text" class="psp-color-field" name="psp_branding_settings[border]" id="psp_branding_border" value="<?php echo esc_attr($branding_settings['border'] ?? ''); ?>" placeholder="#D1D5DB">
								<p class="description">Used for cards, tables, and form controls.</p>
							</td>
						</tr>
						<tr>
							<th scope="row"><label for="psp_branding_font_body">Body Font</label></th>
							<td>
								<input type="text" name="psp_branding_settings[font_body]" id="psp_branding_font_body" value="<?php echo esc_attr($branding_settings['font_body'] ?? ''); ?>" placeholder="Poppins, Inter, Segoe UI, sans-serif" class="regular-text">
								<p class="description">Comma-separated font stack. Defaults to Poppins stack.</p>
							</td>
						</tr>
						<tr>
							<th scope="row"><label for="psp_branding_font_heading">Heading Font</label></th>
							<td>
								<input type="text" name="psp_branding_settings[font_heading]" id="psp_branding_font_heading" value="<?php echo esc_attr($branding_settings['font_heading'] ?? ''); ?>" placeholder="Poppins, Inter, Segoe UI, sans-serif" class="regular-text">
								<p class="description">Used for headings and emphasis.</p>
							</td>
						</tr>
						<tr>
							<th scope="row"><label for="psp_branding_font_size_base">Base Font Size</label></th>
							<td>
								<input type="text" name="psp_branding_settings[font_size_base]" id="psp_branding_font_size_base" value="<?php echo esc_attr($branding_settings['font_size_base'] ?? ''); ?>" placeholder="16px" class="regular-text">
								<p class="description">Optional base font size (e.g., 16px). Leave empty to inherit.</p>
							</td>
						</tr>
					</table>
				</div>

				<!-- Audit Log Tab (Read-Only) -->
				<div id="audit" class="psp-settings-tab" style="display: none;">
					<h2>Settings Audit Log</h2>
					<p class="description">
						View who changed what settings and when. Useful for troubleshooting and compliance.
					</p>

					<?php self::render_audit_log(); ?>
				</div>

				<div class="psp-settings-actions">
					<?php submit_button('Save Settings', 'primary', 'submit', true); ?>
					<button type="button" class="button" id="psp-backup-settings">
						Backup Settings Before Saving
					</button>
					<span id="psp-backup-status"></span>
				</div>
			</form>
		</div>

		<script>
		jQuery(document).ready(function($) {
			// Tab switching
			$('.nav-tab').on('click', function(e) {
				e.preventDefault();
				var tab = $(this).attr('href');
				
				$('.psp-settings-tab').hide();
				$(tab).show();
				
				$('.nav-tab').removeClass('nav-tab-active');
				$(this).addClass('nav-tab-active');
			});

			// Backup settings
			$('#psp-backup-settings').on('click', function() {
				var status = $('#psp-backup-status');
				status.text('Creating backup...');

				$.ajax({
					url: pspSettings.ajax_url,
					method: 'POST',
					data: {
						action: 'psp_backup_settings',
						nonce: pspSettings.nonce
					},
					success: function(response) {
						if (response.success) {
							status.text('✓ Backup created: ' + response.data.filename).css('color', 'green');
							setTimeout(() => status.text(''), 5000);
						} else {
							status.text('✗ Backup failed: ' + response.data).css('color', 'red');
						}
					}
				});
			});
		});
		</script>
		<?php
	}

	/**
	 * Render connection status indicator
	 *
	 * @since 1.1.0
	 * @param string $service Service name (outlook, hubspot).
	 * @return void
	 */
	private static function render_connection_status($service) {
		$status = Connection_Tester::test_connection($service);

		if ($status['connected']) {
			echo '<span style="color: green;">✓ Connected</span>';
			echo '<p class="description">Last tested: ' . esc_html($status['last_tested'] ?? 'Never') . '</p>';
		} else {
			echo '<span style="color: red;">✗ Not Connected</span>';
			if (!empty($status['error'])) {
				echo '<p class="description" style="color: red;">Error: ' . esc_html($status['error']) . '</p>';
			}
		}
	}

	/**
	 * Render alerts
	 *
	 * @since 1.1.0
	 * @return void
	 */
	private static function render_alerts() {
		// Check for API failures from audit log
		$recent_failures = Audit_Logger::get_recent_failures(10);

		if (!empty($recent_failures)) {
			echo '<div class="notice notice-warning"><p>';
			echo 'Recent API connection issues detected. ';
			echo '<a href="#audit">View audit log</a> for details.';
			echo '</p></div>';
		}
	}

	/**
	 * Render audit log
	 *
	 * @since 1.1.0
	 * @return void
	 */
	private static function render_audit_log() {
		$logs = Audit_Logger::get_logs(['limit' => 50]);

		if (empty($logs)) {
			echo '<p>No audit log entries yet.</p>';
			return;
		}

		?>
		<table class="wp-list-table widefat striped">
			<thead>
				<tr>
					<th>Date</th>
					<th>User</th>
					<th>Action</th>
					<th>Setting</th>
					<th>Old Value</th>
					<th>New Value</th>
				</tr>
			</thead>
			<tbody>
				<?php
				foreach ($logs as $log) {
					printf(
						'<tr>
							<td>%s</td>
							<td>%s</td>
							<td>%s</td>
							<td>%s</td>
							<td><code>%s</code></td>
							<td><code>%s</code></td>
						</tr>',
						esc_html($log['timestamp']),
						esc_html($log['user_name']),
						esc_html($log['action']),
						esc_html($log['setting']),
						esc_html(substr($log['old_value'], 0, 50)),
						esc_html(substr($log['new_value'], 0, 50))
					);
				}
				?>
			</tbody>
		</table>
		<?php
	}

	/**
	 * Sanitize Outlook settings
	 *
	 * @since 1.1.0
	 * @param array $input Settings input.
	 * @return array Sanitized settings.
	 */
	public static function sanitize_outlook_settings($input) {
		if (!is_array($input)) {
			return [];
		}

		// Get old values for audit log
		$old_settings = get_option('psp_outlook_settings', []);

		$sanitized = [
			'client_id' => sanitize_text_field($input['client_id'] ?? ''),
			'client_secret' => sanitize_text_field($input['client_secret'] ?? ''),
			'tenant_id' => sanitize_text_field($input['tenant_id'] ?? ''),
			'redirect_uri' => esc_url_raw($input['redirect_uri'] ?? ''),
		];

		// Log changes
		foreach ($sanitized as $key => $value) {
			if (($old_settings[$key] ?? '') !== $value) {
				Audit_Logger::log([
					'action' => 'update_setting',
					'setting' => 'outlook_' . $key,
					'old_value' => $old_settings[$key] ?? '',
					'new_value' => $value,
				]);
			}
		}

		return $sanitized;
	}

	/**
	 * Sanitize HubSpot settings
	 *
	 * @since 1.1.0
	 * @param array $input Settings input.
	 * @return array Sanitized settings.
	 */
	public static function sanitize_hubspot_settings($input) {
		if (!is_array($input)) {
			return [];
		}

		$old_settings = get_option('psp_hubspot_settings', []);

		$sanitized = [
			'api_key' => sanitize_text_field($input['api_key'] ?? ''),
			'portal_id' => sanitize_text_field($input['portal_id'] ?? ''),
			'sync_enabled' => !empty($input['sync_enabled']) ? 1 : 0,
			'sync_frequency' => sanitize_text_field($input['sync_frequency'] ?? 'hourly'),
		];

		// Log changes
		foreach ($sanitized as $key => $value) {
			if (($old_settings[$key] ?? '') !== $value) {
				Audit_Logger::log([
					'action' => 'update_setting',
					'setting' => 'hubspot_' . $key,
					'old_value' => $old_settings[$key] ?? '',
					'new_value' => $value,
				]);
			}
		}

		return $sanitized;
	}

	/**
	 * Sanitize ticketing settings
	 *
	 * @since 1.1.0
	 * @param array $input Settings input.
	 * @return array Sanitized settings.
	 */
	public static function sanitize_ticketing_settings($input) {
		if (!is_array($input)) {
			return [];
		}

		$old_settings = get_option('psp_ticketing_settings', []);

		$sanitized = [
			'support_email' => sanitize_email($input['support_email'] ?? get_option('admin_email')),
			'default_notify' => sanitize_text_field($input['default_notify'] ?? 'email'),
			'auto_assign_group' => sanitize_text_field($input['auto_assign_group'] ?? ''),
			'sla_hours' => intval($input['sla_hours'] ?? 24),
			'allow_attachments' => !empty($input['allow_attachments']) ? 1 : 0,
			'max_file_size' => intval($input['max_file_size'] ?? 10),
		];

		// Log changes
		foreach ($sanitized as $key => $value) {
			if (($old_settings[$key] ?? '') !== $value) {
				Audit_Logger::log([
					'action' => 'update_setting',
					'setting' => 'ticketing_' . $key,
					'old_value' => $old_settings[$key] ?? '',
					'new_value' => $value,
				]);
			}
		}

		return $sanitized;
	}

	/**
	 * Sanitize CSV settings
	 *
	 * @since 1.1.0
	 * @param array $input Settings input.
	 * @return array Sanitized settings.
	 */
	public static function sanitize_csv_settings($input) {
		if (!is_array($input)) {
			return [];
		}

		$old_settings = get_option('psp_csv_settings', []);

		$sanitized = [
			'delimiter' => sanitize_text_field($input['delimiter'] ?? ','),
			'encoding' => sanitize_text_field($input['encoding'] ?? 'UTF-8'),
			'include_headers' => !empty($input['include_headers']) ? 1 : 0,
			'auto_backup' => !empty($input['auto_backup']) ? 1 : 0,
			'batch_size' => intval($input['batch_size'] ?? 100),
		];

		// Log changes
		foreach ($sanitized as $key => $value) {
			if (($old_settings[$key] ?? '') !== $value) {
				Audit_Logger::log([
					'action' => 'update_setting',
					'setting' => 'csv_' . $key,
					'old_value' => $old_settings[$key] ?? '',
					'new_value' => $value,
				]);
			}
		}

		return $sanitized;
	}

	/**
	 * Sanitize branding settings
	 *
	 * @since 3.2.0
	 * @param array $input Settings input.
	 * @return array Sanitized settings.
	 */
	public static function sanitize_branding_settings($input) {
		if (!is_array($input)) {
			return [];
		}

		$old_settings = get_option('psp_branding_settings', []);
		$sanitized = [];

		$color_fields = ['primary', 'secondary', 'text', 'background', 'border'];
		foreach ($color_fields as $field) {
			if (!empty($input[$field]) && sanitize_hex_color($input[$field])) {
				$sanitized[$field] = sanitize_hex_color($input[$field]);
			}
		}

		if (!empty($input['font_body'])) {
			$sanitized['font_body'] = sanitize_text_field($input['font_body']);
		}

		if (!empty($input['font_heading'])) {
			$sanitized['font_heading'] = sanitize_text_field($input['font_heading']);
		}

		if (!empty($input['font_size_base'])) {
			$sanitized['font_size_base'] = sanitize_text_field($input['font_size_base']);
		}

		// Log changes for auditing
		foreach ($sanitized as $key => $value) {
			if (($old_settings[$key] ?? '') !== $value) {
				Audit_Logger::log([
					'action' => 'update_setting',
					'setting' => 'branding_' . $key,
					'old_value' => $old_settings[$key] ?? '',
					'new_value' => $value,
				]);
			}
		}

		return $sanitized;
	}
}
