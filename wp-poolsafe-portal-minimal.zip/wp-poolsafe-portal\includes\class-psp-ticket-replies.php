<?php
/**
 * Ticket Replies & Communication System
 */

if (!defined('ABSPATH')) {
    exit;
}

class PSP_Ticket_Replies {
    
    public function __construct() {
        add_action('wp_footer', [$this, 'register_endpoints']);
    }
    
    /**
     * Register reply endpoints
     */
    public function register_endpoints() {
        add_action('rest_api_init', function() {
            register_rest_route('psp/v1', '/tickets/(?P<ticket_id>\d+)/replies', [
                'methods' => ['GET', 'POST'],
                'callback' => [$this, 'handle_replies'],
                'permission_callback' => [$this, 'check_auth'],
            ]);
            
            register_rest_route('psp/v1', '/replies/(?P<reply_id>\d+)', [
                'methods' => ['DELETE'],
                'callback' => [$this, 'delete_reply'],
                'permission_callback' => [$this, 'check_auth'],
            ]);
        });
    }
    
    /**
     * Check authentication
     */
    public function check_auth() {
        return !empty($_SESSION['psp_user']);
    }
    
    /**
     * Handle ticket replies (GET list / POST create)
     */
    public function handle_replies($request) {
        if ($request->get_method() === 'POST') {
            return $this->create_reply($request);
        }
        return $this->get_replies($request);
    }
    
    /**
     * Get replies for a ticket
     */
    public function get_replies($request) {
        global $wpdb;
        
        $user = $_SESSION['psp_user'] ?? null;
        if (!$user) {
            return new WP_Error('unauthorized', 'Not authenticated', ['status' => 401]);
        }
        
        $ticket_id = intval($request['ticket_id']);
        
        // Verify access to ticket
        $ticket = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}psp_tickets WHERE id = %d",
            $ticket_id
        ));
        
        if (!$ticket) {
            return new WP_Error('not_found', 'Ticket not found', ['status' => 404]);
        }
        
        if ($user['role'] !== 'admin' && $ticket->partner_id !== $user['company_id']) {
            return new WP_Error('forbidden', 'Access denied', ['status' => 403]);
        }
        
        // Get replies
        $replies = $wpdb->get_results($wpdb->prepare(
            "SELECT r.*, u.name as author_name, u.role as author_role
             FROM {$wpdb->prefix}psp_ticket_replies r
             LEFT JOIN {$wpdb->prefix}psp_company_users u ON r.user_id = u.id
             WHERE r.ticket_id = %d
             ORDER BY r.created_at ASC",
            $ticket_id
        ));
        
        // Get attachments for each reply
        foreach ($replies as $reply) {
            $reply->attachments = $wpdb->get_results($wpdb->prepare(
                "SELECT id, filename, file_url, file_size FROM {$wpdb->prefix}psp_reply_attachments 
                 WHERE reply_id = %d",
                $reply->id
            ));
        }
        
        return rest_ensure_response([
            'success' => true,
            'data' => $replies,
            'count' => count($replies),
        ]);
    }
    
    /**
     * Create a reply
     */
    public function create_reply($request) {
        global $wpdb;
        
        $user = $_SESSION['psp_user'] ?? null;
        if (!$user) {
            return new WP_Error('unauthorized', 'Not authenticated', ['status' => 401]);
        }
        
        $ticket_id = intval($request['ticket_id']);
        $data = $request->get_json_params();
        
        // Verify access to ticket
        $ticket = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}psp_tickets WHERE id = %d",
            $ticket_id
        ));
        
        if (!$ticket) {
            return new WP_Error('not_found', 'Ticket not found', ['status' => 404]);
        }
        
        if ($user['role'] !== 'admin' && $ticket->partner_id !== $user['company_id']) {
            return new WP_Error('forbidden', 'Access denied', ['status' => 403]);
        }
        
        if (empty($data['message'])) {
            return new WP_Error('invalid', 'Message required', ['status' => 400]);
        }
        
        // Create reply
        $result = $wpdb->insert(
            "{$wpdb->prefix}psp_ticket_replies",
            [
                'ticket_id' => $ticket_id,
                'user_id' => $user['id'],
                'message' => wp_kses_post($data['message']),
                'is_internal' => isset($data['is_internal']) ? (bool)$data['is_internal'] : false,
                'created_at' => current_time('mysql'),
            ]
        );
        
        if (!$result) {
            return new WP_Error('db_error', 'Failed to create reply', ['status' => 500]);
        }
        
        $reply_id = $wpdb->insert_id;
        
        // Handle file attachments
        if (!empty($data['attachments']) && is_array($data['attachments'])) {
            foreach ($data['attachments'] as $attachment) {
                $wpdb->insert(
                    "{$wpdb->prefix}psp_reply_attachments",
                    [
                        'reply_id' => $reply_id,
                        'filename' => sanitize_file_name($attachment['filename']),
                        'file_url' => esc_url($attachment['file_url']),
                        'file_size' => intval($attachment['file_size']),
                        'uploaded_at' => current_time('mysql'),
                    ]
                );
            }
        }
        
        // Update ticket's updated_at timestamp
        $wpdb->update(
            "{$wpdb->prefix}psp_tickets",
            ['updated_at' => current_time('mysql')],
            ['id' => $ticket_id]
        );
        
        // Log activity
        $this->log_activity('reply_added', "Reply added to ticket #{$ticket_id}", $user['id'], $ticket->partner_id);
        
        // Send notification
        do_action('psp_ticket_reply_added', $ticket_id, $reply_id, $user);
        
        return rest_ensure_response([
            'success' => true,
            'message' => 'Reply created successfully',
            'reply_id' => $reply_id,
        ], 201);
    }
    
    /**
     * Delete a reply
     */
    public function delete_reply($request) {
        global $wpdb;
        
        $user = $_SESSION['psp_user'] ?? null;
        if (!$user) {
            return new WP_Error('unauthorized', 'Not authenticated', ['status' => 401]);
        }
        
        $reply_id = intval($request['reply_id']);
        
        $reply = $wpdb->get_row($wpdb->prepare(
            "SELECT r.*, t.partner_id FROM {$wpdb->prefix}psp_ticket_replies r
             LEFT JOIN {$wpdb->prefix}psp_tickets t ON r.ticket_id = t.id
             WHERE r.id = %d",
            $reply_id
        ));
        
        if (!$reply) {
            return new WP_Error('not_found', 'Reply not found', ['status' => 404]);
        }
        
        // Only admin or reply author can delete
        if ($user['role'] !== 'admin' && $reply->user_id !== $user['id']) {
            return new WP_Error('forbidden', 'Access denied', ['status' => 403]);
        }
        
        // Delete attachments
        $wpdb->delete(
            "{$wpdb->prefix}psp_reply_attachments",
            ['reply_id' => $reply_id]
        );
        
        // Delete reply
        $wpdb->delete(
            "{$wpdb->prefix}psp_ticket_replies",
            ['id' => $reply_id]
        );
        
        return rest_ensure_response([
            'success' => true,
            'message' => 'Reply deleted successfully',
        ]);
    }
    
    /**
     * Log activity
     */
    private function log_activity($action, $description, $user_id, $entity_id) {
        global $wpdb;
        
        $wpdb->insert(
            "{$wpdb->prefix}psp_audit_log",
            [
                'action' => $action,
                'description' => $description,
                'user_id' => $user_id,
                'entity_id' => $entity_id,
                'created_at' => current_time('mysql'),
            ]
        );
    }
}

// Initialize
new PSP_Ticket_Replies();
