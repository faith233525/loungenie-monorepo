<?php
/**
 * Pool Safe Portal - Activity Logs System
 * 
 * Tracks all operational changes, user actions, and system events
 * Provides comprehensive audit trail with filtering and export capabilities
 * 
 * @package PSP\Activity_Logs
 * @version 2.0.0
 */

namespace PSP\Activity_Logs;

if (!defined('ABSPATH')) {
    exit;
}

class Activity_Logs {
    
    // Table name for activity logs
    const TABLE_NAME = 'psp_activity_logs';
    
    // Log action types
    const ACTIONS = [
        'partner_created' => 'Partner Created',
        'partner_updated' => 'Partner Updated',
        'partner_deleted' => 'Partner Deleted',
        'partner_suspended' => 'Partner Suspended',
        'partner_reactivated' => 'Partner Reactivated',
        'ticket_created' => 'Ticket Created',
        'ticket_updated' => 'Ticket Updated',
        'ticket_closed' => 'Ticket Closed',
        'ticket_reopened' => 'Ticket Reopened',
        'property_added' => 'Property Added',
        'property_updated' => 'Property Updated',
        'property_deleted' => 'Property Deleted',
        'video_created' => 'Video Created',
        'video_updated' => 'Video Updated',
        'video_deleted' => 'Video Deleted',
        'service_scheduled' => 'Service Scheduled',
        'service_completed' => 'Service Completed',
        'invoice_created' => 'Invoice Created',
        'invoice_paid' => 'Invoice Paid',
        'report_generated' => 'Report Generated',
        'user_login' => 'User Login',
        'user_logout' => 'User Logout',
        'permission_changed' => 'Permission Changed',
        'notification_sent' => 'Notification Sent',
        'bulk_import' => 'Bulk Import',
        'bulk_export' => 'Bulk Export',
    ];
    
    // Severity levels
    const SEVERITY = [
        'info' => 'Info',
        'notice' => 'Notice',
        'warning' => 'Warning',
        'error' => 'Error',
        'critical' => 'Critical',
    ];
    
    /**
     * Initialize Activity Logs system
     */
    public static function init() {
        // Hook into WordPress actions for logging
        add_action('wp_insert_post', [__CLASS__, 'log_post_changes'], 10, 3);
        add_action('wp_delete_post', [__CLASS__, 'log_post_delete'], 10, 2);
        add_action('update_user_meta', [__CLASS__, 'log_user_meta_changes'], 10, 4);
        add_action('user_register', [__CLASS__, 'log_user_registration']);
        add_action('wp_login', [__CLASS__, 'log_user_login']);
        add_action('wp_logout', [__CLASS__, 'log_user_logout']);
        
        // Register Activity Logs CPT for admin display
        add_action('init', [__CLASS__, 'register_logs_post_type']);
        
        // Register REST API endpoints
        add_action('rest_api_init', [__CLASS__, 'register_rest_endpoints']);
    }
    
    /**
     * Create database table for activity logs
     */
    public static function create_table() {
        global $wpdb;

        $table           = $wpdb->prefix . self::TABLE_NAME;
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE IF NOT EXISTS {$table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            action VARCHAR(100) NOT NULL,
            user_id BIGINT UNSIGNED,
            user_email VARCHAR(255),
            object_type VARCHAR(50),
            object_id BIGINT UNSIGNED,
            object_name VARCHAR(255),
            partner_id BIGINT UNSIGNED,
            property_id BIGINT UNSIGNED,
            old_value LONGTEXT,
            new_value LONGTEXT,
            severity VARCHAR(20) DEFAULT 'info',
            description TEXT,
            ip_address VARCHAR(45),
            user_agent TEXT,
            status VARCHAR(20) DEFAULT 'completed',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY action_idx (action),
            KEY user_id_idx (user_id),
            KEY object_type_idx (object_type),
            KEY partner_id_idx (partner_id),
            KEY created_at_idx (created_at),
            KEY severity_idx (severity)
        ) {$charset_collate};";

        $result = $wpdb->query($sql);

        if ($result === false && !empty($wpdb->last_error)) {
            error_log('[PSP Activity Logs] Failed to create table: ' . $wpdb->last_error);
        }
    }
    
    /**
     * Register Activity Logs CPT
     */
    public static function register_logs_post_type() {
        register_post_type('psp_activity_log', [
            'label' => 'Activity Logs',
            'description' => 'System activity and audit logs',
            'public' => false,
            'show_ui' => true,
            'show_in_menu' => 'psp-portal',
            'show_in_rest' => true,
            'rest_base' => 'activity-logs',
            'supports' => ['title'],
            'capability_type' => 'post',
            'capabilities' => [
                'create_posts' => 'manage_psp_portal',
                'read_post' => 'manage_psp_portal',
                'read_private_posts' => 'manage_psp_portal',
                'edit_post' => 'manage_psp_portal',
                'edit_posts' => 'manage_psp_portal',
                'edit_private_posts' => 'manage_psp_portal',
                'delete_post' => 'manage_psp_portal',
                'delete_posts' => 'manage_psp_portal',
            ],
            'map_meta_cap' => false,
        ]);
    }
    
    /**
     * Register REST API endpoints
     */
    public static function register_rest_endpoints() {
        register_rest_route('psp/v1', '/activity-logs', [
            [
                'methods' => 'GET',
                'callback' => [__CLASS__, 'get_logs'],
                'permission_callback' => function () {
                    return current_user_can('manage_psp_portal');
                },
                'args' => [
                    'action' => ['type' => 'string', 'required' => false],
                    'user_id' => ['type' => 'integer', 'required' => false],
                    'partner_id' => ['type' => 'integer', 'required' => false],
                    'severity' => ['type' => 'string', 'required' => false],
                    'date_from' => ['type' => 'string', 'required' => false],
                    'date_to' => ['type' => 'string', 'required' => false],
                    'limit' => ['type' => 'integer', 'default' => 50],
                    'offset' => ['type' => 'integer', 'default' => 0],
                ],
            ],
            [
                'methods' => 'POST',
                'callback' => [__CLASS__, 'create_log'],
                'permission_callback' => function () {
                    return current_user_can('manage_psp_portal');
                },
            ],
        ]);
        
        register_rest_route('psp/v1', '/activity-logs/(?P<id>\d+)', [
            'methods' => 'GET',
            'callback' => [__CLASS__, 'get_log'],
            'permission_callback' => function () {
                return current_user_can('manage_psp_portal');
            },
        ]);
        
        register_rest_route('psp/v1', '/activity-logs/export', [
            'methods' => 'POST',
            'callback' => [__CLASS__, 'export_logs'],
            'permission_callback' => function () {
                return current_user_can('manage_psp_portal');
            },
        ]);
    }
    
    /**
     * Log an activity
     */
    public static function log(
        $action,
        $object_type = null,
        $object_id = null,
        $object_name = null,
        $old_value = null,
        $new_value = null,
        $severity = 'info',
        $description = null,
        $partner_id = null,
        $property_id = null
    ) {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_NAME;
        
        $current_user = wp_get_current_user();
        $user_id = $current_user->ID ?? null;
        $user_email = $current_user->user_email ?? null;
        
        $data = [
            'action' => $action,
            'user_id' => $user_id,
            'user_email' => $user_email,
            'object_type' => $object_type,
            'object_id' => $object_id,
            'object_name' => $object_name,
            'partner_id' => $partner_id,
            'property_id' => $property_id,
            'old_value' => is_array($old_value) ? json_encode($old_value) : $old_value,
            'new_value' => is_array($new_value) ? json_encode($new_value) : $new_value,
            'severity' => $severity,
            'description' => $description,
            'ip_address' => self::get_client_ip(),
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? null,
        ];
        
        return $wpdb->insert($table, $data);
    }
    
    /**
     * Retrieve activity logs with filtering
     */
    public static function get_logs($request) {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_NAME;
        
        $action = $request->get_param('action');
        $user_id = $request->get_param('user_id');
        $partner_id = $request->get_param('partner_id');
        $severity = $request->get_param('severity');
        $date_from = $request->get_param('date_from');
        $date_to = $request->get_param('date_to');
        $limit = $request->get_param('limit') ?? 50;
        $offset = $request->get_param('offset') ?? 0;
        
        $query = "SELECT * FROM {$table} WHERE 1=1";
        $params = [];
        
        if (!empty($action)) {
            $query .= " AND action = %s";
            $params[] = $action;
        }
        
        if (!empty($user_id)) {
            $query .= " AND user_id = %d";
            $params[] = $user_id;
        }
        
        if (!empty($partner_id)) {
            $query .= " AND partner_id = %d";
            $params[] = $partner_id;
        }
        
        if (!empty($severity)) {
            $query .= " AND severity = %s";
            $params[] = $severity;
        }
        
        if (!empty($date_from)) {
            $query .= " AND created_at >= %s";
            $params[] = $date_from . ' 00:00:00';
        }
        
        if (!empty($date_to)) {
            $query .= " AND created_at <= %s";
            $params[] = $date_to . ' 23:59:59';
        }
        
        $query .= " ORDER BY created_at DESC LIMIT %d OFFSET %d";
        $params[] = $limit;
        $params[] = $offset;
        
        $query_prepared = $wpdb->prepare($query, $params);
        $logs = $wpdb->get_results($query_prepared);
        
        return [
            'data' => $logs,
            'total' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table}"),
            'limit' => $limit,
            'offset' => $offset,
        ];
    }
    
    /**
     * Get single log by ID
     */
    public static function get_log($request) {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_NAME;
        
        $id = $request->get_param('id');
        $log = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$table} WHERE id = %d",
            $id
        ));
        
        return $log ?? new \WP_Error('not_found', 'Log not found');
    }
    
    /**
     * Create a log entry via API
     */
    public static function create_log($request) {
        $params = $request->get_json_params();
        
        $result = self::log(
            $params['action'] ?? 'unknown',
            $params['object_type'] ?? null,
            $params['object_id'] ?? null,
            $params['object_name'] ?? null,
            $params['old_value'] ?? null,
            $params['new_value'] ?? null,
            $params['severity'] ?? 'info',
            $params['description'] ?? null,
            $params['partner_id'] ?? null,
            $params['property_id'] ?? null
        );
        
        return $result ? ['success' => true] : new \WP_Error('db_error', 'Failed to create log');
    }
    
    /**
     * Export logs as JSON or CSV
     */
    public static function export_logs($request) {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_NAME;
        
        $params = $request->get_json_params();
        $format = $params['format'] ?? 'json';
        
        $action = $params['action'] ?? null;
        $partner_id = $params['partner_id'] ?? null;
        $date_from = $params['date_from'] ?? null;
        $date_to = $params['date_to'] ?? null;
        
        $query = "SELECT * FROM {$table} WHERE 1=1";
        $params_arr = [];
        
        if (!empty($action)) {
            $query .= " AND action = %s";
            $params_arr[] = $action;
        }
        
        if (!empty($partner_id)) {
            $query .= " AND partner_id = %d";
            $params_arr[] = $partner_id;
        }
        
        if (!empty($date_from)) {
            $query .= " AND created_at >= %s";
            $params_arr[] = $date_from . ' 00:00:00';
        }
        
        if (!empty($date_to)) {
            $query .= " AND created_at <= %s";
            $params_arr[] = $date_to . ' 23:59:59';
        }
        
        $query .= " ORDER BY created_at DESC";
        
        if (empty($params_arr)) {
            $results = $wpdb->get_results($query);
        } else {
            $results = $wpdb->get_results($wpdb->prepare($query, $params_arr));
        }
        
        if ($format === 'csv') {
            return self::format_csv_export($results);
        }
        
        return ['data' => $results];
    }
    
    /**
     * Format logs as CSV
     */
    private static function format_csv_export($logs) {
        $csv_header = ['ID', 'Action', 'User', 'User Email', 'Object Type', 'Object ID', 'Object Name', 'Partner ID', 'Severity', 'Description', 'IP Address', 'Created At'];
        $csv_rows = [];
        
        foreach ($logs as $log) {
            $csv_rows[] = [
                $log->id,
                $log->action,
                $log->user_id,
                $log->user_email,
                $log->object_type,
                $log->object_id,
                $log->object_name,
                $log->partner_id,
                $log->severity,
                $log->description,
                $log->ip_address,
                $log->created_at,
            ];
        }
        
        return [
            'headers' => $csv_header,
            'rows' => $csv_rows,
            'filename' => 'activity-logs-' . current_time('Y-m-d-His') . '.csv',
        ];
    }
    
    /**
     * Log post changes (partner, property, ticket, etc.)
     */
    public static function log_post_changes($post_id, $post, $update) {
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        
        $post_type = $post->post_type ?? null;
        
        // Only log specific post types
        $loggable_types = ['psp_partner', 'psp_property', 'psp_ticket', 'psp_training_video'];
        if (!in_array($post_type, $loggable_types)) {
            return;
        }
        
        $action_map = [
            'psp_partner' => $update ? 'partner_updated' : 'partner_created',
            'psp_property' => $update ? 'property_updated' : 'property_added',
            'psp_ticket' => $update ? 'ticket_updated' : 'ticket_created',
            'psp_training_video' => $update ? 'video_updated' : 'video_created',
        ];
        
        $action = $action_map[$post_type] ?? 'post_' . ($update ? 'updated' : 'created');
        
        self::log(
            $action,
            $post_type,
            $post_id,
            $post->post_title ?? '',
            null,
            null,
            'info',
            "Modified {$post_type}: {$post->post_title}"
        );
    }
    
    /**
     * Log post deletion
     */
    public static function log_post_delete($post_id, $post) {
        $post_type = $post->post_type ?? null;
        
        $loggable_types = ['psp_partner', 'psp_property', 'psp_ticket', 'psp_training_video'];
        if (!in_array($post_type, $loggable_types)) {
            return;
        }
        
        $action_map = [
            'psp_partner' => 'partner_deleted',
            'psp_property' => 'property_deleted',
            'psp_ticket' => 'ticket_deleted',
            'psp_training_video' => 'video_deleted',
        ];
        
        $action = $action_map[$post_type] ?? 'post_deleted';
        
        self::log(
            $action,
            $post_type,
            $post_id,
            $post->post_title ?? '',
            null,
            null,
            'warning',
            "Deleted {$post_type}: {$post->post_title}"
        );
    }
    
    /**
     * Log user meta changes
     */
    public static function log_user_meta_changes($meta_id, $user_id, $meta_key, $meta_value) {
        $important_keys = ['psp_role', 'psp_partner_id', 'psp_company_id', 'user_status'];
        
        if (!in_array($meta_key, $important_keys)) {
            return;
        }
        
        self::log(
            'permission_changed',
            'user',
            $user_id,
            get_user_by('ID', $user_id)->user_login ?? '',
            null,
            $meta_value,
            'notice',
            "User meta changed: {$meta_key}"
        );
    }
    
    /**
     * Log user registration
     */
    public static function log_user_registration($user_id) {
        $user = get_user_by('ID', $user_id);
        
        self::log(
            'user_login',
            'user',
            $user_id,
            $user->user_login,
            null,
            null,
            'info',
            "New user registered: {$user->user_login}"
        );
    }
    
    /**
     * Log user login
     */
    public static function log_user_login($user_login, $user = null) {
        self::log(
            'user_login',
            'user',
            $user ? $user->ID : null,
            $user_login,
            null,
            null,
            'info',
            "User login: {$user_login}"
        );
    }
    
    /**
     * Log user logout
     */
    public static function log_user_logout() {
        $current_user = wp_get_current_user();
        
        self::log(
            'user_logout',
            'user',
            $current_user->ID,
            $current_user->user_login,
            null,
            null,
            'info',
            "User logout: {$current_user->user_login}"
        );
    }
    
    /**
     * Get client IP address
     */
    private static function get_client_ip() {
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } else {
            $ip = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
        }
        
        return $ip;
    }
    
    /**
     * Get summary statistics for dashboard
     */
    public static function get_summary() {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_NAME;
        
        return [
            'total_logs' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table}"),
            'today' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE DATE(created_at) = CURDATE()"),
            'this_week' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)"),
            'this_month' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE YEAR(created_at) = YEAR(NOW()) AND MONTH(created_at) = MONTH(NOW())"),
            'critical_count' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE severity = 'critical'"),
            'error_count' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE severity = 'error'"),
        ];
    }
}

// Initialize on WordPress init
Activity_Logs::init();
