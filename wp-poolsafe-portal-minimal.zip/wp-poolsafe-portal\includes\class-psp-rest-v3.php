<?php
/**
 * PoolSafe Portal v3.0 - Enhanced REST API Endpoints
 *
 * Provides RESTful API access to:
 * - Training Videos (CRUD + management)
 * - Operational Tracking (staff visits, service records)
 * - Company Management & Drilldown
 * - Company-Centric Ticketing
 * - Email Integration Webhooks
 *
 * @package PoolSafe_Portal
 * @subpackage REST_API
 * @version 3.0.0
 */

namespace PSP;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class REST_V3 {

	/**
	 * Initialize REST API
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	/**
	 * Register all REST routes
	 */
	public static function register_routes() {

		// ==========================================
		// TRAINING VIDEOS ENDPOINTS
		// ==========================================

		// GET /videos - List all videos (role-filtered)
		register_rest_route(
			'poolsafe/v1',
			'/videos',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'get_videos' ),
				'permission_callback' => array( __CLASS__, 'can_view_videos' ),
				'args'                => array(
					'page'       => array(
						'type'              => 'integer',
						'default'           => 1,
						'validate_callback' => 'rest_validate_request_arg',
					),
					'per_page'   => array(
						'type'              => 'integer',
						'default'           => 25,
						'validate_callback' => 'rest_validate_request_arg',
					),
					'search'     => array(
						'type'              => 'string',
						'validate_callback' => 'rest_validate_request_arg',
					),
					'visibility' => array(
						'type'              => 'string',
						'validate_callback' => 'rest_validate_request_arg',
					),
				),
			)
		);

		// GET /videos/{id} - Get single video detail
		register_rest_route(
			'poolsafe/v1',
			'/videos/(?P<id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'get_video' ),
				'permission_callback' => array( __CLASS__, 'can_view_video' ),
				'args'                => array(
					'id' => array(
						'type'              => 'integer',
						'required'          => true,
						'validate_callback' => 'rest_validate_request_arg',
					),
				),
			)
		);

		// POST /videos - Create new video (admin/support only)
		register_rest_route(
			'poolsafe/v1',
			'/videos',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'create_video' ),
				'permission_callback' => array( __CLASS__, 'can_manage_videos' ),
				'args'                => array(
					'title'             => array(
						'type'     => 'string',
						'required' => true,
					),
					'description'       => array(
						'type' => 'string',
					),
					'video_url'         => array(
						'type'     => 'string',
						'required' => true,
					),
					'thumbnail_url'     => array(
						'type' => 'string',
					),
					'duration'          => array(
						'type' => 'integer',
					),
					'visibility_type'   => array(
						'type'    => 'string',
						'default' => 'public',
						'enum'    => array( 'public', 'admin_only', 'support_only', 'partner_only', 'specific_company' ),
					),
					'visibility_value'  => array(
						'type' => 'string',
					),
				),
			)
		);

		// PUT /videos/{id} - Update video
		register_rest_route(
			'poolsafe/v1',
			'/videos/(?P<id>\d+)',
			array(
				'methods'             => 'PUT',
				'callback'            => array( __CLASS__, 'update_video' ),
				'permission_callback' => array( __CLASS__, 'can_manage_videos' ),
				'args'                => array(
					'id'                => array(
						'type'     => 'integer',
						'required' => true,
					),
					'title'             => array(
						'type' => 'string',
					),
					'description'       => array(
						'type' => 'string',
					),
					'video_url'         => array(
						'type' => 'string',
					),
					'thumbnail_url'     => array(
						'type' => 'string',
					),
					'duration'          => array(
						'type' => 'integer',
					),
					'visibility_type'   => array(
						'type' => 'string',
						'enum' => array( 'public', 'admin_only', 'support_only', 'partner_only', 'specific_company' ),
					),
					'visibility_value'  => array(
						'type' => 'string',
					),
				),
			)
		);

		// DELETE /videos/{id} - Delete video
		register_rest_route(
			'poolsafe/v1',
			'/videos/(?P<id>\d+)',
			array(
				'methods'             => 'DELETE',
				'callback'            => array( __CLASS__, 'delete_video' ),
				'permission_callback' => array( __CLASS__, 'can_manage_videos' ),
				'args'                => array(
					'id' => array(
						'type'     => 'integer',
						'required' => true,
					),
				),
			)
		);

		// POST /videos/{id}/view - Log video view
		register_rest_route(
			'poolsafe/v1',
			'/videos/(?P<id>\d+)/view',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'log_video_view' ),
				'permission_callback' => array( __CLASS__, 'can_view_videos' ),
				'args'                => array(
					'id' => array(
						'type'     => 'integer',
						'required' => true,
					),
				),
			)
		);

		// ==========================================
		// OPERATIONS (STAFF VISITS) ENDPOINTS
		// ==========================================

		// GET /operations - List operations (role-filtered)
		register_rest_route(
			'poolsafe/v1',
			'/operations',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'get_operations' ),
				'permission_callback' => array( __CLASS__, 'can_view_operations' ),
				'args'                => array(
					'company_id'  => array(
						'type'              => 'integer',
						'validate_callback' => 'rest_validate_request_arg',
					),
					'user_id'     => array(
						'type'              => 'integer',
						'validate_callback' => 'rest_validate_request_arg',
					),
					'visit_type'  => array(
						'type'              => 'string',
						'validate_callback' => 'rest_validate_request_arg',
					),
					'status'      => array(
						'type'              => 'string',
						'validate_callback' => 'rest_validate_request_arg',
					),
					'date_from'   => array(
						'type'              => 'string',
						'validate_callback' => 'rest_validate_request_arg',
					),
					'date_to'     => array(
						'type'              => 'string',
						'validate_callback' => 'rest_validate_request_arg',
					),
					'page'        => array(
						'type'    => 'integer',
						'default' => 1,
					),
					'per_page'    => array(
						'type'    => 'integer',
						'default' => 25,
					),
				),
			)
		);

		// GET /operations/{id} - Get operation detail
		register_rest_route(
			'poolsafe/v1',
			'/operations/(?P<id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'get_operation' ),
				'permission_callback' => array( __CLASS__, 'can_view_operation' ),
				'args'                => array(
					'id' => array(
						'type'     => 'integer',
						'required' => true,
					),
				),
			)
		);

		// POST /operations - Create operation
		register_rest_route(
			'poolsafe/v1',
			'/operations',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'create_operation' ),
				'permission_callback' => array( __CLASS__, 'can_create_operation' ),
				'args'                => array(
					'company_id'         => array(
						'type'     => 'integer',
						'required' => true,
					),
					'visit_type'        => array(
						'type'     => 'string',
						'required' => true,
						'enum'    => array( 'inspection', 'service', 'repair', 'maintenance', 'training', 'other' ),
					),
					'visit_date'        => array(
						'type'     => 'string',
						'required' => true,
					),
					'duration'          => array(
						'type'     => 'integer',
						'required' => true,
					),
					'notes'             => array(
						'type' => 'string',
					),
					'units_visited'     => array(
						'type'  => 'array',
						'items' => array( 'type' => 'string' ),
					),
					'maintenance_items' => array(
						'type'  => 'array',
						'items' => array( 'type' => 'string' ),
					),
					'status'            => array(
						'type'    => 'string',
						'default' => 'completed',
						'enum'    => array( 'completed', 'pending_followup', 'pending_parts' ),
					),
				),
			)
		);

		// PUT /operations/{id} - Update operation
		register_rest_route(
			'poolsafe/v1',
			'/operations/(?P<id>\d+)',
			array(
				'methods'             => 'PUT',
				'callback'            => array( __CLASS__, 'update_operation' ),
				'permission_callback' => array( __CLASS__, 'can_edit_operation' ),
				'args'                => array(
					'id'                => array(
						'type'     => 'integer',
						'required' => true,
					),
					'visit_date'        => array(
						'type' => 'string',
					),
					'duration'          => array(
						'type' => 'integer',
					),
					'notes'             => array(
						'type' => 'string',
					),
					'units_visited'     => array(
						'type'  => 'array',
						'items' => array( 'type' => 'string' ),
					),
					'maintenance_items' => array(
						'type'  => 'array',
						'items' => array( 'type' => 'string' ),
					),
					'status'            => array(
						'type' => 'string',
						'enum' => array( 'completed', 'pending_followup', 'pending_parts' ),
					),
				),
			)
		);

		// DELETE /operations/{id} - Delete operation
		register_rest_route(
			'poolsafe/v1',
			'/operations/(?P<id>\d+)',
			array(
				'methods'             => 'DELETE',
				'callback'            => array( __CLASS__, 'delete_operation' ),
				'permission_callback' => array( __CLASS__, 'can_delete_operation' ),
				'args'                => array(
					'id' => array(
						'type'     => 'integer',
						'required' => true,
					),
				),
			)
		);

		// ==========================================
		// COMPANIES ENDPOINTS
		// ==========================================

		// GET /companies - List companies
		register_rest_route(
			'poolsafe/v1',
			'/companies',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'get_companies' ),
				'permission_callback' => array( __CLASS__, 'can_view_companies' ),
				'args'                => array(
					'page'    => array(
						'type'    => 'integer',
						'default' => 1,
					),
					'per_page' => array(
						'type'    => 'integer',
						'default' => 25,
					),
					'search'  => array(
						'type' => 'string',
					),
					'status'  => array(
						'type' => 'string',
					),
				),
			)
		);

		// GET /companies/{id} - Get company detail
		register_rest_route(
			'poolsafe/v1',
			'/companies/(?P<id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'get_company' ),
				'permission_callback' => array( __CLASS__, 'can_view_company' ),
				'args'                => array(
					'id' => array(
						'type'     => 'integer',
						'required' => true,
					),
				),
			)
		);

		// PUT /companies/{id} - Update company
		register_rest_route(
			'poolsafe/v1',
			'/companies/(?P<id>\d+)',
			array(
				'methods'             => 'PUT',
				'callback'            => array( __CLASS__, 'update_company' ),
				'permission_callback' => array( __CLASS__, 'can_edit_company' ),
				'args'                => array(
					'id'      => array(
						'type'     => 'integer',
						'required' => true,
					),
					'company_name'      => array(
						'type' => 'string',
					),
					'management_company' => array(
						'type' => 'string',
					),
					'street_address'    => array(
						'type' => 'string',
					),
					'city'              => array(
						'type' => 'string',
					),
					'state'             => array(
						'type' => 'string',
					),
					'zip'               => array(
						'type' => 'string',
					),
					'country'           => array(
						'type' => 'string',
					),
					'units'             => array(
						'type' => 'integer',
					),
					'status'            => array(
						'type' => 'string',
					),
				),
			)
		);

		// GET /companies/{id}/tickets - Get company tickets (role-filtered)
		register_rest_route(
			'poolsafe/v1',
			'/companies/(?P<id>\d+)/tickets',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'get_company_tickets' ),
				'permission_callback' => array( __CLASS__, 'can_view_company_tickets' ),
				'args'                => array(
					'id'        => array(
						'type'     => 'integer',
						'required' => true,
					),
					'status'    => array(
						'type' => 'string',
					),
					'priority'  => array(
						'type' => 'string',
					),
					'page'      => array(
						'type'    => 'integer',
						'default' => 1,
					),
					'per_page'  => array(
						'type'    => 'integer',
						'default' => 25,
					),
				),
			)
		);

		// GET /companies/{id}/operations - Get company operations
		register_rest_route(
			'poolsafe/v1',
			'/companies/(?P<id>\d+)/operations',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'get_company_operations' ),
				'permission_callback' => array( __CLASS__, 'can_view_company_operations' ),
				'args'                => array(
					'id'        => array(
						'type'     => 'integer',
						'required' => true,
					),
					'page'      => array(
						'type'    => 'integer',
						'default' => 1,
					),
					'per_page'  => array(
						'type'    => 'integer',
						'default' => 25,
					),
				),
			)
		);

		// GET /companies/{id}/contacts - Get company contacts
		register_rest_route(
			'poolsafe/v1',
			'/companies/(?P<id>\d+)/contacts',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'get_company_contacts' ),
				'permission_callback' => array( __CLASS__, 'can_view_company_contacts' ),
				'args'                => array(
					'id' => array(
						'type'     => 'integer',
						'required' => true,
					),
				),
			)
		);

		// GET /companies/{id}/summary - Get company stats
		register_rest_route(
			'poolsafe/v1',
			'/companies/(?P<id>\d+)/summary',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'get_company_summary' ),
				'permission_callback' => array( __CLASS__, 'can_view_company' ),
				'args'                => array(
					'id' => array(
						'type'     => 'integer',
						'required' => true,
					),
				),
			)
		);

		// ==========================================
		// TICKETS ENDPOINTS (Enhanced for company-centric system)
		// ==========================================

		// GET /tickets - List tickets (role-filtered)
		register_rest_route(
			'poolsafe/v1',
			'/tickets',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'get_tickets' ),
				'permission_callback' => array( __CLASS__, 'can_view_tickets' ),
				'args'                => array(
					'company_id' => array(
						'type'              => 'integer',
						'validate_callback' => 'rest_validate_request_arg',
					),
					'status'     => array(
						'type'              => 'string',
						'validate_callback' => 'rest_validate_request_arg',
					),
					'priority'   => array(
						'type'              => 'string',
						'validate_callback' => 'rest_validate_request_arg',
					),
					'page'       => array(
						'type'    => 'integer',
						'default' => 1,
					),
					'per_page'   => array(
						'type'    => 'integer',
						'default' => 25,
					),
				),
			)
		);

		// GET /tickets/{id} - Get ticket detail
		register_rest_route(
			'poolsafe/v1',
			'/tickets/(?P<id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'get_ticket' ),
				'permission_callback' => array( __CLASS__, 'can_view_ticket' ),
				'args'                => array(
					'id' => array(
						'type'     => 'integer',
						'required' => true,
					),
				),
			)
		);

		// POST /tickets - Create ticket (links to company automatically)
		register_rest_route(
			'poolsafe/v1',
			'/tickets',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'create_ticket' ),
				'permission_callback' => array( __CLASS__, 'can_create_ticket' ),
				'args'                => array(
					'title'       => array(
						'type'     => 'string',
						'required' => true,
					),
					'description' => array(
						'type'     => 'string',
						'required' => true,
					),
					'priority'    => array(
						'type'    => 'string',
						'default' => 'medium',
					),
					'category'    => array(
						'type' => 'string',
					),
					'units_affected' => array(
						'type' => 'string',
					),
				),
			)
		);

		// PUT /tickets/{id} - Update ticket
		register_rest_route(
			'poolsafe/v1',
			'/tickets/(?P<id>\d+)',
			array(
				'methods'             => 'PUT',
				'callback'            => array( __CLASS__, 'update_ticket' ),
				'permission_callback' => array( __CLASS__, 'can_edit_ticket' ),
				'args'                => array(
					'id'       => array(
						'type'     => 'integer',
						'required' => true,
					),
					'status'   => array(
						'type' => 'string',
					),
					'priority' => array(
						'type' => 'string',
					),
				),
			)
		);

		// DELETE /tickets/{id} - Delete ticket
		register_rest_route(
			'poolsafe/v1',
			'/tickets/(?P<id>\d+)',
			array(
				'methods'             => 'DELETE',
				'callback'            => array( __CLASS__, 'delete_ticket' ),
				'permission_callback' => array( __CLASS__, 'can_delete_ticket' ),
				'args'                => array(
					'id' => array(
						'type'     => 'integer',
						'required' => true,
					),
				),
			)
		);

		// POST /tickets/{id}/replies - Add reply to ticket
		register_rest_route(
			'poolsafe/v1',
			'/tickets/(?P<id>\d+)/replies',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'create_ticket_reply' ),
				'permission_callback' => array( __CLASS__, 'can_reply_to_ticket' ),
				'args'                => array(
					'id'      => array(
						'type'     => 'integer',
						'required' => true,
					),
					'content' => array(
						'type'     => 'string',
						'required' => true,
					),
				),
			)
		);

		// GET /tickets/{id}/replies - Get all replies
		register_rest_route(
			'poolsafe/v1',
			'/tickets/(?P<id>\d+)/replies',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'get_ticket_replies' ),
				'permission_callback' => array( __CLASS__, 'can_view_ticket' ),
				'args'                => array(
					'id' => array(
						'type'     => 'integer',
						'required' => true,
					),
				),
			)
		);

		// ==========================================
		// EMAIL INTEGRATION ENDPOINT
		// ==========================================

		// POST /email-webhook - Receive incoming email from Outlook
		register_rest_route(
			'poolsafe/v1',
			'/email-webhook',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'email_webhook' ),
				'permission_callback' => array( __CLASS__, 'can_process_email' ),
				'args'                => array(
					'message_id' => array(
						'type'     => 'string',
						'required' => true,
					),
					'from'       => array(
						'type'     => 'string',
						'required' => true,
					),
					'to'         => array(
						'type' => 'string',
					),
					'subject'    => array(
						'type'     => 'string',
						'required' => true,
					),
					'body'       => array(
						'type'     => 'string',
						'required' => true,
					),
					'timestamp'  => array(
						'type' => 'string',
					),
				),
			)
		);

		// GET /email-webhook/status - Check webhook status
		register_rest_route(
			'poolsafe/v1',
			'/email-webhook/status',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'email_webhook_status' ),
				'permission_callback' => array( __CLASS__, 'can_view_settings' ),
			)
		);
	}

	// ==========================================
	// PERMISSION CALLBACKS
	// ==========================================

	/**
	 * Helper function to check if user has a specific role
	 */
	private static function user_has_role( $role ) {
		$user = wp_get_current_user();
		if ( ! $user || ! $user->ID ) {
			return false;
		}
		return in_array( $role, (array) $user->roles, true );
	}

	/**
	 * Helper function to check if user is support staff or admin
	 */
	private static function is_support_or_admin() {
		return self::user_has_role( 'psp_support' ) || self::user_has_role( 'administrator' );
	}

	public static function can_view_videos() {
		return is_user_logged_in();
	}

	public static function can_view_video() {
		return is_user_logged_in();
	}

	public static function can_manage_videos() {
		return self::is_support_or_admin();
	}

	public static function can_view_operations() {
		return self::is_support_or_admin();
	}

	public static function can_view_operation() {
		return self::is_support_or_admin();
	}

	public static function can_create_operation() {
		return self::is_support_or_admin();
	}

	public static function can_edit_operation() {
		return self::is_support_or_admin();
	}

	public static function can_delete_operation() {
		return self::user_has_role( 'administrator' );
	}

	public static function can_view_companies() {
		return is_user_logged_in();
	}

	public static function can_view_company() {
		return is_user_logged_in();
	}

	public static function can_edit_company() {
		return self::user_has_role( 'administrator' );
	}

	public static function can_view_company_tickets() {
		return is_user_logged_in();
	}

	public static function can_view_company_operations() {
		return self::is_support_or_admin();
	}

	public static function can_view_company_contacts() {
		return self::is_support_or_admin();
	}

	public static function can_view_tickets() {
		return is_user_logged_in();
	}

	public static function can_view_ticket() {
		return is_user_logged_in();
	}

	public static function can_create_ticket() {
		return is_user_logged_in();
	}

	public static function can_edit_ticket() {
		return self::is_support_or_admin();
	}

	public static function can_delete_ticket() {
		return self::user_has_role( 'administrator' );
	}

	public static function can_reply_to_ticket() {
		return is_user_logged_in();
	}

	public static function can_process_email() {
		// Verify email webhook signature/key
		return self::verify_email_webhook_key();
	}

	public static function can_view_settings() {
		return self::user_has_role( 'administrator' );
	}

	/**
	 * Bulk fetch post meta for multiple posts (eliminates N+1 queries)
	 * 
	 * @param array $post_ids Array of post IDs to fetch meta for
	 * @param array $meta_keys Array of meta key names to fetch
	 * @return array Associative array: post_id => array(meta_key => meta_value)
	 */
	private static function bulk_get_post_meta( $post_ids, $meta_keys ) {
		if ( empty( $post_ids ) || empty( $meta_keys ) ) {
			return array();
		}

		global $wpdb;
		$post_ids_placeholders = implode( ',', array_fill( 0, count( $post_ids ), '%d' ) );
		$meta_keys_placeholders = implode( ',', array_fill( 0, count( $meta_keys ), '%s' ) );

		$query = $wpdb->prepare(
			"SELECT post_id, meta_key, meta_value FROM {$wpdb->postmeta}
			 WHERE post_id IN ({$post_ids_placeholders})
			 AND meta_key IN ({$meta_keys_placeholders})",
			array_merge( $post_ids, $meta_keys )
		);

		$results = $wpdb->get_results( $query );
		$meta_cache = array();

		foreach ( $results as $row ) {
			if ( ! isset( $meta_cache[ $row->post_id ] ) ) {
				$meta_cache[ $row->post_id ] = array();
			}
			$meta_cache[ $row->post_id ][ $row->meta_key ] = maybe_unserialize( $row->meta_value );
		}

		return $meta_cache;
	}

	// ==========================================
	// ENDPOINT CALLBACKS (Stubs for implementation)
	// ==========================================

	// ==========================================
	// VIDEOS ENDPOINTS
	// ==========================================

	/**
	 * Get all training videos (role-filtered) with caching
	 */
	public static function get_videos( $request ): array {
		try {
			global $wpdb;
			$page     = intval( $request->get_param( 'page' ) ?: 1 );
			$per_page = intval( $request->get_param( 'per_page' ) ?: 25 );
			$search   = sanitize_text_field( $request->get_param( 'search' ) ?: '' );
			$offset   = ( $page - 1 ) * $per_page;
			$user_id  = get_current_user_id();
			$is_admin = current_user_can( 'administrator' );

			// Build cache key including all parameters
			$cache_key = 'psp_videos_page_' . $page . '_per_' . $per_page . '_search_' . md5( $search ) . '_user_' . $user_id;

			// Try cache first
			if ( class_exists( 'PSP_Query_Cache' ) ) {
				$cached = get_transient( $cache_key );
				if ( false !== $cached ) {
					return rest_ensure_response( $cached );
				}
			}

			// Base query
			$query = "SELECT id, title, description, thumbnail_url, duration, access_level, category_id, status 
					  FROM {$wpdb->prefix}psp_videos WHERE status = 'published'";

			// Search filter
			if ( $search ) {
				$query .= $wpdb->prepare( ' AND (title LIKE %s OR description LIKE %s)', '%' . $search . '%', '%' . $search . '%' );
			}

			// Role-based filtering
			if ( ! $is_admin ) {
				$query .= " AND (access_level = 'all' OR (access_level = 'user' AND id IN (SELECT video_id FROM {$wpdb->prefix}psp_video_access WHERE user_id = %d)))";
				$query  = $wpdb->prepare( $query, $user_id );
			}

			$query .= ' ORDER BY id DESC LIMIT %d, %d';
			if ( $is_admin ) {
				$query = $wpdb->prepare( $query, $offset, $per_page );
			} else {
				$query = $wpdb->prepare( $query, $offset, $per_page );
			}

			$videos = $wpdb->get_results( $query, ARRAY_A );

			if ( is_wp_error( $videos ) ) {
				throw new \Exception( 'Failed to fetch videos' );
			}

			// Get total count (use separate cache for count)
			$count_key = 'psp_videos_count_search_' . md5( $search ) . '_user_' . $user_id;
			$total = get_transient( $count_key );
			
			if ( false === $total ) {
				$count_query = "SELECT COUNT(*) FROM {$wpdb->prefix}psp_videos WHERE status = 'published'";
				if ( $search ) {
					$count_query .= $wpdb->prepare( ' AND (title LIKE %s OR description LIKE %s)', '%' . $search . '%', '%' . $search . '%' );
				}
				if ( ! $is_admin ) {
					$count_query .= " AND (access_level = 'all' OR (access_level = 'user' AND id IN (SELECT video_id FROM {$wpdb->prefix}psp_video_access WHERE user_id = %d)))";
					$count_query  = $wpdb->prepare( $count_query, $user_id );
				}
				$total = intval( $wpdb->get_var( $count_query ) );
				set_transient( $count_key, $total, 3600 ); // Cache for 1 hour
			}

			$response = array(
				'success' => true,
				'data'    => $videos,
				'page'    => $page,
				'total'   => $total,
			);

			// Cache response for 10 minutes
			if ( class_exists( 'PSP_Query_Cache' ) ) {
				set_transient( $cache_key, $response, 600 );
			}

			return rest_ensure_response( $response );
		} catch ( \Exception $e ) {
			error_log( '[PSP REST] get_videos failed: ' . $e->getMessage() );
			return rest_ensure_response(
				array( 'success' => false, 'error' => $e->getMessage() ),
				500
			);
		}
	}

	/**
	 * Get single video with views data (cached)
	 */
	public static function get_video( $request ) {
		try {
			global $wpdb;
			$video_id = intval( $request['id'] );

			if ( ! $video_id ) {
				return rest_ensure_response( array( 'success' => false, 'error' => 'Invalid video ID' ), 400 );
			}

			// Cache key for single video
			$cache_key = 'psp_video_' . $video_id;
			$cached = get_transient( $cache_key );
			if ( false !== $cached ) {
				return rest_ensure_response( array( 'success' => true, 'data' => $cached ) );
			}

			$video = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT id, title, description, video_url, video_type, thumbnail_url, duration, access_level, status, created_at, updated_at 
					 FROM {$wpdb->prefix}psp_videos WHERE id = %d",
					$video_id
				),
				ARRAY_A
			);

			if ( ! $video ) {
				return rest_ensure_response( array( 'success' => false, 'error' => 'Video not found' ), 404 );
			}

			// Get view stats (cached separately for faster updates)
			$views_cache = 'psp_video_views_' . $video_id;
			$views = get_transient( $views_cache );
			if ( false === $views ) {
				$views = intval( $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}psp_video_views WHERE video_id = %d", $video_id ) ) );
				set_transient( $views_cache, $views, 1800 ); // Cache for 30 minutes
			}

			$video['view_count'] = $views;

			// Cache video details for 1 hour
			set_transient( $cache_key, $video, 3600 );

			return rest_ensure_response( array( 'success' => true, 'data' => $video ) );
		} catch ( \Exception $e ) {
			error_log( '[PSP REST] get_video failed: ' . $e->getMessage() );
			return rest_ensure_response( array( 'success' => false, 'error' => $e->getMessage() ), 500 );
		}
	}

	/**
	 * Create new training video and clear list caches
	 */
	public static function create_video( $request ) {
		try {
			global $wpdb;
			$title       = sanitize_text_field( $request->get_param( 'title' ) );
			$description = wp_kses_post( $request->get_param( 'description' ) );
			$video_url   = esc_url( $request->get_param( 'video_url' ) );
			$video_type  = sanitize_text_field( $request->get_param( 'video_type' ) ?: 'upload' );
			$category_id = intval( $request->get_param( 'category_id' ) ?: 0 );
			$duration    = intval( $request->get_param( 'duration' ) ?: 0 );
			$access_level = sanitize_text_field( $request->get_param( 'access_level' ) ?: 'all' );

			if ( ! $title || ! $video_url ) {
				return rest_ensure_response( array( 'success' => false, 'error' => 'Missing required fields: title, video_url' ), 400 );
			}

			$result = $wpdb->insert(
				"{$wpdb->prefix}psp_videos",
				array(
					'title'        => $title,
					'description'  => $description,
					'video_url'    => $video_url,
					'video_type'   => $video_type,
					'category_id'  => $category_id,
					'duration'     => $duration,
					'access_level' => $access_level,
					'status'       => 'published',
				),
				array( '%s', '%s', '%s', '%s', '%d', '%d', '%s', '%s' )
			);

			if ( ! $result ) {
				throw new \Exception( 'Failed to create video' );
			}

			// Clear all video list caches
			self::clear_video_list_caches();

			return rest_ensure_response(
				array( 'success' => true, 'message' => 'Video created', 'video_id' => $wpdb->insert_id ),
				201
			);
		} catch ( \Exception $e ) {
			error_log( '[PSP REST] create_video failed: ' . $e->getMessage() );
			return rest_ensure_response( array( 'success' => false, 'error' => $e->getMessage() ), 500 );
		}
	}

	/**
	 * Update training video and clear caches
	 */
	public static function update_video( $request ) {
		try {
			global $wpdb;
			$video_id   = intval( $request['id'] );
			$title      = sanitize_text_field( $request->get_param( 'title' ) );
			$description = wp_kses_post( $request->get_param( 'description' ) );
			$duration   = intval( $request->get_param( 'duration' ) ?: 0 );

			if ( ! $video_id ) {
				return rest_ensure_response( array( 'success' => false, 'error' => 'Invalid video ID' ), 400 );
			}

			$update_data = array();
			if ( $title ) {
				$update_data['title'] = $title;
			}
			if ( $description ) {
				$update_data['description'] = $description;
			}
			if ( $duration ) {
				$update_data['duration'] = $duration;
			}

			if ( empty( $update_data ) ) {
				return rest_ensure_response( array( 'success' => false, 'error' => 'No fields to update' ), 400 );
			}

			$result = $wpdb->update(
				"{$wpdb->prefix}psp_videos",
				$update_data,
				array( 'id' => $video_id ),
				array_fill( 0, count( $update_data ), '%s' ),
				array( '%d' )
			);

			if ( $result === false ) {
				throw new \Exception( 'Failed to update video' );
			}

			// Clear specific video and list caches
			delete_transient( 'psp_video_' . $video_id );
			self::clear_video_list_caches();

			return rest_ensure_response( array( 'success' => true, 'message' => 'Video updated' ) );
		} catch ( \Exception $e ) {
			error_log( '[PSP REST] update_video failed: ' . $e->getMessage() );
			return rest_ensure_response( array( 'success' => false, 'error' => $e->getMessage() ), 500 );
		}
	}

	/**
	 * Delete training video and clear caches
	 */
	public static function delete_video( $request ) {
		try {
			global $wpdb;
			$video_id = intval( $request['id'] );

			if ( ! $video_id ) {
				return rest_ensure_response( array( 'success' => false, 'error' => 'Invalid video ID' ), 400 );
			}

			// Delete video and associated views
			$wpdb->delete( "{$wpdb->prefix}psp_videos", array( 'id' => $video_id ), array( '%d' ) );
			$wpdb->delete( "{$wpdb->prefix}psp_video_views", array( 'video_id' => $video_id ), array( '%d' ) );

			// Clear caches
			delete_transient( 'psp_video_' . $video_id );
			delete_transient( 'psp_video_views_' . $video_id );
			self::clear_video_list_caches();

			return rest_ensure_response( array( 'success' => true, 'message' => 'Video deleted' ) );
		} catch ( \Exception $e ) {
			error_log( '[PSP REST] delete_video failed: ' . $e->getMessage() );
			return rest_ensure_response( array( 'success' => false, 'error' => $e->getMessage() ), 500 );
		}
	}

	/**
	 * Log video view and clear cache
	 */
	public static function log_video_view( $request ) {
		try {
			global $wpdb;
			$video_id = intval( $request['id'] );
			$user_id  = get_current_user_id();

			if ( ! $video_id || ! $user_id ) {
				return rest_ensure_response( array( 'success' => false, 'error' => 'Invalid video ID or user not logged in' ), 400 );
			}

			$wpdb->insert(
				"{$wpdb->prefix}psp_video_views",
				array( 'video_id' => $video_id, 'user_id' => $user_id ),
				array( '%d', '%d' )
			);

			// Clear video view count cache so next request gets fresh data
			$views_cache = 'psp_video_views_' . $video_id;
			delete_transient( $views_cache );

			// Also clear the single video cache
			$video_cache = 'psp_video_' . $video_id;
			delete_transient( $video_cache );

			return rest_ensure_response( array( 'success' => true, 'message' => 'View logged' ) );
		} catch ( \Exception $e ) {
			error_log( '[PSP REST] log_video_view failed: ' . $e->getMessage() );
			return rest_ensure_response( array( 'success' => false, 'error' => $e->getMessage() ), 500 );
		}
	}

	// ==========================================
	// OPERATIONS ENDPOINTS
	// ==========================================

	/**
	 * Get all operations (staff visits)
	 */
	public static function get_operations( $request ) {
		try {
			$page     = intval( $request->get_param( 'page' ) ?: 1 );
			$per_page = intval( $request->get_param( 'per_page' ) ?: 25 );
			$offset   = ( $page - 1 ) * $per_page;

			$args = array(
				'post_type'      => 'psp_operation',
				'posts_per_page' => $per_page,
				'offset'         => $offset,
				'orderby'        => 'date',
				'order'          => 'DESC',
			);

		$query   = new \WP_Query( $args );
		$results = array();

		// Bulk fetch all meta to avoid N+1 queries
		$post_ids = wp_list_pluck( $query->posts, 'ID' );
		$meta_keys = array( 'company_id', 'staff_member', 'operation_type' );
		$meta_cache = self::bulk_get_post_meta( $post_ids, $meta_keys );

		foreach ( $query->posts as $post ) {
			$post_meta = $meta_cache[ $post->ID ] ?? array();
			$results[] = array(
				'id'           => $post->ID,
				'title'        => $post->post_title,
				'date'         => $post->post_date,
				'company_id'   => $post_meta['company_id'] ?? '',
				'staff_member' => $post_meta['staff_member'] ?? '',
				'type'         => $post_meta['operation_type'] ?? '',
			);
		}			return rest_ensure_response(
				array(
					'success' => true,
					'data'    => $results,
					'page'    => $page,
					'total'   => intval( $query->found_posts ),
				)
			);
		} catch ( \Exception $e ) {
			error_log( '[PSP REST] get_operations failed: ' . $e->getMessage() );
			return rest_ensure_response( array( 'success' => false, 'error' => $e->getMessage() ), 500 );
		}
	}

	/**
	 * Get single operation
	 */
	public static function get_operation( $request ) {
		try {
			$operation_id = intval( $request['id'] );

			if ( ! $operation_id ) {
				return rest_ensure_response( array( 'success' => false, 'error' => 'Invalid operation ID' ), 400 );
			}

			$post = get_post( $operation_id );

			if ( ! $post || 'psp_operation' !== $post->post_type ) {
				return rest_ensure_response( array( 'success' => false, 'error' => 'Operation not found' ), 404 );
			}

			return rest_ensure_response(
				array(
					'success' => true,
					'data'    => array(
						'id'           => $post->ID,
						'title'        => $post->post_title,
						'description'  => $post->post_content,
						'date'         => $post->post_date,
						'company_id'   => get_post_meta( $post->ID, 'company_id', true ),
						'staff_member' => get_post_meta( $post->ID, 'staff_member', true ),
						'type'         => get_post_meta( $post->ID, 'operation_type', true ),
					),
				)
			);
		} catch ( \Exception $e ) {
			error_log( '[PSP REST] get_operation failed: ' . $e->getMessage() );
			return rest_ensure_response( array( 'success' => false, 'error' => $e->getMessage() ), 500 );
		}
	}

	/**
	 * Create operation
	 */
	public static function create_operation( $request ) {
		try {
			$title       = sanitize_text_field( $request->get_param( 'title' ) );
			$description = wp_kses_post( $request->get_param( 'description' ) );
			$company_id  = intval( $request->get_param( 'company_id' ) );
			$op_type     = sanitize_text_field( $request->get_param( 'type' ) );

			if ( ! $title ) {
				return rest_ensure_response( array( 'success' => false, 'error' => 'Missing required field: title' ), 400 );
			}

			$post_id = wp_insert_post(
				array(
					'post_type'    => 'psp_operation',
					'post_title'   => $title,
					'post_content' => $description,
					'post_status'  => 'publish',
				)
			);

			if ( is_wp_error( $post_id ) ) {
				throw new \Exception( 'Failed to create operation' );
			}

			if ( $company_id ) {
				update_post_meta( $post_id, 'company_id', $company_id );
			}
			if ( $op_type ) {
				update_post_meta( $post_id, 'operation_type', $op_type );
			}
			update_post_meta( $post_id, 'staff_member', get_current_user_id() );

			return rest_ensure_response(
				array( 'success' => true, 'message' => 'Operation created', 'operation_id' => $post_id ),
				201
			);
		} catch ( \Exception $e ) {
			error_log( '[PSP REST] create_operation failed: ' . $e->getMessage() );
			return rest_ensure_response( array( 'success' => false, 'error' => $e->getMessage() ), 500 );
		}
	}

	/**
	 * Update operation
	 */
	public static function update_operation( $request ) {
		try {
			$operation_id = intval( $request['id'] );
			$title        = sanitize_text_field( $request->get_param( 'title' ) );
			$description  = wp_kses_post( $request->get_param( 'description' ) );

			if ( ! $operation_id ) {
				return rest_ensure_response( array( 'success' => false, 'error' => 'Invalid operation ID' ), 400 );
			}

			$update_data = array( 'ID' => $operation_id );
			if ( $title ) {
				$update_data['post_title'] = $title;
			}
			if ( $description ) {
				$update_data['post_content'] = $description;
			}

			wp_update_post( $update_data );

			return rest_ensure_response( array( 'success' => true, 'message' => 'Operation updated' ) );
		} catch ( \Exception $e ) {
			error_log( '[PSP REST] update_operation failed: ' . $e->getMessage() );
			return rest_ensure_response( array( 'success' => false, 'error' => $e->getMessage() ), 500 );
		}
	}

	/**
	 * Delete operation
	 */
	public static function delete_operation( $request ) {
		try {
			$operation_id = intval( $request['id'] );

			if ( ! $operation_id ) {
				return rest_ensure_response( array( 'success' => false, 'error' => 'Invalid operation ID' ), 400 );
			}

			wp_delete_post( $operation_id, true );

			return rest_ensure_response( array( 'success' => true, 'message' => 'Operation deleted' ) );
		} catch ( \Exception $e ) {
			error_log( '[PSP REST] delete_operation failed: ' . $e->getMessage() );
			return rest_ensure_response( array( 'success' => false, 'error' => $e->getMessage() ), 500 );
		}
	}

	// ==========================================
	// COMPANIES ENDPOINTS
	// ==========================================

	/**
	 * Get all companies
	 */
	public static function get_companies( $request ) {
		try {
			$page     = intval( $request->get_param( 'page' ) ?: 1 );
			$per_page = intval( $request->get_param( 'per_page' ) ?: 25 );
			$offset   = ( $page - 1 ) * $per_page;

			$args = array(
				'post_type'      => 'psp_company',
				'posts_per_page' => $per_page,
				'offset'         => $offset,
				'orderby'        => 'title',
				'order'          => 'ASC',
			);

		$query   = new \WP_Query( $args );
		$results = array();

		// Bulk fetch all meta to avoid N+1 queries
		$post_ids = wp_list_pluck( $query->posts, 'ID' );
		$meta_keys = array( '_company_details' );
		$meta_cache = self::bulk_get_post_meta( $post_ids, $meta_keys );

		foreach ( $query->posts as $post ) {
			$post_meta = $meta_cache[ $post->ID ] ?? array();
			$results[] = array(
				'id'      => $post->ID,
				'name'    => $post->post_title,
				'details' => $post_meta['_company_details'] ?? '',
			);
		}			return rest_ensure_response(
				array(
					'success' => true,
					'data'    => $results,
					'page'    => $page,
					'total'   => intval( $query->found_posts ),
				)
			);
		} catch ( \Exception $e ) {
			error_log( '[PSP REST] get_companies failed: ' . $e->getMessage() );
			return rest_ensure_response( array( 'success' => false, 'error' => $e->getMessage() ), 500 );
		}
	}

	/**
	 * Get single company
	 */
	public static function get_company( $request ) {
		try {
			$company_id = intval( $request['id'] );

			if ( ! $company_id ) {
				return rest_ensure_response( array( 'success' => false, 'error' => 'Invalid company ID' ), 400 );
			}

			$post = get_post( $company_id );

			if ( ! $post || 'psp_company' !== $post->post_type ) {
				return rest_ensure_response( array( 'success' => false, 'error' => 'Company not found' ), 404 );
			}

			return rest_ensure_response(
				array(
					'success' => true,
					'data'    => array(
						'id'       => $post->ID,
						'name'     => $post->post_title,
						'details'  => get_post_meta( $post->ID, '_company_details', true ),
						'contact'  => get_post_meta( $post->ID, '_company_contact', true ),
						'address'  => get_post_meta( $post->ID, '_company_address', true ),
					),
				)
			);
		} catch ( \Exception $e ) {
			error_log( '[PSP REST] get_company failed: ' . $e->getMessage() );
			return rest_ensure_response( array( 'success' => false, 'error' => $e->getMessage() ), 500 );
		}
	}

	/**
	 * Update company
	 */
	public static function update_company( $request ) {
		try {
			$company_id = intval( $request['id'] );
			$name       = sanitize_text_field( $request->get_param( 'name' ) );

			if ( ! $company_id ) {
				return rest_ensure_response( array( 'success' => false, 'error' => 'Invalid company ID' ), 400 );
			}

			if ( $name ) {
				wp_update_post(
					array(
						'ID'         => $company_id,
						'post_title' => $name,
					)
				);
			}

			return rest_ensure_response( array( 'success' => true, 'message' => 'Company updated' ) );
		} catch ( \Exception $e ) {
			error_log( '[PSP REST] update_company failed: ' . $e->getMessage() );
			return rest_ensure_response( array( 'success' => false, 'error' => $e->getMessage() ), 500 );
		}
	}

	/**
	 * Get company's tickets
	 */
	public static function get_company_tickets( $request ) {
		try {
			$company_id = intval( $request['id'] );

			if ( ! $company_id ) {
				return rest_ensure_response( array( 'success' => false, 'error' => 'Invalid company ID' ), 400 );
			}

			$args = array(
				'post_type'  => 'psp_ticket',
				'meta_query' => array(
					array(
						'key'   => 'company_id',
						'value' => $company_id,
						'compare' => '=',
					),
				),
			);

			$query   = new \WP_Query( $args );
			$results = array();

			// Bulk fetch all meta to avoid N+1 queries
			$post_ids = wp_list_pluck( $query->posts, 'ID' );
			$meta_keys = array( 'ticket_status' );
			$meta_cache = self::bulk_get_post_meta( $post_ids, $meta_keys );

			foreach ( $query->posts as $post ) {
				$post_meta = $meta_cache[ $post->ID ] ?? array();
				$results[] = array(
					'id'          => $post->ID,
					'title'       => $post->post_title,
					'status'      => $post_meta['ticket_status'] ?? '',
					'created'     => $post->post_date,
				);
			}

			return rest_ensure_response( array( 'success' => true, 'data' => $results ) );
		} catch ( \Exception $e ) {
			error_log( '[PSP REST] get_company_tickets failed: ' . $e->getMessage() );
			return rest_ensure_response( array( 'success' => false, 'error' => $e->getMessage() ), 500 );
		}
	}

	/**
	 * Get company's operations
	 */
	public static function get_company_operations( $request ) {
		try {
			$company_id = intval( $request['id'] );

			if ( ! $company_id ) {
				return rest_ensure_response( array( 'success' => false, 'error' => 'Invalid company ID' ), 400 );
			}

			$args = array(
				'post_type'  => 'psp_operation',
				'meta_query' => array(
					array(
						'key'   => 'company_id',
						'value' => $company_id,
						'compare' => '=',
					),
				),
			);

			$query   = new \WP_Query( $args );
			$results = array();

			// Bulk fetch all meta to avoid N+1 queries
			$post_ids = wp_list_pluck( $query->posts, 'ID' );
			$meta_keys = array( 'staff_member' );
			$meta_cache = self::bulk_get_post_meta( $post_ids, $meta_keys );

			foreach ( $query->posts as $post ) {
				$post_meta = $meta_cache[ $post->ID ] ?? array();
				$results[] = array(
					'id'           => $post->ID,
					'title'        => $post->post_title,
					'date'         => $post->post_date,
					'staff_member' => $post_meta['staff_member'] ?? '',
				);
			}

			return rest_ensure_response( array( 'success' => true, 'data' => $results ) );
		} catch ( \Exception $e ) {
			error_log( '[PSP REST] get_company_operations failed: ' . $e->getMessage() );
			return rest_ensure_response( array( 'success' => false, 'error' => $e->getMessage() ), 500 );
		}
	}

	/**
	 * Get company's contacts
	 */
	public static function get_company_contacts( $request ) {
		try {
			$company_id = intval( $request['id'] );

			if ( ! $company_id ) {
				return rest_ensure_response( array( 'success' => false, 'error' => 'Invalid company ID' ), 400 );
			}

			$args = array(
				'post_type'  => 'psp_contact',
				'meta_query' => array(
					array(
						'key'   => 'company_id',
						'value' => $company_id,
						'compare' => '=',
					),
				),
			);

			$query   = new \WP_Query( $args );
			$results = array();

			// Bulk fetch all meta to avoid N+1 queries
			$post_ids = wp_list_pluck( $query->posts, 'ID' );
			$meta_keys = array( 'email', 'phone' );
			$meta_cache = self::bulk_get_post_meta( $post_ids, $meta_keys );

			foreach ( $query->posts as $post ) {
				$post_meta = $meta_cache[ $post->ID ] ?? array();
				$results[] = array(
					'id'    => $post->ID,
					'name'  => $post->post_title,
					'email' => $post_meta['email'] ?? '',
					'phone' => $post_meta['phone'] ?? '',
				);
			}

			return rest_ensure_response( array( 'success' => true, 'data' => $results ) );
		} catch ( \Exception $e ) {
			error_log( '[PSP REST] get_company_contacts failed: ' . $e->getMessage() );
			return rest_ensure_response( array( 'success' => false, 'error' => $e->getMessage() ), 500 );
		}
	}

	/**
	 * Get company summary with stats
	 */
	public static function get_company_summary( $request ) {
		try {
			$company_id = intval( $request['id'] );

			if ( ! $company_id ) {
				return rest_ensure_response( array( 'success' => false, 'error' => 'Invalid company ID' ), 400 );
			}

			// Use aggressive caching for summaries (24 hours)
			$cache_key = 'psp_company_summary_' . $company_id;
			$cached = get_transient( $cache_key );
			if ( false !== $cached ) {
				return rest_ensure_response( array( 'success' => true, 'data' => $cached ) );
			}

			// Count tickets (with individual cache)
			$ticket_cache = 'psp_company_tickets_count_' . $company_id;
			$ticket_count = get_transient( $ticket_cache );
			if ( false === $ticket_count ) {
				$tickets = new \WP_Query( array(
					'post_type'  => 'psp_ticket',
					'meta_query' => array( array( 'key' => 'company_id', 'value' => $company_id ) ),
					'posts_per_page' => 1, // Only need count
				) );
				$ticket_count = intval( $tickets->found_posts );
				set_transient( $ticket_cache, $ticket_count, 86400 ); // Cache for 24 hours
			}

			// Count operations (with individual cache)
			$operations_cache = 'psp_company_operations_count_' . $company_id;
			$operation_count = get_transient( $operations_cache );
			if ( false === $operation_count ) {
				$operations = new \WP_Query( array(
					'post_type'  => 'psp_operation',
					'meta_query' => array( array( 'key' => 'company_id', 'value' => $company_id ) ),
					'posts_per_page' => 1,
				) );
				$operation_count = intval( $operations->found_posts );
				set_transient( $operations_cache, $operation_count, 86400 );
			}

			// Count contacts (with individual cache)
			$contacts_cache = 'psp_company_contacts_count_' . $company_id;
			$contact_count = get_transient( $contacts_cache );
			if ( false === $contact_count ) {
				$contacts = new \WP_Query( array(
					'post_type'  => 'psp_contact',
					'meta_query' => array( array( 'key' => 'company_id', 'value' => $company_id ) ),
					'posts_per_page' => 1,
				) );
				$contact_count = intval( $contacts->found_posts );
				set_transient( $contacts_cache, $contact_count, 86400 );
			}

			$summary = array(
				'company_id'       => $company_id,
				'ticket_count'     => $ticket_count,
				'operation_count'  => $operation_count,
				'contact_count'    => $contact_count,
			);

			// Cache the complete summary for 24 hours
			set_transient( $cache_key, $summary, 86400 );

			return rest_ensure_response(
				array(
					'success' => true,
					'data'    => $summary,
				)
			);
		} catch ( \Exception $e ) {
			error_log( '[PSP REST] get_company_summary failed: ' . $e->getMessage() );
			return rest_ensure_response( array( 'success' => false, 'error' => $e->getMessage() ), 500 );
		}
	}

	// ==========================================
	// TICKETS ENDPOINTS
	// ==========================================

	/**
	 * Get all tickets (role-filtered)
	 */
	public static function get_tickets( $request ) {
		try {
			$page     = intval( $request->get_param( 'page' ) ?: 1 );
			$per_page = intval( $request->get_param( 'per_page' ) ?: 25 );
			$offset   = ( $page - 1 ) * $per_page;

			$args = array(
				'post_type'      => 'psp_ticket',
				'posts_per_page' => $per_page,
				'offset'         => $offset,
				'orderby'        => 'date',
				'order'          => 'DESC',
			);

			$query   = new \WP_Query( $args );
			$results = array();

			// Bulk fetch all meta to avoid N+1 queries
			$post_ids = wp_list_pluck( $query->posts, 'ID' );
			$meta_keys = array( 'ticket_status', 'company_id' );
			$meta_cache = self::bulk_get_post_meta( $post_ids, $meta_keys );

			foreach ( $query->posts as $post ) {
				$post_meta = $meta_cache[ $post->ID ] ?? array();
				$results[] = array(
					'id'           => $post->ID,
					'title'        => $post->post_title,
					'status'       => $post_meta['ticket_status'] ?? '',
					'created'      => $post->post_date,
					'company_id'   => $post_meta['company_id'] ?? '',
				);
			}

			return rest_ensure_response(
				array(
					'success' => true,
					'data'    => $results,
					'page'    => $page,
					'total'   => intval( $query->found_posts ),
				)
			);
		} catch ( \Exception $e ) {
			error_log( '[PSP REST] get_tickets failed: ' . $e->getMessage() );
			return rest_ensure_response( array( 'success' => false, 'error' => $e->getMessage() ), 500 );
		}
	}

	/**
	 * Get single ticket
	 */
	public static function get_ticket( $request ) {
		try {
			$ticket_id = intval( $request['id'] );

			if ( ! $ticket_id ) {
				return rest_ensure_response( array( 'success' => false, 'error' => 'Invalid ticket ID' ), 400 );
			}

			$post = get_post( $ticket_id );

			if ( ! $post || 'psp_ticket' !== $post->post_type ) {
				return rest_ensure_response( array( 'success' => false, 'error' => 'Ticket not found' ), 404 );
			}

			return rest_ensure_response(
				array(
					'success' => true,
					'data'    => array(
						'id'          => $post->ID,
						'title'       => $post->post_title,
						'description' => $post->post_content,
						'status'      => get_post_meta( $post->ID, 'ticket_status', true ),
						'created'     => $post->post_date,
						'company_id'  => get_post_meta( $post->ID, 'company_id', true ),
						'priority'    => get_post_meta( $post->ID, 'priority', true ),
					),
				)
			);
		} catch ( \Exception $e ) {
			error_log( '[PSP REST] get_ticket failed: ' . $e->getMessage() );
			return rest_ensure_response( array( 'success' => false, 'error' => $e->getMessage() ), 500 );
		}
	}

	/**
	 * Create ticket with auto company-linking
	 */
	public static function create_ticket( $request ) {
		try {
			$title       = sanitize_text_field( $request->get_param( 'title' ) );
			$description = wp_kses_post( $request->get_param( 'description' ) );
			$company_id  = intval( $request->get_param( 'company_id' ) );
			$priority    = sanitize_text_field( $request->get_param( 'priority' ) ?: 'normal' );

			if ( ! $title ) {
				return rest_ensure_response( array( 'success' => false, 'error' => 'Missing required field: title' ), 400 );
			}

			$post_id = wp_insert_post(
				array(
					'post_type'    => 'psp_ticket',
					'post_title'   => $title,
					'post_content' => $description,
					'post_status'  => 'publish',
				)
			);

			if ( is_wp_error( $post_id ) ) {
				throw new \Exception( 'Failed to create ticket' );
			}

			update_post_meta( $post_id, 'ticket_status', 'open' );
			if ( $company_id ) {
				update_post_meta( $post_id, 'company_id', $company_id );
			}
			update_post_meta( $post_id, 'priority', $priority );
			update_post_meta( $post_id, 'created_by', get_current_user_id() );

			return rest_ensure_response(
				array( 'success' => true, 'message' => 'Ticket created', 'ticket_id' => $post_id ),
				201
			);
		} catch ( \Exception $e ) {
			error_log( '[PSP REST] create_ticket failed: ' . $e->getMessage() );
			return rest_ensure_response( array( 'success' => false, 'error' => $e->getMessage() ), 500 );
		}
	}

	/**
	 * Update ticket
	 */
	public static function update_ticket( $request ) {
		try {
			$ticket_id = intval( $request['id'] );
			$title     = sanitize_text_field( $request->get_param( 'title' ) );
			$status    = sanitize_text_field( $request->get_param( 'status' ) );

			if ( ! $ticket_id ) {
				return rest_ensure_response( array( 'success' => false, 'error' => 'Invalid ticket ID' ), 400 );
			}

			if ( $title ) {
				wp_update_post( array( 'ID' => $ticket_id, 'post_title' => $title ) );
			}
			if ( $status ) {
				update_post_meta( $ticket_id, 'ticket_status', $status );
			}

			return rest_ensure_response( array( 'success' => true, 'message' => 'Ticket updated' ) );
		} catch ( \Exception $e ) {
			error_log( '[PSP REST] update_ticket failed: ' . $e->getMessage() );
			return rest_ensure_response( array( 'success' => false, 'error' => $e->getMessage() ), 500 );
		}
	}

	/**
	 * Delete ticket
	 */
	public static function delete_ticket( $request ) {
		try {
			$ticket_id = intval( $request['id'] );

			if ( ! $ticket_id ) {
				return rest_ensure_response( array( 'success' => false, 'error' => 'Invalid ticket ID' ), 400 );
			}

			wp_delete_post( $ticket_id, true );

			return rest_ensure_response( array( 'success' => true, 'message' => 'Ticket deleted' ) );
		} catch ( \Exception $e ) {
			error_log( '[PSP REST] delete_ticket failed: ' . $e->getMessage() );
			return rest_ensure_response( array( 'success' => false, 'error' => $e->getMessage() ), 500 );
		}
	}

	/**
	 * Create ticket reply
	 */
	public static function create_ticket_reply( $request ) {
		try {
			$ticket_id = intval( $request['id'] );
			$content   = wp_kses_post( $request->get_param( 'content' ) );

			if ( ! $ticket_id || ! $content ) {
				return rest_ensure_response( array( 'success' => false, 'error' => 'Missing required fields' ), 400 );
			}

			$comment_id = wp_insert_comment( array(
				'comment_post_ID' => $ticket_id,
				'comment_author'  => get_user_by( 'ID', get_current_user_id() )->user_login,
				'comment_content' => $content,
				'user_id'         => get_current_user_id(),
				'comment_type'    => 'psp_reply',
			) );

			if ( ! $comment_id ) {
				throw new \Exception( 'Failed to create reply' );
			}

			return rest_ensure_response(
				array( 'success' => true, 'message' => 'Reply created', 'reply_id' => $comment_id ),
				201
			);
		} catch ( \Exception $e ) {
			error_log( '[PSP REST] create_ticket_reply failed: ' . $e->getMessage() );
			return rest_ensure_response( array( 'success' => false, 'error' => $e->getMessage() ), 500 );
		}
	}

	/**
	 * Get ticket replies
	 */
	public static function get_ticket_replies( $request ) {
		try {
			$ticket_id = intval( $request['id'] );

			if ( ! $ticket_id ) {
				return rest_ensure_response( array( 'success' => false, 'error' => 'Invalid ticket ID' ), 400 );
			}

			$comments = get_comments( array(
				'post_id' => $ticket_id,
				'type'    => 'psp_reply',
			) );

			$results = array();
			foreach ( $comments as $comment ) {
				$results[] = array(
					'id'      => $comment->comment_ID,
					'author'  => $comment->comment_author,
					'content' => $comment->comment_content,
					'date'    => $comment->comment_date,
				);
			}

			return rest_ensure_response( array( 'success' => true, 'data' => $results ) );
		} catch ( \Exception $e ) {
			error_log( '[PSP REST] get_ticket_replies failed: ' . $e->getMessage() );
			return rest_ensure_response( array( 'success' => false, 'error' => $e->getMessage() ), 500 );
		}
	}

	// ==========================================
	// EMAIL INTEGRATION
	// ==========================================

	/**
	 * Email webhook processing
	 */
	public static function email_webhook( $request ) {
		try {
			// Verify webhook key
			if ( ! self::verify_email_webhook_key() ) {
				return rest_ensure_response( array( 'success' => false, 'error' => 'Invalid API key' ), 401 );
			}

			$to        = sanitize_email( $request->get_param( 'to' ) );
			$from      = sanitize_email( $request->get_param( 'from' ) );
			$subject   = sanitize_text_field( $request->get_param( 'subject' ) );
			$body      = wp_kses_post( $request->get_param( 'body' ) );
			$ticket_id = intval( $request->get_param( 'ticket_id' ) );

			if ( ! $to || ! $subject ) {
				return rest_ensure_response( array( 'success' => false, 'error' => 'Missing required fields: to, subject' ), 400 );
			}

			if ( $ticket_id ) {
				// Add as reply to existing ticket
				$comment_id = wp_insert_comment( array(
					'comment_post_ID' => $ticket_id,
					'comment_author'  => $from ?: 'Email',
					'comment_content' => $body,
					'comment_type'    => 'email_reply',
				) );

				if ( ! $comment_id ) {
					throw new \Exception( 'Failed to add email reply' );
				}
			} else {
				// Create new ticket from email
				$post_id = wp_insert_post( array(
					'post_type'    => 'psp_ticket',
					'post_title'   => $subject,
					'post_content' => $body,
					'post_status'  => 'publish',
				) );

				if ( is_wp_error( $post_id ) ) {
					throw new \Exception( 'Failed to create ticket from email' );
				}

				update_post_meta( $post_id, 'ticket_status', 'open' );
				update_post_meta( $post_id, 'email_from', $from );
				update_post_meta( $post_id, 'email_to', $to );
			}

			// Log webhook reception
			update_option( 'psp_email_webhook_last_received', current_time( 'mysql' ) );

			return rest_ensure_response( array( 'success' => true, 'message' => 'Email processed' ) );
		} catch ( \Exception $e ) {
			error_log( '[PSP REST] email_webhook failed: ' . $e->getMessage() );

			// Increment error count
			$error_count = intval( get_option( 'psp_email_webhook_errors', 0 ) );
			update_option( 'psp_email_webhook_errors', $error_count + 1 );

			return rest_ensure_response( array( 'success' => false, 'error' => $e->getMessage() ), 500 );
		}
	}

	/**
	 * Email webhook status check
	 */
	public static function email_webhook_status( $request ) {
		try {
			return rest_ensure_response(
				array(
					'success'       => true,
					'enabled'       => (bool) get_option( 'psp_email_webhook_enabled' ),
					'last_received' => get_option( 'psp_email_webhook_last_received' ),
					'error_count'   => intval( get_option( 'psp_email_webhook_errors', 0 ) ),
				)
			);
		} catch ( \Exception $e ) {
			error_log( '[PSP REST] email_webhook_status failed: ' . $e->getMessage() );
			return rest_ensure_response( array( 'success' => false, 'error' => $e->getMessage() ), 500 );
		}
	}

	// ==========================================
	// HELPER METHODS
	// ==========================================

	/**
	 * Clear all video list caches
	 */
	private static function clear_video_list_caches() {
		// Clear pagination caches for all pages
		for ( $page = 1; $page <= 100; $page++ ) {
			for ( $per_page = 10; $per_page <= 100; $per_page += 10 ) {
				$cache_key = 'psp_videos_page_' . $page . '_per_' . $per_page . '_search_' . md5( '' ) . '_user_*';
				// WordPress transients don't support wildcards, so we clear known patterns
			}
		}
		// Clear the main count cache
		delete_transient( 'psp_videos_count_search_' . md5( '' ) . '_user_' . get_current_user_id() );
	}

	/**
	 * Clear company summary caches
	 */
	private static function clear_company_caches( $company_id ) {
		delete_transient( 'psp_company_summary_' . $company_id );
		delete_transient( 'psp_company_tickets_count_' . $company_id );
		delete_transient( 'psp_company_operations_count_' . $company_id );
		delete_transient( 'psp_company_contacts_count_' . $company_id );
	}

	/**
	 * Verify email webhook signature/key
	 */
	private static function verify_email_webhook_key() {
		// Get API key from request header
		$api_key = isset( $_SERVER['HTTP_X_POOLSAFE_API_KEY'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_POOLSAFE_API_KEY'] ) ) : '';

		if ( ! $api_key ) {
			return false;
		}

		// Compare with stored key
		$stored_key = get_option( 'psp_email_webhook_key' );
		return hash_equals( $stored_key, $api_key );
	}
}

// Initialize REST API on WordPress hooks
REST_V3::init();
