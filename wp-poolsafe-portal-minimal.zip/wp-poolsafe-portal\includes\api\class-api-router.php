<?php
/**
 * Unified API Router
 *
 * Single entry point for all REST API endpoints.
 * Consolidates psp/v1, poolsafe/v1, and custom endpoints into one namespace.
 *
 * @package PoolSafe_Portal
 * @since 3.0.0
 */

namespace PSP;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class API_Router {

	/**
	 * API namespace (all endpoints under this)
	 */
	const NAMESPACE = 'psp/v1';

	/**
	 * Initialize router
	 */
	public static function init(): void {
		add_action( 'rest_api_init', [ __CLASS__, 'register_routes' ] );
	}

	/**
	 * Register all REST routes
	 */
	public static function register_routes(): void {
		// ===== HEALTH CHECK =====
		register_rest_route(
			self::NAMESPACE,
			'/health',
			[
				'methods'             => 'GET',
				'callback'            => [ __CLASS__, 'health_check' ],
				'permission_callback' => '__return_true',
			]
		);

		// ===== AUTHENTICATION =====
		register_rest_route(
			self::NAMESPACE,
			'/auth/login',
			[
				'methods'             => 'POST',
				'callback'            => [ __CLASS__, 'login' ],
				'permission_callback' => '__return_true',
				'args'                => [
					'username' => [
						'type'     => 'string',
						'required' => true,
					],
					'password' => [
						'type'     => 'string',
						'required' => true,
					],
				],
			]
		);

		register_rest_route(
			self::NAMESPACE,
			'/auth/logout',
			[
				'methods'             => 'POST',
				'callback'            => [ __CLASS__, 'logout' ],
				'permission_callback' => [ __CLASS__, 'check_auth' ],
			]
		);

		// ===== COMPANIES / PARTNERS =====
		register_rest_route(
			self::NAMESPACE,
			'/companies',
			[
				'methods'             => 'GET',
				'callback'            => [ __CLASS__, 'get_companies' ],
				'permission_callback' => [ __CLASS__, 'check_auth' ],
				'args'                => [
					'page'       => [ 'type' => 'integer', 'default' => 1 ],
					'per_page'   => [ 'type' => 'integer', 'default' => 25 ],
					'search'     => [ 'type' => 'string' ],
					'status'     => [ 'type' => 'string' ],
					'sort'       => [ 'type' => 'string', 'default' => 'name' ],
					'order'      => [ 'type' => 'string', 'enum' => [ 'asc', 'desc' ], 'default' => 'asc' ],
				],
			]
		);

		register_rest_route(
			self::NAMESPACE,
			'/companies/(?P<id>\d+)',
			[
				'methods'             => [ 'GET', 'PUT' ],
				'callback'            => [ __CLASS__, 'company_detail' ],
				'permission_callback' => [ __CLASS__, 'check_auth' ],
				'args'                => [
					'id' => [
						'type'     => 'integer',
						'required' => true,
					],
				],
			]
		);

		// ===== TICKETS =====
		register_rest_route(
			self::NAMESPACE,
			'/tickets',
			[
				'methods'             => [ 'GET', 'POST' ],
				'callback'            => [ __CLASS__, 'tickets' ],
				'permission_callback' => [ __CLASS__, 'check_auth' ],
				'args'                => [
					'company_id' => [ 'type' => 'integer' ],
					'status'     => [ 'type' => 'string' ],
					'priority'   => [ 'type' => 'string' ],
					'page'       => [ 'type' => 'integer', 'default' => 1 ],
					'per_page'   => [ 'type' => 'integer', 'default' => 25 ],
				],
			]
		);

		register_rest_route(
			self::NAMESPACE,
			'/tickets/(?P<id>\d+)',
			[
				'methods'             => [ 'GET', 'PUT' ],
				'callback'            => [ __CLASS__, 'ticket_detail' ],
				'permission_callback' => [ __CLASS__, 'check_auth' ],
				'args'                => [
					'id' => [ 'type' => 'integer', 'required' => true ],
				],
			]
		);

		// ===== OPERATIONS / SERVICE VISITS =====
		register_rest_route(
			self::NAMESPACE,
			'/operations',
			[
				'methods'             => [ 'GET', 'POST' ],
				'callback'            => [ __CLASS__, 'operations' ],
				'permission_callback' => [ __CLASS__, 'check_auth' ],
				'args'                => [
					'company_id'  => [ 'type' => 'integer' ],
					'visit_type'  => [ 'type' => 'string' ],
					'from_date'   => [ 'type' => 'string' ],
					'to_date'     => [ 'type' => 'string' ],
					'page'        => [ 'type' => 'integer', 'default' => 1 ],
					'per_page'    => [ 'type' => 'integer', 'default' => 25 ],
				],
			]
		);

		// ===== DASHBOARD STATS =====
		register_rest_route(
			self::NAMESPACE,
			'/stats',
			[
				'methods'             => 'GET',
				'callback'            => [ __CLASS__, 'get_stats' ],
				'permission_callback' => [ __CLASS__, 'check_auth' ],
			]
		);

		// ===== ACTIVITY LOG =====
		register_rest_route(
			self::NAMESPACE,
			'/activity',
			[
				'methods'             => 'GET',
				'callback'            => [ __CLASS__, 'get_activity' ],
				'permission_callback' => [ __CLASS__, 'check_auth' ],
				'args'                => [
					'action'  => [ 'type' => 'string' ],
					'user_id' => [ 'type' => 'integer' ],
					'page'    => [ 'type' => 'integer', 'default' => 1 ],
				],
			]
		);
	}

	/**
	 * Health check endpoint
	 */
	public static function health_check( $request ) {
		return rest_ensure_response( [
			'status'   => 'ok',
			'version'  => '3.2.5',
			'timestamp' => current_time( 'mysql' ),
		] );
	}

	/**
	 * Authentication check
	 */
	public static function check_auth( $request = null ): bool {
		if ( is_user_logged_in() ) {
			return true;
		}

		// Fallback: check cookie
		if ( ! empty( $_COOKIE['psp_user_id'] ) ) {
			wp_set_current_user( (int) $_COOKIE['psp_user_id'] );
			return is_user_logged_in();
		}

		return false;
	}

	/**
	 * Get current user role
	 */
	public static function get_user_role(): ?string {
		if ( ! is_user_logged_in() ) {
			return null;
		}

		$user = wp_get_current_user();
		$roles = [
			'pool_safe_partner',
			'pool_safe_support',
			'administrator',
		];

		foreach ( $roles as $role ) {
			if ( in_array( $role, $user->roles ) ) {
				return $role;
			}
		}

		return null;
	}

	/**
	 * Login endpoint
	 */
	public static function login( $request ) {
		$params = $request->get_json_params();
		$username = sanitize_text_field( $params['username'] ?? '' );
		$password = $params['password'] ?? '';

		if ( ! $username || ! $password ) {
			return new \WP_Error( 'invalid_request', 'Username and password required', [ 'status' => 400 ] );
		}

		$user = wp_authenticate( $username, $password );

		if ( is_wp_error( $user ) ) {
			return new \WP_Error( 'auth_failed', 'Invalid credentials', [ 'status' => 401 ] );
		}

		wp_set_current_user( $user->ID );
		wp_set_auth_cookie( $user->ID );

		return rest_ensure_response( [
			'user_id' => $user->ID,
			'username' => $user->user_login,
			'role'    => self::get_user_role(),
		] );
	}

	/**
	 * Logout endpoint
	 */
	public static function logout( $request ) {
		wp_logout();
		return rest_ensure_response( [ 'message' => 'Logged out successfully' ] );
	}

	/**
	 * Get companies list
	 */
	public static function get_companies( $request ) {
		$user_role = self::get_user_role();

		if ( ! $user_role ) {
			return new \WP_Error( 'unauthorized', 'Not authenticated', [ 'status' => 401 ] );
		}

		$page = (int) $request->get_param( 'page' ) ?: 1;
		$per_page = (int) $request->get_param( 'per_page' ) ?: 25;
		$search = sanitize_text_field( $request->get_param( 'search' ) );
		$status = sanitize_text_field( $request->get_param( 'status' ) );

		$args = [
			'post_type'      => 'psp_partner',
			'paged'          => $page,
			'posts_per_page' => $per_page,
			'post_status'    => 'publish',
		];

		if ( $search ) {
			$args['s'] = $search;
		}

		if ( $status ) {
			$args['meta_key'] = 'status';
			$args['meta_value'] = $status;
		}

		// Partners see only their own company
		if ( 'pool_safe_partner' === $user_role ) {
			$user = wp_get_current_user();
			$partner_id = (int) get_user_meta( $user->ID, 'psp_partner_id', true );

			if ( $partner_id ) {
				$args['post__in'] = [ $partner_id ];
			} else {
				return rest_ensure_response( [ 'companies' => [], 'total' => 0 ] );
			}
		}

		$query = new \WP_Query( $args );
		$companies = array_map( function( $post ) {
			$company = new Company( $post->ID );
			return $company->to_array();
		}, $query->posts );

		return rest_ensure_response( [
			'companies' => $companies,
			'total'     => $query->found_posts,
			'pages'     => $query->max_num_pages,
		] );
	}

	/**
	 * Get/update company detail
	 */
	public static function company_detail( $request ) {
		$id = (int) $request['id'];
		$company = new Company( $id );

		if ( ! $company->to_array() ) {
			return new \WP_Error( 'not_found', 'Company not found', [ 'status' => 404 ] );
		}

		if ( 'GET' === $request->get_method() ) {
			return rest_ensure_response( [
				'company'    => $company->to_array(),
				'tickets'    => $company->get_tickets(),
				'operations' => $company->get_operations(),
				'contacts'   => $company->get_contacts(),
				'location'   => $company->get_location(),
			] );
		}

		// PUT request - update company
		$params = $request->get_json_params();

		foreach ( $params as $key => $value ) {
			$company->set( $key, sanitize_text_field( $value ) );
		}

		if ( $company->save() ) {
			return rest_ensure_response( [ 'success' => true, 'company' => $company->to_array() ] );
		}

		return new \WP_Error( 'save_failed', 'Could not save company', [ 'status' => 500 ] );
	}

	/**
	 * Get/create tickets
	 */
	public static function tickets( $request ) {
		if ( 'GET' === $request->get_method() ) {
			$user_role = self::get_user_role();
			$company_id = (int) $request->get_param( 'company_id' );
			$page = (int) $request->get_param( 'page' ) ?: 1;
			$per_page = (int) $request->get_param( 'per_page' ) ?: 25;

			$args = [
				'post_type'      => 'psp_ticket',
				'paged'          => $page,
				'posts_per_page' => $per_page,
				'post_status'    => 'publish',
			];

			if ( $company_id ) {
				$args['meta_key'] = 'partner_id';
				$args['meta_value'] = $company_id;
			}

			// Partners see only their tickets
			if ( 'pool_safe_partner' === $user_role ) {
				$user = wp_get_current_user();
				$partner_id = (int) get_user_meta( $user->ID, 'psp_partner_id', true );

				if ( $partner_id ) {
					$args['meta_key'] = 'partner_id';
					$args['meta_value'] = $partner_id;
				} else {
					return rest_ensure_response( [ 'tickets' => [], 'total' => 0 ] );
				}
			}

			$query = new \WP_Query( $args );
			$tickets = array_map( function( $post ) {
				return [
					'id'       => $post->ID,
					'title'    => $post->post_title,
					'status'   => get_post_meta( $post->ID, 'status', true ) ?: 'open',
					'priority' => get_post_meta( $post->ID, 'priority', true ) ?: 'normal',
					'created'  => $post->post_date,
				];
			}, $query->posts );

			return rest_ensure_response( [
				'tickets' => $tickets,
				'total'   => $query->found_posts,
				'pages'   => $query->max_num_pages,
			] );
		}

		// POST - create ticket
		$params = $request->get_json_params();
		$company_id = (int) $params['company_id'] ?? 0;
		$title = sanitize_text_field( $params['title'] ?? '' );
		$content = sanitize_textarea_field( $params['content'] ?? '' );

		if ( ! $company_id || ! $title ) {
			return new \WP_Error( 'invalid_request', 'Company and title required', [ 'status' => 400 ] );
		}

		$post_id = wp_insert_post( [
			'post_type'    => 'psp_ticket',
			'post_title'   => $title,
			'post_content' => $content,
			'post_status'  => 'publish',
		] );

		if ( is_wp_error( $post_id ) ) {
			return new \WP_Error( 'create_failed', 'Could not create ticket', [ 'status' => 500 ] );
		}

		update_post_meta( $post_id, 'partner_id', $company_id );
		update_post_meta( $post_id, 'status', 'open' );
		update_post_meta( $post_id, 'priority', 'normal' );

		do_action( 'psp_ticket_created', $post_id, $params );

		return rest_ensure_response( [
			'success' => true,
			'ticket_id' => $post_id,
		] );
	}

	/**
	 * Get/update ticket detail
	 */
	public static function ticket_detail( $request ) {
		$id = (int) $request['id'];
		$ticket = get_post( $id );

		if ( ! $ticket || 'psp_ticket' !== $ticket->post_type ) {
			return new \WP_Error( 'not_found', 'Ticket not found', [ 'status' => 404 ] );
		}

		if ( 'GET' === $request->get_method() ) {
			return rest_ensure_response( [
				'id'       => $ticket->ID,
				'title'    => $ticket->post_title,
				'content'  => $ticket->post_content,
				'status'   => get_post_meta( $ticket->ID, 'status', true ) ?: 'open',
				'priority' => get_post_meta( $ticket->ID, 'priority', true ) ?: 'normal',
				'company_id' => (int) get_post_meta( $ticket->ID, 'partner_id', true ),
				'created'  => $ticket->post_date,
				'updated'  => $ticket->post_modified,
			] );
		}

		// PUT - update ticket
		$params = $request->get_json_params();

		foreach ( [ 'status', 'priority' ] as $key ) {
			if ( isset( $params[ $key ] ) ) {
				update_post_meta( $id, $key, sanitize_text_field( $params[ $key ] ) );
			}
		}

		return rest_ensure_response( [ 'success' => true ] );
	}

	/**
	 * Get/create operations
	 */
	public static function operations( $request ) {
		if ( 'GET' === $request->get_method() ) {
			$company_id = (int) $request->get_param( 'company_id' );
			$visit_type = sanitize_text_field( $request->get_param( 'visit_type' ) );
			$page      = max( 1, (int) $request->get_param( 'page' ) );
			$per_page  = max( 1, min( 100, (int) $request->get_param( 'per_page' ) ?: 25 ) );
			$fields    = $request->get_param( '_fields' );

			$meta_query = [];
			if ( $company_id ) {
				$meta_query[] = [
					'key'   => 'company_id',
					'value' => $company_id,
				];
			}
			if ( $visit_type ) {
				$meta_query[] = [
					'key'   => 'visit_type',
					'value' => $visit_type,
				];
			}

			$query = new \WP_Query(
				[
					'post_type'      => 'psp_operation',
					'post_status'    => 'publish',
					'posts_per_page' => $per_page,
					'paged'          => $page,
					'meta_query'     => $meta_query,
					'no_found_rows'  => false,
				]
			);

			$operations = array_map( function( $post ) use ( $fields ) {
				$data = [
					'id'         => $post->ID,
					'company_id' => (int) get_post_meta( $post->ID, 'company_id', true ),
					'visit_type' => get_post_meta( $post->ID, 'visit_type', true ),
					'visit_date' => get_post_meta( $post->ID, 'visit_date', true ),
					'duration'   => (int) get_post_meta( $post->ID, 'duration', true ),
					'created'    => $post->post_date,
				];
				return self::filter_fields( $data, $fields );
			}, $query->posts );

			return rest_ensure_response( [
				'success'   => true,
				'data'      => $operations,
				'total'     => (int) $query->found_posts,
				'page'      => $page,
				'per_page'  => $per_page,
			] );
		}

		// POST - create operation
		$params = $request->get_json_params();
		$company_id = (int) $params['company_id'] ?? 0;
		$visit_type = sanitize_text_field( $params['visit_type'] ?? '' );

		if ( ! $company_id || ! $visit_type ) {
			return new \WP_Error( 'invalid_request', 'Company and visit type required', [ 'status' => 400 ] );
		}

		$post_id = wp_insert_post( [
			'post_type'   => 'psp_operation',
			'post_status' => 'publish',
		] );

		update_post_meta( $post_id, 'company_id', $company_id );
		update_post_meta( $post_id, 'visit_type', $visit_type );
		update_post_meta( $post_id, 'visit_date', sanitize_text_field( $params['visit_date'] ?? '' ) );
		update_post_meta( $post_id, 'duration', (int) ( $params['duration'] ?? 0 ) );

		return rest_ensure_response( [ 'success' => true, 'operation_id' => $post_id ] );
	}

	/**
	 * Get dashboard stats
	 */
	public static function get_stats( $request ) {
		$user_role = self::get_user_role();

		$stats = [
			'total_companies' => 0,
			'total_tickets'   => 0,
			'open_tickets'    => 0,
			'total_operations' => 0,
		];

		// Count companies
		$company_args = [
			'post_type'      => 'psp_partner',
			'posts_per_page' => 1,
			'post_status'    => 'publish',
			'fields'         => 'ids',
		];

		$company_query = new \WP_Query( $company_args );
		$stats['total_companies'] = $company_query->found_posts;

		// Count tickets
		$ticket_args = [
			'post_type'      => 'psp_ticket',
			'posts_per_page' => 1,
			'post_status'    => 'publish',
			'fields'         => 'ids',
		];

		$ticket_query = new \WP_Query( $ticket_args );
		$stats['total_tickets'] = $ticket_query->found_posts;

		// Count open tickets
		$open_args = [
			'post_type'      => 'psp_ticket',
			'posts_per_page' => 1,
			'post_status'    => 'publish',
			'meta_key'       => 'status',
			'meta_value'     => 'open',
			'fields'         => 'ids',
		];

		$open_query = new \WP_Query( $open_args );
		$stats['open_tickets'] = $open_query->found_posts;

		return rest_ensure_response( $stats );
	}

	/**
	 * Limit returned fields when _fields is provided.
	 */
	private static function filter_fields( array $data, $fields ) {
		if ( empty( $fields ) ) {
			return $data;
		}

		if ( is_string( $fields ) ) {
			$fields = array_map( 'trim', explode( ',', $fields ) );
		}

		if ( ! is_array( $fields ) ) {
			return $data;
		}

		return array_intersect_key( $data, array_flip( $fields ) );
	}

	/**
	 * Get activity log
	 */
	public static function get_activity( $request ) {
		return rest_ensure_response( [
			'success'    => true,
			'data'       => [],
			'total'      => 0,
		] );
	}
}

// Initialize router
API_Router::init();
