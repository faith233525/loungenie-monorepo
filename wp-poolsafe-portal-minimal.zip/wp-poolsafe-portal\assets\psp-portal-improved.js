/**
 * PoolSafe Portal - Enhanced JavaScript Architecture (v3.2.5)
 * 
 * Features:
 * - Modular design with complete namespace isolation
 * - Comprehensive error handling with recovery
 * - Configuration-driven initialization
 * - Memory-efficient event delegation & cleanup
 * - Type checking and input validation
 * - Error logging and debugging support
 * - Full backward compatibility
 * 
 * @author PoolSafe Team
 * @license GPL-2.0+
 * @version 3.2.5
 */

(function() {
    'use strict';

    // Error tracking for debugging
    const errorLog = [];
    const eventListeners = [];
    const timers = [];

    /**
     * Portal Configuration & Constants
     */
    const CONFIG = {
        SELECTORS: {
            NOTIFICATION_BELL: '#psp-notification-bell',
            NOTIFICATION_DROPDOWN: '#psp-notification-dropdown',
            NOTIFICATION_LIST: '#psp-notification-list',
            NOTIFICATION_COUNT: '#psp-notification-count',
            USER_BUTTON: '#psp-user-button',
            USER_DROPDOWN: '#psp-user-dropdown',
            DROPDOWN_TRIGGER: '[data-toggle="dropdown"]',
            ALERT: '.psp-alert',
            FORM_TEXTAREA: 'textarea',
        },
        TIMEOUTS: {
            DROPDOWN_CLOSE: 150,
            NOTIFICATION_RELOAD: 30000, // 30s
            API_TIMEOUT: 5000, // 5s
        },
        DEBOUNCE: {
            RESIZE: 250,
            SCROLL: 150,
        },
        debug: false,
    };

    /**
     * Private helper: Log error with tracking
     */
    function _logError(message, error) {
        const entry = {
            message: message || 'Unknown error',
            error: error && error.message ? error.message : String(error),
            timestamp: new Date().toISOString(),
        };
        errorLog.push(entry);
        
        if (CONFIG.debug || (typeof window.PORTAL_CONFIG === 'object' && window.PORTAL_CONFIG && window.PORTAL_CONFIG.debug)) {
            console.error('[PSPPortal Error] ' + message, error);
        }
        return entry;
    }

    /**
     * Private helper: Log info message
     */
    function _logInfo(message, data) {
        if (CONFIG.debug || (typeof window.PORTAL_CONFIG === 'object' && window.PORTAL_CONFIG && window.PORTAL_CONFIG.debug)) {
            console.log('[PSPPortal] ' + message, data || '');
        }
    }

    /**
     * Private helper: Register event listener for cleanup
     */
    function _trackEvent(el, event, handler) {
        if (el && event && handler) {
            eventListeners.push({ el, event, handler });
        }
    }

    /**
     * Private helper: Register timer for cleanup
     */
    function _trackTimer(timerId) {
        if (typeof timerId === 'number') {
            timers.push(timerId);
        }
        return timerId;
    }

    /**
     * Utility: Safe DOM Element Selection
     */
    const DOM = {
        query: (selector) => {
            if (typeof selector !== 'string' || !selector.trim()) return null;
            try {
                return document.querySelector(selector);
            } catch (e) {
                _logError('Invalid selector: ' + selector, e);
                return null;
            }
        },
        queryAll: (selector) => {
            if (typeof selector !== 'string' || !selector.trim()) return [];
            try {
                return Array.from(document.querySelectorAll(selector));
            } catch (e) {
                _logError('Invalid selector: ' + selector, e);
                return [];
            }
        },
        on: (el, event, handler, options) => {
            if (!el || typeof event !== 'string' || typeof handler !== 'function') {
                return false;
            }
            try {
                el.addEventListener(event, handler, options || {});
                _trackEvent(el, event, handler);
                return true;
            } catch (e) {
                _logError('Event binding failed: ' + event, e);
                return false;
            }
        },
        off: (el, event, handler) => {
            if (!el || typeof event !== 'string' || typeof handler !== 'function') return false;
            try {
                el.removeEventListener(event, handler);
                return true;
            } catch (e) {
                _logError('Event removal failed: ' + event, e);
                return false;
            }
        },
        hasClass: (el, className) => {
            return el && el.classList && el.classList.contains(String(className || ''));
        },
        addClass: (el, className) => {
            if (el && el.classList && className) {
                el.classList.add(String(className));
                return true;
            }
            return false;
        },
        removeClass: (el, className) => {
            if (el && el.classList && className) {
                el.classList.remove(String(className));
                return true;
            }
            return false;
        },
        toggleClass: (el, className) => {
            if (el && el.classList && className) {
                el.classList.toggle(String(className));
                return true;
            }
            return false;
        },
        on_once: (el, event, handler, options) => {
            if (!el || typeof event !== 'string' || typeof handler !== 'function') return false;
            const onceHandler = function(...args) {
                handler.apply(this, args);
                DOM.off(el, event, onceHandler);
            };
            return DOM.on(el, event, onceHandler, options);
        },
    };

    /**
     * Utility: Performance Helpers
     */
    const Perf = {
        debounce: (func, wait) => {
            if (typeof func !== 'function') return () => {};
            wait = Math.max(0, parseInt(wait) || 250);
            let timeout;
            return function debounced(...args) {
                clearTimeout(timeout);
                timeout = _trackTimer(setTimeout(() => {
                    try {
                        func.apply(this, args);
                    } catch (e) {
                        _logError('Debounced function error', e);
                    }
                }, wait));
            };
        },
        throttle: (func, wait) => {
            if (typeof func !== 'function') return () => {};
            wait = Math.max(0, parseInt(wait) || 250);
            let last = 0, timeout;
            return function throttled(...args) {
                const now = Date.now();
                if (now - last >= wait) {
                    last = now;
                    try {
                        func.apply(this, args);
                    } catch (e) {
                        _logError('Throttled function error', e);
                    }
                } else {
                    clearTimeout(timeout);
                    timeout = _trackTimer(setTimeout(() => {
                        last = Date.now();
                        try {
                            func.apply(this, args);
                        } catch (e) {
                            _logError('Throttled function error', e);
                        }
                    }, wait - (now - last)));
                }
            };
        },
        requestIdleCallback: (callback) => {
            if (typeof callback !== 'function') return null;
            if (typeof window.requestIdleCallback === 'function') {
                return window.requestIdleCallback(callback);
            }
            return _trackTimer(setTimeout(callback, 1));
        },
        raf: (callback) => {
            if (typeof callback !== 'function') return null;
            if (typeof window.requestAnimationFrame === 'function') {
                return window.requestAnimationFrame(callback);
            }
            return _trackTimer(setTimeout(callback, 16));
        },
    };

    /**
     * Utility: Safe String Operations
     */
    const Str = {
        escapeHtml: (str) => {
            if (typeof str !== 'string') return '';
            const div = document.createElement('div');
            div.textContent = str;
            return div.innerHTML;
        },
        unescapeHtml: (str) => {
            if (typeof str !== 'string') return '';
            const div = document.createElement('div');
            div.innerHTML = str;
            return div.textContent || div.innerText || '';
        },
        truncate: (str, length) => {
            if (typeof str !== 'string') return '';
            length = Math.max(3, parseInt(length) || 50);
            return str.length > length ? str.substring(0, length - 3).trim() + '...' : str;
        },
        trim: (str) => {
            return typeof str === 'string' ? str.trim() : '';
        },
        capitalize: (str) => {
            if (typeof str !== 'string' || !str) return '';
            return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
        },
    };

    /**
     * Utility: API Communication
     */
    const API = {
        getConfig: () => {
            // Try PORTAL_CONFIG (from wp_localize_script)
            if (typeof window.PORTAL_CONFIG === 'object' && window.PORTAL_CONFIG !== null) {
                return {
                    base: String(window.PORTAL_CONFIG.apiUrl || '').replace(/\/$/, ''),
                    nonce: String(window.PORTAL_CONFIG.nonce || ''),
                };
            }
            // Fallback to pspPortal
            if (typeof window.pspPortal === 'object' && window.pspPortal !== null) {
                return {
                    base: String(window.pspPortal.restUrl || '').replace(/\/$/, ''),
                    nonce: String(window.pspPortal.restNonce || ''),
                };
            }
            _logError('No API config found in window.PORTAL_CONFIG or window.pspPortal');
            return null;
        },
        fetch: async (endpoint, options) => {
            const cfg = API.getConfig();
            if (!cfg || !cfg.base) {
                throw new Error('API config missing or invalid');
            }

            if (typeof endpoint !== 'string' || !endpoint.trim()) {
                throw new Error('Endpoint must be non-empty string');
            }

            options = options || {};
            const url = cfg.base + endpoint;
            const headers = {
                'X-WP-Nonce': cfg.nonce,
                'Content-Type': 'application/json',
                ...(options.headers || {}),
            };

            const controller = new AbortController();
            const timeoutId = _trackTimer(setTimeout(() => controller.abort(), CONFIG.TIMEOUTS.API_TIMEOUT));

            try {
                const response = await fetch(url, {
                    method: options.method || 'GET',
                    headers,
                    signal: controller.signal,
                    body: options.body || undefined,
                });

                if (!response.ok) {
                    throw new Error('HTTP ' + response.status + ' ' + response.statusText);
                }

                const contentType = response.headers.get('content-type') || '';
                if (contentType.includes('application/json')) {
                    return await response.json();
                }
                return await response.text();
            } catch (e) {
                _logError('API fetch failed: ' + endpoint, e);
                throw e;
            } finally {
                clearTimeout(timeoutId);
            }
        },
    };

    /**
     * Notification Module
     */
    const Notifications = {
        bell: null,
        dropdown: null,
        list: null,
        badge: null,
        reloadTimer: null,

        init: () => {
            try {
                Notifications.bell = DOM.query(CONFIG.SELECTORS.NOTIFICATION_BELL);
                Notifications.dropdown = DOM.query(CONFIG.SELECTORS.NOTIFICATION_DROPDOWN);
                Notifications.list = DOM.query(CONFIG.SELECTORS.NOTIFICATION_LIST);
                Notifications.badge = DOM.query(CONFIG.SELECTORS.NOTIFICATION_COUNT);

                if (!Notifications.bell || !Notifications.dropdown) {
                    _logInfo('Notification elements not found in DOM');
                    return;
                }

                Notifications.setupToggle();
                Notifications.load();
                Notifications.startAutoReload();
                _logInfo('Notifications module initialized');
            } catch (e) {
                _logError('Failed to initialize Notifications', e);
            }
        },

        setupToggle: () => {
            DOM.on(Notifications.bell, 'click', (e) => {
                e.stopPropagation();
                Notifications.toggleDropdown();
            });

            DOM.on(document, 'click', (e) => {
                if (
                    !Notifications.bell.contains(e.target) &&
                    !Notifications.dropdown.contains(e.target)
                ) {
                    Notifications.hideDropdown();
                }
            });

            DOM.on(Notifications.dropdown, 'click', (e) => e.stopPropagation());
        },

        toggleDropdown: () => {
            const isVisible = Notifications.dropdown.style.display !== 'none';
            isVisible ? Notifications.hideDropdown() : Notifications.showDropdown();
        },

        showDropdown: () => {
            if (Notifications.dropdown) {
                Notifications.dropdown.style.display = 'block';
            }
        },

        hideDropdown: () => {
            if (Notifications.dropdown) {
                Notifications.dropdown.style.display = 'none';
            }
        },

        load: async () => {
            try {
                const data = await API.fetch('/notifications?per_page=5');
                const notifications = Array.isArray(data) ? data : (data && data.notifications) ? data.notifications : [];
                Notifications.updateBadge(notifications);
                Notifications.updateList(notifications);
            } catch (error) {
                _logError('Failed to load notifications', error);
                if (Notifications.list) {
                    Notifications.list.innerHTML = '<p class="psp-notification-empty">Unable to load notifications</p>';
                }
            }
        },

        updateBadge: (notifications) => {
            if (!Notifications.badge) return;
            const unreadCount = Array.isArray(notifications) 
                ? notifications.filter((n) => n && !n.is_read).length 
                : 0;
            Notifications.badge.textContent = String(unreadCount);
            Notifications.badge.style.display = unreadCount > 0 ? 'flex' : 'none';
        },

        updateList: (notifications) => {
            if (!Notifications.list) return;

            if (!notifications || notifications.length === 0) {
                Notifications.list.innerHTML = '<p class="psp-notification-empty">No new notifications</p>';
                return;
            }

            try {
                Notifications.list.innerHTML = notifications
                    .filter(notif => notif && typeof notif === 'object')
                    .map((notif) => {
                        const title = Str.escapeHtml(notif.title || 'Notification');
                        const content = Str.truncate(Str.escapeHtml(notif.content || ''), 50);
                        const link = notif.actionLink ? '<a href="' + Str.escapeHtml(notif.actionLink) + '">View \u2192</a>' : '';
                        return '<div class="psp-notification-item ' + (!notif.is_read ? 'psp-unread' : '') + '">' +
                            '<strong>' + title + '</strong>' +
                            '<p>' + content + '</p>' +
                            link +
                            '</div>';
                    })
                    .join('');
            } catch (e) {
                _logError('Failed to update notification list', e);
                Notifications.list.innerHTML = '<p class="psp-notification-error">Error loading notifications</p>';
            }
        },

        startAutoReload: () => {
            Notifications.stopAutoReload();
            Notifications.reloadTimer = _trackTimer(setInterval(() => {
                Notifications.load();
            }, CONFIG.TIMEOUTS.NOTIFICATION_RELOAD));
        },

        stopAutoReload: () => {
            if (Notifications.reloadTimer) {
                clearInterval(Notifications.reloadTimer);
                Notifications.reloadTimer = null;
            }
        },

        markAsRead: async (notifId) => {
            if (typeof notifId !== 'number' && typeof notifId !== 'string') return;
            try {
                await API.fetch('/notifications/' + String(notifId), {
                    method: 'POST',
                    body: JSON.stringify({ is_read: true }),
                });
            } catch (error) {
                _logError('Failed to mark notification as read', error);
            }
        },
    };

    /**
     * User Menu Module
     */
    const UserMenu = {
        button: null,
        dropdown: null,

        init: () => {
            try {
                UserMenu.button = DOM.query(CONFIG.SELECTORS.USER_BUTTON);
                UserMenu.dropdown = DOM.query(CONFIG.SELECTORS.USER_DROPDOWN);

                if (!UserMenu.button || !UserMenu.dropdown) {
                    _logInfo('User menu elements not found in DOM');
                    return;
                }

                DOM.on(UserMenu.button, 'click', (e) => {
                    e.stopPropagation();
                    UserMenu.toggle();
                });

                DOM.on(document, 'click', (e) => {
                    if (
                        !UserMenu.button.contains(e.target) &&
                        !UserMenu.dropdown.contains(e.target)
                    ) {
                        UserMenu.hide();
                    }
                });

                DOM.on(UserMenu.dropdown, 'click', (e) => e.stopPropagation());
                _logInfo('UserMenu module initialized');
            } catch (e) {
                _logError('Failed to initialize UserMenu', e);
            }
        },

        toggle: () => {
            const isVisible = UserMenu.dropdown && UserMenu.dropdown.style.display !== 'none';
            isVisible ? UserMenu.hide() : UserMenu.show();
        },

        show: () => {
            if (UserMenu.dropdown) {
                UserMenu.dropdown.style.display = 'block';
            }
        },

        hide: () => {
            if (UserMenu.dropdown) {
                UserMenu.dropdown.style.display = 'none';
            }
        },
    };

    /**
     * Dropdown Module (Generic)
     */
    const Dropdowns = {
        init: () => {
            try {
                const triggers = DOM.queryAll(CONFIG.SELECTORS.DROPDOWN_TRIGGER);
                triggers.forEach((trigger) => {
                    DOM.on(trigger, 'click', (e) => {
                        e.preventDefault();
                        Dropdowns.toggle(trigger);
                    });
                });
                if (triggers.length > 0) {
                    _logInfo('Initialized ' + triggers.length + ' dropdowns');
                }
            } catch (e) {
                _logError('Failed to initialize Dropdowns', e);
            }
        },

        toggle: (trigger) => {
            if (!trigger) return;
            const targetId = trigger.getAttribute('data-target');
            if (!targetId) return;

            const target = DOM.query('#' + targetId);
            if (!target) return;

            const isVisible = target.style.display !== 'none';
            target.style.display = isVisible ? 'none' : 'block';
        },
    };

    /**
     * Alert Module
     */
    const Alerts = {
        init: () => {
            try {
                const alerts = DOM.queryAll(CONFIG.SELECTORS.ALERT);
                alerts.forEach((alert) => {
                    const closeBtn = alert.querySelector('[data-dismiss="alert"]');
                    if (closeBtn) {
                        DOM.on(closeBtn, 'click', (e) => {
                            e.preventDefault();
                            alert.remove();
                        });
                    }
                });
                if (alerts.length > 0) {
                    _logInfo('Initialized ' + alerts.length + ' alerts');
                }
            } catch (e) {
                _logError('Failed to initialize Alerts', e);
            }
        },
    };

    /**
     * Form Module
     */
    const Forms = {
        init: () => {
            try {
                const textareas = DOM.queryAll(CONFIG.SELECTORS.FORM_TEXTAREA);
                textareas.forEach((textarea) => {
                    // Auto-resize textarea
                    const resizeHandler = Perf.debounce(() => {
                        textarea.style.height = 'auto';
                        textarea.style.height = (textarea.scrollHeight) + 'px';
                    }, 100);

                    DOM.on(textarea, 'input', resizeHandler);

                    // Initial resize
                    textarea.style.height = 'auto';
                    textarea.style.height = (textarea.scrollHeight) + 'px';
                });
                if (textareas.length > 0) {
                    _logInfo('Initialized ' + textareas.length + ' auto-resizing textareas');
                }
            } catch (e) {
                _logError('Failed to initialize Forms', e);
            }
        },
    };

    /**
     * Main Portal Initialization
     */
    const Portal = {
        init: () => {
            try {
                // Check if config is available
                const cfg = API.getConfig();
                if (!cfg) {
                    _logError('Portal config unavailable; some features may not work');
                }

                // Initialize modules
                Notifications.init();
                UserMenu.init();
                Dropdowns.init();
                Alerts.init();
                Forms.init();

                _logInfo('PSPPortal v3.2.5 initialized successfully');
            } catch (e) {
                _logError('Portal initialization failed', e);
            }
        },

        destroy: () => {
            try {
                Notifications.stopAutoReload();
                
                // Clean up all tracked event listeners
                eventListeners.forEach(({ el, event, handler }) => {
                    if (el) {
                        el.removeEventListener(event, handler);
                    }
                });
                eventListeners.length = 0;

                // Clear all tracked timers
                timers.forEach((timerId) => {
                    clearTimeout(timerId);
                    clearInterval(timerId);
                });
                timers.length = 0;

                _logInfo('Portal cleanup completed');
            } catch (e) {
                _logError('Error during Portal cleanup', e);
            }
        },
    };

    /**
     * Attach to window for compatibility and debugging
     */
    window.PSPPortal = {
        API,
        DOM,
        Notifications,
        UserMenu,
        Dropdowns,
        Alerts,
        Forms,
        Portal,
        Utils: { Str, Perf },
        VERSION: '3.2.5',
        getErrorLog: () => errorLog.slice(),
        clearErrorLog: () => { errorLog.length = 0; },
        debug: CONFIG.debug,
        _internal: {
            CONFIG,
            errorLog,
            eventListeners,
            timers,
        },
    };

    /**
     * Initialize on DOM ready
     */
    function _initOnReady() {
        try {
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', () => {
                    Portal.init();
                    _logInfo('PSPPortal initialized on DOMContentLoaded');
                }, { once: true });
            } else {
                Portal.init();
                _logInfo('PSPPortal initialized (document already ready)');
            }
        } catch (e) {
            _logError('Failed to initialize PSPPortal', e);
        }
    }

    _initOnReady();

    /**
     * Cleanup on page unload
     */
    window.addEventListener('beforeunload', () => {
        try {
            Portal.destroy();
        } catch (e) {
            _logError('Error during page unload cleanup', e);
        }
    });
})();
