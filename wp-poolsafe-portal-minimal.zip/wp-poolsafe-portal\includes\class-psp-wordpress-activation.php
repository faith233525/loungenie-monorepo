<?php
/**
 * WordPress Standards Compliance - Activation/Deactivation Hooks
 *
 * Handles:
 * - Database table creation with proper prefixing
 * - Custom role and capability registration
 * - WP-Cron scheduling
 * - Default option setup
 * - Rewrite rule flushing
 *
 * @package PoolSafe Portal
 * @since 3.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * WordPress Standards Activation Handler
 */
class PSP_WordPress_Activation {
    
    /**
     * Plugin activation hook
     * Called when plugin is activated in WordPress admin
     */
    public static function activate() {
        // 1. Create custom database tables
        self::create_database_tables();
        
        // 2. Register custom roles and capabilities
        self::register_roles();
        self::register_capabilities();
        
        // 3. Schedule WP-Cron events
        self::schedule_cron_events();
        
        // 4. Set default plugin options
        self::set_default_options();
        
        // 5. Grant activation user admin capability
        self::grant_admin_capability();
        
        // 6. Flush rewrite rules
        flush_rewrite_rules();
        
        // 7. Log activation
        self::log_activation();
    }
    
    /**
     * Plugin deactivation hook
     * Called when plugin is deactivated (NOT uninstalled)
     * IMPORTANT: Do NOT delete database or user data on deactivation
     */
    public static function deactivate() {
        // 1. Unschedule all WP-Cron events
        self::unschedule_cron_events();
        
        // 2. Clear temporary transients (but keep important cache)
        self::clear_temporary_cache();
        
        // 3. Flush rewrite rules
        flush_rewrite_rules();
        
        // 4. Log deactivation
        self::log_deactivation();
        
        // NOTE: Database tables and user data are preserved for re-activation
    }
    
    /**
     * Create custom database tables
     * Uses dbDelta() for safe table creation with WordPress schema
     */
    private static function create_database_tables() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        
        // Companies table (primary table for partner companies)
        // NOTE: Keep indexed VARCHAR columns <=191 chars for utf8mb4 to avoid 1000-byte key limits
        $sql_companies = "CREATE TABLE IF NOT EXISTS " . $wpdb->prefix . "psp_companies (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id BIGINT UNSIGNED,
            name VARCHAR(191) NOT NULL,
            email VARCHAR(191) NOT NULL UNIQUE,
            phone VARCHAR(20),
            website VARCHAR(191),
            status VARCHAR(20) DEFAULT 'active',
            subscription_tier VARCHAR(50) DEFAULT 'free',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_status (status),
            INDEX idx_email (email),
            INDEX idx_created_at (created_at),
            FOREIGN KEY (user_id) REFERENCES {$wpdb->prefix}users(ID) ON DELETE SET NULL
        ) $charset_collate;";
        
        // Tickets table (support tickets for companies)
        $sql_tickets = "CREATE TABLE IF NOT EXISTS " . $wpdb->prefix . "psp_tickets (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            company_id BIGINT UNSIGNED NOT NULL,
            title VARCHAR(255) NOT NULL,
            description LONGTEXT,
            status VARCHAR(50) DEFAULT 'open',
            priority VARCHAR(20) DEFAULT 'medium',
            assigned_to BIGINT UNSIGNED,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            resolved_at TIMESTAMP NULL,
            INDEX idx_company_id (company_id),
            INDEX idx_status (status),
            INDEX idx_priority (priority),
            INDEX idx_assigned_to (assigned_to),
            INDEX idx_created_at (created_at),
            INDEX idx_company_status (company_id, status),
            FULLTEXT INDEX ft_search (title, description),
            FOREIGN KEY (company_id) REFERENCES {$wpdb->prefix}psp_companies(id) ON DELETE CASCADE,
            FOREIGN KEY (assigned_to) REFERENCES {$wpdb->prefix}users(ID) ON DELETE SET NULL
        ) $charset_collate;";
        
        // Units table (pool units for each company)
        $sql_units = "CREATE TABLE IF NOT EXISTS " . $wpdb->prefix . "psp_units (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            company_id BIGINT UNSIGNED NOT NULL,
            unit_number VARCHAR(50) NOT NULL,
            unit_type VARCHAR(50),
            location VARCHAR(255),
            status VARCHAR(20) DEFAULT 'active',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_company_id (company_id),
            INDEX idx_status (status),
            UNIQUE KEY unique_unit (company_id, unit_number),
            FOREIGN KEY (company_id) REFERENCES {$wpdb->prefix}psp_companies(id) ON DELETE CASCADE
        ) $charset_collate;";
        
        // API Keys table (for REST API authentication)
        $sql_api_keys = "CREATE TABLE IF NOT EXISTS " . $wpdb->prefix . "psp_api_keys (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            company_id BIGINT UNSIGNED NOT NULL,
            key_name VARCHAR(191),
            key_hash VARCHAR(191) NOT NULL UNIQUE,
            secret_hash VARCHAR(191) NOT NULL,
            is_active BOOLEAN DEFAULT true,
            last_used_at TIMESTAMP NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_company_id (company_id),
            INDEX idx_is_active (is_active),
            FOREIGN KEY (company_id) REFERENCES {$wpdb->prefix}psp_companies(id) ON DELETE CASCADE
        ) $charset_collate;";
        
        // Activity logs table
        $sql_logs = "CREATE TABLE IF NOT EXISTS " . $wpdb->prefix . "psp_logs (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id BIGINT UNSIGNED,
            action VARCHAR(100) NOT NULL,
            object_type VARCHAR(50),
            object_id BIGINT UNSIGNED,
            message LONGTEXT,
            level VARCHAR(20) DEFAULT 'info',
            ip_address VARCHAR(45),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_user_id (user_id),
            INDEX idx_action (action),
            INDEX idx_created_at (created_at),
            INDEX idx_level (level),
            FOREIGN KEY (user_id) REFERENCES {$wpdb->prefix}users(ID) ON DELETE SET NULL
        ) $charset_collate;";
        
        // Analytics table (daily stats)
        $sql_analytics = "CREATE TABLE IF NOT EXISTS " . $wpdb->prefix . "psp_analytics (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            company_id BIGINT UNSIGNED,
            date DATE NOT NULL,
            total_tickets INT DEFAULT 0,
            resolved_tickets INT DEFAULT 0,
            avg_resolution_time FLOAT DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY unique_analytics (company_id, date),
            INDEX idx_date (date),
            FOREIGN KEY (company_id) REFERENCES {$wpdb->prefix}psp_companies(id) ON DELETE CASCADE
        ) $charset_collate;";
        
        // Execute table creation
        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        dbDelta( $sql_companies );
        dbDelta( $sql_tickets );
        dbDelta( $sql_units );
        dbDelta( $sql_api_keys );
        dbDelta( $sql_logs );
        dbDelta( $sql_analytics );
    }
    
    /**
     * Register custom WordPress roles
     * Creates Support and Partner roles with custom capabilities only
     * IMPORTANT: Does NOT grant core WordPress capabilities like manage_options
     */
    private static function register_roles() {
        // Support role - for internal support staff
        add_role(
            'psp_support',
            __( 'PoolSafe Support', 'psp' ),
            array(
                'psp_view_portal'     => true,
                'psp_list_tickets'    => true,
                'psp_read_ticket'     => true,
                'psp_edit_ticket'     => true,
                'psp_list_companies'  => true,
                'psp_read_company'    => true,
            )
        );
        
        // Partner role - for partner companies
        add_role(
            'psp_partner',
            __( 'PoolSafe Partner', 'psp' ),
            array(
                'psp_view_portal'     => true,
                'psp_list_tickets'    => true,
                'psp_read_ticket'     => true,
                'psp_create_ticket'   => true,
                'psp_read_company'    => true,
            )
        );
    }
    
    /**
     * Add custom capabilities to roles
     */
    private static function register_capabilities() {
        $role_support = get_role( 'psp_support' );
        $role_partner = get_role( 'psp_partner' );
        $role_admin   = get_role( 'administrator' );
        
        // Support capabilities
        if ( $role_support ) {
            $role_support->add_cap( 'psp_manage_settings' );
            $role_support->add_cap( 'psp_view_analytics' );
            $role_support->add_cap( 'psp_manage_api_keys' );
            $role_support->add_cap( 'psp_delete_ticket' );
        }
        
        // Partner capabilities
        if ( $role_partner ) {
            $role_partner->add_cap( 'psp_edit_own_profile' );
            $role_partner->add_cap( 'psp_read_analytics' );
        }
        
        // Admin has all capabilities
        if ( $role_admin ) {
            $role_admin->add_cap( 'psp_manage_all' );
            $role_admin->add_cap( 'psp_manage_settings' );
            $role_admin->add_cap( 'psp_view_analytics' );
            $role_admin->add_cap( 'psp_manage_roles' );
            $role_admin->add_cap( 'psp_manage_api_keys' );
            $role_admin->add_cap( 'psp_view_logs' );
        }
    }
    
    /**
     * Schedule WordPress cron events
     * Uses wp_schedule_event() instead of OS cron
     */
    private static function schedule_cron_events() {
        // Daily cleanup - remove old logs
        if ( ! wp_next_scheduled( 'psp_daily_cleanup' ) ) {
            wp_schedule_event( time(), 'daily', 'psp_daily_cleanup' );
        }
        
        // Hourly cache refresh
        if ( ! wp_next_scheduled( 'psp_hourly_cache_refresh' ) ) {
            wp_schedule_event( time(), 'hourly', 'psp_hourly_cache_refresh' );
        }
        
        // Daily analytics generation
        if ( ! wp_next_scheduled( 'psp_daily_analytics' ) ) {
            wp_schedule_event( time(), 'daily', 'psp_daily_analytics' );
        }
    }
    
    /**
     * Set default plugin options
     */
    private static function set_default_options() {
        add_option( 'psp_version', PSP_VERSION );
        add_option( 'psp_db_version', PSP_DB_VERSION );
        add_option( 'psp_activated_at', current_time( 'mysql' ) );
        add_option( 'psp_plugin_initialized', true );
        
        // Default settings
        $defaults = array(
            'enable_2fa'        => true,
            'enable_sso'        => false,
            'enable_notifications' => true,
            'cache_enabled'     => true,
            'api_rate_limit'    => 100,
        );
        
        add_option( 'psp_settings', $defaults );
    }
    
    /**
     * Grant current user admin capability for portal
     */
    private static function grant_admin_capability() {
        $user = wp_get_current_user();
        if ( $user && $user->ID ) {
            $user->add_cap( 'psp_manage_all' );
        }
    }
    
    /**
     * Unschedule all WP-Cron events
     */
    private static function unschedule_cron_events() {
        wp_unschedule_event( wp_next_scheduled( 'psp_daily_cleanup' ), 'psp_daily_cleanup' );
        wp_unschedule_event( wp_next_scheduled( 'psp_hourly_cache_refresh' ), 'psp_hourly_cache_refresh' );
        wp_unschedule_event( wp_next_scheduled( 'psp_daily_analytics' ), 'psp_daily_analytics' );
    }
    
    /**
     * Clear temporary cache/transients
     * Keeps important data
     */
    private static function clear_temporary_cache() {
        delete_transient( 'psp_cache_companies' );
        delete_transient( 'psp_cache_analytics' );
        delete_option( 'psp_cache_last_update' );
    }
    
    /**
     * Log activation event
     */
    private static function log_activation() {
        global $wpdb;
        
        // Only log if logs table exists
        if ( $wpdb->get_var( "SHOW TABLES LIKE '" . $wpdb->prefix . "psp_logs'" ) ) {
            $wpdb->insert(
                $wpdb->prefix . 'psp_logs',
                array(
                    'user_id'   => get_current_user_id(),
                    'action'    => 'plugin_activation',
                    'message'   => 'PoolSafe Portal v' . PSP_VERSION . ' activated',
                    'level'     => 'info',
                    'ip_address' => sanitize_text_field( $_SERVER['REMOTE_ADDR'] ?? '' ),
                    'created_at' => current_time( 'mysql' ),
                ),
                array( '%d', '%s', '%s', '%s', '%s', '%s' )
            );
        }
    }
    
    /**
     * Log deactivation event
     */
    private static function log_deactivation() {
        global $wpdb;
        
        // Only log if logs table exists
        if ( $wpdb->get_var( "SHOW TABLES LIKE '" . $wpdb->prefix . "psp_logs'" ) ) {
            $wpdb->insert(
                $wpdb->prefix . 'psp_logs',
                array(
                    'user_id'   => get_current_user_id(),
                    'action'    => 'plugin_deactivation',
                    'message'   => 'PoolSafe Portal deactivated',
                    'level'     => 'info',
                    'ip_address' => sanitize_text_field( $_SERVER['REMOTE_ADDR'] ?? '' ),
                    'created_at' => current_time( 'mysql' ),
                ),
                array( '%d', '%s', '%s', '%s', '%s', '%s' )
            );
        }
    }
}
