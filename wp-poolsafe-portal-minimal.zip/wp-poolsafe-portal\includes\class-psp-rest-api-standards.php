<?php
/**
 * REST API Standards Implementation - PoolSafe Portal v3.0.0
 *
 * All REST endpoints use WordPress REST API with:
 * - Proper namespace (poolsafe/v1)
 * - Permission callbacks
 * - Nonce verification
 * - Input sanitization
 * - Output escaping
 *
 * @package PoolSafe Portal
 * @since 3.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Register REST API endpoints for PoolSafe Portal
 * Uses WordPress REST API for all endpoint definitions
 */
class PSP_REST_API {
    
    const API_NAMESPACE = 'poolsafe/v1';
    
    /**
     * Initialize REST API
     */
    public static function init() {
        add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
    }
    
    /**
     * Register all REST routes
     */
    public static function register_routes() {
        // Companies endpoints
        register_rest_route( self::API_NAMESPACE, '/companies', array(
            array(
                'methods'             => 'GET',
                'callback'            => array( __CLASS__, 'get_companies' ),
                'permission_callback' => array( __CLASS__, 'check_list_permission' ),
                'args'                => array(
                    'page'     => array(
                        'type'    => 'integer',
                        'default' => 1,
                    ),
                    'per_page' => array(
                        'type'    => 'integer',
                        'default' => 20,
                        'maximum' => 100,
                    ),
                    'status'   => array(
                        'type' => 'string',
                        'enum' => array( 'active', 'inactive' ),
                    ),
                    'search'   => array(
                        'type'              => 'string',
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                ),
            ),
            array(
                'methods'             => 'POST',
                'callback'            => array( __CLASS__, 'create_company' ),
                'permission_callback' => array( __CLASS__, 'check_create_permission' ),
                'args'                => array(
                    'name'  => array(
                        'type'              => 'string',
                        'required'          => true,
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'email' => array(
                        'type'              => 'string',
                        'required'          => true,
                        'sanitize_callback' => 'sanitize_email',
                    ),
                    'phone' => array(
                        'type'              => 'string',
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'website' => array(
                        'type'              => 'string',
                        'sanitize_callback' => 'esc_url_raw',
                    ),
                ),
            ),
        ) );
        
        // Single company endpoint
        register_rest_route( self::API_NAMESPACE, '/companies/(?P<id>\d+)', array(
            array(
                'methods'             => 'GET',
                'callback'            => array( __CLASS__, 'get_company' ),
                'permission_callback' => array( __CLASS__, 'check_read_permission' ),
                'args'                => array(
                    'id' => array(
                        'type'     => 'integer',
                        'required' => true,
                    ),
                ),
            ),
            array(
                'methods'             => 'PUT',
                'callback'            => array( __CLASS__, 'update_company' ),
                'permission_callback' => array( __CLASS__, 'check_edit_permission' ),
                'args'                => array(
                    'id'   => array(
                        'type'     => 'integer',
                        'required' => true,
                    ),
                    'name' => array(
                        'type'              => 'string',
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'email' => array(
                        'type'              => 'string',
                        'sanitize_callback' => 'sanitize_email',
                    ),
                ),
            ),
            array(
                'methods'             => 'DELETE',
                'callback'            => array( __CLASS__, 'delete_company' ),
                'permission_callback' => array( __CLASS__, 'check_delete_permission' ),
                'args'                => array(
                    'id' => array(
                        'type'     => 'integer',
                        'required' => true,
                    ),
                ),
            ),
        ) );
        
        // Tickets endpoints
        register_rest_route( self::API_NAMESPACE, '/tickets', array(
            array(
                'methods'             => 'GET',
                'callback'            => array( __CLASS__, 'get_tickets' ),
                'permission_callback' => array( __CLASS__, 'check_list_permission' ),
                'args'                => array(
                    'company_id' => array(
                        'type'    => 'integer',
                        'default' => 0,
                    ),
                    'status'     => array(
                        'type' => 'string',
                        'enum' => array( 'open', 'in_progress', 'closed', 'resolved' ),
                    ),
                    'priority'   => array(
                        'type' => 'string',
                        'enum' => array( 'low', 'medium', 'high', 'critical' ),
                    ),
                    'page'       => array(
                        'type'    => 'integer',
                        'default' => 1,
                    ),
                    'per_page'   => array(
                        'type'    => 'integer',
                        'default' => 20,
                        'maximum' => 100,
                    ),
                ),
            ),
            array(
                'methods'             => 'POST',
                'callback'            => array( __CLASS__, 'create_ticket' ),
                'permission_callback' => array( __CLASS__, 'check_create_permission' ),
                'args'                => array(
                    'company_id' => array(
                        'type'     => 'integer',
                        'required' => true,
                    ),
                    'title'      => array(
                        'type'              => 'string',
                        'required'          => true,
                        'sanitize_callback' => 'sanitize_text_field',
                    ),
                    'description' => array(
                        'type'              => 'string',
                        'sanitize_callback' => 'wp_kses_post',
                    ),
                    'priority'   => array(
                        'type'    => 'string',
                        'default' => 'medium',
                        'enum'    => array( 'low', 'medium', 'high', 'critical' ),
                    ),
                ),
            ),
        ) );
        
        // Single ticket endpoint
        register_rest_route( self::API_NAMESPACE, '/tickets/(?P<id>\d+)', array(
            array(
                'methods'             => 'GET',
                'callback'            => array( __CLASS__, 'get_ticket' ),
                'permission_callback' => array( __CLASS__, 'check_read_permission' ),
            ),
            array(
                'methods'             => 'PUT',
                'callback'            => array( __CLASS__, 'update_ticket' ),
                'permission_callback' => array( __CLASS__, 'check_edit_permission' ),
            ),
        ) );
    }
    
    /**
     * Permission callback - List operations
     */
    public static function check_list_permission( WP_REST_Request $request ) {
        // Verify nonce
        $nonce = $request->get_header( 'X-WP-Nonce' );
        if ( ! $nonce || ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
            return new WP_Error(
                'rest_nonce_failure',
                __( 'Nonce verification failed', 'psp' ),
                array( 'status' => 401 )
            );
        }
        
        // Check capability
        if ( ! current_user_can( 'psp_list_tickets' ) ) {
            return new WP_Error(
                'rest_permission_denied',
                __( 'You do not have permission to list items', 'psp' ),
                array( 'status' => 403 )
            );
        }
        
        return true;
    }
    
    /**
     * Permission callback - Read operations
     */
    public static function check_read_permission( WP_REST_Request $request ) {
        // Verify nonce
        $nonce = $request->get_header( 'X-WP-Nonce' );
        if ( ! $nonce || ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
            return false;
        }
        
        return current_user_can( 'psp_read_ticket' );
    }
    
    /**
     * Permission callback - Create operations
     */
    public static function check_create_permission( WP_REST_Request $request ) {
        return current_user_can( 'psp_create_ticket' );
    }
    
    /**
     * Permission callback - Edit operations
     */
    public static function check_edit_permission( WP_REST_Request $request ) {
        $id = $request->get_param( 'id' );
        
        // Verify nonce
        $nonce = $request->get_header( 'X-WP-Nonce' );
        if ( ! $nonce || ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
            return false;
        }
        
        return current_user_can( 'psp_edit_ticket' );
    }
    
    /**
     * Permission callback - Delete operations
     */
    public static function check_delete_permission( WP_REST_Request $request ) {
        $nonce = $request->get_header( 'X-WP-Nonce' );
        if ( ! $nonce || ! wp_verify_nonce( $nonce, 'wp_rest' ) ) {
            return false;
        }
        
        return current_user_can( 'psp_manage_all' );
    }
    
    /**
     * GET /poolsafe/v1/companies
     */
    public static function get_companies( WP_REST_Request $request ) {
        global $wpdb;
        
        $page     = (int) $request->get_param( 'page' ) ?: 1;
        $per_page = (int) $request->get_param( 'per_page' ) ?: 20;
        $status   = sanitize_key( $request->get_param( 'status' ) );
        $search   = sanitize_text_field( $request->get_param( 'search' ) );
        
        $offset = ( $page - 1 ) * $per_page;
        
        // Build query
        $query        = "SELECT * FROM " . $wpdb->prefix . "psp_companies";
        $count_query  = "SELECT COUNT(*) FROM " . $wpdb->prefix . "psp_companies";
        $where_clause = array();
        $params       = array();
        
        if ( $status ) {
            $where_clause[] = 'status = %s';
            $params[]       = $status;
        }
        
        if ( $search ) {
            $where_clause[] = '(name LIKE %s OR email LIKE %s)';
            $search_param   = '%' . $wpdb->esc_like( $search ) . '%';
            $params[]       = $search_param;
            $params[]       = $search_param;
        }
        
        // Apply WHERE clause
        if ( ! empty( $where_clause ) ) {
            $where = ' WHERE ' . implode( ' AND ', $where_clause );
            $query .= $where;
            $count_query .= $where;
        }
        
        // Get total count
        $total = (int) $wpdb->get_var(
            $where_clause ? $wpdb->prepare( $count_query, ...$params ) : $count_query
        );
        
        // Get paginated results
        $query .= ' ORDER BY created_at DESC LIMIT %d OFFSET %d';
        $params[] = $per_page;
        $params[] = $offset;
        
        $companies = $wpdb->get_results(
            $where_clause ? $wpdb->prepare( $query, ...$params ) : $query
        );
        
        return rest_ensure_response( array(
            'data'       => $companies,
            'total'      => $total,
            'page'       => $page,
            'per_page'   => $per_page,
            'total_pages' => ceil( $total / $per_page ),
        ) );
    }
    
    /**
     * POST /poolsafe/v1/companies
     */
    public static function create_company( WP_REST_Request $request ) {
        global $wpdb;
        
        $name    = sanitize_text_field( $request->get_param( 'name' ) );
        $email   = sanitize_email( $request->get_param( 'email' ) );
        $phone   = sanitize_text_field( $request->get_param( 'phone' ) );
        $website = esc_url_raw( $request->get_param( 'website' ) );
        
        // Validate required fields
        if ( empty( $name ) || empty( $email ) ) {
            return new WP_Error(
                'rest_invalid_param',
                __( 'Name and email are required', 'psp' ),
                array( 'status' => 400 )
            );
        }
        
        // Check for duplicate email
        $existing = $wpdb->get_row( $wpdb->prepare(
            "SELECT id FROM " . $wpdb->prefix . "psp_companies WHERE email = %s",
            $email
        ) );
        
        if ( $existing ) {
            return new WP_Error(
                'rest_duplicate_email',
                __( 'A company with this email already exists', 'psp' ),
                array( 'status' => 409 )
            );
        }
        
        // Insert company
        $result = $wpdb->insert(
            $wpdb->prefix . 'psp_companies',
            array(
                'name'    => $name,
                'email'   => $email,
                'phone'   => $phone,
                'website' => $website,
                'status'  => 'active',
            ),
            array( '%s', '%s', '%s', '%s', '%s' )
        );
        
        if ( ! $result ) {
            return new WP_Error(
                'rest_insert_failed',
                __( 'Failed to create company', 'psp' ),
                array( 'status' => 500 )
            );
        }
        
        // Return created company
        $company = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . $wpdb->prefix . "psp_companies WHERE id = %d",
            $wpdb->insert_id
        ) );
        
        return rest_ensure_response( $company );
    }
    
    /**
     * GET /poolsafe/v1/companies/{id}
     */
    public static function get_company( WP_REST_Request $request ) {
        global $wpdb;
        
        $id = (int) $request->get_param( 'id' );
        
        $company = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . $wpdb->prefix . "psp_companies WHERE id = %d",
            $id
        ) );
        
        if ( ! $company ) {
            return new WP_Error(
                'rest_not_found',
                __( 'Company not found', 'psp' ),
                array( 'status' => 404 )
            );
        }
        
        return rest_ensure_response( $company );
    }
    
    /**
     * PUT /poolsafe/v1/companies/{id}
     */
    public static function update_company( WP_REST_Request $request ) {
        global $wpdb;
        
        $id    = (int) $request->get_param( 'id' );
        $name  = sanitize_text_field( $request->get_param( 'name' ) );
        $email = sanitize_email( $request->get_param( 'email' ) );
        
        // Check if company exists
        $company = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . $wpdb->prefix . "psp_companies WHERE id = %d",
            $id
        ) );
        
        if ( ! $company ) {
            return new WP_Error(
                'rest_not_found',
                __( 'Company not found', 'psp' ),
                array( 'status' => 404 )
            );
        }
        
        // Build update array
        $update = array();
        if ( ! empty( $name ) ) {
            $update['name'] = $name;
        }
        if ( ! empty( $email ) ) {
            $update['email'] = $email;
        }
        
        if ( empty( $update ) ) {
            return rest_ensure_response( $company );
        }
        
        // Update company
        $wpdb->update(
            $wpdb->prefix . 'psp_companies',
            $update,
            array( 'id' => $id ),
            array( '%s', '%s' ),
            array( '%d' )
        );
        
        // Return updated company
        $updated = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . $wpdb->prefix . "psp_companies WHERE id = %d",
            $id
        ) );
        
        return rest_ensure_response( $updated );
    }
    
    /**
     * DELETE /poolsafe/v1/companies/{id}
     */
    public static function delete_company( WP_REST_Request $request ) {
        global $wpdb;
        
        $id = (int) $request->get_param( 'id' );
        
        // Check if company exists
        $company = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . $wpdb->prefix . "psp_companies WHERE id = %d",
            $id
        ) );
        
        if ( ! $company ) {
            return new WP_Error(
                'rest_not_found',
                __( 'Company not found', 'psp' ),
                array( 'status' => 404 )
            );
        }
        
        // Delete company (cascades to tickets via foreign key)
        $result = $wpdb->delete(
            $wpdb->prefix . 'psp_companies',
            array( 'id' => $id ),
            array( '%d' )
        );
        
        if ( ! $result ) {
            return new WP_Error(
                'rest_delete_failed',
                __( 'Failed to delete company', 'psp' ),
                array( 'status' => 500 )
            );
        }
        
        return rest_ensure_response( array(
            'deleted' => true,
            'id'      => $id,
        ) );
    }
    
    /**
     * GET /poolsafe/v1/tickets
     */
    public static function get_tickets( WP_REST_Request $request ) {
        global $wpdb;
        
        $company_id = (int) $request->get_param( 'company_id' ) ?: 0;
        $status     = sanitize_key( $request->get_param( 'status' ) );
        $priority   = sanitize_key( $request->get_param( 'priority' ) );
        $page       = (int) $request->get_param( 'page' ) ?: 1;
        $per_page   = (int) $request->get_param( 'per_page' ) ?: 20;
        
        $offset = ( $page - 1 ) * $per_page;
        
        // Build query
        $query        = "SELECT * FROM " . $wpdb->prefix . "psp_tickets";
        $count_query  = "SELECT COUNT(*) FROM " . $wpdb->prefix . "psp_tickets";
        $where_clause = array();
        $params       = array();
        
        if ( $company_id > 0 ) {
            $where_clause[] = 'company_id = %d';
            $params[]       = $company_id;
        }
        
        if ( $status ) {
            $where_clause[] = 'status = %s';
            $params[]       = $status;
        }
        
        if ( $priority ) {
            $where_clause[] = 'priority = %s';
            $params[]       = $priority;
        }
        
        // Apply WHERE clause
        if ( ! empty( $where_clause ) ) {
            $where = ' WHERE ' . implode( ' AND ', $where_clause );
            $query .= $where;
            $count_query .= $where;
        }
        
        // Get total count
        $total = (int) $wpdb->get_var(
            $where_clause ? $wpdb->prepare( $count_query, ...$params ) : $count_query
        );
        
        // Get paginated results
        $query .= ' ORDER BY created_at DESC LIMIT %d OFFSET %d';
        $params[] = $per_page;
        $params[] = $offset;
        
        $tickets = $wpdb->get_results(
            $where_clause ? $wpdb->prepare( $query, ...$params ) : $query
        );
        
        return rest_ensure_response( array(
            'data'       => $tickets,
            'total'      => $total,
            'page'       => $page,
            'per_page'   => $per_page,
            'total_pages' => ceil( $total / $per_page ),
        ) );
    }
    
    /**
     * POST /poolsafe/v1/tickets
     */
    public static function create_ticket( WP_REST_Request $request ) {
        global $wpdb;
        
        $company_id  = (int) $request->get_param( 'company_id' );
        $title       = sanitize_text_field( $request->get_param( 'title' ) );
        $description = wp_kses_post( $request->get_param( 'description' ) );
        $priority    = sanitize_key( $request->get_param( 'priority' ) ) ?: 'medium';
        
        // Validate required fields
        if ( empty( $title ) || empty( $company_id ) ) {
            return new WP_Error(
                'rest_invalid_param',
                __( 'Title and company_id are required', 'psp' ),
                array( 'status' => 400 )
            );
        }
        
        // Verify company exists
        $company = $wpdb->get_row( $wpdb->prepare(
            "SELECT id FROM " . $wpdb->prefix . "psp_companies WHERE id = %d",
            $company_id
        ) );
        
        if ( ! $company ) {
            return new WP_Error(
                'rest_invalid_param',
                __( 'Company not found', 'psp' ),
                array( 'status' => 400 )
            );
        }
        
        // Insert ticket
        $result = $wpdb->insert(
            $wpdb->prefix . 'psp_tickets',
            array(
                'company_id'  => $company_id,
                'title'       => $title,
                'description' => $description,
                'priority'    => $priority,
                'status'      => 'open',
            ),
            array( '%d', '%s', '%s', '%s', '%s' )
        );
        
        if ( ! $result ) {
            return new WP_Error(
                'rest_insert_failed',
                __( 'Failed to create ticket', 'psp' ),
                array( 'status' => 500 )
            );
        }
        
        // Return created ticket
        $ticket = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . $wpdb->prefix . "psp_tickets WHERE id = %d",
            $wpdb->insert_id
        ) );
        
        return rest_ensure_response( $ticket );
    }
    
    /**
     * GET /poolsafe/v1/tickets/{id}
     */
    public static function get_ticket( WP_REST_Request $request ) {
        global $wpdb;
        
        $id = (int) $request->get_param( 'id' );
        
        $ticket = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . $wpdb->prefix . "psp_tickets WHERE id = %d",
            $id
        ) );
        
        if ( ! $ticket ) {
            return new WP_Error(
                'rest_not_found',
                __( 'Ticket not found', 'psp' ),
                array( 'status' => 404 )
            );
        }
        
        return rest_ensure_response( $ticket );
    }
    
    /**
     * PUT /poolsafe/v1/tickets/{id}
     */
    public static function update_ticket( WP_REST_Request $request ) {
        global $wpdb;
        
        $id          = (int) $request->get_param( 'id' );
        $title       = sanitize_text_field( $request->get_param( 'title' ) );
        $description = wp_kses_post( $request->get_param( 'description' ) );
        $status      = sanitize_key( $request->get_param( 'status' ) );
        $priority    = sanitize_key( $request->get_param( 'priority' ) );
        
        // Check if ticket exists
        $ticket = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . $wpdb->prefix . "psp_tickets WHERE id = %d",
            $id
        ) );
        
        if ( ! $ticket ) {
            return new WP_Error(
                'rest_not_found',
                __( 'Ticket not found', 'psp' ),
                array( 'status' => 404 )
            );
        }
        
        // Build update array
        $update = array();
        if ( ! empty( $title ) ) {
            $update['title'] = $title;
        }
        if ( ! empty( $description ) ) {
            $update['description'] = $description;
        }
        if ( ! empty( $status ) ) {
            $update['status'] = $status;
            if ( 'resolved' === $status ) {
                $update['resolved_at'] = current_time( 'mysql' );
            }
        }
        if ( ! empty( $priority ) ) {
            $update['priority'] = $priority;
        }
        
        if ( empty( $update ) ) {
            return rest_ensure_response( $ticket );
        }
        
        // Update ticket
        $wpdb->update(
            $wpdb->prefix . 'psp_tickets',
            $update,
            array( 'id' => $id ),
            array_fill( 0, count( $update ), '%s' ),
            array( '%d' )
        );
        
        // Return updated ticket
        $updated = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . $wpdb->prefix . "psp_tickets WHERE id = %d",
            $id
        ) );
        
        return rest_ensure_response( $updated );
    }
}

// Initialize REST API
add_action( 'init', array( 'PSP_REST_API', 'init' ) );
