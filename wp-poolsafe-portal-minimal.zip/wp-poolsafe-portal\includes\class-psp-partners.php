<?php

namespace PSP;
/**
 * Partners CPT & meta (company, address, lock info, map location)
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Partners {

	public static function init(): void {
		// Register CPT and meta on init
		add_action( 'init', array( __CLASS__, 'register_cpt' ) );
		// Geocode after save if needed
		add_action( 'save_post_psp_partner', array( __CLASS__, 'maybe_geocode_coordinates' ), 10, 3 );
	}

	public static function register_cpt(): void {
		$labels = array(
			'name'          => __( 'Companies', 'psp' ),
			'singular_name' => __( 'Company', 'psp' ),
			'add_new'       => __( 'Add Company', 'psp' ),
			'add_new_item'  => __( 'Add New Company', 'psp' ),
			'edit_item'     => __( 'Edit Company', 'psp' ),
			'new_item'      => __( 'New Company', 'psp' ),
			'view_item'     => __( 'View Company', 'psp' ),
			'search_items'  => __( 'Search Companies', 'psp' ),
		);
		$caps   = array(
			'read_post'           => 'read_psp_partner',
			'read_private_posts'  => 'read_private_psp_partners',
			'edit_post'           => 'edit_psp_partner',
			'edit_posts'          => 'edit_psp_partners',
			'edit_others_posts'   => 'edit_others_psp_partners',
			'publish_posts'       => 'publish_psp_partners',
			'delete_post'         => 'delete_psp_partner',
			'delete_posts'        => 'delete_psp_partners',
			'delete_others_posts' => 'delete_others_psp_partners',
		);
		register_post_type(
			'psp_partner',
			array(
				'labels'          => $labels,
				'public'          => false,
				'show_ui'         => true,
				'show_in_menu'    => true,
				'capability_type' => array( 'psp_partner', 'psp_partners' ),
				'map_meta_cap'    => false,
				'capabilities'    => $caps,
				'supports'        => array( 'title', 'editor', 'custom-fields' ),
				'show_in_rest'    => true,
				'menu_icon'       => 'dashicons-building',
			)
		);

		// Company & location
		self::register_meta( 'company_name', 'string' );
		self::register_meta( 'management_company', 'string' );
		self::register_meta( 'street_address', 'string' );
		self::register_meta( 'city', 'string' );
		self::register_meta( 'state', 'string' );
		self::register_meta( 'zip', 'string' );
		self::register_meta( 'country', 'string' );
		self::register_meta( 'latitude', 'number' );
		self::register_meta( 'longitude', 'number' );
		self::register_meta( 'number_of_lounge_units', 'integer' );
		self::register_meta( 'units', 'integer' );
		self::register_meta( 'top_colour', 'string' );

		// Business/operations
		self::register_meta( 'venue_type', 'string' );
		self::register_meta( 'is_seasonal', 'string' );
		self::register_meta( 'unit_details', 'string' );
		self::register_meta( 'purchase_type', 'string', 'psp_support' );
		self::register_meta( 'revenue_share_details', 'string', 'psp_support' );
		self::register_meta( 'contract_reference', 'string', 'psp_support' );

		// Contacts
		self::register_meta( 'primary_contact_name', 'string' );
		self::register_meta( 'primary_contact_email', 'string' );
		self::register_meta( 'primary_contact_phone', 'string' );
		self::register_meta( 'primary_contact_title', 'string' );
		self::register_meta( 'secondary_contact_name', 'string' );
		self::register_meta( 'secondary_contact_email', 'string' );
		self::register_meta( 'secondary_contact_phone', 'string' );
		self::register_meta( 'secondary_contact_title', 'string' );

		// Identifiers & communication
		self::register_meta( 'primary_user_id', 'integer' );
		self::register_meta( 'user_ids', 'string' );
		self::register_meta( 'company_email', 'string' );
		self::register_meta( 'email_domain', 'string' );
		self::register_meta( 'phone', 'string' );

		// Status & features
		self::register_meta( 'is_active', 'boolean' );
		self::register_meta( 'status', 'string' ); // active, inactive, seasonal
		self::register_meta( 'tags', 'array', null, array(
			'type'  => 'array',
			'items' => array( 'type' => 'string' ),
		) );
		self::register_meta( 'has_fb_call_button', 'boolean' );
		self::register_meta( 'has_usb_charging', 'boolean' );
		self::register_meta( 'has_safe_lock', 'boolean' );
		self::register_meta( 'has_removable_ice_bucket', 'boolean' );

		// Gateway/Channel
		self::register_meta( 'gateway_name', 'string' );
		self::register_meta( 'gateway_address', 'string' );
		self::register_meta( 'channel_number', 'string' );

		// Admin/Support only
		self::register_meta( 'admin_password', 'string', 'psp_support' );
		self::register_meta( 'operation_type', 'string', 'psp_support' );
		self::register_meta( 'seasonal_open_date', 'string', 'psp_support' );
		self::register_meta( 'seasonal_close_date', 'string', 'psp_support' );
		self::register_meta( 'lock_type', 'string', 'psp_support' );
		self::register_meta( 'lock_make', 'string', 'psp_support' );
		self::register_meta( 'master_code', 'string', 'psp_support' );
		self::register_meta( 'sub_master_code', 'string', 'psp_support' );
		self::register_meta( 'lock_part', 'string', 'psp_support' );
		self::register_meta( 'key', 'string', 'psp_support' );

		// Dates & tracking
		self::register_meta( 'installation_date', 'string' );
		self::register_meta( 'install_date', 'string' );
		self::register_meta( 'units_connected', 'integer' );
	}

	private static function register_meta( string $key, string $type, ?string $minRole = null, ?array $rest_schema = null ): void {
		$args = array(
			'type'   => $type,
			'single' => true,
		);
		// Show in REST with default schema based on type
		if ( $type === 'array' && ! empty( $rest_schema ) ) {
			// For array types, wrap in schema structure with items
			$args['show_in_rest'] = array(
				'schema' => $rest_schema,
			);
		} else {
			$args['show_in_rest'] = true;
		}
		// Access control
		$args['auth_callback'] = function () use ( $minRole ) {
			if ( $minRole === 'psp_support' ) {
				return current_user_can( 'administrator' ) || current_user_can( 'psp_support' );
			}
			return current_user_can( 'read_psp_partner' );
		};

		register_post_meta( 'psp_partner', "psp_{$key}", $args );
	}

	/**
	 * Attempt to geocode coordinates based on address if lat/lng are empty.
	 */
	public static function maybe_geocode_coordinates( int $post_id, $post, bool $update ): void {
		if ( wp_is_post_revision( $post_id ) || $post->post_type !== 'psp_partner' ) {
			return;
		}
		$lat = get_post_meta( $post_id, 'psp_latitude', true );
		$lng = get_post_meta( $post_id, 'psp_longitude', true );
		if ( ! empty( $lat ) && ! empty( $lng ) ) {
			return; // already set
		}

		$parts = array();
		foreach ( array( 'psp_street_address', 'psp_city', 'psp_state', 'psp_zip', 'psp_country' ) as $k ) {
			$v = trim( (string) get_post_meta( $post_id, $k, true ) );
			if ( $v !== '' ) {
				$parts[] = $v;
			}
		}
		// Stub: call geocoding API here if needed
	}
}
