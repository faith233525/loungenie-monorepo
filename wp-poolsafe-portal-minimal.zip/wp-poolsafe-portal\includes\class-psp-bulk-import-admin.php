<?php
/**
 * Bulk Import Admin Interface
 * Provides WordPress admin page to manage bulk partner imports
 *
 * @package PoolSafe_Portal
 */

if (!defined('ABSPATH')) {
    exit;
}

class PSP_Bulk_Import_Admin {
    
    public static function init() {
        add_action('admin_menu', array(__CLASS__, 'add_admin_menu'));
        add_action('admin_init', array(__CLASS__, 'handle_import_action'));
    }
    
    public static function add_admin_menu() {
        add_submenu_page(
            'psp-settings',
            'Bulk Import Partners',
            'Import Partners',
            'manage_options',
            'psp-bulk-import',
            array(__CLASS__, 'render_import_page')
        );
    }
    
    public static function handle_import_action() {
        if (!isset($_POST['psp_import_action']) || !wp_verify_nonce($_POST['_wpnonce'], 'psp_bulk_import')) {
            return;
        }
        
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }
        
        // Get the import function from bulk-import-partners.php
        global $wpdb;
        
        $imported = 0;
        $errors = 0;
        $messages = array();
        
        // Get all 48 partners from the global partners_data array
        // We'll import all partners in batch
        
        // For simplicity, we'll call the bulk import function
        // Make sure partners_data is available from bulk-import-partners.php
        include_once __DIR__ . '/bulk-import-partners.php';
        
        if (isset($partners_data) && is_array($partners_data)) {
            foreach ($partners_data as $partner) {
                // Check if partner already exists
                $existing = $wpdb->get_var($wpdb->prepare(
                    "SELECT id FROM {$wpdb->prefix}psp_partners WHERE company_name = %s",
                    $partner['company_name']
                ));
                
                if ($existing) {
                    $messages[] = "⏭️  Skipping {$partner['company_name']} (already exists)";
                    continue;
                }
                
                // Insert partner
                $result = $wpdb->insert(
                    $wpdb->prefix . 'psp_partners',
                    array(
                        'company_name' => $partner['company_name'],
                        'management_company' => $partner['management_company'],
                        'street_address' => $partner['street_address'],
                        'city' => $partner['city'],
                        'state' => $partner['state'],
                        'zip' => $partner['zip'],
                        'country' => $partner['country'],
                        'phone' => $partner['number'],
                        'units' => $partner['units'],
                        'pool_colour' => $partner['top_colour'],
                        'lock_type' => $partner['lock'],
                        'master_code' => $partner['master_code'],
                        'sub_master_code' => $partner['sub_master_code'],
                        'lock_part' => $partner['lock_part'],
                        'key_type' => $partner['key'],
                        'created_at' => current_time('mysql'),
                        'status' => 'active'
                    ),
                    array('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')
                );
                
                if ($result) {
                    $partner_id = $wpdb->insert_id;
                    
                    // Create portal user for partner
                    $password_hash = password_hash($partner['user_pass'], PASSWORD_BCRYPT);
                    
                    $wpdb->insert(
                        $wpdb->prefix . 'psp_company_users',
                        array(
                            'company_id' => $partner_id,
                            'username' => $partner['user_login'],
                            'password' => $password_hash,
                            'email' => strtolower($partner['user_login']) . '@poolsafe.local',
                            'first_name' => $partner['display_name'],
                            'last_name' => 'Admin',
                            'role' => 'admin',
                            'status' => 'active',
                            'created_at' => current_time('mysql')
                        ),
                        array('%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')
                    );
                    
                    $messages[] = "✅ {$partner['company_name']} imported successfully";
                    $imported++;
                } else {
                    $messages[] = "❌ Failed to import {$partner['company_name']}: " . $wpdb->last_error;
                    $errors++;
                }
            }
        }
        
        // Store messages in transient for display
        set_transient('psp_import_result_' . get_current_user_id(), array(
            'imported' => $imported,
            'errors' => $errors,
            'messages' => $messages
        ), HOUR_IN_SECONDS);
        
        wp_safe_redirect(add_query_arg('import_status', 'complete', admin_url('admin.php?page=psp-bulk-import')));
        exit;
    }
    
    public static function render_import_page() {
        // Check if import was just completed
        $import_result = null;
        if (isset($_GET['import_status']) && $_GET['import_status'] === 'complete') {
            $import_result = get_transient('psp_import_result_' . get_current_user_id());
            delete_transient('psp_import_result_' . get_current_user_id());
        }
        
        ?>
        <div class="wrap">
            <h1>Bulk Import Partners</h1>
            
            <?php if ($import_result): ?>
                <div class="notice <?php echo ($import_result['errors'] === 0) ? 'notice-success' : 'notice-warning'; ?> is-dismissible">
                    <p><strong>Import Complete!</strong></p>
                    <p>Imported: <strong><?php echo esc_html($import_result['imported']); ?></strong></p>
                    <p>Errors: <strong><?php echo esc_html($import_result['errors']); ?></strong></p>
                    
                    <?php if (!empty($import_result['messages'])): ?>
                        <details>
                            <summary>Show Details</summary>
                            <ul style="margin-top: 10px; list-style: none; padding-left: 0;">
                                <?php foreach ($import_result['messages'] as $msg): ?>
                                    <li><?php echo esc_html($msg); ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </details>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            
            <div class="card">
                <h2>48 Waterpark Partners Ready to Import</h2>
                <p>This will import all 48 waterpark partners with their complete information:</p>
                <ul style="margin-left: 20px;">
                    <li>Company names and details</li>
                    <li>Contact information and phone numbers</li>
                    <li>Pool equipment details (colors, lock types, master codes)</li>
                    <li>Portal user accounts with login credentials</li>
                    <li>All users set to 'active' status</li>
                </ul>
                
                <div style="background: #f5f5f5; padding: 15px; margin: 15px 0; border-left: 4px solid #0073aa;">
                    <strong>Data Included:</strong>
                    <ul style="margin-left: 20px; margin-top: 10px;">
                        <li><strong>usernames:</strong> adventureland, beechbend, bigdamwaterpark, ... (48 total)</li>
                        <li><strong>passwords:</strong> Pre-set to company-specific (as provided)</li>
                        <li><strong>companies:</strong> Full address, city, state, zip, country</li>
                        <li><strong>units:</strong> Number of pools (6-101 units per park)</li>
                        <li><strong>equipment:</strong> Lock types, master codes, key codes</li>
                    </ul>
                </div>
                
                <form method="post" style="margin-top: 20px;">
                    <?php wp_nonce_field('psp_bulk_import'); ?>
                    <input type="hidden" name="psp_import_action" value="1">
                    
                    <p style="margin-bottom: 10px;">
                        <strong>After import:</strong>
                    </p>
                    <ul style="margin-left: 20px; margin-bottom: 20px;">
                        <li>Partners can log in with their username and pre-set password</li>
                        <li>You can change passwords anytime in <strong>User Management</strong></li>
                        <li>All partner data is stored in database</li>
                        <li>Audit logs track all changes</li>
                    </ul>
                    
                    <button type="submit" class="button button-primary button-large" 
                            onclick="return confirm('Import all 48 partners? This cannot be undone.');">
                        ▶ Start Import Now
                    </button>
                </form>
            </div>
            
            <div class="card" style="margin-top: 20px;">
                <h3>Import Details</h3>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th>Company Name</th>
                            <th>Username</th>
                            <th>City</th>
                            <th>State</th>
                            <th>Units</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        include_once __DIR__ . '/bulk-import-partners.php';
                        if (isset($partners_data)) {
                            foreach (array_slice($partners_data, 0, 10) as $partner) {
                                echo '<tr>';
                                echo '<td>' . esc_html($partner['company_name']) . '</td>';
                                echo '<td><code>' . esc_html($partner['user_login']) . '</code></td>';
                                echo '<td>' . esc_html($partner['city']) . '</td>';
                                echo '<td>' . esc_html($partner['state']) . '</td>';
                                echo '<td>' . esc_html($partner['units']) . '</td>';
                                echo '</tr>';
                            }
                            echo '<tr><td colspan="5" style="text-align: center; font-style: italic; color: #666;">... and ' . (count($partners_data) - 10) . ' more</td></tr>';
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php
    }
}

// Initialize on plugins_loaded if not already initialized
add_action('plugins_loaded', function() {
    if (class_exists('PSP_Bulk_Import_Admin')) {
        PSP_Bulk_Import_Admin::init();
    }
});
