<?php
/**
 * Security Headers Class
 * File: includes/class-psp-security-headers.php
 * 
 * Implements HTTP security headers (CSP, HSTS, X-Frame-Options, etc).
 * 
 * @package PoolSafe_Portal
 * @subpackage Security
 * @since 3.0.0
 * @author PoolSafe Team
 */

class PSP_Security_Headers {

    /**
     * Initialize security headers
     */
    public static function init() {
        add_action( 'wp_headers', [ __CLASS__, 'add_security_headers' ] );
        add_action( 'template_redirect', [ __CLASS__, 'send_headers' ], 1 );
    }

    /**
     * Add security headers via WordPress hooks
     *
     * @param array $headers Headers array
     * @return array Modified headers array
     */
    public static function add_security_headers( $headers ) {
        $headers = array_merge( $headers, self::get_headers() );
        return $headers;
    }

    /**
     * Send headers directly (for non-WordPress responses)
     */
    public static function send_headers() {
        if ( headers_sent() ) {
            return;
        }

        foreach ( self::get_headers() as $name => $value ) {
            header( "$name: $value" );
        }
    }

    /**
     * Get all security headers
     *
     * @return array Headers to send
     */
    public static function get_headers() {
        $headers = [];

        // Content Security Policy
        $headers['Content-Security-Policy'] = self::get_csp_policy();

        // HTTP Strict Transport Security
        $headers['Strict-Transport-Security'] = self::get_hsts_policy();

        // X-Frame-Options (clickjacking protection)
        $headers['X-Frame-Options'] = 'SAMEORIGIN';

        // X-Content-Type-Options (MIME sniffing protection)
        $headers['X-Content-Type-Options'] = 'nosniff';

        // X-XSS-Protection (browser XSS filter)
        $headers['X-XSS-Protection'] = '1; mode=block';

        // Referrer-Policy
        $headers['Referrer-Policy'] = 'strict-origin-when-cross-origin';

        // Permissions-Policy (formerly Feature-Policy)
        $headers['Permissions-Policy'] = self::get_permissions_policy();

        // Apply filters
        return apply_filters( 'psp_security_headers', $headers );
    }

    /**
     * Get CSP policy
     *
     * @return string CSP policy string
     */
    private static function get_csp_policy() {
        $is_https = is_ssl();
        $site_url = home_url();

        $directives = [
            'default-src' => "'self'",
            'script-src' => [
                "'self'",
                'https://code.jquery.com',
                'https://cdnjs.cloudflare.com',
                'https://stackpath.bootstrapcdn.com',
                'https://cdn.jsdelivr.net',
            ],
            'style-src' => [
                "'self'",
                "'unsafe-inline'", // Required for WordPress dynamic styles
                'https://cdnjs.cloudflare.com',
                'https://stackpath.bootstrapcdn.com',
                'https://fonts.googleapis.com',
            ],
            'font-src' => [
                "'self'",
                'https://fonts.gstatic.com',
                'https://cdnjs.cloudflare.com',
            ],
            'img-src' => [
                "'self'",
                'data:',
                'https:',
            ],
            'connect-src' => [
                "'self'",
                'https://chart.googleapis.com', // For QR codes in 2FA
            ],
            'frame-ancestors' => "'none'",
            'base-uri' => "'self'",
            'form-action' => "'self'",
        ];

        // Allow inline scripts for WordPress admin
        if ( is_admin() ) {
            $directives['script-src'][] = "'unsafe-inline'";
            $directives['script-src'][] = "'unsafe-eval'";
        }

        // Apply filters for custom policies
        $directives = apply_filters( 'psp_csp_directives', $directives );

        // Build policy string
        $policy = '';
        foreach ( $directives as $directive => $sources ) {
            $sources = is_array( $sources ) ? implode( ' ', $sources ) : $sources;
            $policy .= "$directive $sources; ";
        }

        return trim( $policy );
    }

    /**
     * Get HSTS policy
     *
     * @return string HSTS header value
     */
    private static function get_hsts_policy() {
        // max-age: 31536000 = 1 year
        // includeSubDomains: apply to all subdomains
        // preload: allow inclusion in HSTS preload list
        return 'max-age=31536000; includeSubDomains; preload';
    }

    /**
     * Get Permissions-Policy (Feature-Policy)
     *
     * @return string Permissions-Policy header value
     */
    private static function get_permissions_policy() {
        $policies = [
            'accelerometer' => '()',
            'ambient-light-sensor' => '()',
            'autoplay' => '()',
            'camera' => '()',
            'encrypted-media' => '()',
            'fullscreen' => '()',
            'geolocation' => '()',
            'gyroscope' => '()',
            'magnetometer' => '()',
            'microphone' => '()',
            'midi' => '()',
            'payment' => '()',
            'picture-in-picture' => '()',
            'sync-xhr' => '()',
            'usb' => '()',
            'vr' => '()',
            'xr-spatial-tracking' => '()',
        ];

        $policies = apply_filters( 'psp_permissions_policy', $policies );

        $policy = '';
        foreach ( $policies as $feature => $allowlist ) {
            $policy .= "$feature$allowlist, ";
        }

        return rtrim( $policy, ', ' );
    }

    /**
     * Check if security headers are being sent
     *
     * @return array Headers that are currently set
     */
    public static function check_headers() {
        $headers = self::get_headers();
        $active_headers = [];

        foreach ( $headers as $name => $value ) {
            // Check if header is set in response
            if ( function_exists( 'headers_list' ) ) {
                foreach ( headers_list() as $header ) {
                    if ( stripos( $header, $name ) === 0 ) {
                        $active_headers[ $name ] = true;
                        break;
                    }
                }
            }
        }

        return $active_headers;
    }

    /**
     * Log security header issues
     *
     * @param string $issue Issue description
     * @param string $header Header name
     */
    public static function log_issue( $issue, $header = '' ) {
        $log = [
            'timestamp' => current_time( 'mysql' ),
            'issue' => $issue,
            'header' => $header,
            'url' => $_SERVER['REQUEST_URI'] ?? '',
            'ip' => PSP_Rate_Limiter::get_client_ip(),
        ];

        do_action( 'psp_security_header_issue', $log );

        // Store in options for debugging
        $history = get_option( 'psp_security_header_issues', [] );
        $history[] = $log;

        // Keep last 100 issues
        if ( count( $history ) > 100 ) {
            $history = array_slice( $history, -100 );
        }

        update_option( 'psp_security_header_issues', $history );
    }

    /**
     * Register WP-CLI commands
     */
    public static function register_cli_commands() {
        if ( ! class_exists( 'WP_CLI' ) ) {
            return;
        }

        WP_CLI::add_command( 'psp security-headers check', [ __CLASS__, 'cli_check' ] );
        WP_CLI::add_command( 'psp security-headers test', [ __CLASS__, 'cli_test' ] );
    }

    /**
     * WP-CLI: Check security headers
     *
     * @param array $args Positional arguments
     * @param array $assoc_args Associative arguments
     */
    public static function cli_check( $args, $assoc_args ) {
        $headers = self::get_headers();

        WP_CLI::log( 'Security Headers Configuration:' );
        WP_CLI::log( '' );

        foreach ( $headers as $name => $value ) {
            WP_CLI::log( "$name:" );
            
            // Truncate long values for display
            $display_value = strlen( $value ) > 80 ? 
                substr( $value, 0, 77 ) . '...' : 
                $value;
            
            WP_CLI::log( "  $display_value" );
            WP_CLI::log( '' );
        }
    }

    /**
     * WP-CLI: Test security headers
     *
     * @param array $args Positional arguments
     * @param array $assoc_args Associative arguments
     */
    public static function cli_test( $args, $assoc_args ) {
        $headers = self::check_headers();
        $expected = self::get_headers();

        WP_CLI::log( 'Security Headers Test Results:' );
        WP_CLI::log( '' );

        $passed = 0;
        $failed = 0;

        foreach ( $expected as $name => $value ) {
            if ( isset( $headers[ $name ] ) ) {
                WP_CLI::success( "✓ $name is set" );
                $passed++;
            } else {
                WP_CLI::warning( "✗ $name is NOT set" );
                $failed++;
            }
        }

        WP_CLI::log( '' );
        WP_CLI::log( "Passed: $passed / " . count( $expected ) );
        WP_CLI::log( "Failed: $failed / " . count( $expected ) );
    }

    /**
     * Add inline nonce to scripts
     *
     * @param string $script Script content
     * @return string Script with nonce attribute
     */
    public static function add_nonce_to_script( $script ) {
        $nonce = wp_create_nonce( 'psp_script_execution' );
        return str_replace( '<script', "<script nonce=\"$nonce\"", $script );
    }
}
