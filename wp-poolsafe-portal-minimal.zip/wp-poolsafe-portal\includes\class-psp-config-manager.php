<?php
/**
 * Configuration Manager - Centralized Configuration for PoolSafe Portal
 * 
 * Best Practices:
 * - Single source of truth for all configuration
 * - Environment-aware settings and overrides
 * - Safe defaults with comprehensive validation
 * - Dot notation support for nested access
 * - Feature flags for conditional functionality
 * - Automatic frontend config injection
 * 
 * @package PSP
 * @version 3.2.5
 */

namespace PSP\Config;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * ConfigManager Class - Centralized configuration management
 */
class ConfigManager {

	/**
	 * Class version
	 */
	const VERSION = '3.2.5';

	/**
	 * Default configuration template
	 *
	 * @var array
	 */
	private static $defaults = array(
		'version'       => '3.2.5',
		'plugin_file'   => '',
		'plugin_dir'    => '',
		'plugin_url'    => '',
		'debug'         => false,
		'environment'   => 'production',
		'cache_enabled' => true,
		'cache_ttl'     => 3600,
		'cache_key_prefix' => 'psp_',
		'api'           => array(
			'namespace'     => 'psp/v1',
			'timeout'       => 30,
			'retries'       => 3,
			'retry_delay'   => 1000,
		),
		'security'      => array(
			'nonce_action'  => 'wp_rest',
			'nonce_ttl'     => 86400, // 24 hours
			'min_cap'       => 'read', // Minimum capability
			'enforce_ssl'   => false,
		),
		'features'      => array(
			'notifications' => true,
			'support_notes' => true,
			'audit_log'     => true,
			'2fa'           => false,
			'bulk_import'   => true,
			'api_logging'   => true,
		),
		'performance'   => array(
			'lazy_load_images'  => true,
			'debounce_delay'    => 250,
			'throttle_delay'    => 150,
			'enable_caching'    => true,
			'compression'       => true,
		),
		'ui'            => array(
			'theme'             => 'modern',
			'breakpoint_sm'     => 640,
			'breakpoint_md'     => 768,
			'breakpoint_lg'     => 1024,
			'breakpoint_xl'     => 1280,
			'animation_enabled' => true,
		),
		'logging'       => array(
			'enabled'       => true,
			'retention_days' => 30,
			'log_level'     => 'info', // debug, info, warning, error
		),
	);

	/**
	 * Runtime configuration (merged defaults + environment + overrides)
	 *
	 * @var array
	 */
	private static $config = array();

	/**
	 * Configuration overrides (user-provided)
	 *
	 * @var array
	 */
	private static $overrides = array();

	/**
	 * Initialization flag
	 *
	 * @var bool
	 */
	private static $initialized = false;

	/**
	 * Initialize configuration
	 *
	 * Must be called early in plugin initialization (before features are loaded)
	 *
	 * @param string $plugin_file Plugin main file path
	 * @param array  $overrides   Optional configuration overrides
	 * @return bool True if initialized successfully, false otherwise
	 *
	 * @example
	 *   ConfigManager::init(__FILE__, ['debug' => true, 'features' => ['2fa' => true]]);\n *
	 */
	public static function init( $plugin_file = '', $overrides = array() ) {
		if ( self::$initialized ) {
			return true;
		}

		// Set plugin paths
		if ( ! empty( $plugin_file ) && file_exists( $plugin_file ) ) {
			self::$defaults['plugin_file'] = $plugin_file;
			self::$defaults['plugin_dir']  = plugin_dir_path( $plugin_file );
			self::$defaults['plugin_url']  = plugin_dir_url( $plugin_file );
		}

		// Detect environment
		self::$defaults['environment'] = defined( 'WP_ENV' ) ? WP_ENV : 'production';
		self::$defaults['debug']       = defined( 'PSP_DEBUG' ) ? PSP_DEBUG : ( WP_DEBUG && WP_DEBUG_LOG );

		// Merge configurations
		self::$overrides = is_array( $overrides ) ? $overrides : array();
		self::$config    = self::merge_config( self::$defaults, self::$overrides );

		// Validate critical settings
		$valid = self::validate();

		self::$initialized = true;

		if ( ! $valid && WP_DEBUG ) {
			error_log( '[PSP] Configuration validation found issues - review logs' );
		}

		return $valid;
	}

	/**
	 * Get configuration value with dot notation support
	 *
	 * @param string $key     Configuration key (dot notation: 'api.timeout', 'features.2fa')
	 * @param mixed  $default Default value if not found
	 * @return mixed Configuration value or default
	 *
	 * @example
	 *   $timeout = ConfigManager::get('api.timeout', 30);\n *   $debug = ConfigManager::get('debug', false);
	 */
	public static function get( $key, $default = null ) {
		if ( ! self::$initialized ) {
			self::init();
		}

		if ( empty( $key ) || ! is_string( $key ) ) {
			return $default;
		}

		// Support dot notation (e.g., 'api.timeout')
		if ( false !== strpos( $key, '.' ) ) {
			return self::get_nested( self::$config, $key, $default );
		}

		return isset( self::$config[ $key ] ) ? self::$config[ $key ] : $default;
	}

	/**
	 * Get nested configuration value using dot notation
	 *
	 * @param array  $array   Array to search
	 * @param string $keys    Dot-separated keys (e.g., 'api.timeout')
	 * @param mixed  $default Default value
	 * @return mixed
	 *
	 * @example
	 *   $value = self::get_nested($config, 'api.namespace', 'psp/v1');
	 */
	private static function get_nested( $array, $keys, $default = null ) {
		if ( ! is_array( $array ) || empty( $keys ) ) {
			return $default;
		}

		$keys = explode( '.', $keys );

		foreach ( $keys as $key ) {
			if ( ! is_array( $array ) || ! isset( $array[ $key ] ) ) {
				return $default;
			}
			$array = $array[ $key ];
		}

		return $array;
	}

	/**
	 * Set configuration value at runtime
	 *
	 * Note: Only affects current request, not persisted
	 *
	 * @param string $key   Configuration key
	 * @param mixed  $value Configuration value
	 * @return void
	 *
	 * @example
	 *   ConfigManager::set('debug', true);\n *   ConfigManager::set('features.2fa', true);
	 */
	public static function set( $key, $value ) {
		if ( ! self::$initialized ) {
			self::init();
		}

		if ( empty( $key ) || ! is_string( $key ) ) {
			return;
		}

		self::$overrides[ $key ] = $value;
		self::$config[ $key ]    = $value;
	}

	/**
	 * Check if feature is enabled
	 *
	 * @param string $feature Feature name
	 * @return bool True if feature is enabled, false otherwise
	 *
	 * @example
	 *   if (ConfigManager::is_feature_enabled('2fa')) {\n     // Enable 2FA UI\n   }
	 */
	public static function is_feature_enabled( $feature ) {
		$features = self::get( 'features', array() );
		return isset( $features[ $feature ] ) ? (bool) $features[ $feature ] : false;
	}

	/**
	 * Get REST API configuration
	 *
	 * @return array REST API config with namespace, URL, nonce
	 *
	 * @example
	 *   $api_cfg = ConfigManager::get_rest_config();\n *   wp_localize_script('my-script', 'PORTAL_CONFIG', $api_cfg);
	 */
	public static function get_rest_config() {
		if ( ! self::$initialized ) {
			self::init();
		}

		$namespace = self::get( 'api.namespace', 'psp/v1' );

		return array(
			'namespace' => $namespace,
			'url'       => rest_url( $namespace ),
			'nonce'     => wp_create_nonce( 'wp_rest' ),
			'timeout'   => self::get( 'api.timeout', 30 ) * 1000, // Convert to ms for JS
		);
	}

	/**
	 * Get frontend configuration for JavaScript injection
	 *
	 * Includes user data, features, UI settings, and API config
	 *
	 * @param array $additional Additional config to merge
	 * @return array Frontend-safe configuration
	 *
	 * @example
	 *   $cfg = ConfigManager::get_frontend_config();\n *   wp_localize_script('portal-script', 'pspPortal', $cfg);
	 */
	public static function get_frontend_config( $additional = array() ) {
		if ( ! self::$initialized ) {
			self::init();
		}

		$base_config = array(
			'apiUrl'     => rest_url( self::get( 'api.namespace', 'psp/v1' ) ),
			'nonce'      => wp_create_nonce( 'wp_rest' ),
			'debug'      => self::get( 'debug', false ) && current_user_can( 'manage_options' ),
			'features'   => self::get( 'features', array() ),
			'ui'         => self::get( 'ui', array() ),
			'version'    => self::get( 'version', '3.2.5' ),
		);

		// Add user data if logged in
		if ( is_user_logged_in() ) {
			$user = wp_get_current_user();

			$base_config['user'] = array(
				'id'           => $user->ID,
				'name'         => $user->display_name,
				'email'        => $user->user_email,
				'roles'        => array_values( $user->roles ),
				'caps'         => array_keys( $user->allcaps ),
				'avatarUrl'    => get_avatar_url( $user->ID ),
			);

			// Add admin URL only for users with manage_options capability
			if ( current_user_can( 'manage_options' ) ) {
				$base_config['adminUrl'] = admin_url();
			}
		}

		// Merge additional config
		if ( is_array( $additional ) ) {
			$base_config = array_merge( $base_config, $additional );
		}

		return $base_config;
	}

	/**
	 * Merge configurations recursively
	 *
	 * @param array $base     Base configuration
	 * @param array $override Override configuration (takes precedence)
	 * @return array Merged configuration
	 */
	private static function merge_config( $base, $override ) {
		if ( ! is_array( $override ) || empty( $override ) ) {
			return $base;
		}

		foreach ( $override as $key => $value ) {
			if ( is_array( $value ) && isset( $base[ $key ] ) && is_array( $base[ $key ] ) ) {
				$base[ $key ] = self::merge_config( $base[ $key ], $value );
			} else {
				$base[ $key ] = $value;
			}
		}

		return $base;
	}

	/**
	 * Validate critical configuration values
	 *
	 * @return bool True if all critical settings are valid, false otherwise
	 */
	private static function validate() {
		$valid = true;

		// Validate plugin file if set
		if ( ! empty( self::$config['plugin_file'] ) && ! file_exists( self::$config['plugin_file'] ) ) {
			if ( WP_DEBUG ) {
				error_log( '[PSP] Invalid plugin_file in configuration' );
			}
			$valid = false;
		}

		// Validate API namespace format
		$namespace = self::get( 'api.namespace', '' );
		if ( ! empty( $namespace ) && ! preg_match( '/^[a-z0-9\/-]+$/i', $namespace ) ) {
			if ( WP_DEBUG ) {
				error_log( '[PSP] Invalid API namespace format: ' . $namespace );
			}
			$valid = false;
		}

		// Validate timeouts are reasonable
		$timeout = self::get( 'api.timeout', 30 );
		if ( ! is_numeric( $timeout ) || $timeout < 1 || $timeout > 300 ) {
			if ( WP_DEBUG ) {
				error_log( '[PSP] API timeout out of reasonable range: ' . $timeout );
			}
			$valid = false;
		}

		// Validate breakpoints are in order
		$sm = self::get( 'ui.breakpoint_sm', 640 );
		$md = self::get( 'ui.breakpoint_md', 768 );
		$lg = self::get( 'ui.breakpoint_lg', 1024 );
		if ( ! ( $sm < $md && $md < $lg ) ) {
			if ( WP_DEBUG ) {
				error_log( '[PSP] UI breakpoints not in ascending order' );
			}
			$valid = false;
		}

		return $valid;
	}

	/**
	 * Get all configuration
	 *
	 * Note: Returns a copy to prevent external modification
	 *
	 * @return array Complete configuration array
	 */
	public static function get_all() {
		if ( ! self::$initialized ) {
			self::init();
		}

		return self::$config;
	}

	/**
	 * Reset to defaults
	 *
	 * Clears all overrides and restores default configuration
	 *
	 * @return void
	 */
	public static function reset() {
		self::$config       = self::$defaults;
		self::$overrides    = array();
		self::$initialized  = false;
	}

	/**
	 * Get configuration statistics
	 *
	 * @return array Statistics including total keys, initialized status
	 */
	public static function get_stats() {
		if ( ! self::$initialized ) {
			self::init();
		}

		return array(
			'version'       => self::VERSION,
			'initialized'   => self::$initialized,
			'environment'   => self::get( 'environment', 'unknown' ),
			'debug'         => self::get( 'debug', false ),
			'total_keys'    => count( self::$config ),
			'overrides'     => count( self::$overrides ),
		);
	}

	/**
	 * Get class version
	 *
	 * @return string Version string
	 */
	public static function get_version() {
		return self::VERSION;
	}

	/**
	 * Check if configuration is initialized
	 *
	 * @return bool
	 */
	public static function is_initialized() {
		return self::$initialized;
	}

	/**
	 * Export configuration to JSON for frontend
	 * Filters sensitive values automatically
	 *
	 * @return string JSON string
	 */
	public static function export_json() {
		$config = self::get_all();
		
		// Remove sensitive data
		unset( $config['security']['nonce_action'] );
		
		return wp_json_encode( $config );
	}

	/**
	 * Create configuration backup
	 *
	 * @return array Backup data
	 */
	public static function create_backup() {
		return array(
			'timestamp' => current_time( 'mysql' ),
			'version'   => self::VERSION,
			'config'    => self::get_all(),
		);
	}

	/**
	 * Restore configuration from backup
	 *
	 * @param array $backup Backup data
	 * @return bool Success
	 */
	public static function restore_backup( $backup ) {
		if ( ! is_array( $backup ) || ! isset( $backup['config'] ) ) {
			return false;
		}

		self::$config = self::deep_merge( self::$config, $backup['config'] );
		return true;
	}

	/**
	 * Deep merge arrays (recursive)
	 *
	 * @param array $base Base array
	 * @param array $merge Array to merge
	 * @return array Merged result
	 */
	private static function deep_merge( $base, $merge ) {
		foreach ( $merge as $key => $value ) {
			if ( is_array( $value ) && isset( $base[ $key ] ) && is_array( $base[ $key ] ) ) {
				$base[ $key ] = self::deep_merge( $base[ $key ], $value );
			} else {
				$base[ $key ] = $value;
			}
		}
		return $base;
	}

	/**
	 * Get configuration difference from defaults
	 *
	 * @return array Differences
	 */
	public static function get_changes() {
		$changes = array();
		$current = self::get_all();

		array_walk_recursive( $current, function( $value, $key ) use ( &$changes, &$defaults ) {
			if ( $value !== self::get_nested( self::$defaults, $key ) ) {
				$changes[ $key ] = $value;
			}
		});

		return $changes;
	}



	/**
	 * Validate all current configuration
	 *
	 * @return array Validation errors
	 */
	public static function validate_all() {
		$errors = array();

		// Validate API config
		if ( ! preg_match( '/^[\w\/\-]+$/', self::$config['api']['namespace'] ?? '' ) ) {
			$errors[] = 'Invalid API namespace format';
		}

		if ( ! is_int( self::$config['api']['timeout'] ?? 0 ) || self::$config['api']['timeout'] < 1 ) {
			$errors[] = 'Invalid API timeout';
		}

		// Validate UI breakpoints
		$breakpoints = self::$config['ui'] ?? array();
		if ( isset( $breakpoints['breakpoint_sm'], $breakpoints['breakpoint_md'] ) ) {
			if ( $breakpoints['breakpoint_sm'] >= $breakpoints['breakpoint_md'] ) {
				$errors[] = 'Invalid breakpoint configuration (sm must be < md)';
			}
		}

		return $errors;
	}
}

