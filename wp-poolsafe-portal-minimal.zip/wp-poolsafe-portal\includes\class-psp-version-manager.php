<?php
/**
 * Version Manager Class
 * File: includes/class-psp-version-manager.php
 * 
 * Manages plugin version tracking and cache busting.
 * Automatically updates asset versions on rebuild.
 * 
 * @package PoolSafe_Portal
 * @subpackage Performance
 * @since 3.0.0
 * @author PoolSafe Team
 */

class PSP_Version_Manager {

    const MANIFEST_FILE = __DIR__ . '/../dist/.vite/manifest.json';
    const PLUGIN_VERSION_OPTION = 'psp_plugin_version';
    const ASSET_VERSION_OPTION = 'psp_asset_version';

    /**
     * Cached manifest contents.
     *
     * @var array|false|null
     */
    private static $manifest_cache = null;

    /**
     * Load Vite manifest if present.
     *
     * @return array|false
     */
    private static function get_manifest() {
        if ( null !== self::$manifest_cache ) {
            return self::$manifest_cache;
        }

        if ( ! file_exists( self::MANIFEST_FILE ) ) {
            self::$manifest_cache = false;
            return false;
        }

        $raw       = file_get_contents( self::MANIFEST_FILE );
        $manifest  = json_decode( $raw, true );
        self::$manifest_cache = is_array( $manifest ) ? $manifest : false;
        return self::$manifest_cache;
    }

    /**
     * Find a manifest entry by key or name.
     *
     * @param string $entry_key Key or name (e.g., 'psp-portal', 'js/psp-portal-app.js').
     * @return array|null
     */
    private static function get_manifest_entry( $entry_key ) {
        $manifest = self::get_manifest();
        if ( ! $manifest ) {
            return null;
        }

        // Direct key match first.
        if ( isset( $manifest[ $entry_key ] ) && is_array( $manifest[ $entry_key ] ) ) {
            return $manifest[ $entry_key ];
        }

        foreach ( $manifest as $key => $entry ) {
            if ( ! is_array( $entry ) ) {
                continue;
            }

            $name      = $entry['name'] ?? '';
            $key_base  = pathinfo( $key, PATHINFO_FILENAME );
            $entry_key_base = pathinfo( $entry_key, PATHINFO_FILENAME );

            if ( $name === $entry_key || $name === $entry_key_base || $key === $entry_key || $key_base === $entry_key || $key_base === $entry_key_base ) {
                return $entry;
            }
        }

        return null;
    }

    /**
     * Initialize version manager
     */
    public static function init() {
        add_action( 'wp_enqueue_scripts', [ __CLASS__, 'enqueue_assets' ] );
        add_action( 'admin_enqueue_scripts', [ __CLASS__, 'enqueue_admin_assets' ] );
    }

    /**
     * Get current plugin version
     *
     * @return string Version number
     */
    public static function get_plugin_version() {
        return get_option( self::PLUGIN_VERSION_OPTION, PSP_VERSION );
    }

    /**
     * Get asset version hash
     *
     * @return string Version hash
     */
    public static function get_asset_version() {
        return get_option( self::ASSET_VERSION_OPTION, PSP_VERSION );
    }

    /**
     * Generate version hash from built files
     *
     * @return string Generated hash
     */
    public static function generate_asset_hash() {
        $plugin_dir = WP_PLUGIN_DIR . '/wp-poolsafe-portal/';
        $dist_dir   = $plugin_dir . 'dist/';

        $files = [
            self::get_manifest_asset_path( 'js/psp-portal-app.js' ) ?: $plugin_dir . 'js/psp-portal-app.js',
            self::get_manifest_asset_path( 'js/api-client.js' ) ?: $plugin_dir . 'js/api-client.js',
            $plugin_dir . 'css/portal-shortcode.css',
        ];
        
        $hash_source = '';
        foreach ( $files as $file ) {
            if ( file_exists( $file ) ) {
                $hash_source .= $file . '::' . filemtime( $file ) . ';';
            }
        }
        
        return md5( $hash_source );
    }

    /**
     * Resolve an asset path from the manifest entry.
     *
     * @param string $entry_key Manifest key or name.
     * @return string|null Absolute path or null if not found.
     */
    private static function get_manifest_asset_path( $entry_key ) {
        $entry = self::get_manifest_entry( $entry_key );
        if ( ! $entry || empty( $entry['file'] ) ) {
            return null;
        }

        $rel_path = ltrim( $entry['file'], '/\\' );
        $abs_path = WP_PLUGIN_DIR . '/wp-poolsafe-portal/dist/' . $rel_path;
        return file_exists( $abs_path ) ? $abs_path : null;
    }

    /**
     * Update asset version on rebuild
     */
    public static function update_asset_version() {
        $new_hash = self::generate_asset_hash();
        update_option( self::ASSET_VERSION_OPTION, $new_hash );
    }

    /**
     * Enqueue frontend assets
     */
    public static function enqueue_assets() {
        // Only enqueue on portal pages
        if ( ! is_front_end_portal_page() ) {
            return;
        }
        
        $version         = self::get_asset_version();
        $dist_base_url   = plugins_url( 'dist/', PSP_PLUGIN_FILE );
        $dist_base_path  = trailingslashit( plugin_dir_path( PSP_PLUGIN_FILE ) . 'dist' );

        $portal_entry    = self::get_manifest_entry( 'js/psp-portal-app.js' );
        $portal_rel      = $portal_entry['file'] ?? 'psp-portal.min.js';
        $portal_abs      = $dist_base_path . ltrim( $portal_rel, '/\\' );
        $portal_url      = $dist_base_url . ltrim( $portal_rel, '/\\' );

        if ( ! file_exists( $portal_abs ) ) {
            $portal_abs = $dist_base_path . 'psp-portal.min.js';
            $portal_url = plugins_url( 'dist/psp-portal.min.js', PSP_PLUGIN_FILE );
        }

        $api_entry = self::get_manifest_entry( 'js/api-client.js' );
        $api_rel   = $api_entry['file'] ?? 'api-client.min.js';
        $api_abs   = $dist_base_path . ltrim( $api_rel, '/\\' );
        $api_url   = $dist_base_url . ltrim( $api_rel, '/\\' );

        if ( ! file_exists( $api_abs ) ) {
            $api_abs = $dist_base_path . 'api-client.min.js';
            $api_url = plugins_url( 'dist/api-client.min.js', PSP_PLUGIN_FILE );
        }

        // Enqueue main CSS
        wp_enqueue_style(
            'psp-portal-css',
            plugins_url( 'css/portal-shortcode.css', PSP_PLUGIN_FILE ),
            [],
            $version
        );
        
        // Enqueue main JS (hashed when available)
        wp_enqueue_script(
            'psp-portal-app',
            $portal_url,
            [],
            $version,
            true
        );
        
        // Enqueue API client (hashed when available)
        wp_enqueue_script(
            'psp-api-client',
            $api_url,
            [],
            $version,
            true
        );
        
        // Localize script with essential data
        wp_localize_script(
            'psp-portal-app',
            'PSP',
            [
                'apiUrl'      => rest_url( 'psp/v1' ),
                'nonce'       => wp_create_nonce( 'wp_rest' ),
                'version'     => self::get_plugin_version(),
                'debug'       => defined( 'WP_DEBUG' ) && WP_DEBUG,
                'homeUrl'     => home_url(),
            ]
        );
    }

    /**
     * Enqueue admin assets
     */
    public static function enqueue_admin_assets() {
        // Only enqueue in PSP admin pages
        if ( ! isset( $_GET['page'] ) || strpos( $_GET['page'], 'psp' ) === false ) {
            return;
        }
        
        $version = self::get_asset_version();
        
        // Enqueue admin CSS
        wp_enqueue_style(
            'psp-admin-css',
            plugins_url( 'css/admin.css', PSP_PLUGIN_FILE ),
            [],
            $version
        );
        
        // Enqueue admin JS if exists
        if ( file_exists( WP_PLUGIN_DIR . '/wp-poolsafe-portal/dist/admin.min.js' ) ) {
            wp_enqueue_script(
                'psp-admin-app',
                plugins_url( 'dist/admin.min.js', PSP_PLUGIN_FILE ),
                [],
                $version,
                true
            );
        }
    }

    /**
     * Get asset URL with cache busting parameter
     *
     * @param string $relative_path Path relative to plugin root
     * @return string Full URL with version parameter
     */
    public static function get_asset_url( $relative_path ) {
        $version = self::get_asset_version();
        $url = plugins_url( $relative_path, PSP_PLUGIN_FILE );
        return add_query_arg( 'v', $version, $url );
    }

    /**
     * Check if assets are outdated (plugin updated but assets not rebuilt)
     *
     * @return bool True if assets need rebuild
     */
    public static function needs_rebuild() {
        $plugin_version = self::get_plugin_version();
        $asset_version = self::get_asset_version();
        
        return $plugin_version !== $asset_version;
    }

    /**
     * Check and clear incompatible caches on version change
     */
    public static function check_version_change() {
        $current_version = get_option( self::PLUGIN_VERSION_OPTION );
        
        if ( $current_version !== PSP_VERSION ) {
            // Version changed, clear relevant caches
            PSP_Query_Cache::clear_all();
            PSP_Cache_Manager::clear_all();
            
            // Update version
            update_option( self::PLUGIN_VERSION_OPTION, PSP_VERSION );
            
            // Update asset version
            self::update_asset_version();
        }
    }

    /**
     * Register WP-CLI command for asset updates
     */
    public static function register_cli_commands() {
        if ( ! class_exists( 'WP_CLI' ) ) {
            return;
        }
        
        WP_CLI::add_command( 'psp update-assets', [ __CLASS__, 'cli_update_assets' ] );
    }

    /**
     * WP-CLI command to update assets
     *
     * @param array $args Command arguments
     */
    public static function cli_update_assets( $args ) {
        self::update_asset_version();
        WP_CLI::success( 'Asset version updated: ' . self::get_asset_version() );
    }
}

/**
 * Helper function to check if on portal page
 *
 * @return bool
 */
function is_front_end_portal_page() {
    if ( is_admin() ) {
        return false;
    }
    
    // Check if it's a PSP portal page
    $portal_pages = get_option( 'psp_portal_pages', [] );
    return in_array( get_the_ID(), $portal_pages, true ) || is_page( 'poolsafe-portal' );
}
