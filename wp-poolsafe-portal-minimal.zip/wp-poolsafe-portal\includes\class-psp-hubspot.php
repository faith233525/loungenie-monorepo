<?php
/**
 * HubSpot Integration
 *
 * @link       https://poolsafe.com
 * @since      1.0.0
 *
 * @package    PoolSafe_Portal
 * @subpackage PoolSafe_Portal/includes
 */

/**
 * Handle HubSpot CRM synchronization
 * Syncs tickets, partners, and service records to HubSpot
 *
 * @since      1.0.0
 * @package    PoolSafe_Portal
 */
class PSP_HubSpot {

	/**
	 * HubSpot API base URL
	 */
	const API_BASE = 'https://api.hubapi.com';

	/**
	 * HubSpot API key (from settings)
	 *
	 * @var string
	 */
	private static $api_key;

	/**
	 * Initialize HubSpot integration
	 *
	 * @since    1.0.0
	 */
	public static function init() {
		// Require explicit enable toggle and API token (HubSpot private app token)
		$enabled       = get_option( 'psp_hubspot_enabled' );
		self::$api_key = get_option( 'psp_hubspot_api_key' );

		if ( '1' !== (string) $enabled || ! self::$api_key ) {
			return;
		}

		// Hook into ticket creation
		add_action( 'psp_ticket_created', array( __CLASS__, 'sync_ticket_to_hubspot' ), 10, 2 );

		// Hook into ticket updates
		add_action( 'psp_ticket_updated', array( __CLASS__, 'update_hubspot_deal' ), 10, 3 );

		// Hook into ticket status changes
		add_action( 'psp_ticket_status_changed', array( __CLASS__, 'sync_ticket_status' ), 10, 3 );

		// Hook into ticket assignment
		add_action( 'psp_ticket_assigned', array( __CLASS__, 'sync_ticket_assignment' ), 10, 3 );

		// Hook into service record creation
		add_action( 'psp_service_record_created', array( __CLASS__, 'sync_service_record' ), 10, 2 );

		// Hook into partner creation
		add_action( 'psp_partner_created', array( __CLASS__, 'sync_partner_to_hubspot' ), 10, 1 );

		// Hook into partner updates
		add_action( 'psp_partner_updated', array( __CLASS__, 'update_hubspot_company' ), 10, 3 );
	}

	/**
	 * Sync ticket to HubSpot as a deal
	 *
	 * @param int   $ticket_id Ticket ID
	 * @param array $ticket_data Ticket data
	 * @return bool|WP_Error
	 */
	public static function sync_ticket_to_hubspot( $ticket_id, $ticket_data = null ) {
		global $wpdb;

		if ( ! self::$api_key ) {
			return false;
		}

		// Get ticket from database
		if ( ! $ticket_data ) {
			$ticket = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT * FROM {$wpdb->prefix}psp_tickets WHERE id = %d",
					$ticket_id
				)
			);
		} else {
			$ticket = (object) $ticket_data;
		}

		if ( ! $ticket ) {
			return new WP_Error( 'ticket_not_found', 'Ticket not found' );
		}

		// Get partner/company info
		$partner = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}psp_partners WHERE id = %d",
				$ticket->partner_id
			)
		);

		// Get creator info
		$creator = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}psp_users WHERE id = %d",
				$ticket->created_by_user_id
			)
		);

		// Prepare deal data for HubSpot
		$deal_data = array(
			'properties' => array(
				array(
					'name'  => 'dealname',
					'value' => $ticket->title,
				),
				array(
					'name'  => 'description',
					'value' => $ticket->description,
				),
				array(
					'name'  => 'dealstage',
					'value' => self::map_ticket_status( $ticket->status ),
				),
				array(
					'name'  => 'amount',
					'value' => '0', // Default, can be customized
				),
				array(
					'name'  => 'priority',
					'value' => strtoupper( $ticket->priority ),
				),
				array(
					'name'  => 'ticket_id',
					'value' => (string) $ticket_id,
				),
				array(
					'name'  => 'ticket_number',
					'value' => $ticket->ticket_number,
				),
				array(
					'name'  => 'created_date',
					'value' => strtotime( $ticket->created_at ) * 1000, // HubSpot wants milliseconds
				),
			),
		);

		// Create deal in HubSpot
		$deal_id = self::create_deal( $deal_data );

		if ( is_wp_error( $deal_id ) ) {
			self::log_sync_error( $ticket_id, 'deal_creation_failed', $deal_id->get_error_message() );
			return $deal_id;
		}

		// Store HubSpot deal ID in database
		update_option( "psp_hubspot_deal_{$ticket_id}", $deal_id );

		// Associate deal with company (if partner exists)
		if ( $partner ) {
			$company_id = self::get_or_create_company( $partner );
			if ( $company_id && ! is_wp_error( $company_id ) ) {
				self::associate_deal_to_company( $deal_id, $company_id );
			}
		}

		// Associate deal with contact (if creator exists)
		if ( $creator ) {
			$contact_id = self::get_or_create_contact( $creator );
			if ( $contact_id && ! is_wp_error( $contact_id ) ) {
				self::associate_deal_to_contact( $deal_id, $contact_id );
			}
		}

		self::log_sync_success( $ticket_id, 'ticket_synced', "Deal ID: {$deal_id}" );

		return $deal_id;
	}

	/**
	 * Update HubSpot deal when ticket is updated
	 *
	 * @param int   $ticket_id Ticket ID
	 * @param array $old_data Old ticket data
	 * @param array $new_data New ticket data
	 * @return bool|WP_Error
	 */
	public static function update_hubspot_deal( $ticket_id, $old_data, $new_data ) {
		if ( ! self::$api_key ) {
			return false;
		}

		// Get stored HubSpot deal ID
		$deal_id = get_option( "psp_hubspot_deal_{$ticket_id}" );

		if ( ! $deal_id ) {
			// If no deal exists, create one
			return self::sync_ticket_to_hubspot( $ticket_id, $new_data );
		}

		// Prepare updated properties
		$properties = array();

		if ( isset( $new_data['title'] ) && $new_data['title'] !== $old_data['title'] ) {
			$properties[] = array(
				'name'  => 'dealname',
				'value' => $new_data['title'],
			);
		}

		if ( isset( $new_data['description'] ) && $new_data['description'] !== $old_data['description'] ) {
			$properties[] = array(
				'name'  => 'description',
				'value' => $new_data['description'],
			);
		}

		if ( isset( $new_data['priority'] ) && $new_data['priority'] !== $old_data['priority'] ) {
			$properties[] = array(
				'name'  => 'priority',
				'value' => strtoupper( $new_data['priority'] ),
			);
		}

		if ( empty( $properties ) ) {
			return true; // No changes to sync
		}

		// Update deal in HubSpot
		$result = self::update_deal( $deal_id, $properties );

		if ( is_wp_error( $result ) ) {
			self::log_sync_error( $ticket_id, 'deal_update_failed', $result->get_error_message() );
			return $result;
		}

		self::log_sync_success( $ticket_id, 'ticket_updated', "Deal {$deal_id} updated" );

		return true;
	}

	/**
	 * Sync ticket status change to HubSpot
	 *
	 * @param int    $ticket_id Ticket ID
	 * @param string $old_status Old status
	 * @param string $new_status New status
	 * @return bool|WP_Error
	 */
	public static function sync_ticket_status( $ticket_id, $old_status, $new_status ) {
		if ( ! self::$api_key ) {
			return false;
		}

		$deal_id = get_option( "psp_hubspot_deal_{$ticket_id}" );

		if ( ! $deal_id ) {
			return false;
		}

		$properties = array(
			array(
				'name'  => 'dealstage',
				'value' => self::map_ticket_status( $new_status ),
			),
		);

		return self::update_deal( $deal_id, $properties );
	}

	/**
	 * Sync ticket assignment to HubSpot
	 *
	 * @param int    $ticket_id Ticket ID
	 * @param int    $assigned_user_id Assigned user ID
	 * @param int    $previous_user_id Previous user ID
	 * @return bool|WP_Error
	 */
	public static function sync_ticket_assignment( $ticket_id, $assigned_user_id, $previous_user_id ) {
		if ( ! self::$api_key ) {
			return false;
		}

		global $wpdb;

		$deal_id = get_option( "psp_hubspot_deal_{$ticket_id}" );

		if ( ! $deal_id ) {
			return false;
		}

		// Get assigned user info
		$user = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}psp_users WHERE id = %d",
				$assigned_user_id
			)
		);

		if ( ! $user ) {
			return false;
		}

		// Get or create HubSpot contact for assigned user
		$contact_id = self::get_or_create_contact( $user );

		if ( ! $contact_id || is_wp_error( $contact_id ) ) {
			return false;
		}

		// Associate deal with contact
		return self::associate_deal_to_contact( $deal_id, $contact_id );
	}

	/**
	 * Sync service record to HubSpot as a deal
	 *
	 * @param int $service_record_id Service record ID
	 * @param int $partner_id Partner/company ID
	 * @return bool|WP_Error
	 */
	public static function sync_service_record( $service_record_id, $partner_id ) {
		global $wpdb;

		if ( ! self::$api_key ) {
			return false;
		}

		// Get service record
		$service = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}psp_service_records WHERE id = %d",
				$service_record_id
			)
		);

		if ( ! $service ) {
			return new WP_Error( 'service_record_not_found', 'Service record not found' );
		}

		// Get partner info
		$partner = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}psp_partners WHERE id = %d",
				$partner_id
			)
		);

		// Prepare deal data
		$deal_data = array(
			'properties' => array(
				array(
					'name'  => 'dealname',
					'value' => 'Service: ' . $service->service_type . ' - ' . $partner->company_name,
				),
				array(
					'name'  => 'description',
					'value' => $service->description,
				),
				array(
					'name'  => 'dealstage',
					'value' => self::map_service_status( $service->status ),
				),
				array(
					'name'  => 'service_record_id',
					'value' => (string) $service_record_id,
				),
				array(
					'name'  => 'service_type',
					'value' => $service->service_type,
				),
				array(
					'name'  => 'service_date',
					'value' => strtotime( $service->service_date ) * 1000,
				),
			),
		);

		// Create deal
		$deal_id = self::create_deal( $deal_data );

		if ( is_wp_error( $deal_id ) ) {
			self::log_sync_error( $service_record_id, 'service_deal_creation_failed', $deal_id->get_error_message() );
			return $deal_id;
		}

		// Store deal ID
		update_option( "psp_hubspot_service_{$service_record_id}", $deal_id );

		// Associate with company
		if ( $partner ) {
			$company_id = self::get_or_create_company( $partner );
			if ( $company_id && ! is_wp_error( $company_id ) ) {
				self::associate_deal_to_company( $deal_id, $company_id );
			}
		}

		self::log_sync_success( $service_record_id, 'service_synced', "Deal ID: {$deal_id}" );

		return $deal_id;
	}

	/**
	 * Sync partner to HubSpot as a company
	 *
	 * @param int $partner_id Partner ID
	 * @return bool|WP_Error
	 */
	public static function sync_partner_to_hubspot( $partner_id ) {
		global $wpdb;

		if ( ! self::$api_key ) {
			return false;
		}

		// Get partner
		$partner = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}psp_partners WHERE id = %d",
				$partner_id
			)
		);

		if ( ! $partner ) {
			return new WP_Error( 'partner_not_found', 'Partner not found' );
		}

		return self::get_or_create_company( $partner );
	}

	/**
	 * Update HubSpot company when partner is updated
	 *
	 * @param int   $partner_id Partner ID
	 * @param array $old_data Old partner data
	 * @param array $new_data New partner data
	 * @return bool|WP_Error
	 */
	public static function update_hubspot_company( $partner_id, $old_data, $new_data ) {
		if ( ! self::$api_key ) {
			return false;
		}

		$company_id = get_option( "psp_hubspot_company_{$partner_id}" );

		if ( ! $company_id ) {
			// If no company exists, create one
			return self::sync_partner_to_hubspot( $partner_id );
		}

		// Prepare updated properties
		$properties = array();

		if ( isset( $new_data['company_name'] ) && $new_data['company_name'] !== $old_data['company_name'] ) {
			$properties[] = array(
				'name'  => 'name',
				'value' => $new_data['company_name'],
			);
		}

		if ( isset( $new_data['phone'] ) && $new_data['phone'] !== $old_data['phone'] ) {
			$properties[] = array(
				'name'  => 'phone',
				'value' => $new_data['phone'],
			);
		}

		if ( isset( $new_data['email'] ) && $new_data['email'] !== $old_data['email'] ) {
			$properties[] = array(
				'name'  => 'twitterhandle',
				'value' => $new_data['email'], // Using email as identifier
			);
		}

		if ( empty( $properties ) ) {
			return true;
		}

		return self::update_company( $company_id, $properties );
	}

	/**
	 * Get or create a company in HubSpot
	 *
	 * @param object $partner Partner object
	 * @return int|WP_Error Company ID or error
	 */
	private static function get_or_create_company( $partner ) {
		// Check if company already exists in options
		$company_id = get_option( "psp_hubspot_company_{$partner->id}" );

		if ( $company_id ) {
			return $company_id;
		}

		// Search for company by name in HubSpot
		$company_id = self::search_company_by_name( $partner->company_name );

		if ( $company_id ) {
			// Store the mapping
			update_option( "psp_hubspot_company_{$partner->id}", $company_id );
			return $company_id;
		}

		// Company doesn't exist, create it
		$company_data = array(
			'properties' => array(
				array(
					'name'  => 'name',
					'value' => $partner->company_name,
				),
				array(
					'name'  => 'phone',
					'value' => $partner->phone ?? '',
				),
				array(
					'name'  => 'email',
					'value' => $partner->email ?? '',
				),
				array(
					'name'  => 'address',
					'value' => $partner->address ?? '',
				),
				array(
					'name'  => 'city',
					'value' => $partner->city ?? '',
				),
				array(
					'name'  => 'state',
					'value' => $partner->state ?? '',
				),
				array(
					'name'  => 'zip',
					'value' => $partner->zip ?? '',
				),
				array(
					'name'  => 'country',
					'value' => $partner->country ?? '',
				),
				array(
					'name'  => 'partner_id',
					'value' => (string) $partner->id,
				),
			),
		);

		$company_id = self::create_company( $company_data );

		if ( ! is_wp_error( $company_id ) ) {
			update_option( "psp_hubspot_company_{$partner->id}", $company_id );
		}

		return $company_id;
	}

	/**
	 * Get or create a contact in HubSpot
	 *
	 * @param object $user User object
	 * @return int|WP_Error Contact ID or error
	 */
	private static function get_or_create_contact( $user ) {
		// Check if contact already exists
		$contact_id = get_option( "psp_hubspot_contact_{$user->id}" );

		if ( $contact_id ) {
			return $contact_id;
		}

		// Search for contact by email
		$contact_id = self::search_contact_by_email( $user->email );

		if ( $contact_id ) {
			update_option( "psp_hubspot_contact_{$user->id}", $contact_id );
			return $contact_id;
		}

		// Create new contact
		$contact_data = array(
			'properties' => array(
				array(
					'name'  => 'firstname',
					'value' => $user->first_name ?? '',
				),
				array(
					'name'  => 'lastname',
					'value' => $user->last_name ?? '',
				),
				array(
					'name'  => 'email',
					'value' => $user->email,
				),
				array(
					'name'  => 'phone',
					'value' => $user->phone ?? '',
				),
				array(
					'name'  => 'user_id',
					'value' => (string) $user->id,
				),
			),
		);

		$contact_id = self::create_contact( $contact_data );

		if ( ! is_wp_error( $contact_id ) ) {
			update_option( "psp_hubspot_contact_{$user->id}", $contact_id );
		}

		return $contact_id;
	}

	/**
	 * Create a deal in HubSpot
	 *
	 * @param array $deal_data Deal data
	 * @return int|WP_Error Deal ID or error
	 */
	private static function create_deal( $deal_data ) {
		$response = wp_remote_post(
			self::API_BASE . '/crm/v3/objects/deals',
			array(
				'headers' => array(
					'Authorization' => 'Bearer ' . self::$api_key,
					'Content-Type'  => 'application/json',
				),
				'body'    => wp_json_encode( $deal_data ),
			)
		);

		return self::handle_api_response( $response, 'id' );
	}

	/**
	 * Update a deal in HubSpot
	 *
	 * @param int   $deal_id Deal ID
	 * @param array $properties Properties to update
	 * @return bool|WP_Error
	 */
	private static function update_deal( $deal_id, $properties ) {
		$response = wp_remote_request(
			self::API_BASE . "/crm/v3/objects/deals/{$deal_id}",
			array(
				'method'  => 'PATCH',
				'headers' => array(
					'Authorization' => 'Bearer ' . self::$api_key,
					'Content-Type'  => 'application/json',
				),
				'body'    => wp_json_encode(
					array(
						'properties' => $properties,
					)
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );

		if ( isset( $data['errors'] ) ) {
			return new WP_Error( 'hubspot_error', $data['message'] ?? 'HubSpot API error' );
		}

		return true;
	}

	/**
	 * Create a company in HubSpot
	 *
	 * @param array $company_data Company data
	 * @return int|WP_Error Company ID or error
	 */
	private static function create_company( $company_data ) {
		$response = wp_remote_post(
			self::API_BASE . '/crm/v3/objects/companies',
			array(
				'headers' => array(
					'Authorization' => 'Bearer ' . self::$api_key,
					'Content-Type'  => 'application/json',
				),
				'body'    => wp_json_encode( $company_data ),
			)
		);

		return self::handle_api_response( $response, 'id' );
	}

	/**
	 * Update a company in HubSpot
	 *
	 * @param int   $company_id Company ID
	 * @param array $properties Properties to update
	 * @return bool|WP_Error
	 */
	private static function update_company( $company_id, $properties ) {
		$response = wp_remote_request(
			self::API_BASE . "/crm/v3/objects/companies/{$company_id}",
			array(
				'method'  => 'PATCH',
				'headers' => array(
					'Authorization' => 'Bearer ' . self::$api_key,
					'Content-Type'  => 'application/json',
				),
				'body'    => wp_json_encode(
					array(
						'properties' => $properties,
					)
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );

		if ( isset( $data['errors'] ) ) {
			return new WP_Error( 'hubspot_error', $data['message'] ?? 'HubSpot API error' );
		}

		return true;
	}

	/**
	 * Create a contact in HubSpot
	 *
	 * @param array $contact_data Contact data
	 * @return int|WP_Error Contact ID or error
	 */
	private static function create_contact( $contact_data ) {
		$response = wp_remote_post(
			self::API_BASE . '/crm/v3/objects/contacts',
			array(
				'headers' => array(
					'Authorization' => 'Bearer ' . self::$api_key,
					'Content-Type'  => 'application/json',
				),
				'body'    => wp_json_encode( $contact_data ),
			)
		);

		return self::handle_api_response( $response, 'id' );
	}

	/**
	 * Search for a company by name
	 *
	 * @param string $company_name Company name
	 * @return int|false Company ID or false
	 */
	private static function search_company_by_name( $company_name ) {
		$response = wp_remote_post(
			self::API_BASE . '/crm/v3/objects/companies/search',
			array(
				'headers' => array(
					'Authorization' => 'Bearer ' . self::$api_key,
					'Content-Type'  => 'application/json',
				),
				'body'    => wp_json_encode(
					array(
						'filterGroups' => array(
							array(
								'filters' => array(
									array(
										'propertyName' => 'name',
										'operator'     => 'EQ',
										'value'        => $company_name,
									),
								),
							),
						),
						'limit'        => 1,
					)
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return false;
		}

		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );

		if ( isset( $data['results'][0]['id'] ) ) {
			return (int) $data['results'][0]['id'];
		}

		return false;
	}

	/**
	 * Search for a contact by email
	 *
	 * @param string $email Email address
	 * @return int|false Contact ID or false
	 */
	private static function search_contact_by_email( $email ) {
		$response = wp_remote_post(
			self::API_BASE . '/crm/v3/objects/contacts/search',
			array(
				'headers' => array(
					'Authorization' => 'Bearer ' . self::$api_key,
					'Content-Type'  => 'application/json',
				),
				'body'    => wp_json_encode(
					array(
						'filterGroups' => array(
							array(
								'filters' => array(
									array(
										'propertyName' => 'email',
										'operator'     => 'EQ',
										'value'        => $email,
									),
								),
							),
						),
						'limit'        => 1,
					)
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return false;
		}

		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );

		if ( isset( $data['results'][0]['id'] ) ) {
			return (int) $data['results'][0]['id'];
		}

		return false;
	}

	/**
	 * Associate a deal with a company
	 *
	 * @param int $deal_id Deal ID
	 * @param int $company_id Company ID
	 * @return bool|WP_Error
	 */
	private static function associate_deal_to_company( $deal_id, $company_id ) {
		$response = wp_remote_post(
			self::API_BASE . "/crm/v3/objects/deals/{$deal_id}/associations/companies/{$company_id}",
			array(
				'method'  => 'PUT',
				'headers' => array(
					'Authorization' => 'Bearer ' . self::$api_key,
					'Content-Type'  => 'application/json',
				),
				'body'    => wp_json_encode(
					array(
						'associationCategory' => 'HUBSPOTDEFINED',
						'associationType'     => 'deal_to_company',
					)
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		return true;
	}

	/**
	 * Associate a deal with a contact
	 *
	 * @param int $deal_id Deal ID
	 * @param int $contact_id Contact ID
	 * @return bool|WP_Error
	 */
	private static function associate_deal_to_contact( $deal_id, $contact_id ) {
		$response = wp_remote_post(
			self::API_BASE . "/crm/v3/objects/deals/{$deal_id}/associations/contacts/{$contact_id}",
			array(
				'method'  => 'PUT',
				'headers' => array(
					'Authorization' => 'Bearer ' . self::$api_key,
					'Content-Type'  => 'application/json',
				),
				'body'    => wp_json_encode(
					array(
						'associationCategory' => 'HUBSPOTDEFINED',
						'associationType'     => 'deal_to_contact',
					)
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		return true;
	}

	/**
	 * Handle API responses
	 *
	 * @param mixed  $response Response from wp_remote_*
	 * @param string $extract_field Field to extract from response
	 * @return mixed|WP_Error
	 */
	private static function handle_api_response( $response, $extract_field = null ) {
		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );

		if ( isset( $data['errors'] ) ) {
			return new WP_Error( 'hubspot_error', $data['message'] ?? 'HubSpot API error' );
		}

		if ( $extract_field && isset( $data[ $extract_field ] ) ) {
			return $data[ $extract_field ];
		}

		return $data;
	}

	/**
	 * Map ticket status to HubSpot deal stage
	 *
	 * @param string $status Ticket status
	 * @return string Deal stage
	 */
	private static function map_ticket_status( $status ) {
		$mapping = array(
			'open'        => 'negotiation',
			'assigned'    => 'negotiation',
			'in_progress' => 'presentation',
			'waiting'     => 'proposal',
			'resolved'    => 'closedwon',
			'closed'      => 'closedlost',
		);

		return $mapping[ $status ] ?? 'qualification';
	}

	/**
	 * Map service record status to HubSpot deal stage
	 *
	 * @param string $status Service status
	 * @return string Deal stage
	 */
	private static function map_service_status( $status ) {
		$mapping = array(
			'scheduled'   => 'negotiation',
			'in_progress' => 'presentation',
			'completed'   => 'closedwon',
			'cancelled'   => 'closedlost',
		);

		return $mapping[ $status ] ?? 'qualification';
	}

	/**
	 * Log successful sync
	 *
	 * @param int    $resource_id Resource ID
	 * @param string $action Action performed
	 * @param string $details Additional details
	 */
	private static function log_sync_success( $resource_id, $action, $details = '' ) {
		global $wpdb;

		$wpdb->insert(
			$wpdb->prefix . 'psp_audit_log',
			array(
				'user_id'      => 0, // System action
				'action'       => "hubspot_{$action}",
				'resource_type' => 'hubspot_sync',
				'resource_id'  => $resource_id,
				'new_values'   => $details,
				'ip_address'   => isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( $_SERVER['REMOTE_ADDR'] ) : '',
			)
		);
	}

	/**
	 * Log sync error
	 *
	 * @param int    $resource_id Resource ID
	 * @param string $error_type Error type
	 * @param string $error_message Error message
	 */
	private static function log_sync_error( $resource_id, $error_type, $error_message = '' ) {
		global $wpdb;

		$wpdb->insert(
			$wpdb->prefix . 'psp_audit_log',
			array(
				'user_id'      => 0,
				'action'       => "hubspot_error_{$error_type}",
				'resource_type' => 'hubspot_sync',
				'resource_id'  => $resource_id,
				'old_values'   => $error_message,
				'ip_address'   => isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( $_SERVER['REMOTE_ADDR'] ) : '',
			)
		);
	}

	/**
	 * Test HubSpot connection
	 *
	 * @param string $api_key API key to test
	 * @return bool|WP_Error True if valid, WP_Error otherwise
	 */
	public static function test_connection( $api_key ) {
		$response = wp_remote_get(
			self::API_BASE . '/crm/v3/objects/contacts?limit=1',
			array(
				'headers' => array(
					'Authorization' => 'Bearer ' . $api_key,
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$status_code = wp_remote_retrieve_response_code( $response );

		if ( 200 === $status_code ) {
			return true;
		}

		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );

		return new WP_Error( 'invalid_api_key', $data['message'] ?? 'Invalid HubSpot API key' );
	}
}
