<?php
/**
 * Performance Optimizer - Query Caching, Lazy Loading, Asset Optimization
 *
 * Features:
 * - Query result caching with TTL
 * - Lazy loading for heavy components
 * - Asset combination and minification
 * - Database query optimization
 * - Memory usage monitoring
 * - Performance metrics collection
 *
 * @package PSP
 * @version 3.2.5
 */

namespace PSP\Performance;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * PerformanceOptimizer Class
 */
class PerformanceOptimizer {

	/**
	 * Class version
	 */
	const VERSION = '3.2.5';

	/**
	 * Performance metrics storage
	 */
	private static $metrics = array(
		'queries' => 0,
		'query_time' => 0,
		'memory_peak' => 0,
		'cache_hits' => 0,
		'cache_misses' => 0,
	);

	/**
	 * Initialize performance monitoring
	 */
	public static function init() {
		// Hook into WordPress database queries
		add_action( 'wp_footer', array( __CLASS__, 'collect_metrics' ) );
		
		// Monitor database queries in debug mode
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			add_action( 'wp_footer', array( __CLASS__, 'log_performance_data' ) );
		}
	}

	/**
	 * Collect performance metrics
	 */
	public static function collect_metrics() {
		global $wpdb;

		self::$metrics['queries'] = $wpdb->num_queries;
		self::$metrics['memory_peak'] = memory_get_peak_usage( true ) / 1024 / 1024; // MB

		// Log metrics every 100 requests
		if ( ( get_option( 'psp_requests_count', 0 ) % 100 ) === 0 ) {
			update_option( 'psp_last_metrics', self::$metrics );
		}

		update_option( 'psp_requests_count', get_option( 'psp_requests_count', 0 ) + 1 );
	}

	/**
	 * Log performance data
	 */
	public static function log_performance_data() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$log = sprintf(
			'[PSP Performance] Queries: %d | Memory Peak: %.2f MB | Cache Hits: %d | Cache Misses: %d',
			self::$metrics['queries'],
			self::$metrics['memory_peak'],
			self::$metrics['cache_hits'],
			self::$metrics['cache_misses']
		);

		error_log( $log );
	}

	/**
	 * Cache query results with automatic expiration
	 *
	 * @param string   $key        Cache key
	 * @param callable $callback   Function to execute if cache miss
	 * @param int      $ttl        Time to live in seconds (default: 1 hour)
	 * @return mixed Cached or fresh result
	 */
	public static function cache_query( $key, $callback, $ttl = 3600 ) {
		$cache_key = 'psp_perf_cache_' . sanitize_key( $key );
		$cached = get_transient( $cache_key );

		if ( false !== $cached ) {
			self::$metrics['cache_hits']++;
			return $cached;
		}

		self::$metrics['cache_misses']++;
		$result = call_user_func( $callback );
		set_transient( $cache_key, $result, $ttl );

		return $result;
	}

	/**
	 * Invalidate cache by pattern
	 *
	 * @param string $pattern Cache key pattern (supports *)
	 * @return int Number of caches cleared
	 */
	public static function invalidate_cache( $pattern = '*' ) {
		global $wpdb;

		$like = str_replace( '*', '%', $pattern );
		$query = $wpdb->prepare(
			"SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s",
			'psp_perf_cache_' . $like
		);

		$keys = $wpdb->get_col( $query );
		$count = 0;

		foreach ( $keys as $key ) {
			delete_transient( str_replace( 'psp_perf_cache_', '', $key ) );
			$count++;
		}

		return $count;
	}

	/**
	 * Optimize database query with caching
	 *
	 * @param string $sql    SQL query
	 * @param array  $args   Query arguments
	 * @param int    $ttl    Cache TTL in seconds
	 * @return array Query results
	 */
	public static function optimize_query( $sql, $args = array(), $ttl = 3600 ) {
		global $wpdb;

		$cache_key = md5( $sql . serialize( $args ) );

		$result = self::cache_query(
			$cache_key,
			function() use ( $wpdb, $sql, $args ) {
				return $wpdb->get_results( $wpdb->prepare( $sql, $args ) );
			},
			$ttl
		);

		return is_array( $result ) ? $result : array();
	}

	/**
	 * Get performance metrics
	 *
	 * @return array Metrics
	 */
	public static function get_metrics() {
		return self::$metrics;
	}

	/**
	 * Get performance report
	 *
	 * @return array Performance report
	 */
	public static function get_report() {
		$metrics = self::$metrics;
		$last_metrics = get_option( 'psp_last_metrics', $metrics );

		return array(
			'current' => $metrics,
			'previous' => $last_metrics,
			'improvement' => array(
				'query_reduction' => ( $last_metrics['queries'] - $metrics['queries'] ) / max( 1, $last_metrics['queries'] ) * 100,
				'memory_savings' => ( $last_metrics['memory_peak'] - $metrics['memory_peak'] ) / max( 1, $last_metrics['memory_peak'] ) * 100,
				'cache_hit_ratio' => $metrics['cache_hits'] / max( 1, $metrics['cache_hits'] + $metrics['cache_misses'] ) * 100,
			),
		);
	}

	/**
	 * Lazy load component
	 *
	 * @param string $component_id Component ID to lazy load
	 * @param string $api_endpoint API endpoint to fetch data
	 * @return string HTML with lazy load wrapper
	 */
	public static function lazy_load_component( $component_id, $api_endpoint ) {
		$nonce = wp_create_nonce( 'psp_lazy_load' );
		
		return sprintf(
			'<div id="%s" class="psp-lazy-load" data-endpoint="%s" data-nonce="%s"><div class="psp-skeleton"></div></div>',
			esc_attr( $component_id ),
			esc_attr( $api_endpoint ),
			esc_attr( $nonce )
		);
	}

	/**
	 * Combine and minimize assets (CSS/JS)
	 *
	 * @param array  $files  Files to combine
	 * @param string $type   File type (css/js)
	 * @return string Combined asset path
	 */
	public static function combine_assets( $files, $type = 'css' ) {
		if ( empty( $files ) ) {
			return '';
		}

		$hash = md5( serialize( $files ) );
		$combined_file = wp_upload_dir()['basedir'] . '/psp-combined-' . $hash . '.' . $type;

		// If combined file doesn't exist, create it
		if ( ! file_exists( $combined_file ) ) {
			$combined_content = '';

			foreach ( $files as $file ) {
				if ( file_exists( $file ) ) {
					$combined_content .= file_get_contents( $file ) . "\n\n";
				}
			}

			if ( ! empty( $combined_content ) ) {
				// Simple minification (remove comments and extra whitespace)
				if ( $type === 'css' ) {
					$combined_content = preg_replace( '!/\*[^*]*\*+(?:[^/*][^*]*\*+)*/!', '', $combined_content );
					$combined_content = preg_replace( '/\s+/', ' ', $combined_content );
				} elseif ( $type === 'js' ) {
					$combined_content = preg_replace( '!/\*.*?\*/!s', '', $combined_content );
					$combined_content = preg_replace( '/\/\/.*$/m', '', $combined_content );
				}

				file_put_contents( $combined_file, $combined_content );
			}
		}

		return wp_upload_dir()['baseurl'] . '/psp-combined-' . $hash . '.' . $type;
	}

	/**
	 * Database query statistics
	 *
	 * @return array Query statistics
	 */
	public static function get_query_stats() {
		global $wpdb;

		return array(
			'total_queries' => $wpdb->num_queries,
			'database_time' => $wpdb->total_query_time ?? 0,
			'memory_usage' => memory_get_usage( true ) / 1024 / 1024, // MB
			'memory_peak' => memory_get_peak_usage( true ) / 1024 / 1024, // MB
		);
	}

	/**
	 * Get class version
	 *
	 * @return string Version string
	 */
	public static function get_version() {
		return self::VERSION;
	}
}

// Initialize performance optimizer
if ( ! function_exists( 'psp_init_performance' ) ) {
	function psp_init_performance() {
		if ( class_exists( 'PSP\Performance\PerformanceOptimizer' ) ) {
			PerformanceOptimizer::init();
		}
	}
	add_action( 'plugins_loaded', 'psp_init_performance' );
}
