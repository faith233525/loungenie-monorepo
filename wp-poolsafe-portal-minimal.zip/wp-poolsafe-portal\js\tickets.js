/**
 * PoolSafe Portal - Ticket System JavaScript
 */

(function ($) {
    'use strict';

    // Initialize on document ready
    $(document).ready(function () {
        initTicketFiltering();
        initTicketForm();
        initReplyForm();
        initFileUpload();
        initInternalNotes();
    });

    /**
     * Ticket List Filtering
     */
    function initTicketFiltering() {
        var $statusFilter = $('#status-filter');
        var $priorityFilter = $('#priority-filter');
        var $searchInput = $('#ticket-search');
        var $dateFrom = $('#date-from');
        var $dateTo = $('#date-to');
        var $filterBtn = $('#apply-filters');

        if ($statusFilter.length === 0) {
            return; // Not on ticket list page
        }

        // Filter on change
        $statusFilter.on('change', applyFilters);
        $priorityFilter.on('change', applyFilters);
        $dateFrom.on('change', applyFilters);
        $dateTo.on('change', applyFilters);
        $filterBtn.on('click', applyFilters);

        // Search on Enter key
        $searchInput.on('keypress', function (e) {
            if (e.which === 13) {
                e.preventDefault();
                applyFilters();
            }
        });

        function applyFilters() {
            var data = {
                action: 'psp_filter_tickets',
                nonce: PSP.nonce,
                status: $statusFilter.val(),
                priority: $priorityFilter.val(),
                search: $searchInput.val(),
                date_from: $dateFrom.val(),
                date_to: $dateTo.val(),
                page: 1
            };

            $.ajax({
                type: 'POST',
                url: PSP.ajaxUrl,
                data: data,
                beforeSend: function () {
                    $('.psp-tickets-list').after(
                        '<div class="psp-loading"><span>Loading...</span></div>'
                    );
                },
                success: function (response) {
                    if (response.success) {
                        $('.psp-tickets-list').replaceWith(response.data.html);
                        PSP.currentPage = 1;
                        initPagination();
                    }
                },
                error: function () {
                    alert('Error loading tickets. Please try again.');
                },
                complete: function () {
                    $('.psp-loading').remove();
                }
            });
        }
    }

    /**
     * Pagination
     */
    function initPagination() {
        $('.psp-pagination a').on('click', function (e) {
            e.preventDefault();
            var page = $(this).data('page');
            loadTicketsPage(page);
        });
    }

    function loadTicketsPage(page) {
        var $statusFilter = $('#status-filter');
        var $priorityFilter = $('#priority-filter');
        var $searchInput = $('#ticket-search');

        var data = {
            action: 'psp_filter_tickets',
            nonce: PSP.nonce,
            status: $statusFilter.val(),
            priority: $priorityFilter.val(),
            search: $searchInput.val(),
            page: page
        };

        $.ajax({
            type: 'POST',
            url: PSP.ajaxUrl,
            data: data,
            beforeSend: function () {
                $(window).scrollTop(0);
            },
            success: function (response) {
                if (response.success) {
                    $('.psp-tickets-list').replaceWith(response.data.html);
                    initPagination();
                }
            }
        });
    }

    /**
     * Ticket Create Form
     */
    function initTicketForm() {
        var $form = $('#create-ticket-form');

        if ($form.length === 0) {
            return; // Not on create page
        }

        $form.on('submit', function (e) {
            e.preventDefault();

            // Validate form
            if (!validateTicketForm()) {
                return;
            }

            var formData = new FormData($form[0]);
            formData.append('action', 'psp_create_ticket');
            formData.append('nonce', PSP.nonce);

            $.ajax({
                type: 'POST',
                url: PSP.ajaxUrl,
                data: formData,
                processData: false,
                contentType: false,
                beforeSend: function () {
                    $form.find('[type="submit"]').prop('disabled', true);
                },
                success: function (response) {
                    if (response.success) {
                        showMessage('Ticket created successfully!', 'success');
                        setTimeout(function () {
                            if (response.data.ticket_id) {
                                window.location.href = PSP.ticketDetailUrl + '?id=' + response.data.ticket_id;
                            } else {
                                window.location.href = PSP.ticketListUrl;
                            }
                        }, 1500);
                    } else {
                        showMessage(response.data.message || 'Error creating ticket', 'error');
                    }
                },
                error: function () {
                    showMessage('Error creating ticket. Please try again.', 'error');
                },
                complete: function () {
                    $form.find('[type="submit"]').prop('disabled', false);
                }
            });
        });

        function validateTicketForm() {
            var $subject = $form.find('input[name="subject"]');
            var $description = $form.find('textarea[name="description"]');

            if ($subject.val().trim() === '') {
                showMessage('Subject is required', 'error');
                return false;
            }

            if ($description.val().trim() === '') {
                showMessage('Description is required', 'error');
                return false;
            }

            return true;
        }
    }

    /**
     * Reply Form
     */
    function initReplyForm() {
        var $form = $('#reply-form');

        if ($form.length === 0) {
            return; // Not on detail page
        }

        $form.on('submit', function (e) {
            e.preventDefault();

            var $replyText = $form.find('textarea[name="reply"]');

            if ($replyText.val().trim() === '') {
                showMessage('Reply cannot be empty', 'error');
                return;
            }

            var formData = new FormData($form[0]);
            formData.append('action', 'psp_add_reply');
            formData.append('nonce', PSP.nonce);
            formData.append('ticket_id', PSP.ticketId);

            $.ajax({
                type: 'POST',
                url: PSP.ajaxUrl,
                data: formData,
                processData: false,
                contentType: false,
                beforeSend: function () {
                    $form.find('[type="submit"]').prop('disabled', true);
                },
                success: function (response) {
                    if (response.success) {
                        showMessage('Reply added successfully!', 'success');
                        $replyText.val('');

                        // Reload conversation
                        setTimeout(function () {
                            location.reload();
                        }, 1000);
                    } else {
                        showMessage(response.data.message || 'Error adding reply', 'error');
                    }
                },
                error: function () {
                    showMessage('Error adding reply. Please try again.', 'error');
                },
                complete: function () {
                    $form.find('[type="submit"]').prop('disabled', false);
                }
            });
        });
    }

    /**
     * File Upload Handler
     */
    function initFileUpload() {
        var $uploadArea = $('.psp-file-upload');

        if ($uploadArea.length === 0) {
            return;
        }

        var $fileInput = $uploadArea.find('input[type="file"]');

        // Click upload area to open file picker
        $uploadArea.on('click', function () {
            $fileInput.click();
        });

        // Drag and drop
        $uploadArea.on('dragover dragenter', function (e) {
            e.preventDefault();
            e.stopPropagation();
            $(this).css('background', 'var(--psp-primary-light)');
        });

        $uploadArea.on('dragleave', function (e) {
            e.preventDefault();
            $(this).css('background', '');
        });

        $uploadArea.on('drop', function (e) {
            e.preventDefault();
            e.stopPropagation();
            $(this).css('background', '');

            var files = e.originalEvent.dataTransfer.files;
            handleFiles(files);
        });

        // File input change
        $fileInput.on('change', function () {
            handleFiles(this.files);
        });

        function handleFiles(files) {
            var $container = $('.psp-uploaded-files');

            $.each(files, function (i, file) {
                if (file.size > 5242880) { // 5MB
                    showMessage('File too large: ' + file.name, 'error');
                    return;
                }

                var $item = $('<div class="psp-file-item">')
                    .html(file.name + ' (' + formatFileSize(file.size) + ')')
                    .append('<button type="button" class="remove-file">Remove</button>');

                $container.append($item);
            });
        }

        $(document).on('click', '.remove-file', function () {
            $(this).closest('.psp-file-item').remove();
        });
    }

    /**
     * Internal Notes
     */
    function initInternalNotes() {
        var $form = $('#internal-notes-form');

        if ($form.length === 0) {
            return;
        }

        $form.on('submit', function (e) {
            e.preventDefault();

            var $noteText = $form.find('textarea[name="note"]');

            if ($noteText.val().trim() === '') {
                showMessage('Note cannot be empty', 'error');
                return;
            }

            var data = {
                action: 'psp_add_internal_note',
                nonce: PSP.nonce,
                ticket_id: PSP.ticketId,
                note: $noteText.val()
            };

            $.ajax({
                type: 'POST',
                url: PSP.ajaxUrl,
                data: data,
                beforeSend: function () {
                    $form.find('[type="submit"]').prop('disabled', true);
                },
                success: function (response) {
                    if (response.success) {
                        showMessage('Note added successfully!', 'success');
                        $noteText.val('');

                        // Add note to list
                        var $noteHtml = $('<div class="psp-message internal">')
                            .html(
                                '<div class="psp-message-header">' +
                                '<span class="psp-message-author">' + response.data.author + '</span>' +
                                '<span class="psp-message-badge">Internal Note</span>' +
                                '<span class="psp-message-time">' + response.data.time + '</span>' +
                                '</div>' +
                                '<div class="psp-message-body">' + response.data.note + '</div>'
                            );

                        $('.psp-internal-notes').prepend($noteHtml);
                    } else {
                        showMessage(response.data.message || 'Error adding note', 'error');
                    }
                },
                error: function () {
                    showMessage('Error adding note. Please try again.', 'error');
                },
                complete: function () {
                    $form.find('[type="submit"]').prop('disabled', false);
                }
            });
        });
    }

    /**
     * Status & Priority Dropdown Change
     */
    $(document).on('change', '#ticket-status, #ticket-priority', function () {
        var $select = $(this);
        var field = $select.attr('id') === 'ticket-status' ? 'status' : 'priority';
        var value = $select.val();

        var data = {
            action: 'psp_update_ticket_field',
            nonce: PSP.nonce,
            ticket_id: PSP.ticketId,
            field: field,
            value: value
        };

        $.ajax({
            type: 'POST',
            url: PSP.ajaxUrl,
            data: data,
            success: function (response) {
                if (response.success) {
                    showMessage(
                        field.charAt(0).toUpperCase() + field.slice(1) + ' updated!',
                        'success'
                    );
                } else {
                    showMessage('Error updating ' + field, 'error');
                    location.reload();
                }
            }
        });
    });

    /**
     * Utility Functions
     */
    function showMessage(message, type) {
        var $alert = $('<div class="psp-message-alert ' + type + '">')
            .text(message);

        if ($('.psp-message-alert').length) {
            $('.psp-message-alert').replaceWith($alert);
        } else {
            $alert.prependTo('.psp-tickets-container, .psp-ticket-detail, .psp-ticket-form');
        }

        // Auto remove after 5 seconds
        setTimeout(function () {
            $alert.fadeOut(function () {
                $(this).remove();
            });
        }, 5000);
    }

    function formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        var k = 1024;
        var sizes = ['Bytes', 'KB', 'MB', 'GB'];
        var i = Math.floor(Math.log(bytes) / Math.log(k));
        return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
    }

})(jQuery);
