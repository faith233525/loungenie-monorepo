<?php

namespace PSP;

/**
 * GDPR Database Setup
 * 
 * Creates necessary database tables for GDPR compliance features.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class GDPR_DB_Setup {

	/**
	 * Create GDPR tables
	 * 
	 * @return void
	 */
	public static function create_tables(): void {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		// GDPR Exports table
		$table_exports = $wpdb->prefix . 'psp_gdpr_exports';
		if ( $wpdb->get_var( "SHOW TABLES LIKE '$table_exports'" ) !== $table_exports ) {
			$sql = "CREATE TABLE $table_exports (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				user_id bigint(20) unsigned NOT NULL,
				format varchar(10) NOT NULL DEFAULT 'json',
				data longtext NOT NULL,
				created_at datetime NOT NULL,
				expires_at datetime NOT NULL,
				downloaded tinyint(1) NOT NULL DEFAULT 0,
				downloaded_at datetime,
				PRIMARY KEY (id),
				KEY user_id (user_id),
				KEY expires_at (expires_at)
			) $charset_collate;";

			require_once ABSPATH . 'wp-admin/includes/upgrade.php';
			dbDelta( $sql );
		}

		// GDPR Deletions table
		$table_deletions = $wpdb->prefix . 'psp_gdpr_deletions';
		if ( $wpdb->get_var( "SHOW TABLES LIKE '$table_deletions'" ) !== $table_deletions ) {
			$sql = "CREATE TABLE $table_deletions (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				user_id bigint(20) unsigned NOT NULL,
				status enum('pending', 'confirmed', 'cancelled', 'completed') NOT NULL DEFAULT 'pending',
				token varchar(255) NOT NULL,
				reason text,
				requested_at datetime NOT NULL,
				confirmed_at datetime,
				deleted_at datetime,
				expires_at datetime NOT NULL,
				PRIMARY KEY (id),
				KEY user_id (user_id),
				KEY status (status),
				KEY expires_at (expires_at),
				UNIQUE KEY token (token)
			) $charset_collate;";

			require_once ABSPATH . 'wp-admin/includes/upgrade.php';
			dbDelta( $sql );
		}

		// GDPR Consents table
		$table_consents = $wpdb->prefix . 'psp_gdpr_consents';
		if ( $wpdb->get_var( "SHOW TABLES LIKE '$table_consents'" ) !== $table_consents ) {
			$sql = "CREATE TABLE $table_consents (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				user_id bigint(20) unsigned NOT NULL,
				type varchar(50) NOT NULL,
				given tinyint(1) NOT NULL DEFAULT 0,
				created_at datetime NOT NULL,
				updated_at datetime NOT NULL,
				PRIMARY KEY (id),
				KEY user_id (user_id),
				KEY type (type),
				UNIQUE KEY user_type (user_id, type)
			) $charset_collate;";

			require_once ABSPATH . 'wp-admin/includes/upgrade.php';
			dbDelta( $sql );
		}

		// GDPR Consent Log table (for unauthenticated users)
		$table_consent_log = $wpdb->prefix . 'psp_gdpr_consent_log';
		if ( $wpdb->get_var( "SHOW TABLES LIKE '$table_consent_log'" ) !== $table_consent_log ) {
			$sql = "CREATE TABLE $table_consent_log (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				user_id bigint(20) unsigned,
				type varchar(50) NOT NULL,
				given tinyint(1) NOT NULL DEFAULT 0,
				source varchar(100),
				ip_address varchar(45),
				user_agent text,
				created_at datetime NOT NULL,
				PRIMARY KEY (id),
				KEY user_id (user_id),
				KEY type (type),
				KEY created_at (created_at)
			) $charset_collate;";

			require_once ABSPATH . 'wp-admin/includes/upgrade.php';
			dbDelta( $sql );
		}

		// GDPR Archives table (for deleted user data retention)
		$table_archives = $wpdb->prefix . 'psp_gdpr_archives';
		if ( $wpdb->get_var( "SHOW TABLES LIKE '$table_archives'" ) !== $table_archives ) {
			$sql = "CREATE TABLE $table_archives (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				user_id bigint(20) unsigned NOT NULL,
				archived longtext NOT NULL,
				archived_at datetime NOT NULL,
				retention_until datetime,
				PRIMARY KEY (id),
				KEY user_id (user_id),
				KEY retention_until (retention_until)
			) $charset_collate;";

			require_once ABSPATH . 'wp-admin/includes/upgrade.php';
			dbDelta( $sql );
		}

		// Data Processing Agreement table
		$table_dpa = $wpdb->prefix . 'psp_gdpr_dpa';
		if ( $wpdb->get_var( "SHOW TABLES LIKE '$table_dpa'" ) !== $table_dpa ) {
			$sql = "CREATE TABLE $table_dpa (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				user_id bigint(20) unsigned NOT NULL,
				processing_purpose text NOT NULL,
				processor_info text,
				retention_period varchar(100),
				legal_basis varchar(100),
				accepted tinyint(1) NOT NULL DEFAULT 0,
				accepted_at datetime,
				version int NOT NULL DEFAULT 1,
				created_at datetime NOT NULL,
				updated_at datetime NOT NULL,
				PRIMARY KEY (id),
				KEY user_id (user_id),
				KEY legal_basis (legal_basis)
			) $charset_collate;";

			require_once ABSPATH . 'wp-admin/includes/upgrade.php';
			dbDelta( $sql );
		}

		// Data Breach Log table
		$table_breach = $wpdb->prefix . 'psp_gdpr_breach_log';
		if ( $wpdb->get_var( "SHOW TABLES LIKE '$table_breach'" ) !== $table_breach ) {
			$sql = "CREATE TABLE $table_breach (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				description text NOT NULL,
				affected_users int,
				data_categories text,
				discovery_date datetime NOT NULL,
				notification_sent tinyint(1) NOT NULL DEFAULT 0,
				reported_to_authority tinyint(1) NOT NULL DEFAULT 0,
				authority_reference varchar(255),
				remediation text,
				created_at datetime NOT NULL,
				PRIMARY KEY (id),
				KEY discovery_date (discovery_date)
			) $charset_collate;";

			require_once ABSPATH . 'wp-admin/includes/upgrade.php';
			dbDelta( $sql );
		}
	}

	/**
	 * Drop GDPR tables on uninstall
	 * 
	 * @return void
	 */
	public static function drop_tables(): void {
		global $wpdb;

		// Only drop tables if explicitly configured
		if ( ! get_option( 'psp_gdpr_delete_on_uninstall' ) ) {
			return;
		}

		$tables = array(
			$wpdb->prefix . 'psp_gdpr_exports',
			$wpdb->prefix . 'psp_gdpr_deletions',
			$wpdb->prefix . 'psp_gdpr_consents',
			$wpdb->prefix . 'psp_gdpr_consent_log',
			$wpdb->prefix . 'psp_gdpr_archives',
			$wpdb->prefix . 'psp_gdpr_dpa',
			$wpdb->prefix . 'psp_gdpr_breach_log',
		);

		foreach ( $tables as $table ) {
			$wpdb->query( "DROP TABLE IF EXISTS $table" );
		}
	}

	/**
	 * Schedule cleanup tasks
	 * 
	 * @return void
	 */
	public static function schedule_cleanup(): void {
		if ( ! wp_next_scheduled( 'psp_gdpr_cleanup' ) ) {
			wp_schedule_event( time(), 'daily', 'psp_gdpr_cleanup' );
		}

		if ( ! wp_next_scheduled( 'psp_gdpr_execute_deletions' ) ) {
			wp_schedule_event( time(), 'hourly', 'psp_gdpr_execute_deletions' );
		}
	}

	/**
	 * Cleanup expired data
	 * 
	 * @return void
	 */
	public static function cleanup_expired_data(): void {
		global $wpdb;

		// Delete expired exports
		$wpdb->query(
			"DELETE FROM {$wpdb->prefix}psp_gdpr_exports 
			WHERE expires_at < NOW()"
		);

		// Delete expired deletion requests
		$wpdb->query(
			"DELETE FROM {$wpdb->prefix}psp_gdpr_deletions 
			WHERE status = 'pending' AND expires_at < NOW()"
		);

		// Delete old consent logs (keep for 90 days)
		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->prefix}psp_gdpr_consent_log 
				WHERE created_at < DATE_SUB(NOW(), INTERVAL %d DAY)",
				90
			)
		);

		// Delete archived data after retention period
		$wpdb->query(
			"DELETE FROM {$wpdb->prefix}psp_gdpr_archives 
			WHERE retention_until IS NOT NULL AND retention_until < NOW()"
		);
	}

	/**
	 * Execute pending deletions
	 * 
	 * @return void
	 */
	public static function execute_pending_deletions(): void {
		global $wpdb;

		// Get confirmed deletions ready for execution
		$deletions = $wpdb->get_results(
			"SELECT id, user_id FROM {$wpdb->prefix}psp_gdpr_deletions 
			WHERE status = 'confirmed' AND confirmed_at < DATE_SUB(NOW(), INTERVAL 7 DAY)"
		);

		foreach ( $deletions as $deletion ) {
			GDPR_Deletion::execute_deletion( $deletion->user_id, $deletion->id );
		}
	}
}
