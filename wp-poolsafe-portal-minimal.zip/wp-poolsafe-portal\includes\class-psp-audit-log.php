<?php
/**
 * PSP Audit Log: Custom post type for audit logging
 *
 * Registers audit log CPT, logs partner info changes, and provides admin UI.
 *
 * @package PSP
 */
add_action(
	'init',
	function () {
		register_post_type(
			'psp_audit_log',
			array(
				'label'           => 'Audit Logs',
				'public'          => false,
				'show_ui'         => true,
				'capability_type' => 'post',
				'capabilities'    => array(
					'edit_posts'   => 'manage_options',
					'read_post'    => 'manage_options',
					'delete_posts' => 'manage_options',
				),
				'supports'        => array( 'title', 'editor', 'custom-fields' ),
				'menu_icon'       => 'dashicons-list-view',
			)
		);
	}
);

/**
 * Log partner info changes.
 *
 * @param int    $meta_id    Meta ID.
 * @param int    $object_id  Object ID.
 * @param string $meta_key   Meta key.
 * @param mixed  $meta_value Meta value.
 */
// Log when post meta is updated (use the 'updated_post_meta' action)
add_action(
	'updated_post_meta',
	function ( $meta_id, $object_id, $meta_key, $meta_value ) {
		$post = get_post( $object_id );
		if ( $post && 'psp_partner' === $post->post_type ) { // Yoda condition
			$user      = wp_get_current_user(); // Not deprecated, safe to use
			$log_entry = array(
				'user'       => sanitize_user( $user->user_login ),
				'user_id'    => intval( $user->ID ),
				'meta_key'   => sanitize_text_field( $meta_key ),
				'meta_value' => maybe_serialize( $meta_value ),
				'partner_id' => intval( $object_id ),
				'timestamp'  => current_time( 'mysql' ),
			);
			wp_insert_post(
				array(
					'post_type'    => 'psp_audit_log',
					'post_title'   => 'Partner Change: ' . sanitize_text_field( $meta_key ),
					'post_content' => wp_json_encode( $log_entry ),
					'post_status'  => 'publish',
				)
			);
		}
	},
	10,
	4
);

/**
 * Admin UI: List audit logs.
 */
add_action(
	'admin_menu',
	function () {
		add_menu_page(
			'Audit Logs',
			'Audit Logs',
			'manage_options',
			'psp-audit-logs',
			function () {
				echo '<div class="wrap"><h1>Audit Logs</h1>';
				$logs = get_posts(
					array(
						'post_type'   => 'psp_audit_log',
						'numberposts' => 50,
						'post_status' => 'publish',
					)
				);
				echo '<table class="widefat"><thead><tr><th>User</th><th>Change</th><th>Partner</th><th>Time</th></tr></thead><tbody>';
				foreach ( $logs as $log ) {
						$entry = json_decode( $log->post_content, true );
						// Output sanitized for security
						echo '<tr>';
						echo '<td>' . esc_html( isset( $entry['user'] ) ? $entry['user'] : '' ) . '</td>';
						echo '<td>' . esc_html( $log->post_title ) . '</td>';
						echo '<td>' . esc_html( isset( $entry['partner_id'] ) ? $entry['partner_id'] : '' ) . '</td>';
						echo '<td>' . esc_html( isset( $entry['timestamp'] ) ? $entry['timestamp'] : '' ) . '</td>';
						echo '</tr>';
				}
				echo '</tbody></table></div>';
			},
			'dashicons-list-view'
		);
	}
);
