/**
 * Validation Error Handler
 * Displays field-specific validation errors from REST API responses
 * Works with structured error format: { field_name: "error message" }
 */

const ValidationErrorHandler = {
    /**
     * Display validation errors for form fields
     * @param {Object} errors - Error object with field names as keys
     * @param {HTMLElement|string} formSelector - Form element or selector
     */
    displayErrors: function (errors, formSelector) {
        const form = typeof formSelector === 'string'
            ? document.querySelector(formSelector)
            : formSelector;

        if (!form) return;

        // Clear existing errors first
        this.clearErrors(form);

        // Display each field error
        Object.keys(errors).forEach(fieldName => {
            const errorMessage = errors[fieldName];
            if (!errorMessage) return; // Skip empty error messages

            this.displayFieldError(fieldName, errorMessage, form);
        });
    },

    /**
     * Display error for a single field
     * @param {string} fieldName - Name of the form field
     * @param {string} errorMessage - Error message to display
     * @param {HTMLElement} form - Parent form element
     */
    displayFieldError: function (fieldName, errorMessage, form) {
        // Find the input field (by name or id)
        let field = form.querySelector(`[name="${fieldName}"]`);
        if (!field) {
            field = form.querySelector(`#${fieldName}`);
        }
        if (!field) {
            field = form.querySelector(`[data-field="${fieldName}"]`);
        }

        if (!field) {
            console.warn(`Field not found: ${fieldName}`);
            return;
        }

        // Add error styling to field
        field.classList.add('validation-error');
        field.setAttribute('aria-invalid', 'true');

        // Create error message element
        const errorElement = document.createElement('div');
        errorElement.className = 'validation-error-message';
        errorElement.setAttribute('role', 'alert');
        errorElement.textContent = errorMessage;
        errorElement.id = `error-${fieldName}`;

        // Link error to field for accessibility
        field.setAttribute('aria-describedby', `error-${fieldName}`);

        // Insert error after field or its wrapper
        const wrapper = field.closest('.form-group') || field.closest('.field-wrapper');
        if (wrapper) {
            wrapper.appendChild(errorElement);
        } else {
            field.parentNode.insertBefore(errorElement, field.nextSibling);
        }
    },

    /**
     * Clear all validation errors from a form
     * @param {HTMLElement|string} formSelector - Form element or selector
     */
    clearErrors: function (formSelector) {
        const form = typeof formSelector === 'string'
            ? document.querySelector(formSelector)
            : formSelector;

        if (!form) return;

        // Remove error styling from fields
        form.querySelectorAll('.validation-error').forEach(field => {
            field.classList.remove('validation-error');
            field.removeAttribute('aria-invalid');
            field.removeAttribute('aria-describedby');
        });

        // Remove error message elements
        form.querySelectorAll('.validation-error-message').forEach(errorMsg => {
            errorMsg.remove();
        });
    },

    /**
     * Clear error for a specific field
     * @param {string} fieldName - Name of the form field
     * @param {HTMLElement|string} formSelector - Form element or selector
     */
    clearFieldError: function (fieldName, formSelector) {
        const form = typeof formSelector === 'string'
            ? document.querySelector(formSelector)
            : formSelector;

        if (!form) return;

        let field = form.querySelector(`[name="${fieldName}"]`);
        if (!field) {
            field = form.querySelector(`#${fieldName}`);
        }

        if (field) {
            field.classList.remove('validation-error');
            field.removeAttribute('aria-invalid');
            field.removeAttribute('aria-describedby');
        }

        const errorMsg = form.querySelector(`#error-${fieldName}`);
        if (errorMsg) {
            errorMsg.remove();
        }
    },

    /**
     * Handle API response and display errors if validation failed
     * @param {Object} response - API response object
     * @param {HTMLElement|string} formSelector - Form element or selector
     * @returns {boolean} - True if errors were displayed, false otherwise
     */
    handleResponse: function (response, formSelector) {
        if (response.success === false && response.errors) {
            this.displayErrors(response.errors, formSelector);
            return true;
        }

        // Clear errors if response is successful
        if (response.success === true) {
            this.clearErrors(formSelector);
        }

        return false;
    },

    /**
     * Set up real-time field validation clearing
     * Removes error styling when user starts typing/editing
     * @param {HTMLElement|string} formSelector - Form element or selector
     */
    setupFieldClearance: function (formSelector) {
        const form = typeof formSelector === 'string'
            ? document.querySelector(formSelector)
            : formSelector;

        if (!form) return;

        form.querySelectorAll('input, textarea, select').forEach(field => {
            field.addEventListener('input', (e) => {
                if (field.classList.contains('validation-error')) {
                    const fieldName = field.name || field.id;
                    this.clearFieldError(fieldName, form);
                }
            });

            field.addEventListener('change', (e) => {
                if (field.classList.contains('validation-error')) {
                    const fieldName = field.name || field.id;
                    this.clearFieldError(fieldName, form);
                }
            });
        });
    },
};

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ValidationErrorHandler;
}
