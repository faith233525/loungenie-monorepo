<?php

namespace PSP;

/**
 * GDPR Data Deletion (Right to be Forgotten)
 * 
 * Handles user data deletion requests in compliance with GDPR Article 17.
 * Implements secure deletion of personal data with audit trails.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class GDPR_Deletion {

	/**
	 * Initialize GDPR deletion functionality
	 * 
	 * @return void
	 */
	public static function init(): void {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	/**
	 * Register REST API routes
	 * 
	 * @return void
	 */
	public static function register_routes(): void {
		// Request data deletion
		register_rest_route(
			'psp/v1',
			'/user/request-deletion',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'request_deletion' ),
				'permission_callback' => array( __CLASS__, 'check_auth' ),
				'args'                => array(
					'password' => array(
						'type'     => 'string',
						'required' => true,
					),
					'reason'   => array(
						'type' => 'string',
					),
				),
			)
		);

		// Confirm deletion with token
		register_rest_route(
			'psp/v1',
			'/user/confirm-deletion',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'confirm_deletion' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'token' => array(
						'type'     => 'string',
						'required' => true,
					),
				),
			)
		);

		// Cancel deletion request
		register_rest_route(
			'psp/v1',
			'/user/cancel-deletion',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'cancel_deletion' ),
				'permission_callback' => array( __CLASS__, 'check_auth' ),
			)
		);

		// Get deletion status
		register_rest_route(
			'psp/v1',
			'/user/deletion-status',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'get_deletion_status' ),
				'permission_callback' => array( __CLASS__, 'check_auth' ),
			)
		);
	}

	/**
	 * Check if user is authenticated
	 * 
	 * @return bool
	 */
	public static function check_auth(): bool {
		return ( isset( $_SESSION['psp_user_id'] ) && ! empty( $_SESSION['psp_user_id'] ) ) || is_user_logged_in();
	}

	/**
	 * Request data deletion
	 * 
	 * @param \WP_REST_Request $request REST request
	 * @return \WP_REST_Response
	 */
	public static function request_deletion( \WP_REST_Request $request ): \WP_REST_Response {
		global $wpdb;

		try {
			$user_id = absint( $_SESSION['psp_user_id'] );
			if ( $user_id === 0 ) {
				return Error_Handler::unauthorized();
			}

			// Verify password
			$password = sanitize_text_field( $request->get_param( 'password' ) );
			$user = get_user_by( 'id', $user_id );

			if ( ! wp_check_password( $password, $user->user_pass, $user->ID ) ) {
				return Error_Handler::validation_error( 'password', __( 'Invalid password', 'psp' ) );
			}

			// Check if deletion already pending
			$pending = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT id FROM {$wpdb->prefix}psp_gdpr_deletions 
					WHERE user_id = %d AND status = 'pending'",
					$user_id
				)
			);

			if ( $pending ) {
				return Error_Handler::conflict(
					__( 'Deletion request already pending. Please cancel it before requesting again.', 'psp' ),
					array( 'request_id' => $pending->id )
				);
			}

			// Generate confirmation token
			$token = bin2hex( random_bytes( 32 ) );
			$token_hash = hash( 'sha256', $token );
			$reason = sanitize_textarea_field( $request->get_param( 'reason' ) );

			// Store deletion request
			$insert = $wpdb->insert(
				"{$wpdb->prefix}psp_gdpr_deletions",
				array(
					'user_id'          => $user_id,
					'status'           => 'pending',
					'token'            => $token_hash,
					'reason'           => $reason,
					'requested_at'     => current_time( 'mysql' ),
					'expires_at'       => gmdate( 'Y-m-d H:i:s', time() + 30 * DAY_IN_SECONDS ),
					'confirmed_at'     => null,
					'deleted_at'       => null,
				),
				array( '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s' )
			);

			if ( ! $insert ) {
				return Error_Handler::server_error( __( 'Failed to create deletion request', 'psp' ) );
			}

			$request_id = $wpdb->insert_id;

			// Send confirmation email
			self::send_confirmation_email( $user, $token, $request_id );

			// Log deletion request
			Audit_Logger::log_event(
				'gdpr_deletion_requested',
				wp_json_encode( array( 'request_id' => $request_id ) ),
				'gdpr',
				$user_id
			);

			return Error_Handler::success(
				array(
					'request_id' => $request_id,
					'status'     => 'pending',
					'expires_at' => gmdate( 'Y-m-d H:i:s', time() + 30 * DAY_IN_SECONDS ),
					'message'    => __( 'Check your email to confirm deletion', 'psp' ),
				)
			);
		} catch ( \Exception $e ) {
			return Error_Handler::server_error(
				__( 'Failed to request data deletion', 'psp' ),
				array( 'exception' => $e->getMessage() )
			);
		}
	}

	/**
	 * Send confirmation email
	 * 
	 * @param \WP_User $user WordPress user
	 * @param string $token Confirmation token
	 * @param int $request_id Deletion request ID
	 * @return void
	 */
	private static function send_confirmation_email( \WP_User $user, string $token, int $request_id ): void {
		$confirm_url = add_query_arg(
			array(
				'action' => 'psp_confirm_deletion',
				'token'  => $token,
				'id'     => $request_id,
			),
			home_url( '/gdpr-confirmation/' )
		);

		$subject = __( 'Confirm Your Data Deletion Request - PoolSafe Portal', 'psp' );
		$message = sprintf(
			__( "Hi %s,\n\nYou have requested to delete your account and personal data from PoolSafe Portal.\n\nTo confirm this deletion, please click the link below:\n%s\n\nThis link will expire in 30 days.\n\nIf you did not request this, please ignore this email.\n\nBest regards,\nPoolSafe Team", 'psp' ),
			$user->display_name,
			$confirm_url
		);

		wp_mail(
			$user->user_email,
			$subject,
			$message,
			array( 'Content-Type: text/plain; charset=UTF-8' )
		);
	}

	/**
	 * Confirm deletion
	 * 
	 * @param \WP_REST_Request $request REST request
	 * @return \WP_REST_Response
	 */
	public static function confirm_deletion( \WP_REST_Request $request ): \WP_REST_Response {
		global $wpdb;

		try {
			$token = sanitize_text_field( $request->get_param( 'token' ) );
			if ( empty( $token ) ) {
				return Error_Handler::validation_error( 'token', __( 'Token is required', 'psp' ) );
			}

			$token_hash = hash( 'sha256', $token );

			// Verify token and get deletion request
			$deletion = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT * FROM {$wpdb->prefix}psp_gdpr_deletions 
					WHERE token = %s AND status = 'pending' AND expires_at > NOW()",
					$token_hash
				)
			);

			if ( ! $deletion ) {
				return Error_Handler::not_found(
					__( 'Deletion request not found or expired', 'psp' )
				);
			}

			// Mark as confirmed
			$wpdb->update(
				"{$wpdb->prefix}psp_gdpr_deletions",
				array(
					'status'       => 'confirmed',
					'confirmed_at' => current_time( 'mysql' ),
				),
				array( 'id' => $deletion->id ),
				array( '%s', '%s' ),
				array( '%d' )
			);

			// Schedule actual deletion in 7 days (grace period)
			wp_schedule_single_event(
				time() + 7 * DAY_IN_SECONDS,
				'psp_execute_deletion',
				array( $deletion->user_id, $deletion->id )
			);

			Audit_Logger::log_event(
				'gdpr_deletion_confirmed',
				wp_json_encode( array( 'deletion_id' => $deletion->id ) ),
				'gdpr',
				$deletion->user_id
			);

			return Error_Handler::success(
				null,
				__( 'Deletion confirmed. Your data will be deleted in 7 days. You can still cancel this action.', 'psp' )
			);
		} catch ( \Exception $e ) {
			return Error_Handler::server_error(
				__( 'Failed to confirm deletion', 'psp' ),
				array( 'exception' => $e->getMessage() )
			);
		}
	}

	/**
	 * Cancel deletion request
	 * 
	 * @return \WP_REST_Response
	 */
	public static function cancel_deletion(): \WP_REST_Response {
		global $wpdb;

		$user_id = absint( $_SESSION['psp_user_id'] );
		if ( $user_id === 0 ) {
			return Error_Handler::unauthorized();
		}

		$deletion = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT id FROM {$wpdb->prefix}psp_gdpr_deletions 
				WHERE user_id = %d AND status IN ('pending', 'confirmed')",
				$user_id
			)
		);

		if ( ! $deletion ) {
			return Error_Handler::not_found( __( 'No active deletion request found', 'psp' ) );
		}

		// Cancel deletion
		$wpdb->update(
			"{$wpdb->prefix}psp_gdpr_deletions",
			array( 'status' => 'cancelled' ),
			array( 'id' => $deletion->id ),
			array( '%s' ),
			array( '%d' )
		);

		Audit_Logger::log_event(
			'gdpr_deletion_cancelled',
			wp_json_encode( array( 'deletion_id' => $deletion->id ) ),
			'gdpr',
			$user_id
		);

		return Error_Handler::success( null, __( 'Deletion request cancelled', 'psp' ) );
	}

	/**
	 * Get deletion status
	 * 
	 * @return \WP_REST_Response
	 */
	public static function get_deletion_status(): \WP_REST_Response {
		global $wpdb;

		$user_id = absint( $_SESSION['psp_user_id'] );
		if ( $user_id === 0 ) {
			return Error_Handler::unauthorized();
		}

		$deletion = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT id, status, requested_at, confirmed_at, expires_at FROM {$wpdb->prefix}psp_gdpr_deletions 
				WHERE user_id = %d ORDER BY requested_at DESC LIMIT 1",
				$user_id
			),
			ARRAY_A
		);

		if ( ! $deletion ) {
			return Error_Handler::success( null );
		}

		return Error_Handler::success( $deletion );
	}

	/**
	 * Execute actual data deletion (called from scheduled event)
	 * 
	 * @param int $user_id User ID
	 * @param int $deletion_id Deletion request ID
	 * @return void
	 */
	public static function execute_deletion( int $user_id, int $deletion_id ): void {
		global $wpdb;

		try {
			// Verify deletion still confirmed
			$deletion = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT id, status FROM {$wpdb->prefix}psp_gdpr_deletions WHERE id = %d",
					$deletion_id
				)
			);

			if ( ! $deletion || $deletion->status !== 'confirmed' ) {
				return;
			}

			// Archive user data for compliance (optional)
			$user_data = array(
				'user_id'    => $user_id,
				'archived'   => wp_json_encode( self::get_user_data_for_archive( $user_id ) ),
				'archived_at' => current_time( 'mysql' ),
			);

			$wpdb->insert(
				"{$wpdb->prefix}psp_gdpr_archives",
				$user_data,
				array( '%d', '%s', '%s' )
			);

			// Delete user data from all tables
			self::delete_user_tickets( $user_id );
			self::delete_user_replies( $user_id );
			self::delete_user_services( $user_id );
			self::delete_user_company_data( $user_id );

			// Anonymize user account
			$user = new \stdClass();
			$user->ID = $user_id;
			$user->user_login = 'deleted-user-' . $user_id;
			$user->user_email = 'deleted-' . $user_id . '@deleted.local';
			$user->first_name = '[Deleted]';
			$user->last_name = '[Deleted]';
			wp_update_user( $user );

			// Mark deletion complete
			$wpdb->update(
				"{$wpdb->prefix}psp_gdpr_deletions",
				array(
					'status'     => 'completed',
					'deleted_at' => current_time( 'mysql' ),
				),
				array( 'id' => $deletion_id ),
				array( '%s', '%s' ),
				array( '%d' )
			);

			Audit_Logger::log_event(
				'gdpr_deletion_completed',
				wp_json_encode( array( 'deletion_id' => $deletion_id ) ),
				'gdpr',
				$user_id
			);
		} catch ( \Exception $e ) {
			error_log( 'GDPR Deletion Error: ' . $e->getMessage() );
		}
	}

	/**
	 * Delete user tickets
	 * 
	 * @param int $user_id User ID
	 * @return void
	 */
	private static function delete_user_tickets( int $user_id ): void {
		global $wpdb;

		$wpdb->delete(
			"{$wpdb->prefix}psp_tickets",
			array( 'created_by' => $user_id ),
			array( '%d' )
		);
	}

	/**
	 * Delete user replies
	 * 
	 * @param int $user_id User ID
	 * @return void
	 */
	private static function delete_user_replies( int $user_id ): void {
		global $wpdb;

		$wpdb->delete(
			"{$wpdb->prefix}psp_ticket_replies",
			array( 'created_by' => $user_id ),
			array( '%d' )
		);
	}

	/**
	 * Delete user services
	 * 
	 * @param int $user_id User ID
	 * @return void
	 */
	private static function delete_user_services( int $user_id ): void {
		global $wpdb;

		$wpdb->delete(
			"{$wpdb->prefix}psp_service_records",
			array( 'created_by' => $user_id ),
			array( '%d' )
		);
	}

	/**
	 * Delete user company data
	 * 
	 * @param int $user_id User ID
	 * @return void
	 */
	private static function delete_user_company_data( int $user_id ): void {
		global $wpdb;

		// Find and delete company data
		$company_id = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT post_id FROM {$wpdb->postmeta} 
				WHERE meta_key = 'psp_primary_user_id' AND meta_value = %d",
				$user_id
			)
		);

		if ( $company_id ) {
			wp_delete_post( $company_id, true );
		}
	}

	/**
	 * Get user data for archival
	 * 
	 * @param int $user_id User ID
	 * @return array
	 */
	private static function get_user_data_for_archive( int $user_id ): array {
		global $wpdb;

		return array(
			'user_id'    => $user_id,
			'user'       => get_user_by( 'id', $user_id ),
			'tickets'    => $wpdb->get_results(
				$wpdb->prepare(
					"SELECT * FROM {$wpdb->prefix}psp_tickets WHERE created_by = %d",
					$user_id
				),
				ARRAY_A
			),
			'replies'    => $wpdb->get_results(
				$wpdb->prepare(
					"SELECT * FROM {$wpdb->prefix}psp_ticket_replies WHERE created_by = %d",
					$user_id
				),
				ARRAY_A
			),
		);
	}
}
