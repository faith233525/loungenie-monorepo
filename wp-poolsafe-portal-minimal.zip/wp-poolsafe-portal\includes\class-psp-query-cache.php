<?php
/**
 * Query Cache Class
 * File: includes/class-psp-query-cache.php
 * 
 * Implements transient-based caching for database queries.
 * Provides automatic cache invalidation on updates.
 * 
 * @package PoolSafe_Portal
 * @subpackage Performance
 * @since 3.0.0
 * @author PoolSafe Team
 * @version 3.2.5
 */

class PSP_Query_Cache {

    const DEFAULT_TTL = 3600; // 1 hour
    const CACHE_PREFIX = 'psp_query_';
    
    // Legacy cache key constants for backward compatibility
    const COMPANY_CACHE_KEY = 'psp_company_%d';
    const COMPANY_LIST_CACHE_KEY = 'psp_company_list_page_%d';
    const TICKET_CACHE_KEY = 'psp_ticket_%d';
    const COMPANY_TICKETS_CACHE_KEY = 'psp_tickets_company_%d';
    const STATS_CACHE_KEY = 'psp_stats_%d';

    /**
     * Get cached query result or execute and cache
     *
     * @param string   $cache_key Unique identifier for this query
     * @param callable $callback Function that returns the query result
     * @param int      $ttl Cache time-to-live in seconds (default 1 hour)
     * @return mixed Query result
     */
    public static function get( $cache_key, $callback, $ttl = self::DEFAULT_TTL ) {
        $full_key = self::CACHE_PREFIX . $cache_key;

        // Try to get from transient cache first
        $cached = get_transient( $full_key );

        if ( false !== $cached ) {
            if ( class_exists( 'PSP_Logger' ) ) {
                PSP_Logger::debug( 'Cache HIT', array( 'key' => $cache_key ) );
            }
            return $cached;
        }

        // Cache miss - execute callback
        if ( class_exists( 'PSP_Logger' ) ) {
            PSP_Logger::debug( 'Cache MISS', array( 'key' => $cache_key ) );
        }
        
        $result = call_user_func( $callback );

        // Store in cache if result is not empty
        if ( ! empty( $result ) || is_array( $result ) ) {
            set_transient( $full_key, $result, $ttl );
        }

        return $result;
    }

    /**
     * Invalidate a specific cached query
     *
     * @param string $cache_key The cache key to invalidate
     * @return bool True on success
     */
    public static function invalidate( $cache_key ) {
        $full_key = self::CACHE_PREFIX . $cache_key;
        
        if ( class_exists( 'PSP_Logger' ) ) {
            PSP_Logger::debug( 'Cache INVALIDATE', array( 'key' => $cache_key ) );
        }
        
        return delete_transient( $full_key );
    }

    /**
     * Invalidate multiple cache keys matching a pattern
     *
     * @param string $pattern Wildcard pattern (e.g., 'tickets_*')
     * @return int Number of keys invalidated
     */
    public static function invalidate_pattern( $pattern ) {
        global $wpdb;

        $like_pattern = self::CACHE_PREFIX . str_replace( '*', '%', $pattern );
        
        $transients = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT option_name FROM {$wpdb->options} 
                WHERE option_name LIKE %s",
                '_transient_' . $like_pattern
            )
        );

        $count = 0;
        foreach ( $transients as $transient ) {
            $key = str_replace( '_transient_' . self::CACHE_PREFIX, '', $transient );
            if ( delete_transient( self::CACHE_PREFIX . $key ) ) {
                $count++;
            }
        }

        if ( class_exists( 'PSP_Logger' ) ) {
            PSP_Logger::debug( 'Cache INVALIDATE PATTERN', array(
                'pattern' => $pattern,
                'count'   => $count,
            ) );
        }

        return $count;
    }

    /**
     * Generate cache key from query parameters
     *
     * @param string $base_key Base identifier
     * @param array  $params Query parameters that affect results
     * @return string Hashed cache key
     */
    public static function generate_key( $base_key, $params = array() ) {
        if ( empty( $params ) ) {
            return $base_key;
        }

        // Sort params for consistent hashing
        ksort( $params );
        
        $hash = md5( wp_json_encode( $params ) );
        
        return $base_key . '_' . $hash;
    }

    /**
     * Get single company with cache
     *
     * @param int $company_id Company ID
     * @return array|null Company data or null
     */
    public static function get_company( $company_id ) {
        $cache_key = sprintf( self::COMPANY_CACHE_KEY, $company_id );
        
        // Try cache first
        $cached = get_transient( $cache_key );
        if ( false !== $cached ) {
            return $cached;
        }
        
        // Get from database
        $company = Company::get_by_id( $company_id );
        
        // Cache result if found
        if ( $company ) {
            set_transient( $cache_key, $company, self::DEFAULT_TTL );
        }
        
        return $company;
    }

    /**
     * Get companies list with pagination and cache
     *
     * @param int $page Current page
     * @param int $per_page Items per page
     * @return array Companies list
     */
    public static function get_companies( $page = 1, $per_page = 20 ) {
        $cache_key = sprintf( self::COMPANY_LIST_CACHE_KEY, $page );
        
        // Try cache first
        $cached = get_transient( $cache_key );
        if ( false !== $cached ) {
            return $cached;
        }
        
        // Get from database
        $companies = Company::get_all( [
            'offset' => ( $page - 1 ) * $per_page,
            'number' => $per_page,
        ] );
        
        // Cache result
        if ( ! empty( $companies ) ) {
            set_transient( $cache_key, $companies, self::DEFAULT_TTL );
        }
        
        return $companies;
    }

    /**
     * Get company tickets with optional status filter
     *
     * @param int    $company_id Company ID
     * @param string $status Optional status filter
     * @return WP_Query Query object
     */
    public static function get_company_tickets( $company_id, $status = null ) {
        $status_key = $status ? "_$status" : '';
        $cache_key = sprintf( self::COMPANY_TICKETS_CACHE_KEY, $company_id ) . $status_key;
        
        // Try cache first
        $cached = get_transient( $cache_key );
        if ( false !== $cached ) {
            return $cached;
        }
        
        // Build query
        $args = [
            'post_type'              => 'psp_ticket',
            'posts_per_page'         => -1,
            'meta_query'             => [
                [
                    'key'   => '_psp_company_id',
                    'value' => $company_id,
                ]
            ],
            'update_post_meta_cache' => true,
            'update_post_term_cache' => true,
            'no_found_rows'          => true,
        ];
        
        // Add status filter if provided
        if ( $status ) {
            $args['tax_query'] = [
                [
                    'taxonomy' => 'psp_ticket_status',
                    'field'    => 'slug',
                    'terms'    => $status,
                ]
            ];
        }
        
        // Execute query
        $tickets = new WP_Query( $args );
        
        // Cache result
        set_transient( $cache_key, $tickets, self::DEFAULT_TTL );
        
        return $tickets;
    }

    /**
     * Get company statistics with cache
     *
     * @param int $company_id Company ID
     * @return array|null Stats array or null
     */
    public static function get_stats( $company_id ) {
        global $wpdb;
        
        $cache_key = sprintf( self::STATS_CACHE_KEY, $company_id );
        
        // Try cache first
        $cached = get_transient( $cache_key );
        if ( false !== $cached ) {
            return $cached;
        }
        
        // Get fresh stats from database
        $stats = $wpdb->get_row( $wpdb->prepare(
            "SELECT 
                COUNT(CASE WHEN post_status='publish' THEN 1 END) as total_tickets,
                COUNT(CASE WHEN pm.meta_value='open' THEN 1 END) as open_tickets,
                COUNT(CASE WHEN pm.meta_value='closed' THEN 1 END) as closed_tickets,
                COUNT(CASE WHEN pm.meta_value='pending' THEN 1 END) as pending_tickets,
                AVG(DATEDIFF(post_modified, post_date)) as avg_resolution_time
            FROM {$wpdb->posts} p
            LEFT JOIN {$wpdb->postmeta} pc ON p.ID = pc.post_id AND pc.meta_key = '_psp_company_id'
            LEFT JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_psp_ticket_status'
            WHERE p.post_type = 'psp_ticket'
            AND pc.meta_value = %d",
            $company_id
        ) );
        
        // Cache result if found
        if ( $stats ) {
            set_transient( $cache_key, $stats, self::DEFAULT_TTL );
        }
        
        return $stats;
    }

    /**
     * Clear cache for a specific company
     *
     * @param int $company_id Company ID
     */
    public static function clear_company_cache( $company_id ) {
        // Clear company cache
        delete_transient( sprintf( self::COMPANY_CACHE_KEY, $company_id ) );
        
        // Clear company list caches (all pages)
        for ( $page = 1; $page <= 10; $page++ ) {
            delete_transient( sprintf( self::COMPANY_LIST_CACHE_KEY, $page ) );
        }
        
        // Clear company tickets cache
        delete_transient( sprintf( self::COMPANY_TICKETS_CACHE_KEY, $company_id ) );
        
        // Clear stats cache
        delete_transient( sprintf( self::STATS_CACHE_KEY, $company_id ) );
    }

    /**
     * Clear cache for a specific ticket
     *
     * @param int $ticket_id Ticket ID
     * @param int $company_id Company ID (optional)
     */
    public static function clear_ticket_cache( $ticket_id, $company_id = null ) {
        // If company_id not provided, try to get it
        if ( ! $company_id ) {
            $company_id = get_post_meta( $ticket_id, '_psp_company_id', true );
        }
        
        // Clear company tickets cache
        if ( $company_id ) {
            delete_transient( sprintf( self::COMPANY_TICKETS_CACHE_KEY, $company_id ) );
            
            // Clear stats for this company
            delete_transient( sprintf( self::STATS_CACHE_KEY, $company_id ) );
        }
    }

    /**
     * Clear all plugin caches
     */
    public static function clear_all() {
        global $wpdb;
        
        // Delete all PSP transients (improved version)
        $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$wpdb->options} 
                WHERE option_name LIKE %s 
                OR option_name LIKE %s",
                '_transient_' . self::CACHE_PREFIX . '%',
                '_transient_timeout_' . self::CACHE_PREFIX . '%'
            )
        );
        
        // Also clear legacy cache keys
        $wpdb->query(
            "DELETE FROM {$wpdb->options} 
            WHERE option_name LIKE '%psp_%' 
            AND option_name LIKE '%transient%'"
        );
        
        if ( class_exists( 'PSP_Logger' ) ) {
            PSP_Logger::info( 'All query caches flushed' );
        }
    }

    /**
     * Invalidate caches related to a specific entity
     *
     * @param string $entity Entity type (ticket, partner, user, etc.)
     * @param int    $entity_id Entity ID
     */
    public static function invalidate_entity( $entity, $entity_id = null ) {
        $patterns = array();

        switch ( $entity ) {
            case 'ticket':
                $patterns = array(
                    'tickets_*',
                    'stats_*',
                );
                if ( $entity_id ) {
                    $patterns[] = 'ticket_' . $entity_id . '_*';
                }
                break;

            case 'partner':
            case 'company':
                $patterns = array(
                    'company_*',
                    'companies_*',
                    'stats_*',
                );
                if ( $entity_id ) {
                    $patterns[] = 'company_' . $entity_id . '_*';
                    // Clear legacy cache keys too
                    self::clear_company_cache( $entity_id );
                }
                break;

            case 'user':
                $patterns = array(
                    'users_*',
                    'company_users_*',
                );
                if ( $entity_id ) {
                    $patterns[] = 'user_' . $entity_id . '_*';
                }
                break;

            default:
                $patterns = array( $entity . '_*' );
                break;
        }

        foreach ( $patterns as $pattern ) {
            self::invalidate_pattern( $pattern );
        }
    }

    /**
     * Schedule automatic cache cleanup
     * Removes expired transients
     */
    public static function schedule_cleanup() {
        if ( ! wp_next_scheduled( 'psp_cache_cleanup' ) ) {
            wp_schedule_event( time(), 'daily', 'psp_cache_cleanup' );
        }
    }

    /**
     * Cleanup expired cache entries
     * Hooked to scheduled event
     */
    public static function cleanup_expired() {
        global $wpdb;

        // WordPress automatically handles transient expiration,
        // but we can clean up explicitly for housekeeping
        $wpdb->query(
            "DELETE a, b FROM {$wpdb->options} a, {$wpdb->options} b
            WHERE a.option_name LIKE '_transient_psp_query_%'
            AND a.option_name NOT LIKE '_transient_timeout_psp_query_%'
            AND b.option_name = CONCAT('_transient_timeout_', SUBSTRING(a.option_name, 12))
            AND b.option_value < UNIX_TIMESTAMP()"
        );

        if ( class_exists( 'PSP_Logger' ) ) {
            PSP_Logger::debug( 'Expired cache entries cleaned' );
        }
    }

    /**
     * Get cache statistics
     *
     * @return array Cache stats
     */
    public static function get_stats_summary() {
        global $wpdb;
        
        $cached_items = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->options} 
                WHERE option_name LIKE %s",
                '_transient_' . self::CACHE_PREFIX . '%'
            )
        );
        
        $total_size = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT SUM(LENGTH(option_value)) FROM {$wpdb->options} 
                WHERE option_name LIKE %s",
                '_transient_' . self::CACHE_PREFIX . '%'
            )
        );
        
        return array(
            'cached_items'    => (int) $cached_items,
            'cache_size_kb'   => round( $total_size / 1024, 2 ),
            'formatted_size'  => size_format( $total_size ),
            'ttl_seconds'     => self::DEFAULT_TTL,
        );
    }
}

// Initialize cache cleanup scheduler
add_action( 'psp_cache_cleanup', array( 'PSP_Query_Cache', 'cleanup_expired' ) );
PSP_Query_Cache::schedule_cleanup();
