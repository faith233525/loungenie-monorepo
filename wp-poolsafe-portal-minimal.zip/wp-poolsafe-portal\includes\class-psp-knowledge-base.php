<?php
namespace PSP;
/**
 * Knowledge Base CPT & REST API
 * Handles knowledge base features for PoolSafe Portal plugin.
 *
 * @package PoolSafePortal
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Knowledge_Base {


				// Register taxonomy for tags on KB Documents
	public static function register_document_tag_taxonomy(): void {
		register_taxonomy(
			'psp_kb_doc_tag',
			'psp_kb_document',
			array(
				'labels'            => array(
					'name'          => __( 'Document Tags', 'psp' ),
					'singular_name' => __( 'Tag', 'psp' ),
				),
				'hierarchical'      => false,
				'show_ui'           => true,
				'show_in_rest'      => true,
				'show_admin_column' => true,
			)
		);
	}
	// REST: Update and delete KB Document
	// (Removed duplicate register_document_routes definition)

	public static function update_document( $request ) {
		$tags    = $request->get_param( 'tags' );
		$id      = intval( $request->get_param( 'id' ) );
		$title   = sanitize_text_field( $request->get_param( 'title' ) );
		$desc    = sanitize_text_field( $request->get_param( 'description' ) );
		$postarr = array( 'ID' => $id );
		if ( $title ) {
			$postarr['post_title'] = $title;
		}
		if ( $desc ) {
			$postarr['post_excerpt'] = $desc;
		}
		$result = wp_update_post( $postarr, true );
		if ( ! is_wp_error( $result ) && ! empty( $tags ) && is_array( $tags ) ) {
			wp_set_object_terms( $id, $tags, 'psp_kb_doc_tag' );
		}
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		return rest_ensure_response(
			array(
				'id'          => $id,
				'title'       => get_the_title( $id ),
				'description' => $desc,
				'tags'        => $tags,
			)
		);
	}

	public static function delete_document( $request ) {
		$id            = intval( $request->get_param( 'id' ) );
		$attachment_id = get_post_meta( $id, 'psp_kb_attachment_id', true );
		wp_delete_post( $id, true );
		if ( $attachment_id ) {
			wp_delete_attachment( $attachment_id, true );
		}
		return rest_ensure_response( array( 'deleted' => true ) );
	}
	// Register KB Document CPT for uploaded files
	public static function register_document_cpt(): void {
		register_post_type(
			'psp_kb_document',
			array(
				'labels'       => array(
					'name'          => __( 'KB Documents', 'psp' ),
					'singular_name' => __( 'KB Document', 'psp' ),
					'add_new'       => __( 'Add Document', 'psp' ),
					'add_new_item'  => __( 'Add New Document', 'psp' ),
					'edit_item'     => __( 'Edit Document', 'psp' ),
					'search_items'  => __( 'Search Documents', 'psp' ),
				),
				'public'       => false,
				'show_ui'      => false,
				'supports'     => array( 'title', 'excerpt' ),
				'show_in_rest' => false,
			)
		);
	}

	public static function init(): void {
		add_action( 'init', array( __CLASS__, 'register_taxonomy' ) );
		add_action( 'init', array( __CLASS__, 'register_document_tag_taxonomy' ) );
		add_action( 'init', array( __CLASS__, 'register_document_cpt' ) );
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
		add_action( 'rest_api_init', array( __CLASS__, 'register_document_routes' ) );
	}
	// REST: Upload KB Document (PDF, DOC, etc.)
	public static function register_document_routes(): void {
		register_rest_route(
			'poolsafe/v1',
			'/kb/documents',
			array(
				array(
					'methods'             => 'POST',
					'permission_callback' => function () {
						return current_user_can( 'psp_support' ) || current_user_can( 'administrator' );
					},
					'args'                => array(
						'title'       => array(
							'required' => false,
							'type'     => 'string',
						),
						'description' => array(
							'required' => false,
							'type'     => 'string',
						),
					),
					'callback'            => array( __CLASS__, 'upload_document' ),
				),
				array(
					'methods'             => 'GET',
					'permission_callback' => function () {
						return is_user_logged_in();
					},
					'callback'            => array( __CLASS__, 'list_documents' ),
				),
			)
		);

		// Order endpoint
		register_rest_route(
			'poolsafe/v1',
			'/kb/documents/order',
			array(
				'methods'             => 'POST',
				'permission_callback' => function () {
					return current_user_can( 'psp_support' ) || current_user_can( 'administrator' );
				},
				'callback'            => array( __CLASS__, 'save_document_order' ),
			)
		);

		// Download tracking endpoint
		register_rest_route(
			'poolsafe/v1',
			'/kb/documents/(?P<id>\\d+)/download',
			array(
				'methods'             => 'POST',
				'permission_callback' => function () {
					return is_user_logged_in();
				},
				'callback'            => array( __CLASS__, 'record_document_download' ),
				'args'                => array(
					'id' => array(
						'required' => true,
						'type'     => 'integer',
					),
				),
			)
		);
	}

	public static function upload_document( $request ) {
		if ( empty( $_FILES['file'] ) ) {
			return new WP_Error( 'no_file', __( 'No file uploaded', 'psp' ), array( 'status' => 400 ) );
		}
		if ( ! function_exists( 'media_handle_upload' ) ) {
			include_once ABSPATH . 'wp-admin/includes/image.php';
			include_once ABSPATH . 'wp-admin/includes/file.php';
			include_once ABSPATH . 'wp-admin/includes/media.php';
		}
		$tags          = $request->get_param( 'tags' );
		$title         = sanitize_text_field( $request->get_param( 'title' ) );
		$desc          = sanitize_text_field( $request->get_param( 'description' ) );
		$attachment_id = media_handle_upload( 'file', 0 );
		if ( is_wp_error( $attachment_id ) ) {
			return $attachment_id;
		}
		// Create KB Document post and link attachment
		$doc_id = wp_insert_post(
			array(
				'post_type'    => 'psp_kb_document',
				'post_title'   => $title ?: get_the_title( $attachment_id ),
				'post_excerpt' => $desc ?: '',
				'post_status'  => 'publish',
			)
		);
		if ( $doc_id && ! is_wp_error( $doc_id ) ) {
			update_post_meta( $doc_id, 'psp_kb_uploaded', current_time( 'mysql' ) );
		}
		if ( $doc_id && ! is_wp_error( $doc_id ) ) {
			update_post_meta( $doc_id, 'psp_kb_attachment_id', $attachment_id );
			// Set tags if provided
			if ( ! empty( $tags ) && is_array( $tags ) ) {
				wp_set_object_terms( $doc_id, $tags, 'psp_kb_doc_tag' );
			}
		}
		$url = wp_get_attachment_url( $attachment_id );
		return rest_ensure_response(
			array(
				'id'            => $doc_id,
				'attachment_id' => $attachment_id,
				'url'           => $url,
				'title'         => get_the_title( $doc_id ),
				'description'   => $desc,
				'tags'          => $tags,
			)
		);
	}

	public static function list_documents( $request ) {
		// Tag filter
		$tag = $request->get_param( 'tag' );
		// Get saved order (array of IDs)
		$order = get_option( 'psp_kb_document_order', array() );
		$args  = array(
			'post_type'      => 'psp_kb_document',
			'posts_per_page' => 100,
			'post_status'    => 'publish',
			'orderby'        => 'title',
			'order'          => 'ASC',
		);
		if ( $tag ) {
			$args['tax_query'] = array(
				array(
					'taxonomy' => 'psp_kb_doc_tag',
					'field'    => 'slug',
					'terms'    => $tag,
				),
			);
		}
		$query = new WP_Query( $args );
		$docs  = array();
		foreach ( $query->posts as $post ) {
			$attachment_id   = get_post_meta( $post->ID, 'psp_kb_attachment_id', true );
			$uploaded        = get_post_meta( $post->ID, 'psp_kb_uploaded', true );
			$url             = $attachment_id ? wp_get_attachment_url( $attachment_id ) : '';
			$ext             = $url ? strtoupper( pathinfo( $url, PATHINFO_EXTENSION ) ) : '';
			$download_count  = intval( get_post_meta( $post->ID, 'psp_kb_download_count', true ) );
			$last_downloaded = get_post_meta( $post->ID, 'psp_kb_last_downloaded', true );
			$tags            = wp_get_post_terms( $post->ID, 'psp_kb_doc_tag', array( 'fields' => 'names' ) );
			$docs[]          = array(
				'id'              => $post->ID,
				'title'           => get_the_title( $post ),
				'description'     => $post->post_excerpt,
				'attachment_id'   => $attachment_id,
				'url'             => $url,
				'uploaded'        => $uploaded,
				'ext'             => $ext,
				'download_count'  => $download_count,
				'last_downloaded' => $last_downloaded,
				'tags'            => $tags,
			);
		}
		// If order exists, sort docs accordingly
		if ( is_array( $order ) && count( $order ) > 0 ) {
			usort(
				$docs,
				function ( $a, $b ) use ( $order ) {
					$posa = array_search( $a['id'], $order );
					$posb = array_search( $b['id'], $order );
					if ( $posa === false ) {
						$posa = 9999;
					}
					if ( $posb === false ) {
						$posb = 9999;
					}
							return $posa - $posb;
				}
			);
		}
		return rest_ensure_response( $docs );
	}

	// Download tracking: increment count and update last_downloaded
	public static function record_document_download( $request ) {
		$id = intval( $request->get_param( 'id' ) );
		if ( ! $id ) {
			return new WP_Error( 'invalid_id', 'Invalid document ID', array( 'status' => 400 ) );
		}
		$count = intval( get_post_meta( $id, 'psp_kb_download_count', true ) );
		++$count;
		update_post_meta( $id, 'psp_kb_download_count', $count );
		$now = current_time( 'mysql' );
		update_post_meta( $id, 'psp_kb_last_downloaded', $now );
		return rest_ensure_response(
			array(
				'success'         => true,
				'download_count'  => $count,
				'last_downloaded' => $now,
			)
		);
	}

	// Save document order
	public static function save_document_order( $request ) {
		$order = $request->get_json_params()['order'] ?? array();
		// Sanitize: only allow IDs of existing docs
		$args      = array(
			'post_type'      => 'psp_kb_document',
			'posts_per_page' => 100,
			'post_status'    => 'publish',
			'fields'         => 'ids',
		);
		$query     = new WP_Query( $args );
		$valid_ids = $query->posts;
		$order     = array_values(
			array_filter(
				$order,
				function ( $id ) use ( $valid_ids ) {
						return in_array( intval( $id ), $valid_ids );
				}
			)
		);
		update_option( 'psp_kb_document_order', $order );
		return rest_ensure_response(
			array(
				'success' => true,
				'order'   => $order,
			)
		);
	}

	public static function register_cpt(): void {
		register_post_type(
			'psp_kb_article',
			array(
				'labels'       => array(
					'name'          => __( 'Knowledge Base', 'psp' ),
					'singular_name' => __( 'Article', 'psp' ),
					'add_new'       => __( 'Add Article', 'psp' ),
					'add_new_item'  => __( 'Add New Article', 'psp' ),
					'edit_item'     => __( 'Edit Article', 'psp' ),
					'search_items'  => __( 'Search Articles', 'psp' ),
				),
				'public'       => false,
				'show_ui'      => true,
				'show_in_menu' => 'psp-admin',
				'supports'     => array( 'title', 'editor', 'thumbnail', 'excerpt' ),
				'show_in_rest' => true,
				'menu_icon'    => 'dashicons-book',
				'has_archive'  => false,
			)
		);
	}

	public static function register_taxonomy(): void {
		register_taxonomy(
			'psp_kb_category',
			'psp_kb_article',
			array(
				'labels'            => array(
					'name'          => __( 'KB Categories', 'psp' ),
					'singular_name' => __( 'Category', 'psp' ),
				),
				'hierarchical'      => true,
				'show_ui'           => true,
				'show_in_rest'      => true,
				'show_admin_column' => true,
			)
		);
	}

	public static function register_routes(): void {
		register_rest_route(
			'poolsafe/v1',
			'/kb/articles',
			array(
				'methods'             => 'GET',
				'permission_callback' => function () {
					return is_user_logged_in();
				},
				'callback'            => array( __CLASS__, 'list_articles' ),
			)
		);

		register_rest_route(
			'poolsafe/v1',
			'/kb/articles/(?P<id>\\d+)',
			array(
				'methods'             => 'GET',
				'permission_callback' => function () {
					return is_user_logged_in();
				},
				'callback'            => array( __CLASS__, 'get_article' ),
			)
		);

		register_rest_route(
			'poolsafe/v1',
			'/kb/search',
			array(
				'methods'             => 'GET',
				'permission_callback' => function () {
					return is_user_logged_in();
				},
				'args'                => array(
					'q' => array(
						'required' => true,
						'type'     => 'string',
					),
				),
				'callback'            => array( __CLASS__, 'search_articles' ),
			)
		);
	}

	public static function list_articles( $request ) {
		$args = array(
			'post_type'      => 'psp_kb_article',
			'posts_per_page' => $request->get_param( 'per_page' ) ?: 20,
			'paged'          => $request->get_param( 'page' ) ?: 1,
			'post_status'    => 'publish',
			'orderby'        => 'title',
			'order'          => 'ASC',
		);

		$category = $request->get_param( 'category' );
		if ( $category ) {
			$args['tax_query'] = array(
				array(
					'taxonomy' => 'psp_kb_category',
					'field'    => 'slug',
					'terms'    => $category,
				),
			);
		}

		$query    = new WP_Query( $args );
		$articles = array();

		foreach ( $query->posts as $post ) {
			$categories = wp_get_post_terms( $post->ID, 'psp_kb_category', array( 'fields' => 'names' ) );
			$articles[] = array(
				'id'         => $post->ID,
				'title'      => $post->post_title,
				'excerpt'    => $post->post_excerpt,
				'content'    => apply_filters( 'the_content', $post->post_content ),
				'categories' => $categories,
				'thumbnail'  => get_the_post_thumbnail_url( $post->ID, 'medium' ),
				'date'       => $post->post_date,
			);
		}

		return rest_ensure_response(
			array(
				'articles' => $articles,
				'total'    => $query->found_posts,
				'pages'    => $query->max_num_pages,
			)
		);
	}

	public static function get_article( $request ) {
		$post = get_post( $request['id'] );

		if ( ! $post || $post->post_type !== 'psp_kb_article' ) {
			return new WP_Error( 'not_found', 'Article not found', array( 'status' => 404 ) );
		}

		$categories = wp_get_post_terms( $post->ID, 'psp_kb_category', array( 'fields' => 'names' ) );

		return rest_ensure_response(
			array(
				'id'         => $post->ID,
				'title'      => $post->post_title,
				'content'    => apply_filters( 'the_content', $post->post_content ),
				'categories' => $categories,
				'thumbnail'  => get_the_post_thumbnail_url( $post->ID, 'large' ),
				'date'       => $post->post_date,
			)
		);
	}

	public static function search_articles( $request ) {
		$query_string = sanitize_text_field( $request['q'] );

		$args = array(
			'post_type'      => 'psp_kb_article',
			'posts_per_page' => 10,
			'post_status'    => 'publish',
			's'              => $query_string,
		);

		$query   = new WP_Query( $args );
		$results = array();

		foreach ( $query->posts as $post ) {
			$results[] = array(
				'id'      => $post->ID,
				'title'   => $post->post_title,
				'excerpt' => $post->post_excerpt,
			);
		}

		return rest_ensure_response( $results );
	}
}
