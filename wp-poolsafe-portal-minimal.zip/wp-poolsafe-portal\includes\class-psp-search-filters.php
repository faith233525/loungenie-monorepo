<?php
/**
 * Search & Filtering System
 * Full-text search and advanced filtering for tickets, services, companies
 */

if (!defined('ABSPATH')) {
    exit;
}

class PSP_Search_Filters {
    
    public function __construct() {
        add_action('rest_api_init', [$this, 'register_endpoints']);
    }
    
    /**
     * Register search endpoints
     */
    public function register_endpoints() {
        register_rest_route('psp/v1', '/search', [
            'methods' => 'GET',
            'callback' => [$this, 'global_search'],
            'permission_callback' => [$this, 'check_auth'],
        ]);
        
        register_rest_route('psp/v1', '/tickets/search', [
            'methods' => 'GET',
            'callback' => [$this, 'search_tickets'],
            'permission_callback' => [$this, 'check_auth'],
        ]);
        
        register_rest_route('psp/v1', '/services/search', [
            'methods' => 'GET',
            'callback' => [$this, 'search_services'],
            'permission_callback' => [$this, 'check_auth'],
        ]);
        
        register_rest_route('psp/v1', '/companies/search', [
            'methods' => 'GET',
            'callback' => [$this, 'search_companies'],
            'permission_callback' => [$this, 'check_auth'],
        ]);
        
        // Save filter preferences
        register_rest_route('psp/v1', '/filters/save', [
            'methods' => 'POST',
            'callback' => [$this, 'save_filter'],
            'permission_callback' => [$this, 'check_auth'],
        ]);
        
        // Get saved filters
        register_rest_route('psp/v1', '/filters', [
            'methods' => 'GET',
            'callback' => [$this, 'get_saved_filters'],
            'permission_callback' => [$this, 'check_auth'],
        ]);
    }
    
    /**
     * Check authentication
     */
    public function check_auth() {
        return !empty($_SESSION['psp_user']);
    }
    
    /**
     * Global search across all resources
     */
    public function global_search($request) {
        global $wpdb;
        
        $user = $_SESSION['psp_user'] ?? null;
        if (!$user) {
            return new WP_Error('unauthorized', 'Not authenticated', ['status' => 401]);
        }
        
        $search_term = sanitize_text_field($request->get_param('q'));
        $limit = intval($request->get_param('limit')) ?: 10;
        
        if (strlen($search_term) < 2) {
            return new WP_Error('invalid', 'Search term too short', ['status' => 400]);
        }
        
        $search_pattern = '%' . $wpdb->esc_like($search_term) . '%';
        
        // Build params for ticket search
        $ticket_params = [$search_pattern, $search_pattern];
        if ($user['role'] !== 'admin') {
            $ticket_params[] = $user['company_id'];
        }
        $ticket_params[] = $limit;
        
        // Search tickets
        $tickets = $wpdb->get_results($wpdb->prepare(
            "SELECT id, subject, status, priority FROM {$wpdb->prefix}psp_tickets 
             WHERE (subject LIKE %s OR id LIKE %s)
             " . ($user['role'] !== 'admin' ? "AND partner_id = %d" : "") . "
             LIMIT %d",
            ...$ticket_params
        ));
        
        // Build params for company search
        $company_params = [$search_pattern];
        if ($user['role'] !== 'admin') {
            $company_params[] = $user['company_id'];
        }
        $company_params[] = $limit;
        
        // Search companies
        $companies = $wpdb->get_results($wpdb->prepare(
            "SELECT id, name FROM {$wpdb->prefix}psp_partners 
             WHERE name LIKE %s
             " . ($user['role'] !== 'admin' ? "AND id = %d" : "") . "
             LIMIT %d",
            ...$company_params
        ));
        
        return rest_ensure_response([
            'success' => true,
            'data' => [
                'tickets' => array_map(function($t) {
                    return ['type' => 'ticket', 'id' => $t->id, 'title' => $t->subject, 'status' => $t->status];
                }, $tickets),
                'companies' => array_map(function($c) {
                    return ['type' => 'company', 'id' => $c->id, 'title' => $c->name];
                }, $companies),
            ],
        ]);
    }
    
    /**
     * Search tickets with filters
     */
    public function search_tickets($request) {
        global $wpdb;
        
        $user = $_SESSION['psp_user'] ?? null;
        if (!$user) {
            return new WP_Error('unauthorized', 'Not authenticated', ['status' => 401]);
        }
        
        $search_term = sanitize_text_field($request->get_param('search')) ?? '';
        $status = sanitize_text_field($request->get_param('status')) ?? '';
        $priority = sanitize_text_field($request->get_param('priority')) ?? '';
        $assigned_to = intval($request->get_param('assigned_to')) ?: 0;
        $date_from = sanitize_text_field($request->get_param('date_from')) ?? '';
        $date_to = sanitize_text_field($request->get_param('date_to')) ?? '';
        $page = intval($request->get_param('page')) ?: 1;
        $per_page = intval($request->get_param('per_page')) ?: 20;
        $offset = ($page - 1) * $per_page;
        
        $where_clauses = [];
        $params = [];
        
        // Company filter
        if ($user['role'] !== 'admin') {
            $where_clauses[] = "t.partner_id = %d";
            $params[] = $user['company_id'];
        }
        
        // Search term
        if (!empty($search_term)) {
            $search_pattern = '%' . $wpdb->esc_like($search_term) . '%';
            $where_clauses[] = "(t.subject LIKE %s OR t.id LIKE %s OR t.description LIKE %s)";
            $params[] = $search_pattern;
            $params[] = $search_pattern;
            $params[] = $search_pattern;
        }
        
        // Status filter
        if (!empty($status)) {
            $where_clauses[] = "t.status = %s";
            $params[] = $status;
        }
        
        // Priority filter
        if (!empty($priority)) {
            $where_clauses[] = "t.priority = %s";
            $params[] = $priority;
        }
        
        // Assigned to filter
        if ($assigned_to > 0) {
            $where_clauses[] = "t.assigned_to = %d";
            $params[] = $assigned_to;
        }
        
        // Date range filter
        if (!empty($date_from)) {
            $where_clauses[] = "DATE(t.created_at) >= %s";
            $params[] = $date_from;
        }
        if (!empty($date_to)) {
            $where_clauses[] = "DATE(t.created_at) <= %s";
            $params[] = $date_to;
        }
        
        $where = !empty($where_clauses) ? 'WHERE ' . implode(' AND ', $where_clauses) : '';
        
        // Get total count
        $total = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}psp_tickets t {$where}",
                ...($params ?: [])
            )
        );
        
        // Get filtered results
        $tickets = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT t.*, u.name as assigned_user_name 
                 FROM {$wpdb->prefix}psp_tickets t
                 LEFT JOIN {$wpdb->prefix}psp_company_users u ON t.assigned_to = u.id
                 {$where}
                 ORDER BY t.created_at DESC
                 LIMIT %d OFFSET %d",
                ...array_merge($params ?: [], [$per_page, $offset])
            )
        );
        
        return rest_ensure_response([
            'success' => true,
            'data' => $tickets,
            'pagination' => [
                'page' => $page,
                'per_page' => $per_page,
                'total' => intval($total),
                'pages' => ceil($total / $per_page),
            ],
            'filters_applied' => [
                'search' => !empty($search_term),
                'status' => !empty($status),
                'priority' => !empty($priority),
                'assigned_to' => $assigned_to > 0,
                'date_range' => !empty($date_from) || !empty($date_to),
            ],
        ]);
    }
    
    /**
     * Search services with filters
     */
    public function search_services($request) {
        global $wpdb;
        
        $user = $_SESSION['psp_user'] ?? null;
        if (!$user) {
            return new WP_Error('unauthorized', 'Not authenticated', ['status' => 401]);
        }
        
        $search_term = sanitize_text_field($request->get_param('search')) ?? '';
        $date_from = sanitize_text_field($request->get_param('date_from')) ?? '';
        $date_to = sanitize_text_field($request->get_param('date_to')) ?? '';
        $min_cost = floatval($request->get_param('min_cost')) ?: 0;
        $max_cost = floatval($request->get_param('max_cost')) ?: PHP_FLOAT_MAX;
        $page = intval($request->get_param('page')) ?: 1;
        $per_page = intval($request->get_param('per_page')) ?: 20;
        $offset = ($page - 1) * $per_page;
        
        $where_clauses = [];
        $params = [];
        
        // Company filter
        if ($user['role'] !== 'admin') {
            $where_clauses[] = "partner_id = %d";
            $params[] = $user['company_id'];
        }
        
        // Search term
        if (!empty($search_term)) {
            $search_pattern = '%' . $wpdb->esc_like($search_term) . '%';
            $where_clauses[] = "(description LIKE %s OR notes LIKE %s)";
            $params[] = $search_pattern;
            $params[] = $search_pattern;
        }
        
        // Date range
        if (!empty($date_from)) {
            $where_clauses[] = "DATE(service_date) >= %s";
            $params[] = $date_from;
        }
        if (!empty($date_to)) {
            $where_clauses[] = "DATE(service_date) <= %s";
            $params[] = $date_to;
        }
        
        // Cost range
        $where_clauses[] = "cost >= %f AND cost <= %f";
        $params[] = $min_cost;
        $params[] = $max_cost;
        
        $where = !empty($where_clauses) ? 'WHERE ' . implode(' AND ', $where_clauses) : '';
        
        // Get total count
        $total = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}psp_service_records {$where}",
                ...($params ?: [])
            )
        );
        
        // Get results
        $services = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}psp_service_records {$where}
                 ORDER BY service_date DESC
                 LIMIT %d OFFSET %d",
                ...array_merge($params ?: [], [$per_page, $offset])
            )
        );
        
        return rest_ensure_response([
            'success' => true,
            'data' => $services,
            'pagination' => [
                'page' => $page,
                'per_page' => $per_page,
                'total' => intval($total),
                'pages' => ceil($total / $per_page),
            ],
        ]);
    }
    
    /**
     * Search companies
     */
    public function search_companies($request) {
        global $wpdb;
        
        $user = $_SESSION['psp_user'] ?? null;
        if (!$user || $user['role'] !== 'admin') {
            return new WP_Error('forbidden', 'Admin only', ['status' => 403]);
        }
        
        $search_term = sanitize_text_field($request->get_param('search')) ?? '';
        $city = sanitize_text_field($request->get_param('city')) ?? '';
        $state = sanitize_text_field($request->get_param('state')) ?? '';
        $page = intval($request->get_param('page')) ?: 1;
        $per_page = intval($request->get_param('per_page')) ?: 20;
        $offset = ($page - 1) * $per_page;
        
        $where_clauses = [];
        $params = [];
        
        if (!empty($search_term)) {
            $search_pattern = '%' . $wpdb->esc_like($search_term) . '%';
            $where_clauses[] = "(name LIKE %s OR email LIKE %s OR phone LIKE %s)";
            $params[] = $search_pattern;
            $params[] = $search_pattern;
            $params[] = $search_pattern;
        }
        
        if (!empty($city)) {
            $where_clauses[] = "city = %s";
            $params[] = $city;
        }
        
        if (!empty($state)) {
            $where_clauses[] = "state = %s";
            $params[] = $state;
        }
        
        $where = !empty($where_clauses) ? 'WHERE ' . implode(' AND ', $where_clauses) : '';
        
        $total = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}psp_partners {$where}" . 
            ($where ? "" : "WHERE 1=1"));
        
        $companies = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}psp_partners {$where}
                 ORDER BY name ASC
                 LIMIT %d OFFSET %d",
                ...array_merge($params ?: [], [$per_page, $offset])
            )
        );
        
        return rest_ensure_response([
            'success' => true,
            'data' => $companies,
            'pagination' => [
                'page' => $page,
                'per_page' => $per_page,
                'total' => intval($total),
                'pages' => ceil($total / $per_page),
            ],
        ]);
    }
    
    /**
     * Save filter preferences
     */
    public function save_filter($request) {
        global $wpdb;
        
        $user = $_SESSION['psp_user'] ?? null;
        if (!$user) {
            return new WP_Error('unauthorized', 'Not authenticated', ['status' => 401]);
        }
        
        $data = $request->get_json_params();
        
        if (empty($data['name']) || empty($data['filter_type']) || empty($data['filters'])) {
            return new WP_Error('invalid', 'Missing required fields', ['status' => 400]);
        }
        
        // Check if filter exists
        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}psp_saved_filters 
             WHERE user_id = %d AND name = %s",
            $user['id'],
            $data['name']
        ));
        
        $filter_data = [
            'user_id' => $user['id'],
            'name' => sanitize_text_field($data['name']),
            'filter_type' => sanitize_text_field($data['filter_type']),
            'filters' => wp_json_encode($data['filters']),
            'updated_at' => current_time('mysql'),
        ];
        
        if ($existing) {
            $wpdb->update("{$wpdb->prefix}psp_saved_filters", $filter_data, ['id' => $existing->id]);
            $filter_id = $existing->id;
        } else {
            $filter_data['created_at'] = current_time('mysql');
            $wpdb->insert("{$wpdb->prefix}psp_saved_filters", $filter_data);
            $filter_id = $wpdb->insert_id;
        }
        
        return rest_ensure_response([
            'success' => true,
            'message' => 'Filter saved successfully',
            'filter_id' => $filter_id,
        ], 201);
    }
    
    /**
     * Get saved filters
     */
    public function get_saved_filters($request) {
        global $wpdb;
        
        $user = $_SESSION['psp_user'] ?? null;
        if (!$user) {
            return new WP_Error('unauthorized', 'Not authenticated', ['status' => 401]);
        }
        
        $filter_type = sanitize_text_field($request->get_param('filter_type')) ?? '';
        
        $query = "SELECT * FROM {$wpdb->prefix}psp_saved_filters WHERE user_id = %d";
        $params = [$user['id']];
        
        if (!empty($filter_type)) {
            $query .= " AND filter_type = %s";
            $params[] = $filter_type;
        }
        
        $query .= " ORDER BY name ASC";
        
        $filters = $wpdb->get_results($wpdb->prepare($query, ...$params));
        
        // Decode JSON filters
        foreach ($filters as $filter) {
            $filter->filters = json_decode($filter->filters, true);
        }
        
        return rest_ensure_response([
            'success' => true,
            'data' => $filters,
            'count' => count($filters),
        ]);
    }
}

// Initialize
new PSP_Search_Filters();
