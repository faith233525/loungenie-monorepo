<?php
/**
 * PoolSafe Portal - Performance Monitoring
 *
 * Tracks performance metrics and diagnostics for the unified portal
 *
 * @package   PoolSafe Portal
 * @namespace PSP\Performance
 * @version   3.2.5
 */

namespace PSP\Performance;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Performance Monitor Class
 *
 * Tracks:
 * - Cache hit/miss rates
 * - Query execution times
 * - Response times
 * - Slow queries
 */
class PerformanceMonitor {

    /**
     * Start time tracking
     *
     * @var float
     */
    private static $start_time = 0;

    /**
     * Query count tracking
     *
     * @var int
     */
    private static $query_count = 0;

    /**
     * Cache metrics
     *
     * @var array
     */
    private static $cache_metrics = array(
        'hits'   => 0,
        'misses' => 0,
    );

    /**
     * Start performance tracking
     *
     * @return void
     */
    public static function start(): void {
        try {
            self::$start_time = microtime( true );
            self::$query_count = get_num_queries();
            self::$cache_metrics = array( 'hits' => 0, 'misses' => 0 );
        } catch ( \Exception $e ) {
            error_log( '[PSP Performance] Start tracking failed: ' . $e->getMessage() );
        }
    }

    /**
     * Record cache hit
     *
     * @return void
     */
    public static function record_cache_hit(): void {
        self::$cache_metrics['hits']++;
    }

    /**
     * Record cache miss
     *
     * @return void
     */
    public static function record_cache_miss(): void {
        self::$cache_metrics['misses']++;
    }

    /**
     * Get current metrics
     *
     * @return array Performance metrics
     */
    public static function get_metrics(): array {
        try {
            $elapsed = microtime( true ) - self::$start_time;
            $queries = get_num_queries() - self::$query_count;
            $total_cache = self::$cache_metrics['hits'] + self::$cache_metrics['misses'];
            $hit_rate = $total_cache > 0 ? ( self::$cache_metrics['hits'] / $total_cache ) * 100 : 0;

            return array(
                'elapsed_ms'     => round( $elapsed * 1000, 2 ),
                'query_count'    => $queries,
                'cache_hits'     => self::$cache_metrics['hits'],
                'cache_misses'   => self::$cache_metrics['misses'],
                'cache_hit_rate' => round( $hit_rate, 2 ) . '%',
                'timestamp'      => current_time( 'mysql' ),
            );
        } catch ( \Exception $e ) {
            error_log( '[PSP Performance] Get metrics failed: ' . $e->getMessage() );
            return array();
        }
    }

    /**
     * Log performance data
     *
     * @param string $operation Operation name
     * @return void
     */
    public static function log_operation( string $operation ): void {
        try {
            $metrics = self::get_metrics();
            
            // Only log if performance is concerning
            if ( $metrics['elapsed_ms'] > 500 || $metrics['query_count'] > 10 ) {
                error_log( '[PSP Performance] ' . $operation . ': ' . wp_json_encode( $metrics ) );
            }
        } catch ( \Exception $e ) {
            error_log( '[PSP Performance] Log operation failed: ' . $e->getMessage() );
        }
    }

    /**
     * Get slow queries
     *
     * Identifies queries taking longer than threshold
     *
     * @param float $threshold Time threshold in seconds
     * @return array Slow queries
     */
    public static function get_slow_queries( float $threshold = 0.1 ): array {
        try {
            if ( ! defined( 'SAVEQUERIES' ) || ! SAVEQUERIES ) {
                return array();
            }

            global $wpdb;
            $slow = array();

            foreach ( (array) $wpdb->queries as $query ) {
                if ( isset( $query[1] ) && (float) $query[1] > $threshold ) {
                    $slow[] = array(
                        'query' => $query[0],
                        'time'  => $query[1],
                    );
                }
            }

            return $slow;
        } catch ( \Exception $e ) {
            error_log( '[PSP Performance] Get slow queries failed: ' . $e->getMessage() );
            return array();
        }
    }

    /**
     * Get performance dashboard data
     *
     * @return array Dashboard metrics
     */
    public static function get_dashboard_data(): array {
        try {
            global $wpdb;

            $metrics = self::get_metrics();
            $slow_queries = self::get_slow_queries();

            return array(
                'current'       => $metrics,
                'slow_queries'  => count( $slow_queries ),
                'memory_usage'  => round( memory_get_usage() / 1024 / 1024, 2 ) . ' MB',
                'peak_memory'   => round( memory_get_peak_usage() / 1024 / 1024, 2 ) . ' MB',
                'query_count'   => get_num_queries(),
                'timestamp'     => current_time( 'mysql' ),
            );
        } catch ( \Exception $e ) {
            error_log( '[PSP Performance] Get dashboard data failed: ' . $e->getMessage() );
            return array();
        }
    }

    /**
     * Initialize performance monitoring
     *
     * @return void
     */
    public static function init(): void {
        try {
            // Start tracking on WordPress init
            add_action( 'wp_loaded', array( __CLASS__, 'start' ), 1 );

            // Log slow operations
            if ( defined( 'WP_DEBUG_LOG' ) && WP_DEBUG_LOG ) {
                add_action( 'wp_footer', array( __CLASS__, 'log_operation' ), 999, 0 );
            }
        } catch ( \Exception $e ) {
            error_log( '[PSP Performance] Initialization failed: ' . $e->getMessage() );
        }
    }
}
