<?php
/**
 * Email Template - New Ticket Notification
 * Sends when a new ticket is created
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 600px;
            margin: 0 auto;
            background-color: #f9f9f9;
        }
        .email-container {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 8px 8px 0 0;
            text-align: center;
        }
        .header h1 {
            margin: 0;
            font-size: 24px;
        }
        .content {
            padding: 20px;
        }
        .ticket-info {
            background-color: #f0f4ff;
            border-left: 4px solid #667eea;
            padding: 15px;
            margin: 20px 0;
            border-radius: 4px;
        }
        .ticket-info p {
            margin: 8px 0;
        }
        .ticket-info strong {
            color: #667eea;
        }
        .button {
            display: inline-block;
            background-color: #667eea;
            color: white;
            padding: 12px 24px;
            text-decoration: none;
            border-radius: 4px;
            margin: 20px 0;
            font-weight: bold;
        }
        .button:hover {
            background-color: #5568d3;
        }
        .footer {
            text-align: center;
            color: #666;
            font-size: 12px;
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #eee;
        }
    </style>
</head>
<body>
    <div class="email-container">
        <div class="header">
            <h1>🎫 New Ticket Received</h1>
        </div>

        <div class="content">
            <p>Hello <?php echo isset($ticket_author) ? esc_html($ticket_author) : 'Support Team'; ?>,</p>

            <p>A new ticket has been created and assigned to you.</p>

            <div class="ticket-info">
                <p><strong>Ticket #:</strong> <?php echo isset($ticket_number) ? esc_html($ticket_number) : '—'; ?></p>
                <p><strong>Title:</strong> <?php echo isset($ticket_title) ? esc_html($ticket_title) : '—'; ?></p>
                <p><strong>Priority:</strong> <span style="color: <?php 
                    echo match(isset($ticket_priority) ? $ticket_priority : '') {
                        'urgent' => '#ef4444',
                        'high' => '#f59e0b',
                        'medium' => '#10b981',
                        'low' => '#3b82f6',
                        default => '#666'
                    };
                ?>"><?php echo isset($ticket_priority) ? ucfirst($ticket_priority) : '—'; ?></span></p>
                <p><strong>Category:</strong> <?php echo isset($ticket_category) ? esc_html($ticket_category) : '—'; ?></p>
                <p><strong>Company:</strong> <?php echo isset($ticket_company) ? esc_html($ticket_company) : '—'; ?></p>
                <p><strong>Submitted:</strong> <?php echo isset($ticket_created) ? date_i18n('M d, Y @ g:i A', strtotime($ticket_created)) : '—'; ?></p>
            </div>

            <h3>Description:</h3>
            <p><?php echo isset($ticket_description) ? wp_kses_post($ticket_description) : '—'; ?></p>

            <center>
                <a href="<?php echo isset($ticket_url) ? esc_url($ticket_url) : '#'; ?>" class="button">
                    View Ticket in Portal →
                </a>
            </center>

            <p>Please review and take action on this ticket at your earliest convenience.</p>

            <p>Thank you!</p>
        </div>

        <div class="footer">
            <p>PoolSafe Portal | Support Team</p>
            <p>This is an automated email. Please do not reply directly to this message.</p>
        </div>
    </div>
</body>
</html>
