<?php
/**
 * PoolSafe Portal - API Rate Limiter
 *
 * Provides endpoint-specific rate limiting and request validation
 *
 * @package   PoolSafe Portal
 * @namespace PSP\API
 * @version   3.2.5
 */

namespace PSP\API;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * API Rate Limiter Class
 *
 * Features:
 * - Per-endpoint rate limiting
 * - Per-user rate limiting
 * - Sliding window algorithm
 * - Request validation
 * - Automatic cleanup
 */
class RateLimiter {

    /**
     * Default rate limits (requests per minute)
     *
     * @var array
     */
    private static $limits = array(
        'default'           => 60,
        'get_user_tickets'  => 30,
        'get_partners'      => 20,
        'create_ticket'     => 10,
        'update_ticket'     => 10,
        'delete_ticket'     => 5,
    );

    /**
     * Check if request is rate limited
     *
     * @param int $user_id User ID
     * @param string $endpoint Endpoint name
     * @return bool True if rate limited, false if allowed
     */
    public static function is_limited( int $user_id, string $endpoint = 'default' ): bool {
        try {
            if ( $user_id <= 0 ) {
                return true; // No unauthenticated requests
            }

            $cache_key = 'rate_limit_' . $user_id . '_' . $endpoint;
            $limit = self::$limits[ $endpoint ] ?? self::$limits['default'];
            
            // Get current request count
            $count = (int) get_transient( $cache_key );

            if ( $count >= $limit ) {
                return true; // Rate limited
            }

            // Increment and set transient for 1 minute
            set_transient( $cache_key, $count + 1, 60 );
            return false; // Not rate limited
        } catch ( \Exception $e ) {
            error_log( '[PSP Rate Limiter] Check limited failed: ' . $e->getMessage() );
            return false; // Allow on error
        }
    }

    /**
     * Get remaining requests
     *
     * @param int $user_id User ID
     * @param string $endpoint Endpoint name
     * @return int Remaining requests
     */
    public static function get_remaining( int $user_id, string $endpoint = 'default' ): int {
        try {
            $cache_key = 'rate_limit_' . $user_id . '_' . $endpoint;
            $limit = self::$limits[ $endpoint ] ?? self::$limits['default'];
            $count = (int) get_transient( $cache_key );

            return max( 0, $limit - $count );
        } catch ( \Exception $e ) {
            error_log( '[PSP Rate Limiter] Get remaining failed: ' . $e->getMessage() );
            return 0;
        }
    }

    /**
     * Reset rate limit for user/endpoint
     *
     * @param int $user_id User ID
     * @param string $endpoint Endpoint name (empty for all)
     * @return void
     */
    public static function reset( int $user_id, string $endpoint = '' ): void {
        try {
            if ( empty( $endpoint ) ) {
                // Reset all endpoints for user
                foreach ( array_keys( self::$limits ) as $ep ) {
                    delete_transient( 'rate_limit_' . $user_id . '_' . $ep );
                }
            } else {
                delete_transient( 'rate_limit_' . $user_id . '_' . $endpoint );
            }
        } catch ( \Exception $e ) {
            error_log( '[PSP Rate Limiter] Reset failed: ' . $e->getMessage() );
        }
    }

    /**
     * Set custom rate limit
     *
     * @param string $endpoint Endpoint name
     * @param int $limit Requests per minute
     * @return void
     */
    public static function set_limit( string $endpoint, int $limit ): void {
        try {
            if ( ! empty( $endpoint ) && $limit > 0 ) {
                self::$limits[ $endpoint ] = $limit;
            }
        } catch ( \Exception $e ) {
            error_log( '[PSP Rate Limiter] Set limit failed: ' . $e->getMessage() );
        }
    }

    /**
     * Get current limits configuration
     *
     * @return array Rate limit configuration
     */
    public static function get_limits(): array {
        return self::$limits;
    }

    /**
     * Validate API request
     *
     * Checks user auth, rate limit, and request validity
     *
     * @param int $user_id User ID
     * @param string $endpoint Endpoint name
     * @param string $method Request method (GET, POST, etc)
     * @return array Validation result
     */
    public static function validate_request( int $user_id, string $endpoint, string $method = 'GET' ): array {
        try {
            // Check user authentication
            if ( ! is_user_logged_in() || get_current_user_id() !== $user_id ) {
                return array(
                    'valid' => false,
                    'reason' => 'Unauthorized',
                    'code' => 401,
                );
            }

            // Check rate limit
            if ( self::is_limited( $user_id, $endpoint ) ) {
                return array(
                    'valid' => false,
                    'reason' => 'Rate limit exceeded',
                    'code' => 429,
                    'remaining' => 0,
                    'retry_after' => 60,
                );
            }

            return array(
                'valid' => true,
                'remaining' => self::get_remaining( $user_id, $endpoint ),
                'code' => 200,
            );
        } catch ( \Exception $e ) {
            error_log( '[PSP Rate Limiter] Validate request failed: ' . $e->getMessage() );
            return array(
                'valid' => false,
                'reason' => 'Validation error',
                'code' => 500,
            );
        }
    }

    /**
     * Get usage statistics
     *
     * @param int $user_id User ID
     * @return array Usage statistics
     */
    public static function get_usage_stats( int $user_id ): array {
        try {
            $stats = array();

            foreach ( array_keys( self::$limits ) as $endpoint ) {
                $limit = self::$limits[ $endpoint ];
                $remaining = self::get_remaining( $user_id, $endpoint );
                $used = $limit - $remaining;

                $stats[ $endpoint ] = array(
                    'limit'     => $limit,
                    'used'      => $used,
                    'remaining' => $remaining,
                    'percent'   => round( ( $used / $limit ) * 100, 2 ),
                );
            }

            return $stats;
        } catch ( \Exception $e ) {
            error_log( '[PSP Rate Limiter] Get usage stats failed: ' . $e->getMessage() );
            return array();
        }
    }

    /**
     * Initialize rate limiter
     *
     * @return void
     */
    public static function init(): void {
        try {
            // Register hooks for rate limiting
            add_filter( 'rest_pre_dispatch', array( __CLASS__, 'check_rate_limit' ), 10, 3 );
        } catch ( \Exception $e ) {
            error_log( '[PSP Rate Limiter] Initialization failed: ' . $e->getMessage() );
        }
    }

    /**
     * Check rate limit on REST API requests
     *
     * @param mixed $result Response result
     * @param object $server REST server
     * @param object $request REST request
     * @return mixed Response
     */
    public static function check_rate_limit( $result, $server, $request ) {
        try {
            if ( ! isset( $_SERVER['REQUEST_URI'] ) || strpos( $_SERVER['REQUEST_URI'], '/psp/' ) === false ) {
                return $result;
            }

            $user_id = get_current_user_id();
            if ( $user_id <= 0 ) {
                return $result;
            }

            $path = $request->get_route();
            $endpoint = basename( $path );

            if ( self::is_limited( $user_id, $endpoint ) ) {
                return new \WP_Error(
                    'rate_limit_exceeded',
                    'Rate limit exceeded. Please try again later.',
                    array( 'status' => 429 )
                );
            }

            return $result;
        } catch ( \Exception $e ) {
            error_log( '[PSP Rate Limiter] Check rate limit failed: ' . $e->getMessage() );
            return $result;
        }
    }
}
