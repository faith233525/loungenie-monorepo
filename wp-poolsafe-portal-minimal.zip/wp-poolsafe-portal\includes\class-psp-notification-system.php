<?php
/**
 * Pool Safe Portal - Notifications System
 * 
 * Handles email notifications, in-app alerts, and notification preferences
 * Supports multiple notification types and recipient management
 * 
 * @package PSP\Notifications
 * @version 2.0.0
 */

namespace PSP\Notifications;

if (!defined('ABSPATH')) {
    exit;
}

class Notifications {
    
    // Notification types
    const TYPES = [
        'ticket_created' => 'New Ticket Created',
        'ticket_assigned' => 'Ticket Assigned to You',
        'ticket_updated' => 'Ticket Updated',
        'ticket_closed' => 'Ticket Closed',
        'partner_registered' => 'New Partner Registered',
        'partner_status_changed' => 'Partner Status Changed',
        'property_added' => 'New Property Added',
        'service_scheduled' => 'Service Scheduled',
        'service_completed' => 'Service Completed',
        'invoice_created' => 'Invoice Created',
        'invoice_overdue' => 'Invoice Overdue',
        'video_uploaded' => 'New Training Video',
        'alert_warning' => 'Alert: Warning',
        'alert_critical' => 'Alert: Critical Issue',
    ];
    
    // Delivery channels
    const CHANNELS = [
        'email' => 'Email',
        'in_app' => 'In-App',
        'sms' => 'SMS (Optional)',
    ];
    
    /**
     * Initialize Notifications system
     */
    public static function init() {
        add_action('init', [__CLASS__, 'register_notification_post_type']);
        add_action('rest_api_init', [__CLASS__, 'register_rest_endpoints']);
        add_action('init', [__CLASS__, 'setup_notification_hooks']);
    }
    
    /**
     * Register notification CPT for storing notification history
     */
    public static function register_notification_post_type() {
        register_post_type('psp_notification', [
            'label' => 'Notifications',
            'description' => 'User notifications and alerts',
            'public' => false,
            'show_ui' => true,
            'show_in_menu' => 'psp-portal',
            'show_in_rest' => true,
            'rest_base' => 'notifications',
            'supports' => ['title', 'editor'],
            'capability_type' => 'post',
            'capabilities' => [
                'create_posts' => 'manage_psp_portal',
                'read_post' => 'manage_psp_portal',
                'edit_post' => 'manage_psp_portal',
                'delete_post' => 'manage_psp_portal',
            ],
        ]);
        
        // Register meta fields for notifications
        register_post_meta('psp_notification', 'psp_notification_type', [
            'show_in_rest' => true,
            'type' => 'string',
            'single' => true,
        ]);
        
        register_post_meta('psp_notification', 'psp_notification_recipient_id', [
            'show_in_rest' => true,
            'type' => 'integer',
            'single' => true,
        ]);
        
        register_post_meta('psp_notification', 'psp_notification_read', [
            'show_in_rest' => true,
            'type' => 'boolean',
            'single' => true,
        ]);
        
        register_post_meta('psp_notification', 'psp_notification_channels', [
            'show_in_rest' => [
                'schema' => [
                    'type'  => 'array',
                    'items' => [ 'type' => 'string' ],
                ],
            ],
            'type' => 'array',
            'single' => true,
        ]);
        
        register_post_meta('psp_notification', 'psp_notification_related_object', [
            'show_in_rest' => true,
            'type' => 'string',
            'single' => true,
        ]);
    }
    
    /**
     * Register REST API endpoints
     */
    public static function register_rest_endpoints() {
        register_rest_route('poolsafe/v1', '/notifications', [
            [
                'methods' => 'GET',
                'callback' => [__CLASS__, 'get_notifications'],
                'permission_callback' => function () {
                    return is_user_logged_in();
                },
                'args' => [
                    'read' => ['type' => 'boolean', 'required' => false],
                    'limit' => ['type' => 'integer', 'default' => 20],
                    'offset' => ['type' => 'integer', 'default' => 0],
                ],
            ],
            [
                'methods' => 'POST',
                'callback' => [__CLASS__, 'create_notification'],
                'permission_callback' => function () {
                    return current_user_can('manage_psp_portal');
                },
            ],
        ]);
        
        register_rest_route('poolsafe/v1', '/notifications/(?P<id>\d+)', [
            'methods' => 'PATCH',
            'callback' => [__CLASS__, 'mark_notification_read'],
            'permission_callback' => function () {
                return is_user_logged_in();
            },
        ]);
        
        register_rest_route('poolsafe/v1', '/notifications/mark-all-read', [
            'methods' => 'POST',
            'callback' => [__CLASS__, 'mark_all_read'],
            'permission_callback' => function () {
                return is_user_logged_in();
            },
        ]);
        
        register_rest_route('poolsafe/v1', '/notification-preferences', [
            [
                'methods' => 'GET',
                'callback' => [__CLASS__, 'get_preferences'],
                'permission_callback' => function () {
                    return is_user_logged_in();
                },
            ],
            [
                'methods' => 'POST',
                'callback' => [__CLASS__, 'save_preferences'],
                'permission_callback' => function () {
                    return is_user_logged_in();
                },
            ],
        ]);
    }
    
    /**
     * Setup WordPress hooks for notifications
     */
    public static function setup_notification_hooks() {
        // Hook into activity logs
        add_action('psp_activity_logged', [__CLASS__, 'handle_activity_notification'], 10, 2);
        
        // Hook into ticket events
        add_action('psp_ticket_created', [__CLASS__, 'notify_ticket_created'], 10, 2);
        add_action('psp_ticket_assigned', [__CLASS__, 'notify_ticket_assigned'], 10, 3);
        add_action('psp_ticket_updated', [__CLASS__, 'notify_ticket_updated'], 10, 2);
        add_action('psp_ticket_closed', [__CLASS__, 'notify_ticket_closed'], 10, 2);
        
        // Hook into partner events
        add_action('psp_partner_registered', [__CLASS__, 'notify_partner_registered'], 10, 1);
        add_action('psp_partner_status_changed', [__CLASS__, 'notify_partner_status_changed'], 10, 3);
        
        // Hook into service events
        add_action('psp_service_scheduled', [__CLASS__, 'notify_service_scheduled'], 10, 2);
        add_action('psp_service_completed', [__CLASS__, 'notify_service_completed'], 10, 2);
    }
    
    /**
     * Send notification to user
     */
    public static function send(
        $recipient_id,
        $type,
        $title,
        $message,
        $channels = ['email', 'in_app'],
        $related_object = null
    ) {
        // Create notification post
        $post_id = wp_insert_post([
            'post_type' => 'psp_notification',
            'post_status' => 'publish',
            'post_title' => $title,
            'post_content' => $message,
        ]);
        
        if (!$post_id) {
            return false;
        }
        
        // Add meta
        update_post_meta($post_id, 'psp_notification_type', $type);
        update_post_meta($post_id, 'psp_notification_recipient_id', $recipient_id);
        update_post_meta($post_id, 'psp_notification_read', false);
        update_post_meta($post_id, 'psp_notification_channels', $channels);
        update_post_meta($post_id, 'psp_notification_related_object', $related_object);
        
        // Send via channels
        $recipient = get_user_by('ID', $recipient_id);
        if (!$recipient) {
            wp_delete_post($post_id, true);
            return false;
        }
        
        if (in_array('email', $channels)) {
            self::send_email_notification($recipient->user_email, $title, $message);
        }
        
        return $post_id;
    }
    
    /**
     * Send email notification
     */
    private static function send_email_notification($email, $subject, $message) {
        $headers = ['Content-Type: text/html; charset=UTF-8'];
        
        $html_message = "
            <html>
                <body style='font-family: Arial, sans-serif; background-color: #f5f5f5;'>
                    <div style='max-width: 600px; margin: 0 auto; background-color: white; padding: 20px; border-radius: 5px;'>
                        <h2 style='color: #333;'>" . esc_html($subject) . "</h2>
                        <div style='color: #666; line-height: 1.6;'>
                            " . wp_kses_post($message) . "
                        </div>
                        <hr style='border: none; border-top: 1px solid #eee; margin: 20px 0;'>
                        <p style='color: #999; font-size: 12px;'>
                            This is an automated message from Pool Safe Portal. 
                            You can manage your notification preferences in your account settings.
                        </p>
                    </div>
                </body>
            </html>
        ";
        
        wp_mail($email, $subject, $html_message, $headers);
    }
    
    /**
     * Get user notifications
     */
    public static function get_notifications($request) {
        $user_id = get_current_user_id();
        $read = $request->get_param('read');
        $limit = $request->get_param('limit') ?? 20;
        $offset = $request->get_param('offset') ?? 0;
        
        $args = [
            'post_type' => 'psp_notification',
            'posts_per_page' => $limit,
            'offset' => $offset,
            'orderby' => 'date',
            'order' => 'DESC',
            'meta_query' => [
                [
                    'key' => 'psp_notification_recipient_id',
                    'value' => $user_id,
                    'type' => 'NUMERIC',
                ],
            ],
        ];
        
        if ($read !== null) {
            $args['meta_query'][] = [
                'key' => 'psp_notification_read',
                'value' => $read ? '1' : '0',
                'type' => 'BOOLEAN',
            ];
        }
        
        $query = new \WP_Query($args);
        $notifications = [];
        
        foreach ($query->posts as $post) {
            $notifications[] = [
                'id' => $post->ID,
                'type' => get_post_meta($post->ID, 'psp_notification_type', true),
                'title' => $post->post_title,
                'message' => $post->post_content,
                'read' => (bool) get_post_meta($post->ID, 'psp_notification_read', true),
                'created_at' => $post->post_date,
                'related_object' => get_post_meta($post->ID, 'psp_notification_related_object', true),
            ];
        }
        
        return [
            'data' => $notifications,
            'total' => $query->found_posts,
            'unread' => self::count_unread_notifications($user_id),
        ];
    }
    
    /**
     * Create notification via API
     */
    public static function create_notification($request) {
        $params = $request->get_json_params();
        
        $post_id = self::send(
            $params['recipient_id'] ?? 0,
            $params['type'] ?? 'alert_warning',
            $params['title'] ?? 'Notification',
            $params['message'] ?? '',
            $params['channels'] ?? ['email', 'in_app'],
            $params['related_object'] ?? null
        );
        
        return $post_id ? ['id' => $post_id, 'success' => true] : new \WP_Error('failed', 'Failed to create notification');
    }
    
    /**
     * Mark notification as read
     */
    public static function mark_notification_read($request) {
        $user_id = get_current_user_id();
        $post_id = $request->get_param('id');
        
        // Verify ownership
        $recipient_id = get_post_meta($post_id, 'psp_notification_recipient_id', true);
        if ((int) $recipient_id !== $user_id) {
            return new \WP_Error('forbidden', 'Not authorized');
        }
        
        update_post_meta($post_id, 'psp_notification_read', true);
        
        return ['success' => true];
    }
    
    /**
     * Mark all notifications as read
     */
    public static function mark_all_read($request) {
        $user_id = get_current_user_id();
        
        $args = [
            'post_type' => 'psp_notification',
            'posts_per_page' => -1,
            'meta_query' => [
                [
                    'key' => 'psp_notification_recipient_id',
                    'value' => $user_id,
                    'type' => 'NUMERIC',
                ],
                [
                    'key' => 'psp_notification_read',
                    'value' => '0',
                    'type' => 'BOOLEAN',
                    'compare' => '=',
                ],
            ],
        ];
        
        $query = new \WP_Query($args);
        
        foreach ($query->posts as $post) {
            update_post_meta($post->ID, 'psp_notification_read', true);
        }
        
        return ['success' => true, 'count' => count($query->posts)];
    }
    
    /**
     * Get user notification preferences
     */
    public static function get_preferences($request) {
        $user_id = get_current_user_id();
        
        $preferences = get_user_meta($user_id, 'psp_notification_preferences', true);
        
        if (empty($preferences)) {
            $preferences = self::get_default_preferences();
        }
        
        return $preferences;
    }
    
    /**
     * Save user notification preferences
     */
    public static function save_preferences($request) {
        $user_id = get_current_user_id();
        $params = $request->get_json_params();
        
        update_user_meta($user_id, 'psp_notification_preferences', $params);
        
        return ['success' => true];
    }
    
    /**
     * Get default notification preferences
     */
    private static function get_default_preferences() {
        $preferences = [];
        
        foreach (self::TYPES as $key => $label) {
            $preferences[$key] = [
                'enabled' => true,
                'email' => true,
                'in_app' => true,
                'sms' => false,
            ];
        }
        
        return $preferences;
    }
    
    /**
     * Count unread notifications for user
     */
    public static function count_unread_notifications($user_id) {
        $args = [
            'post_type' => 'psp_notification',
            'posts_per_page' => -1,
            'meta_query' => [
                [
                    'key' => 'psp_notification_recipient_id',
                    'value' => $user_id,
                    'type' => 'NUMERIC',
                ],
                [
                    'key' => 'psp_notification_read',
                    'value' => '0',
                    'type' => 'BOOLEAN',
                ],
            ],
        ];
        
        $query = new \WP_Query($args);
        return $query->found_posts;
    }
    
    /**
     * Notification event handlers
     */
    
    public static function notify_ticket_created($ticket_id, $partner_id) {
        self::send(
            $partner_id,
            'ticket_created',
            'New Ticket Created',
            'A new support ticket has been created for you.',
            ['email', 'in_app'],
            "ticket:{$ticket_id}"
        );
    }
    
    public static function notify_ticket_assigned($ticket_id, $assigned_to, $assigned_by) {
        self::send(
            $assigned_to,
            'ticket_assigned',
            'Ticket Assigned',
            'You have been assigned a support ticket.',
            ['email', 'in_app'],
            "ticket:{$ticket_id}"
        );
    }
    
    public static function notify_ticket_updated($ticket_id, $partner_id) {
        self::send(
            $partner_id,
            'ticket_updated',
            'Ticket Updated',
            'Your support ticket has been updated.',
            ['email', 'in_app'],
            "ticket:{$ticket_id}"
        );
    }
    
    public static function notify_ticket_closed($ticket_id, $partner_id) {
        self::send(
            $partner_id,
            'ticket_closed',
            'Ticket Closed',
            'Your support ticket has been closed.',
            ['email', 'in_app'],
            "ticket:{$ticket_id}"
        );
    }
    
    public static function notify_partner_registered($partner_id) {
        // Notify admins
        $admins = get_users(['role' => 'administrator']);
        foreach ($admins as $admin) {
            self::send(
                $admin->ID,
                'partner_registered',
                'New Partner Registered',
                'A new partner has registered in the system.',
                ['email'],
                "partner:{$partner_id}"
            );
        }
    }
    
    public static function notify_partner_status_changed($partner_id, $old_status, $new_status) {
        self::send(
            $partner_id,
            'partner_status_changed',
            'Account Status Changed',
            "Your account status has changed from {$old_status} to {$new_status}.",
            ['email'],
            "partner:{$partner_id}"
        );
    }
    
    public static function notify_service_scheduled($service_id, $partner_id) {
        self::send(
            $partner_id,
            'service_scheduled',
            'Service Scheduled',
            'A service has been scheduled for one of your properties.',
            ['email', 'in_app'],
            "service:{$service_id}"
        );
    }
    
    public static function notify_service_completed($service_id, $partner_id) {
        self::send(
            $partner_id,
            'service_completed',
            'Service Completed',
            'A scheduled service has been marked as completed.',
            ['email', 'in_app'],
            "service:{$service_id}"
        );
    }
    
    public static function handle_activity_notification($action, $data) {
        // Send alert notifications for critical activities
        $critical_actions = ['partner_deleted', 'ticket_closed', 'invoice_paid'];
        
        if (in_array($action, $critical_actions)) {
            $admins = get_users(['role' => 'administrator']);
            foreach ($admins as $admin) {
                self::send(
                    $admin->ID,
                    'alert_warning',
                    "Critical Activity: {$action}",
                    json_encode($data),
                    ['email'],
                    null
                );
            }
        }
    }
}

// Initialize on WordPress init
Notifications::init();
