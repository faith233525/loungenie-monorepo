<?php
/**
 * Plugin Update Checker Library 5.6
 * http://w-shadow.com/
 *
 * Copyright 2025 Janis Elsts
 * Released under the MIT license. See license.txt for details.
 */

require __DIR__ . '/load-v5p6.php';
