<?php
namespace PSP;

/**
 * Settings Backup Manager
 * Creates backups of API credentials and settings before updating
 * Allows rollback if updates cause issues
 *
 * @since 1.1.0
 */

if (!defined('ABSPATH')) {
	exit;
}

class Settings_Backup {

	/**
	 * Backup directory path
	 *
	 * @var string
	 */
	private static $backup_dir = '';

	/**
	 * Initialize backup manager
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public static function init() {
		self::$backup_dir = wp_upload_dir()['basedir'] . '/psp-backups';
		add_action('wp_ajax_psp_backup_settings', [self::class, 'ajax_backup_settings']);
		add_action('wp_ajax_psp_restore_backup', [self::class, 'ajax_restore_backup']);
		add_action('wp_ajax_psp_list_backups', [self::class, 'ajax_list_backups']);
	}

	/**
	 * Create settings backup
	 *
	 * @since 1.1.0
	 * @return array Backup info or error.
	 */
	public static function create_backup() {
		// Check permissions
		if (!current_user_can('psp_manage_api_settings')) {
			return [
				'success' => false,
				'error' => 'Insufficient permissions',
			];
		}

		// Ensure backup directory exists
		if (!is_dir(self::$backup_dir)) {
			wp_mkdir_p(self::$backup_dir);
		}

		// Check directory is writable
		if (!is_writable(self::$backup_dir)) {
			return [
				'success' => false,
				'error' => 'Backup directory is not writable',
			];
		}

		// Get all plugin settings
		$settings = [
			'outlook' => get_option('psp_outlook_settings', []),
			'hubspot' => get_option('psp_hubspot_settings', []),
			'ticketing' => get_option('psp_ticketing_settings', []),
			'csv' => get_option('psp_csv_settings', []),
		];

		// Create backup file
		$filename = 'backup-' . date('Y-m-d-H-i-s') . '.json';
		$filepath = self::$backup_dir . '/' . $filename;

		$backup_data = [
			'timestamp' => current_time('mysql'),
			'user_id' => get_current_user_id(),
			'user_name' => wp_get_current_user()->display_name,
			'settings' => self::mask_sensitive_values($settings),
			'hash' => self::generate_backup_hash($settings),
		];

		$result = file_put_contents(
			$filepath,
			wp_json_encode($backup_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES),
			LOCK_EX
		);

		if ($result === false) {
			return [
				'success' => false,
				'error' => 'Failed to write backup file',
			];
		}

		// Log backup creation
		Audit_Logger::log([
			'action' => 'backup_created',
			'setting' => 'all_settings',
			'new_value' => $filename,
		]);

		return [
			'success' => true,
			'filename' => $filename,
			'timestamp' => current_time('mysql'),
			'user' => wp_get_current_user()->display_name,
		];
	}

	/**
	 * List all backups
	 *
	 * @since 1.1.0
	 * @return array List of backups.
	 */
	public static function list_backups() {
		if (!is_dir(self::$backup_dir)) {
			return [];
		}

		$files = glob(self::$backup_dir . '/backup-*.json');

		if (empty($files)) {
			return [];
		}

		$backups = [];

		foreach ($files as $file) {
			$content = file_get_contents($file);
			$data = json_decode($content, true);

			if ($data) {
				$backups[] = [
					'filename' => basename($file),
					'timestamp' => $data['timestamp'] ?? '',
					'user' => $data['user_name'] ?? 'Unknown',
					'size' => filesize($file),
				];
			}
		}

		// Sort by timestamp descending
		usort($backups, function ($a, $b) {
			return strtotime($b['timestamp']) - strtotime($a['timestamp']);
		});

		return $backups;
	}

	/**
	 * Restore from backup
	 *
	 * @since 1.1.0
	 * @param string $filename Backup filename.
	 * @return array Result.
	 */
	public static function restore_backup($filename) {
		// Check permissions
		if (!current_user_can('psp_manage_api_settings')) {
			return [
				'success' => false,
				'error' => 'Insufficient permissions',
			];
		}

		// Validate filename (prevent directory traversal)
		if (strpos($filename, '/') !== false || strpos($filename, '\\') !== false) {
			return [
				'success' => false,
				'error' => 'Invalid filename',
			];
		}

		$filepath = self::$backup_dir . '/' . $filename;

		if (!file_exists($filepath)) {
			return [
				'success' => false,
				'error' => 'Backup file not found',
			];
		}

		// Read backup
		$content = file_get_contents($filepath);
		$data = json_decode($content, true);

		if (!$data || empty($data['settings'])) {
			return [
				'success' => false,
				'error' => 'Invalid backup file',
			];
		}

		// Verify backup integrity
		if (empty($data['hash']) || $data['hash'] !== self::generate_backup_hash($data['settings'])) {
			return [
				'success' => false,
				'error' => 'Backup file integrity check failed',
			];
		}

		// Restore settings
		update_option('psp_outlook_settings', $data['settings']['outlook'] ?? []);
		update_option('psp_hubspot_settings', $data['settings']['hubspot'] ?? []);
		update_option('psp_ticketing_settings', $data['settings']['ticketing'] ?? []);
		update_option('psp_csv_settings', $data['settings']['csv'] ?? []);

		// Log restoration
		Audit_Logger::log([
			'action' => 'backup_restored',
			'setting' => 'all_settings',
			'new_value' => $filename,
		]);

		// Clear connection status cache
		delete_transient('psp_outlook_connection_status');
		delete_transient('psp_hubspot_connection_status');

		return [
			'success' => true,
			'message' => 'Settings restored from ' . $filename,
		];
	}

	/**
	 * AJAX handler: backup settings
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public static function ajax_backup_settings() {
		check_ajax_referer('psp_settings_nonce', 'nonce');

		if (!current_user_can('psp_manage_api_settings')) {
			wp_send_json_error('Insufficient permissions');
		}

		$result = self::create_backup();
		wp_send_json($result);
	}

	/**
	 * AJAX handler: restore backup
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public static function ajax_restore_backup() {
		check_ajax_referer('psp_settings_nonce', 'nonce');

		if (!current_user_can('psp_manage_api_settings')) {
			wp_send_json_error('Insufficient permissions');
		}

		$filename = sanitize_text_field($_POST['filename'] ?? '');

		if (empty($filename)) {
			wp_send_json_error('No backup specified');
		}

		$result = self::restore_backup($filename);
		wp_send_json($result);
	}

	/**
	 * AJAX handler: list backups
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public static function ajax_list_backups() {
		check_ajax_referer('psp_settings_nonce', 'nonce');

		if (!current_user_can('psp_manage_api_settings')) {
			wp_send_json_error('Insufficient permissions');
		}

		$backups = self::list_backups();
		wp_send_json_success($backups);
	}

	/**
	 * Mask sensitive values for display
	 *
	 * @since 1.1.0
	 * @param array $settings Settings to mask.
	 * @return array Masked settings.
	 */
	private static function mask_sensitive_values($settings) {
		// Don't store actual API keys/secrets in backup files
		// Store only metadata
		$masked = $settings;

		if (!empty($masked['outlook']['client_secret'])) {
			$masked['outlook']['client_secret'] = '***MASKED***';
		}

		if (!empty($masked['hubspot']['api_key'])) {
			$masked['hubspot']['api_key'] = '***MASKED***';
		}

		return $masked;
	}

	/**
	 * Generate backup integrity hash
	 *
	 * @since 1.1.0
	 * @param array $settings Settings to hash.
	 * @return string Hash value.
	 */
	private static function generate_backup_hash($settings) {
		// Hash includes actual values for integrity checking
		// But hash is stored in backup file, not transmitted
		return hash('sha256', wp_json_encode($settings));
	}

	/**
	 * Clean up old backups
	 *
	 * @since 1.1.0
	 * @param int $days Age threshold in days.
	 * @return int Number of backups deleted.
	 */
	public static function cleanup_old_backups($days = 30) {
		if (!is_dir(self::$backup_dir)) {
			return 0;
		}

		$files = glob(self::$backup_dir . '/backup-*.json');
		$deleted = 0;
		$cutoff = time() - ($days * DAY_IN_SECONDS);

		foreach ($files as $file) {
			if (filemtime($file) < $cutoff) {
				unlink($file);
				$deleted++;
			}
		}

		return $deleted;
	}
}
