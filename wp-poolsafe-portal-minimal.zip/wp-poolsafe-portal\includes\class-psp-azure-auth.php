<?php
// PSP Azure AD Authentication Handler
// Handles OAuth2 flow and Microsoft Graph token exchange

namespace PSP;

class Azure_Auth {


	private $clientId;
	private $tenantId;
	private $clientSecret;
	private $redirectUri;
	private $authorizeUrl;
	private $tokenUrl;
	private $scopes;

	public function __construct() {
		$this->clientId     = getenv( 'CLIENT_ID' );
		$this->tenantId     = getenv( 'TENANT_ID' );
		$this->clientSecret = getenv( 'CLIENT_SECRET' );
		// Allow override via environment; fallback to default for shared hosting
		$this->redirectUri  = getenv( 'AZURE_REDIRECT_URI' ) ?: 'https://portal.loungenie.com/psp-azure-callback';
		$this->authorizeUrl = "https://login.microsoftonline.com/{$this->tenantId}/oauth2/v2.0/authorize";
		$this->tokenUrl     = "https://login.microsoftonline.com/{$this->tenantId}/oauth2/v2.0/token";
		$this->scopes       = 'openid profile offline_access User.Read Mail.Read Mail.Send';
	}

	// Step 1: Redirect to Azure AD login
	public function getLoginUrl() {
		$params = array(
			'client_id'     => $this->clientId,
			'response_type' => 'code',
			'redirect_uri'  => $this->redirectUri,
			'response_mode' => 'query',
			'scope'         => $this->scopes,
			'state'         => wp_create_nonce( 'psp_azure_auth' ),
		);
		return $this->authorizeUrl . '?' . http_build_query( $params );
	}

	// Step 2: Handle callback and exchange code for token
	public function handleCallback() {
		// Verify user is logged in
		if ( ! is_user_logged_in() ) {
			PSP_Logger::error( 'Azure auth callback: User not logged in' );
			return false;
		}

		// Verify required parameters
		if ( ! isset( $_GET['code'] ) || ! isset( $_GET['state'] ) ) {
			PSP_Logger::error( 'Azure auth callback: Missing code or state parameter' );
			return false;
		}

		// Verify CSRF state token
		$state = sanitize_text_field( $_GET['state'] );
		if ( ! wp_verify_nonce( $state, 'psp_azure_auth' ) ) {
			PSP_Logger::error( 'Azure auth callback: Invalid state token (CSRF check failed)' );
			return false;
		}

		$code     = sanitize_text_field( $_GET['code'] );
		$body     = array(
			'client_id'     => $this->clientId,
			'scope'         => $this->scopes,
			'code'          => $code,
			'redirect_uri'  => $this->redirectUri,
			'grant_type'    => 'authorization_code',
			'client_secret' => $this->clientSecret,
		);
		$response = wp_remote_post(
			$this->tokenUrl,
			array(
				'body'    => $body,
				'timeout' => 15,
			)
		);
		if ( is_wp_error( $response ) ) {
			PSP_Logger::error(
				'Azure token exchange failed',
				array(
					'error'   => $response->get_error_message(),
					'code'    => $response->get_error_code(),
				)
			);
			return false;
		}

		$response_code = wp_remote_retrieve_response_code( $response );
		if ( 200 !== (int) $response_code ) {
			PSP_Logger::error(
				'Azure token exchange HTTP error',
				array(
					'status' => $response_code,
					'body'   => wp_remote_retrieve_body( $response ),
				)
			);
			return false;
		}

		$data = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( ! isset( $data['access_token'] ) ) {
			PSP_Logger::error(
				'Azure token response missing access_token',
				array(
					'response' => $data,
				)
			);
			return false;
		}

		// Store token in user meta
		$user_id = get_current_user_id();
		update_user_meta( $user_id, 'psp_azure_access_token', $data['access_token'] );
		if ( isset( $data['refresh_token'] ) ) {
			update_user_meta( $user_id, 'psp_azure_refresh_token', $data['refresh_token'] );
		}

		PSP_Logger::info(
			'Azure auth successful',
			array(
				'user_id' => $user_id,
				'token_expires' => isset( $data['expires_in'] ) ? time() + $data['expires_in'] : null,
			)
		);

		return true;
	}

	// Step 3: Get access token for current user
	public function getAccessToken() {
		$user_id = get_current_user_id();
		return get_user_meta( $user_id, 'psp_azure_access_token', true );
	}

	// Step 4: Call Microsoft Graph API
	public function callGraph( $endpoint, $method = 'GET', $body = null ) {
		$token = $this->getAccessToken();
		if ( ! $token ) {
			return false;
		}
		$args = array(
			'headers' => array(
				'Authorization' => 'Bearer ' . $token,
				'Content-Type'  => 'application/json',
			),
		);
		if ( $body ) {
			$args['body'] = json_encode( $body );
		}
		$url      = 'https://graph.microsoft.com/v1.0/' . ltrim( $endpoint, '/' );
		$response = ( $method === 'POST' ) ? wp_remote_post( $url, $args ) : wp_remote_get( $url, $args );
		if ( is_wp_error( $response ) ) {
			return false;
		}
		return json_decode( wp_remote_retrieve_body( $response ), true );
	}
}
