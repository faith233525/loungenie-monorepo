<?php
/**
 * Plugin Deactivation Class
 *
 * @link       https://poolsafe.com
 * @since      1.0.0
 *
 * @package    PoolSafe_Portal
 * @subpackage PoolSafe_Portal/includes
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Deactivation handler for the plugin
 *
 * @since      1.0.0
 * @package    PoolSafe_Portal
 */
class PSP_Deactivator {

    /**
     * Plugin deactivation handler
     * 
     * Safely cleans up plugin resources:
     * - Removes scheduled cron jobs
     * - Flushes rewrite rules
     * - Logs deactivation for auditing
     *
     * @since    1.0.0
     */
    public static function deactivate() {
        try {
            // Validate WordPress functions availability
            if ( ! function_exists( 'wp_clear_scheduled_hook' ) ) {
                error_log( '[PSP Deactivate] wp_clear_scheduled_hook() not available' );
                return;
            }
            
            // Remove plugin-specific schedule hooks with error handling
            $hooks = array(
                'psp_email_polling',
                'psp_audit_cleanup',
                'psp_notification_processing'
            );
            
            foreach ( $hooks as $hook ) {
                try {
                    wp_clear_scheduled_hook( $hook );
                } catch ( \Exception $e ) {
                    error_log( '[PSP Deactivate] Failed to clear hook ' . $hook . ': ' . $e->getMessage() );
                }
            }
            
            // Flush rewrite rules with error handling
            try {
                if ( function_exists( 'flush_rewrite_rules' ) ) {
                    flush_rewrite_rules();
                } else {
                    error_log( '[PSP Deactivate] flush_rewrite_rules() not available' );
                }
            } catch ( \Exception $e ) {
                error_log( '[PSP Deactivate] Failed to flush rewrite rules: ' . $e->getMessage() );
            }
            
            // Log deactivation for audit trail
            try {
                if ( function_exists( 'current_time' ) ) {
                    error_log( '[PSP Deactivate] Plugin deactivated at ' . current_time( 'Y-m-d H:i:s' ) );
                } else {
                    error_log( '[PSP Deactivate] Plugin deactivated' );
                }
            } catch ( \Exception $e ) {
                // Silently fail on logging error
            }
        } catch ( \Exception $e ) {
            error_log( '[PSP Deactivate] Deactivation error: ' . $e->getMessage() );
        }
    }
}
