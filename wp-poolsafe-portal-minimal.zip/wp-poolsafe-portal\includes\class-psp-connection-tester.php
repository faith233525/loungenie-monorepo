<?php
namespace PSP;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Lightweight connection tester stub for Outlook/Azure AD and HubSpot.
 * Returns connection status without causing fatals if credentials are absent.
 */
class Connection_Tester {
    /**
     * Test a service connection.
     *
     * @param string $service Service key: 'outlook' or 'hubspot'.
     * @return array { connected: bool, service: string, error: string|null }
     */
    public static function test_connection(string $service): array {
        $service = strtolower($service);

        // Default: report disconnected if required env/options are missing
        $connected = true;
        $error = null;

        switch ($service) {
            case 'outlook':
            case 'azure':
            case 'azuread':
                // If Azure client ID/secret are missing, mark as not connected.
                $client_id = getenv('CLIENT_ID') ?: ''; // per .env guidance in project
                $tenant_id = getenv('TENANT_ID') ?: '';
                $client_secret = getenv('CLIENT_SECRET') ?: '';
                if (!$client_id || !$tenant_id || !$client_secret) {
                    $connected = false;
                    $error = 'Azure credentials missing';
                }
                break;

            case 'hubspot':
                $api_key = get_option('psp_hubspot_api_key');
                $enabled = get_option('psp_hubspot_enabled');
                if (empty($enabled) || empty($api_key)) {
                    $connected = false;
                    $error = 'HubSpot not configured';
                }
                break;

            default:
                // Unknown service: treat as connected to avoid blocking; note it.
                $service = $service ?: 'unknown';
                $connected = true;
                $error = null;
                break;
        }

        return [
            'connected' => (bool) $connected,
            'service'   => $service,
            'error'     => $error,
        ];
    }
}
