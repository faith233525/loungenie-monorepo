<?php
namespace PSP;
/**
 * Tickets CPT & meta
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Tickets {


	/**
	 * Initialize ticket system with error handling
	 * 
	 * Features:
	 * - Safe action hook registration
	 * - Error logging
	 *
	 * @return void
	 */
	public static function init(): void {
		try {
			// Hook into ticket creation for email notifications
			if ( function_exists( 'add_action' ) ) {
				add_action( 'transition_post_status', array( __CLASS__, 'on_status_change' ), 10, 3 );
			} else {
				error_log( '[PSP Tickets] add_action function not available' );
			}
		} catch ( \Exception $e ) {
			error_log( '[PSP Tickets] Init failed: ' . $e->getMessage() );
		}
	}

	/**
	 * Register ticket custom post type with comprehensive error handling
	 * 
	 * Features:
	 * - Safe CPT registration
	 * - Capability mapping
	 * - Meta field registration with error handling
	 * - Validation of registration success
	 *
	 * @return void
	 */
	public static function register_cpt(): void {
		try {
			if ( ! function_exists( 'register_post_type' ) ) {
				error_log( '[PSP Tickets] register_post_type function not available' );
				return;
			}

			$labels = array(
				'name'          => __( 'Tickets', 'psp' ),
				'singular_name' => __( 'Ticket', 'psp' ),
			);
			$caps   = array(
				'read_post'           => 'read_psp_ticket',
				'read_private_posts'  => 'read_private_psp_tickets',
				'edit_post'           => 'edit_psp_ticket',
				'edit_posts'          => 'edit_psp_tickets',
				'edit_others_posts'   => 'edit_others_psp_tickets',
				'publish_posts'       => 'publish_psp_tickets',
				'delete_post'         => 'delete_psp_ticket',
				'delete_posts'        => 'delete_psp_tickets',
				'delete_others_posts' => 'delete_others_psp_tickets',
			);

			try {
				$result = register_post_type(
					'psp_ticket',
					array(
						'labels'          => $labels,
						'public'          => false,
						'show_ui'         => true,
						'show_in_menu'    => true,
						'capability_type' => array( 'psp_ticket', 'psp_tickets' ),
						'map_meta_cap'    => false,
						'capabilities'    => $caps,
						'supports'        => array( 'title', 'editor', 'author', 'custom-fields', 'comments' ),
						'show_in_rest'    => true,
						'menu_icon'       => 'dashicons-tickets',
					)
				);

				if ( is_wp_error( $result ) ) {
					error_log( '[PSP Tickets] CPT registration failed: ' . $result->get_error_message() );
					return;
				}
			} catch ( \Exception $e ) {
				error_log( '[PSP Tickets] CPT registration exception: ' . $e->getMessage() );
				return;
			}

			// Register core meta fields
			self::register_meta( 'priority', 'string' );
			self::register_meta( 'status', 'string' );
			self::register_meta( 'partner_id', 'integer' );
			// Register attachment_ids as array of integers with correct REST schema
			self::register_meta(
				'attachment_ids',
				'array',
				array(
					'type'  => 'array',
					'items' => array( 'type' => 'integer' ),
				)
			);

			// Register contact fields
			self::register_meta( 'first_name', 'string' );
			self::register_meta( 'last_name', 'string' );
			self::register_meta( 'position', 'string' );
			self::register_meta( 'contact_email', 'string' );
			self::register_meta( 'contact_number', 'string' );
			self::register_meta( 'units_affected', 'string' );

			// Register enhanced ticket fields
			self::register_meta( 'category', 'string' );
			self::register_meta( 'severity', 'string' );
			self::register_meta( 'video_link', 'string' );
			self::register_meta( 'resort_name', 'string' );

			// Email thread tracking
			self::register_meta( 'source', 'string' ); // portal, email, phone, chat
			self::register_meta( 'sender_email', 'string' ); // Original sender email
			self::register_meta( 'sender_name', 'string' ); // Original sender name
			self::register_meta( 'thread_id', 'string' ); // Email thread ID for tracking
			self::register_meta( 'response_count', 'integer' ); // Number of responses
			self::register_meta( 'last_response_at', 'string' ); // ISO datetime
			self::register_meta( 'last_response_by', 'string' ); // User ID or email
			self::register_meta( 'last_response_via', 'string' ); // portal, outlook, gmail

		} catch ( \Exception $e ) {
			error_log( '[PSP Tickets] CPT registration failed: ' . $e->getMessage() );
		}
	}

	/**
	 * Register meta field with comprehensive error handling
	 * 
	 * Features:
	 * - Safe function checking
	 * - Array type schema handling
	 * - Error logging
	 * - Authorization callback
	 *
	 * @param string $key Meta key name
	 * @param string $type Data type
	 * @param array  $rest_schema Optional REST schema for arrays
	 * @return void
	 */
	private static function register_meta( string $key, string $type, $rest_schema = null ): void {
		try {
			if ( ! function_exists( 'register_post_meta' ) ) {
				error_log( '[PSP Tickets] register_post_meta function not available' );
				return;
			}

			// Validate key and type
			if ( empty( $key ) || empty( $type ) ) {
				error_log( '[PSP Tickets] Invalid meta key or type' );
				return;
			}

			$args = array(
				'type'          => $type,
				'single'        => true,
				'auth_callback' => function () {
					try {
						return current_user_can( 'read_psp_ticket' );
					} catch ( \Exception $e ) {
						error_log( '[PSP Tickets] Auth callback failed: ' . $e->getMessage() );
						return false;
					}
				},
			);

			if ( 'array' === $type ) {
				// Use provided schema if given, else default to string array
				$args['show_in_rest'] = array(
					'schema' => $rest_schema ?: array(
						'type'  => 'array',
						'items' => array( 'type' => 'string' ),
					),
				);
			} else {
				$args['show_in_rest'] = true;
			}

			try {
				$result = register_post_meta( 'psp_ticket', 'psp_' . $key, $args );
				if ( ! $result ) {
					error_log( '[PSP Tickets] Meta registration failed for: ' . $key );
				}
			} catch ( \Exception $e ) {
				error_log( '[PSP Tickets] Meta registration exception for ' . $key . ': ' . $e->getMessage() );
			}

		} catch ( \Exception $e ) {
			error_log( '[PSP Tickets] Register meta failed: ' . $e->getMessage() );
		}
	}

	/**
	 * Handle ticket status changes with comprehensive error handling
	 * 
	 * Features:
	 * - Safe post type validation
	 * - Status change detection
	 * - Email notification routing
	 * - Previous status tracking
	 * - Error logging
	 *
	 * @param string $new_status New post status
	 * @param string $old_status Old post status
	 * @param WP_Post $post Post object
	 * @return void
	 */
	public static function on_status_change( $new_status, $old_status, $post ): void {
		try {
			// Validate post object
			if ( ! is_object( $post ) || empty( $post->post_type ) ) {
				error_log( '[PSP Tickets] Status change: invalid post object' );
				return;
			}

			// Only handle ticket post type
			if ( 'psp_ticket' !== $post->post_type ) {
				return;
			}

			// Validate post ID
			if ( empty( $post->ID ) || ! is_numeric( $post->ID ) ) {
				error_log( '[PSP Tickets] Status change: invalid post ID' );
				return;
			}

			$post_id = intval( $post->ID );

			// New ticket created
			if ( 'publish' === $new_status && 'publish' !== $old_status ) {
				try {
					if ( class_exists( 'PSP_Email' ) ) {
						PSP_Email::notify_new_ticket( $post_id );
					}
				} catch ( \Exception $e ) {
					error_log( '[PSP Tickets] New ticket notification failed: ' . $e->getMessage() );
				}
			}

			// Status changed (but not publish -> publish)
			if ( $new_status !== $old_status && 'publish' === $new_status && 'publish' === $old_status ) {
				try {
					// Check if status meta field changed
					$current_status = get_post_meta( $post_id, 'psp_status', true );
					$previous_status = get_post_meta( $post_id, '_psp_previous_status', true );

					if ( ! empty( $current_status ) && ! empty( $previous_status ) && $current_status !== $previous_status ) {
						try {
							if ( class_exists( 'PSP_Email' ) ) {
								PSP_Email::notify_status_change( $post_id, $previous_status, $current_status );
							}
						} catch ( \Exception $e ) {
							error_log( '[PSP Tickets] Status change notification failed: ' . $e->getMessage() );
						}
					}
				} catch ( \Exception $e ) {
					error_log( '[PSP Tickets] Status meta check failed: ' . $e->getMessage() );
				}
			}

		} catch ( \Exception $e ) {
			error_log( '[PSP Tickets] Status change handler failed: ' . $e->getMessage() );
		}
	}
}
