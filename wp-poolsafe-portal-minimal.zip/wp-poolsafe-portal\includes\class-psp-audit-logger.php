<?php
/**
 * Enhanced Audit Logging & Compliance
 * Tracks all changes, user actions, and provides audit trail
 */

if (!defined('ABSPATH')) {
    exit;
}

class PSP_Audit_Logger {
    
    public function __construct() {
        add_action('rest_api_init', [$this, 'register_endpoints']);
        
        // Log various actions
        add_action('psp_ticket_created', [$this, 'log_ticket_created'], 10, 2);
        add_action('psp_ticket_updated', [$this, 'log_ticket_updated'], 10, 3);
        add_action('psp_ticket_assigned', [$this, 'log_ticket_assigned'], 10, 3);
        add_action('psp_user_login', [$this, 'log_user_login'], 10, 1);
        add_action('psp_user_logout', [$this, 'log_user_logout'], 10, 1);
    }
    
    /**
     * Register audit endpoints
     */
    public function register_endpoints() {
        register_rest_route('psp/v1', '/audit-log', [
            'methods' => 'GET',
            'callback' => [$this, 'get_audit_log'],
            'permission_callback' => [$this, 'check_admin'],
        ]);
        
        register_rest_route('psp/v1', '/audit-log/(?P<log_id>\d+)', [
            'methods' => 'GET',
            'callback' => [$this, 'get_audit_entry'],
            'permission_callback' => [$this, 'check_admin'],
        ]);
        
        register_rest_route('psp/v1', '/audit-log/export', [
            'methods' => 'GET',
            'callback' => [$this, 'export_audit_log'],
            'permission_callback' => [$this, 'check_admin'],
        ]);
        
        register_rest_route('psp/v1', '/user-activity', [
            'methods' => 'GET',
            'callback' => [$this, 'get_user_activity'],
            'permission_callback' => [$this, 'check_auth'],
        ]);
    }
    
    /**
     * Check if admin
     */
    public function check_admin() {
        $user = $_SESSION['psp_user'] ?? null;
        return $user && $user['role'] === 'admin';
    }
    
    /**
     * Check if authenticated
     */
    public function check_auth() {
        return !empty($_SESSION['psp_user']);
    }
    
    /**
     * Create audit log entry
     */
    public function create_entry($action, $description, $user_id = null, $entity_id = null, 
                                 $entity_type = null, $old_values = null, $new_values = null) {
        global $wpdb;
        
        if (!$user_id) {
            $user = $_SESSION['psp_user'] ?? null;
            $user_id = $user['id'] ?? null;
        }
        
        $ip_address = $this->get_client_ip();
        
        return $wpdb->insert(
            "{$wpdb->prefix}psp_audit_log",
            [
                'action' => $action,
                'description' => $description,
                'user_id' => $user_id,
                'entity_type' => $entity_type,
                'entity_id' => $entity_id,
                'old_values' => $old_values ? wp_json_encode($old_values) : null,
                'new_values' => $new_values ? wp_json_encode($new_values) : null,
                'ip_address' => $ip_address,
                'user_agent' => substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255),
                'created_at' => current_time('mysql'),
            ]
        );
    }
    
    /**
     * Log ticket created
     */
    public function log_ticket_created($ticket_id, $ticket_data) {
        $this->create_entry(
            'ticket_created',
            "Ticket #{$ticket_id} created: {$ticket_data['subject']}",
            null,
            $ticket_id,
            'ticket',
            null,
            $ticket_data
        );
    }
    
    /**
     * Log ticket updated
     */
    public function log_ticket_updated($ticket_id, $old_values, $new_values) {
        // Only log if actual changes
        $changes = array_diff_assoc($new_values, $old_values);
        if (!empty($changes)) {
            $this->create_entry(
                'ticket_updated',
                "Ticket #{$ticket_id} updated: " . implode(', ', array_keys($changes)),
                null,
                $ticket_id,
                'ticket',
                $old_values,
                $changes
            );
        }
    }
    
    /**
     * Log ticket assigned
     */
    public function log_ticket_assigned($ticket_id, $assigned_user_id, $assigner) {
        global $wpdb;
        
        $user = $wpdb->get_row($wpdb->prepare(
            "SELECT name FROM {$wpdb->prefix}psp_company_users WHERE id = %d",
            $assigned_user_id
        ));
        
        $this->create_entry(
            'ticket_assigned',
            "Ticket #{$ticket_id} assigned to {$user->name}",
            $assigner['id'],
            $ticket_id,
            'ticket',
            null,
            ['assigned_to' => $assigned_user_id]
        );
    }
    
    /**
     * Log user login
     */
    public function log_user_login($user) {
        $this->create_entry(
            'user_login',
            "{$user['name']} ({$user['role']}) logged in",
            $user['id'],
            $user['company_id'],
            'user'
        );
    }
    
    /**
     * Log user logout
     */
    public function log_user_logout($user) {
        $this->create_entry(
            'user_logout',
            "{$user['name']} ({$user['role']}) logged out",
            $user['id'],
            $user['company_id'],
            'user'
        );
    }
    
    /**
     * Get audit log (admin only)
     */
    public function get_audit_log($request) {
        global $wpdb;
        
        $action = sanitize_text_field($request->get_param('action')) ?? '';
        $entity_type = sanitize_text_field($request->get_param('entity_type')) ?? '';
        $user_id = intval($request->get_param('user_id')) ?: 0;
        $entity_id = intval($request->get_param('entity_id')) ?: 0;
        $date_from = sanitize_text_field($request->get_param('date_from')) ?? '';
        $date_to = sanitize_text_field($request->get_param('date_to')) ?? '';
        $page = intval($request->get_param('page')) ?: 1;
        $per_page = intval($request->get_param('per_page')) ?: 50;
        $offset = ($page - 1) * $per_page;
        
        $where_clauses = [];
        $params = [];
        
        if (!empty($action)) {
            $where_clauses[] = "action = %s";
            $params[] = $action;
        }
        
        if (!empty($entity_type)) {
            $where_clauses[] = "entity_type = %s";
            $params[] = $entity_type;
        }
        
        if ($user_id > 0) {
            $where_clauses[] = "user_id = %d";
            $params[] = $user_id;
        }
        
        if ($entity_id > 0) {
            $where_clauses[] = "entity_id = %d";
            $params[] = $entity_id;
        }
        
        if (!empty($date_from)) {
            $where_clauses[] = "DATE(created_at) >= %s";
            $params[] = $date_from;
        }
        
        if (!empty($date_to)) {
            $where_clauses[] = "DATE(created_at) <= %s";
            $params[] = $date_to;
        }
        
        $where = !empty($where_clauses) ? 'WHERE ' . implode(' AND ', $where_clauses) : '';
        
        $total = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}psp_audit_log {$where}",
                ...($params ?: [])
            )
        );
        
        $entries = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT l.*, u.name as user_name 
                 FROM {$wpdb->prefix}psp_audit_log l
                 LEFT JOIN {$wpdb->prefix}psp_company_users u ON l.user_id = u.id
                 {$where}
                 ORDER BY l.created_at DESC
                 LIMIT %d OFFSET %d",
                ...array_merge($params ?: [], [$per_page, $offset])
            )
        );
        
        // Decode JSON fields
        foreach ($entries as $entry) {
            $entry->old_values = $entry->old_values ? json_decode($entry->old_values, true) : null;
            $entry->new_values = $entry->new_values ? json_decode($entry->new_values, true) : null;
        }
        
        return rest_ensure_response([
            'success' => true,
            'data' => $entries,
            'pagination' => [
                'page' => $page,
                'per_page' => $per_page,
                'total' => intval($total),
                'pages' => ceil($total / $per_page),
            ],
        ]);
    }
    
    /**
     * Get single audit entry
     */
    public function get_audit_entry($request) {
        global $wpdb;
        
        $log_id = intval($request['log_id']);
        
        $entry = $wpdb->get_row($wpdb->prepare(
            "SELECT l.*, u.name as user_name, u.email as user_email
             FROM {$wpdb->prefix}psp_audit_log l
             LEFT JOIN {$wpdb->prefix}psp_company_users u ON l.user_id = u.id
             WHERE l.id = %d",
            $log_id
        ));
        
        if (!$entry) {
            return new WP_Error('not_found', 'Log entry not found', ['status' => 404]);
        }
        
        $entry->old_values = $entry->old_values ? json_decode($entry->old_values, true) : null;
        $entry->new_values = $entry->new_values ? json_decode($entry->new_values, true) : null;
        
        return rest_ensure_response([
            'success' => true,
            'data' => $entry,
        ]);
    }
    
    /**
     * Export audit log to CSV
     */
    public function export_audit_log($request) {
        global $wpdb;
        
        $action = sanitize_text_field($request->get_param('action')) ?? '';
        $date_from = sanitize_text_field($request->get_param('date_from')) ?? '';
        $date_to = sanitize_text_field($request->get_param('date_to')) ?? '';
        
        $where = "1=1";
        if (!empty($action)) {
            $where .= $wpdb->prepare(" AND action = %s", $action);
        }
        if (!empty($date_from)) {
            $where .= $wpdb->prepare(" AND DATE(created_at) >= %s", $date_from);
        }
        if (!empty($date_to)) {
            $where .= $wpdb->prepare(" AND DATE(created_at) <= %s", $date_to);
        }
        
        $entries = $wpdb->get_results(
            "SELECT l.id, l.action, l.description, l.user_id, u.name as user_name, 
                    l.entity_type, l.entity_id, l.ip_address, l.created_at
             FROM {$wpdb->prefix}psp_audit_log l
             LEFT JOIN {$wpdb->prefix}psp_company_users u ON l.user_id = u.id
             WHERE {$where}
             ORDER BY l.created_at DESC"
        );
        
        // Create CSV
        $csv = "ID,Action,Description,User,User ID,Entity Type,Entity ID,IP Address,Timestamp\n";
        
        foreach ($entries as $entry) {
            $csv .= sprintf(
                "%d,%s,%s,%s,%d,%s,%d,%s,%s\n",
                $entry->id,
                $entry->action,
                str_getcsv($entry->description)[0] ?? '',
                $entry->user_name ?? 'System',
                $entry->user_id ?? 0,
                $entry->entity_type ?? '',
                $entry->entity_id ?? 0,
                $entry->ip_address ?? '',
                $entry->created_at
            );
        }
        
        // Return CSV response
        $response = new WP_REST_Response([
            'success' => true,
            'csv' => $csv,
            'count' => count($entries),
        ]);
        
        return $response;
    }
    
    /**
     * Get user's own activity
     */
    public function get_user_activity($request) {
        global $wpdb;
        
        $user = $_SESSION['psp_user'] ?? null;
        if (!$user) {
            return new WP_Error('unauthorized', 'Not authenticated', ['status' => 401]);
        }
        
        $days = intval($request->get_param('days')) ?: 30;
        $page = intval($request->get_param('page')) ?: 1;
        $per_page = intval($request->get_param('per_page')) ?: 20;
        $offset = ($page - 1) * $per_page;
        
        $total = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}psp_audit_log 
             WHERE user_id = %d AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)",
            $user['id'],
            $days
        ));
        
        $entries = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}psp_audit_log 
             WHERE user_id = %d AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
             ORDER BY created_at DESC
             LIMIT %d OFFSET %d",
            $user['id'],
            $days,
            $per_page,
            $offset
        ));
        
        return rest_ensure_response([
            'success' => true,
            'data' => $entries,
            'pagination' => [
                'page' => $page,
                'per_page' => $per_page,
                'total' => intval($total),
                'pages' => ceil($total / $per_page),
            ],
        ]);
    }
    
    /**
     * Get client IP address
     */
    private function get_client_ip() {
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0];
        } else {
            $ip = $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN';
        }
        
        return filter_var($ip, FILTER_VALIDATE_IP) ? $ip : 'UNKNOWN';
    }
}

// Initialize
new PSP_Audit_Logger();
