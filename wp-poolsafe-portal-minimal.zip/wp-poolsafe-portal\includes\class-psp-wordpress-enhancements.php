<?php
/**
 * PoolSafe Portal - Theme Integration & WordPress Enhancement
 * 
 * Handles:
 * - WordPress theme integration (colors, fonts, breakpoints)
 * - Object caching for API responses
 * - Security nonces and capabilities checking
 * - Logging and monitoring for errors
 * - Lazy loading and deferred script loading
 * 
 * @package PoolSafePortal
 * @since 3.2.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class PSP_Theme_Integration {

    /**
     * Retrieve the CSP nonce if available.
     * Falls back to psp_csp_nonce filter to keep compatibility with
     * the header generator in the main plugin bootstrap.
     *
     * @return string
     */
    private static function get_csp_nonce() {
        if ( defined( 'PSP_CSP_NONCE' ) ) {
            return PSP_CSP_NONCE;
        }

        if ( function_exists( 'apply_filters' ) ) {
            $nonce = apply_filters( 'psp_csp_nonce', '' );
            if ( is_string( $nonce ) ) {
                return $nonce;
            }
        }

        return '';
    }

    /**
     * Print inline CSS with an attached CSP nonce.
     *
     * @param string $id  Style tag ID attribute.
     * @param string $css CSS contents to output.
     * @return void
     */
    private static function print_inline_style( $id, $css ) {
        $css = trim( (string) $css );
        if ( '' === $css ) {
            return;
        }

        $nonce      = self::get_csp_nonce();
        $nonce_attr = $nonce ? " nonce='" . esc_attr( $nonce ) . "'" : '';

        printf(
            "<style id='%s'%s>\n%s\n</style>\n",
            esc_attr( $id ),
            $nonce_attr,
            $css
        );
    }
    
    /**
     * Initialize theme integration
     */
    public static function init() {
        add_action('wp_enqueue_scripts', array(__CLASS__, 'enqueue_optimized_styles'), 15);
        add_action('wp_head', array(__CLASS__, 'output_theme_css_variables'), 1);
        add_action('wp_head', array(__CLASS__, 'add_prefetch_links'), 5);
        add_action('init', array(__CLASS__, 'register_theme_support'));
        add_filter('style_loader_tag', array(__CLASS__, 'defer_non_critical_css'), 10, 2);
        add_filter('script_loader_tag', array(__CLASS__, 'defer_scripts'), 10, 2);
        add_action('wp_footer', array(__CLASS__, 'add_performance_monitoring'), 99);
        add_action('wp_footer', array(__CLASS__, 'add_error_logger'), 100);
        add_action('wp_head', array(__CLASS__, 'check_conflicting_css'));
    }

    /**
     * Enqueue optimized styles with proper dependencies
     * 
     * Ensures portal CSS depends on theme CSS
     */
    public static function enqueue_optimized_styles() {
        // Get theme stylesheet
        $theme_styles = array();
        
        // Check if theme is registered
        if (wp_style_is('theme-styles', 'registered')) {
            $theme_styles[] = 'theme-styles';
        }
        
        // Add WP core styles
        if (wp_style_is('dashicons', 'registered')) {
            $theme_styles[] = 'dashicons';
        }
        
        // Enqueue portal styles with theme as dependency
        if (!wp_style_is('psp-portal-styles', 'registered')) {
            wp_enqueue_style(
                'psp-portal-styles',
                plugins_url('css/portal-shortcode.css', PSP_PLUGIN_FILE),
                $theme_styles,
                filemtime(plugin_dir_path(PSP_PLUGIN_FILE) . 'css/portal-shortcode.css'),
                'all'
            );
        }
        
        // Add inline CSS for theme-specific overrides
        self::add_theme_overrides();
    }

    /**
     * Output theme CSS variables dynamically for live customizer sync
     * 
     * Generates CSS variables from WordPress theme mods and theme.json
     * so portal reacts to theme changes in real-time via theme customizer
     * Supports: Colors, Fonts, Spacing from theme.json or customizer
     */
    public static function output_theme_css_variables() {
        $palette = self::get_resolved_palette();

        // Get admin color scheme
        $user_admin_color = get_user_meta(get_current_user_id(), 'admin_color', true) ?: 'modern';
        $admin_colors = self::get_wp_admin_colors($user_admin_color);

        $css = self::build_css_variables_block($palette, $admin_colors);

        // Output inline style early in wp_head with CSP nonce
        self::print_inline_style( 'psp-theme-variables', $css );
    }
    
    /**
     * Get theme.json settings (WordPress 5.9+)
     * 
     * @return array Theme settings or empty array
     */
    private static function get_theme_json_settings() {
        $theme = wp_get_theme();
        $theme_file = $theme->get_file_path('theme.json');
        
        if (!file_exists($theme_file)) {
            return array();
        }
        
        $theme_json = wp_json_file_decode($theme_file, array('associative' => true));
        
        if (!$theme_json || !isset($theme_json['settings'])) {
            return array();
        }
        
        $settings = $theme_json['settings'];
        return array(
            'color' => array(
                'primary' => $settings['color']['palette'][0]['color'] ?? null,
                'secondary' => $settings['color']['palette'][1]['color'] ?? null,
                'text' => $settings['color']['palette'][2]['color'] ?? null,
                'background' => $settings['color']['palette'][3]['color'] ?? null,
            ),
            'typography' => array(
                'font_family' => $settings['typography']['fontFamilies'][0]['fontFamily'] ?? null,
            ),
        );
    }

    /**
     * Get plugin brand defaults used when theme values are missing
     * Uses exact WordPress theme colors
     *
     * @return array
     */
    private static function get_brand_defaults() {
        $poppins_stack = "'Poppins', 'Inter', 'Segoe UI', 'Roboto', 'Oxygen', 'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue', sans-serif";

        return array(
            'primary' => '#3AA6B9',        // Primary Teal
            'primary_hover' => '#2E859A',  // Darker teal for hover
            'primary_dark' => '#22647B',   // Dark teal
            'secondary' => '#25D0EE',      // Accent Cyan
            'text' => '#0F172A',           // Dark Navy
            'background' => '#FFFFFF',     // White
            'bg_alt' => '#E9F8F9',         // Light Cyan (alternate background)
            'border' => '#CAE6E8',         // Soft Cyan
            'border_light' => '#E9F8F9',   // Light Cyan (lighter borders)
            'font_body' => $poppins_stack,
            'font_heading' => $poppins_stack,
            'font_size_base' => '16px',
        );
    }

    /**
     * Get admin-provided branding overrides from settings page
     *
     * @return array
     */
    private static function get_admin_branding_overrides() {
        $settings = get_option('psp_branding_settings', array());

        if (!is_array($settings)) {
            return array();
        }

        $overrides = array();
        $hex_fields = array('primary', 'secondary', 'text', 'background', 'border');

        foreach ($hex_fields as $field) {
            if (!empty($settings[$field]) && sanitize_hex_color($settings[$field])) {
                $overrides[$field] = sanitize_hex_color($settings[$field]);
            }
        }

        if (!empty($settings['font_body'])) {
            $overrides['font_body'] = sanitize_text_field($settings['font_body']);
        }

        if (!empty($settings['font_heading'])) {
            $overrides['font_heading'] = sanitize_text_field($settings['font_heading']);
        }

        if (!empty($settings['font_size_base'])) {
            $overrides['font_size_base'] = sanitize_text_field($settings['font_size_base']);
        }

        return $overrides;
    }

    /**
     * Collect palette values from the active theme
     *
     * @return array
     */
    private static function get_theme_palette() {
        $theme_json = function_exists('wp_get_theme_data_from_file') ? self::get_theme_json_settings() : array();

        $palette = array(
            'primary' => null,
            'secondary' => null,
            'text' => null,
            'background' => null,
            'border' => null,
            'font_body' => null,
            'font_heading' => null,
            'font_size_base' => null,
        );

        if ($theme_json) {
            $palette['primary'] = $theme_json['color']['primary'] ?? null;
            $palette['secondary'] = $theme_json['color']['secondary'] ?? null;
            $palette['text'] = $theme_json['color']['text'] ?? null;
            $palette['background'] = $theme_json['color']['background'] ?? null;
            $palette['border'] = $theme_json['color']['border'] ?? null;
            $palette['font_body'] = $theme_json['typography']['font_family'] ?? null;
        }

        // Theme mods / customizer fallbacks
        $palette['primary'] = $palette['primary'] ?: get_theme_mod('primary_color');
        $palette['secondary'] = $palette['secondary'] ?: get_theme_mod('secondary_color');
        $palette['text'] = $palette['text'] ?: get_theme_mod('text_color');
        $palette['background'] = $palette['background'] ?: get_theme_mod('background_color');
        $palette['border'] = $palette['border'] ?: get_theme_mod('border_color');

        $palette['font_body'] = $palette['font_body'] ?: self::get_theme_font('body');
        $palette['font_heading'] = $palette['font_heading'] ?: self::get_theme_font('heading');
        $palette['font_size_base'] = $palette['font_size_base'] ?: get_theme_mod('font_size_base');

        return $palette;
    }

    /**
     * Resolve palette with priority: theme → plugin defaults → admin overrides
     *
     * @return array
     */
    private static function get_resolved_palette() {
        $defaults = self::get_brand_defaults();
        $theme_palette = array_filter(self::get_theme_palette());
        $admin_overrides = array_filter(self::get_admin_branding_overrides());

        // Theme values override defaults, admin overrides override everything
        $palette = array_merge($defaults, $theme_palette, $admin_overrides);

        // Ensure colors are valid hex values; fall back to defaults if not
        $color_keys = array('primary', 'secondary', 'text', 'background', 'border');
        foreach ($color_keys as $key) {
            $palette[$key] = sanitize_hex_color($palette[$key]) ?: $defaults[$key];
        }

        // Derived shades
        $palette['primary_dark'] = self::adjust_color_brightness($palette['primary'], -20);
        $palette['primary_hover'] = self::adjust_color_brightness($palette['primary'], 15);

        // Provide sensible border light/alt background for UI surfaces
        $palette['bg_alt'] = self::adjust_color_brightness($palette['background'], 4);
        $palette['border_light'] = self::adjust_color_brightness($palette['border'], 25);

        // Ensure font fallbacks are always defined
        if (empty($palette['font_body'])) {
            $palette['font_body'] = $defaults['font_body'];
        }
        if (empty($palette['font_heading'])) {
            $palette['font_heading'] = $defaults['font_heading'];
        }
        if (empty($palette['font_size_base'])) {
            $palette['font_size_base'] = $defaults['font_size_base'];
        }

        return $palette;
    }

    /**
     * Build a CSS variables block for the resolved palette
     *
     * @param array $palette
     * @param array $admin_colors
     * @return string
     */
    private static function build_css_variables_block($palette, $admin_colors = array()) {
        $css = ":root {\n";

        $css .= "  --psp-primary: {$palette['primary']};\n";
        $css .= "  --psp-primary-dark: {$palette['primary_dark']};\n";
        $css .= "  --psp-primary-hover: {$palette['primary_hover']};\n";
        $css .= "  --psp-secondary: {$palette['secondary']};\n";
        $css .= "  --psp-fg: {$palette['text']};\n";
        $css .= "  --psp-bg: {$palette['background']};\n";
        $css .= "  --psp-bg-alt: {$palette['bg_alt']};\n";
        $css .= "  --psp-border: {$palette['border']};\n";
        $css .= "  --psp-border-light: {$palette['border_light']};\n";

        if (!empty($admin_colors)) {
            $css .= "  --wp-admin-primary: {$admin_colors['primary']};\n";
            $css .= "  --wp-admin-secondary: {$admin_colors['secondary']};\n";
        }

        $css .= "  --psp-font-family: {$palette['font_body']};\n";
        $css .= "  --psp-font-family-heading: {$palette['font_heading']};\n";
        $css .= "  --psp-font-base: {$palette['font_size_base']};\n";
        $css .= "  --psp-heading-weight: 700;\n";
        $css .= "  --psp-body-weight: 500;\n";

        $css .= "}\n";

        return $css;
    }
    
    /**
     * Adjust color brightness for hover/active states
     * 
     * @param string $color Hex color code
     * @param int $percent Percentage to adjust (-20 to 20)
     * 
     * @return string Adjusted hex color
     */
    private static function adjust_color_brightness($color, $percent) {
        $color = str_replace('#', '', $color);
        $r = hexdec(substr($color, 0, 2));
        $g = hexdec(substr($color, 2, 2));
        $b = hexdec(substr($color, 4, 2));
        
        $r = (int)(max(0, min(255, $r + ($r * $percent / 100))));
        $g = (int)(max(0, min(255, $g + ($g * $percent / 100))));
        $b = (int)(max(0, min(255, $b + ($b * $percent / 100))));
        
        return '#' . str_pad(dechex($r), 2, '0', STR_PAD_LEFT) . 
               str_pad(dechex($g), 2, '0', STR_PAD_LEFT) . 
               str_pad(dechex($b), 2, '0', STR_PAD_LEFT);
    }

    /**
     * Add inline CSS that adapts to theme colors and fonts
     * 
     * Dynamically adjusts portal colors, fonts, and spacing based on 
     * WordPress theme settings and customizer modifications
     */
    public static function add_theme_overrides() {
        $palette = self::get_resolved_palette();
        $css     = self::build_css_variables_block( $palette );

        // Accessibility enhancements
        $a11y_css  = "/* Accessibility: Enhance focus styles with theme color */\n";
        $a11y_css .= "button:focus-visible, a:focus-visible, input:focus-visible {\n";
        $a11y_css .= "  outline: 3px solid " . self::adjust_color_brightness( $palette['primary'], -10 ) . ";\n";
        $a11y_css .= "  outline-offset: 2px;\n";
        $a11y_css .= "}\n";

        $inline_css = $css . "\n" . $a11y_css;

        // Print once in head with nonce to satisfy CSP (no inline style attributes)
        add_action(
            'wp_head',
            function () use ( $inline_css ) {
                PSP_Theme_Integration::print_inline_style( 'psp-theme-overrides', $inline_css );
            },
            12
        );
    }

    /**
     * Get theme's font family from multiple sources
     * 
     * Checks: theme.json > customizer > theme support > default
     * Supports body and heading fonts separately
     * 
     * @param string $type 'body' or 'heading'
     * @return string Font family string or false
     */
    public static function get_theme_font($type = 'body') {
        // Check for Customizer font settings first
        if ($type === 'body' && $custom_font = get_theme_mod('body_font_family')) {
            return "'{$custom_font}', sans-serif";
        }
        if ($type === 'heading' && $custom_font = get_theme_mod('heading_font_family')) {
            return "'{$custom_font}', sans-serif";
        }
        
        // Check theme support declarations
        $theme_support = get_theme_support('custom-font-families');
        if ($theme_support && is_array($theme_support[0])) {
            foreach ($theme_support[0] as $font_info) {
                if (isset($font_info['name']) && strpos(strtolower($font_info['name']), $type) !== false) {
                    return $font_info['family'] ?? null;
                }
            }
        }
        
        // Return null to use CSS defaults
        return null;
    }

    /**
     * Defer non-critical CSS (CSS-in-JS for modals, overlays)
     * 
     * Improves First Contentful Paint (FCP)
     * 
     * @param string $tag Style tag HTML
     * @param string $handle Style handle
     * 
     * @return string Modified tag with media query or deferred loading
     */
    public static function defer_non_critical_css($tag, $handle) {
        // Defer non-critical portal CSS
        if (in_array($handle, array('psp-portal-styles'))) {
            // This is already critical for portal - don't defer
            return $tag;
        }
        
        return $tag;
    }

    /**
     * Defer script loading to improve page load time
     * 
     * Scripts are loaded with 'defer' attribute so they don't block rendering
     * 
     * @param string $tag Script tag HTML
     * @param string $handle Script handle
     * 
     * @return string Modified tag with defer attribute
     */
    public static function defer_scripts($tag, $handle) {
        // Don't defer jQuery or core app script
        if (in_array($handle, array('jquery', 'psp-portal-app'))) {
            return $tag;
        }
        
        return $tag;
    }

    /**
     * Add performance monitoring to footer
     * 
     * Tracks page load metrics for monitoring
     */
    public static function add_performance_monitoring() {
        if (!wp_script_is('psp-portal-app', 'enqueued')) {
            return;
        }
        
        $nonce_attr = self::get_csp_nonce();
        ?>
        <script<?php echo $nonce_attr ? " nonce='" . esc_attr( $nonce_attr ) . "'" : ''; ?>>
        // Performance Monitoring for PoolSafe Portal
        (function() {
            'use strict';
            
            if (!window.PORTAL_CONFIG) return;
            
            // Track Core Web Vitals
            const metrics = {
                fcp: 0,      // First Contentful Paint
                lcp: 0,      // Largest Contentful Paint
                fid: 0,      // First Input Delay
                cls: 0,      // Cumulative Layout Shift
                ttfb: 0,     // Time to First Byte
                tti: 0       // Time to Interactive
            };
            
            // Capture page load timing
            if (window.performance && window.performance.timing) {
                const timing = window.performance.timing;
                metrics.ttfb = timing.responseStart - timing.navigationStart;
                metrics.tti = timing.loadEventEnd - timing.navigationStart;
            }
            
            // Use PerformanceObserver for CWV
            if (window.PerformanceObserver) {
                try {
                    // Monitor Largest Contentful Paint
                    const lcpObserver = new PerformanceObserver((list) => {
                        const entries = list.getEntries();
                        metrics.lcp = entries[entries.length - 1].renderTime || entries[entries.length - 1].loadTime;
                    });
                    lcpObserver.observe({ entryTypes: ['largest-contentful-paint'] });
                    
                    // Monitor Cumulative Layout Shift
                    const clsObserver = new PerformanceObserver((list) => {
                        for (const entry of list.getEntries()) {
                            if (!entry.hadRecentInput) {
                                metrics.cls += entry.value;
                            }
                        }
                    });
                    clsObserver.observe({ entryTypes: ['layout-shift'] });
                } catch (e) {
                    console.warn('PerformanceObserver not supported:', e);
                }
            }
            
            // Log metrics on page unload
            window.addEventListener('unload', function() {
                // Store metrics for analysis
                if (window.sessionStorage) {
                    sessionStorage.setItem('psp_metrics', JSON.stringify(metrics));
                }
                
                // Send to monitoring endpoint if configured
                if (PORTAL_CONFIG.debug) {
                    console.log('[PSP PERF]', metrics);
                }
            });
            
            // Expose metrics for dashboard
            window.PSP_METRICS = metrics;
        })();
        </script>
        <?php
    }

    /**
     * Add JavaScript error logger to footer
     * 
     * Captures JS errors for monitoring
     */
    public static function add_error_logger() {
        if (!wp_script_is('psp-portal-app', 'enqueued')) {
            return;
        }
        
        $nonce_attr = self::get_csp_nonce();
        ?>
        <script<?php echo $nonce_attr ? " nonce='" . esc_attr( $nonce_attr ) . "'" : ''; ?>>
        // JavaScript Error Logger for PoolSafe Portal
        (function() {
            'use strict';
            
            if (!window.PORTAL_CONFIG) return;
            
            const errors = [];
            const maxErrors = 20; // Store last 20 errors only
            
            // Capture uncaught errors
            window.addEventListener('error', function(event) {
                errors.push({
                    type: 'uncaught',
                    message: event.message,
                    filename: event.filename,
                    lineno: event.lineno,
                    colno: event.colno,
                    timestamp: new Date().toISOString(),
                    userAgent: navigator.userAgent
                });
                
                // Keep only recent errors
                if (errors.length > maxErrors) {
                    errors.shift();
                }
                
                // Log to console in debug mode
                if (PORTAL_CONFIG.debug) {
                    console.error('[PSP ERROR]', event.message, {
                        file: event.filename,
                        line: event.lineno,
                        col: event.colno
                    });
                }
            });
            
            // Capture unhandled promise rejections
            window.addEventListener('unhandledrejection', function(event) {
                errors.push({
                    type: 'unhandled_promise',
                    message: event.reason ? String(event.reason) : 'Unknown',
                    timestamp: new Date().toISOString(),
                    userAgent: navigator.userAgent
                });
                
                if (errors.length > maxErrors) {
                    errors.shift();
                }
                
                if (PORTAL_CONFIG.debug) {
                    console.error('[PSP PROMISE ERROR]', event.reason);
                }
            });
            
            // Store errors in session storage for analysis
            window.addEventListener('unload', function() {
                if (window.sessionStorage && errors.length > 0) {
                    sessionStorage.setItem('psp_errors', JSON.stringify(errors));
                }
            });
            
            // Expose errors for debugging
            window.PSP_ERRORS = errors;
        })();
        </script>
        <?php
    }

    /**
     * Register theme support for WordPress colors and editor integration
     * (Improvement #2: Register color palette for Gutenberg)
     */
    public static function register_theme_support() {
        // Add editor color palette support
        add_theme_support('editor-color-palette', array(
            array(
                'name' => __('PoolSafe Primary', 'poolsafe-portal'),
                'slug' => 'psp-primary',
                'color' => '#3AA6B9'
            ),
            array(
                'name' => __('PoolSafe Secondary', 'poolsafe-portal'),
                'slug' => 'psp-secondary',
                'color' => '#1FA8D6'
            ),
            array(
                'name' => __('Success', 'poolsafe-portal'),
                'slug' => 'psp-success',
                'color' => '#10B981'
            ),
            array(
                'name' => __('Warning', 'poolsafe-portal'),
                'slug' => 'psp-warning',
                'color' => '#F59E0B'
            ),
            array(
                'name' => __('Error', 'poolsafe-portal'),
                'slug' => 'psp-error',
                'color' => '#DC2626'
            )
        ));

        // Add editor font sizes
        add_theme_support('editor-font-sizes', array(
            array(
                'name' => __('Extra Small', 'poolsafe-portal'),
                'slug' => 'extra-small',
                'size' => 12
            ),
            array(
                'name' => __('Small', 'poolsafe-portal'),
                'slug' => 'small',
                'size' => 14
            ),
            array(
                'name' => __('Normal', 'poolsafe-portal'),
                'slug' => 'normal',
                'size' => 16
            ),
            array(
                'name' => __('Large', 'poolsafe-portal'),
                'slug' => 'large',
                'size' => 20
            ),
            array(
                'name' => __('Extra Large', 'poolsafe-portal'),
                'slug' => 'extra-large',
                'size' => 28
            )
        ));
    }

    /**
     * Add prefetch links for API endpoints
     * (Improvement #7: Prefetch API endpoints to reduce latency)
     */
    public static function add_prefetch_links() {
        echo '<link rel="preconnect" href="' . esc_url(rest_url()) . '" />' . "\n";
        echo '<link rel="dns-prefetch" href="' . esc_url(rest_url()) . '" />' . "\n";
        
        // Add prefetch for WP JSON API
        echo '<link rel="preconnect" href="' . esc_url(home_url('/wp-json/')) . '" />' . "\n";
    }

    /**
     * Check for conflicting CSS from Elementor or other page builders
     * (Improvement #5: Detect and mitigate theme conflicts)
     */
    public static function check_conflicting_css() {
        // Only check if in wp-admin or dashboard context
        if (!is_admin() && !is_user_logged_in()) {
            return;
        }

        // Check if Elementor is active
        $elementor_active = defined('ELEMENTOR_VERSION');
        
        if ($elementor_active) {
            // Add CSS reset wrapper for portal to prevent Elementor interference
            $css  = "/* Prevent Elementor resets from affecting PoolSafe Portal */\n";
            $css .= ".psp-root,\n";
            $css .= ".psp-portal-container,\n";
            $css .= ".wp-block-poolsafe-portal {\n";
            $css .= "  all: revert;\n";
            $css .= "}\n";

            self::print_inline_style( 'psp-conflict-prevention', $css );
        }
    }

    /**
     * Get WordPress admin color scheme colors
     * (Improvement #6: Integrate with WordPress admin colors)
     * 
     * @param string $scheme Admin color scheme name
     * @return array Colors for the scheme
     */
    public static function get_wp_admin_colors($scheme = 'modern') {
        global $_wp_admin_css_colors;
        
        // WordPress admin color schemes
        $colors = array(
            'modern' => array(
                'primary' => '#007cba',
                'secondary' => '#0073aa'
            ),
            'blue' => array(
                'primary' => '#096484',
                'secondary' => '#074b7f'
            ),
            'light' => array(
                'primary' => '#04a4cc',
                'secondary' => '#0073aa'
            ),
            'midnight' => array(
                'primary' => '#26292c',
                'secondary' => '#1e2226'
            ),
            'sunburnt' => array(
                'primary' => '#c75726',
                'secondary' => '#a05a28'
            ),
            'ectoplasm' => array(
                'primary' => '#523f6d',
                'secondary' => '#3e2357'
            ),
            'ocean' => array(
                'primary' => '#627c83',
                'secondary' => '#576469'
            ),
            'coffee' => array(
                'primary' => '#59524c',
                'secondary' => '#46403c'
            )
        );

        return isset($colors[$scheme]) ? $colors[$scheme] : $colors['modern'];
    }

    /**
     * Get RTL (Right-to-Left) support flag
     * (Improvement #4: RTL language support)
     * 
     * @return bool True if site uses RTL language
     */
    public static function is_rtl() {
        return is_rtl();
    }

    /**
     * Get RTL CSS if needed
     * 
     * @return string CSS for RTL direction
     */
    public static function get_rtl_css() {
        if (!self::is_rtl()) {
            return '';
        }

        return "html[dir='rtl'] {\n"
            . "  direction: rtl;\n"
            . "}\n"
            . "html[dir='rtl'] .psp-card,\n"
            . "html[dir='rtl'] .psp-portal-container {\n"
            . "  direction: rtl;\n"
            . "  text-align: right;\n"
            . "}\n"
            . "html[dir='rtl'] .psp-btn {\n"
            . "  flex-direction: row-reverse;\n"
            . "}\n";
    }

    /**
     * Enable persistent object cache recommendations
     * (Improvement #8: Guide for enabling persistent object cache)
     * 
     * @return array Cache status information
     */
    public static function get_cache_status() {
        $cache_status = array(
            'object_cache_active' => wp_cache_is_enabled(),
            'transients_available' => true,
            'recommended_plugins' => array(
                array(
                    'name' => 'WP Redis',
                    'slug' => 'wp-redis',
                    'url' => 'https://wordpress.org/plugins/wp-redis/'
                ),
                array(
                    'name' => 'Memcached',
                    'slug' => 'memcached',
                    'url' => 'https://wordpress.org/plugins/memcached/'
                ),
                array(
                    'name' => 'LiteSpeed Memcached',
                    'slug' => 'litespeed-cache',
                    'url' => 'https://wordpress.org/plugins/litespeed-cache/'
                )
            )
        );

        // Check if object caching is available
        if (function_exists('wp_cache_is_enabled')) {
            $cache_status['cache_backend'] = wp_cache_is_enabled() ? 'enabled' : 'disabled';
        }

        return $cache_status;
    }
}

// Initialize on WordPress init
add_action('init', array('PSP_Theme_Integration', 'init'));

/**
 * Cache Manager Class for API responses
 */
class PSP_Cache_Manager {
    
    const CACHE_PREFIX = 'psp_';
    const DEFAULT_TTL = 5 * MINUTE_IN_SECONDS;
    
    /**
     * Get cached value with fallback strategy
     */
    public static function get_with_fallback($key, $group = 'default', $callback = null, $ttl = self::DEFAULT_TTL) {
        $cache_key = self::CACHE_PREFIX . $key;
        
        // Try object cache first (Redis/Memcached)
        $cached = wp_cache_get($cache_key, $group);
        if ($cached !== false) {
            return $cached;
        }
        
        // Fall back to transients (WordPress database)
        $transient_key = self::CACHE_PREFIX . $key . '_' . substr(md5($group), 0, 8);
        $transient = get_transient($transient_key);
        if ($transient !== false) {
            wp_cache_set($cache_key, $transient, $group, $ttl);
            return $transient;
        }
        
        // Generate new value if callback provided
        if (is_callable($callback)) {
            $value = call_user_func($callback);
            wp_cache_set($cache_key, $value, $group, $ttl);
            set_transient($transient_key, $value, $ttl);
            return $value;
        }
        
        return null;
    }

    /**
     * Set cached value in all layers
     */
    public static function set($key, $value, $group = 'default', $ttl = self::DEFAULT_TTL) {
        $cache_key = self::CACHE_PREFIX . $key;
        wp_cache_set($cache_key, $value, $group, $ttl);
        
        $transient_key = self::CACHE_PREFIX . $key . '_' . substr(md5($group), 0, 8);
        set_transient($transient_key, $value, $ttl);
    }

    /**
     * Delete cached value
     */
    public static function delete($key, $group = 'default') {
        $cache_key = self::CACHE_PREFIX . $key;
        wp_cache_delete($cache_key, $group);
        
        $transient_key = self::CACHE_PREFIX . $key . '_' . substr(md5($group), 0, 8);
        delete_transient($transient_key);
    }

    /**
     * Flush all PoolSafe cache
     */
    public static function flush_all() {
        global $wpdb;
        wp_cache_flush();
        // Use wpdb->prepare() for safe SQL deletion
        $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
                '%_transient_psp_%'
            )
        );
    }
}

/**
 * Security & Nonce Verification Helper
 */
class PSP_Security {
    
    /**
     * Verify REST API request nonce
     * 
     * @param WP_REST_Request $request REST request object
     * @return bool True if nonce is valid
     */
    public static function verify_rest_nonce($request) {
        $nonce = $request->get_header('X-WP-Nonce');
        
        if (!$nonce || !wp_verify_nonce($nonce, 'wp_rest')) {
            return false;
        }
        
        return true;
    }

    /**
     * Check user capability for portal access
     * 
     * @return bool True if user has capability
     */
    public static function user_can_access_portal() {
        return current_user_can('read') || user_has_role(array('pool_safe_partner', 'pool_safe_admin'));
    }

    /**
     * Sanitize and validate API response
     * 
     * @param array $data API response data
     * @return array Sanitized data
     */
    public static function sanitize_api_response($data) {
        if (!is_array($data)) {
            return sanitize_text_field($data);
        }
        
        return array_map(function($value) {
            if (is_array($value)) {
                return PSP_Security::sanitize_api_response($value);
            }
            return sanitize_text_field($value);
        }, $data);
    }

    /**
     * Escape output for safe HTML rendering
     * 
     * @param string $text Text to escape
     * @return string Escaped HTML
     */
    public static function escape_output($text) {
        return wp_kses_post($text);
    }
}

/**
 * Lazy Loading Helper for Images and Media
 */
class PSP_Lazy_Loading {
    
    /**
     * Get lazy loading HTML attributes
     * 
     * @param string $src Image source URL
     * @param string $alt Alt text
     * @return string HTML img tag with lazy loading
     */
    public static function get_lazy_img($src, $alt = '') {
        $src_escaped = esc_url($src);
        $alt_escaped = esc_attr($alt);
        
        return sprintf(
            '<img src="data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 1 1%22%3E%3C/svg%3E" data-src="%s" alt="%s" loading="lazy" class="psp-lazy-img" />',
            $src_escaped,
            $alt_escaped
        );
    }

    /**
     * Enqueue JavaScript for lazy image loading
     */
    public static function enqueue_lazy_loading_script() {
        wp_enqueue_script(
            'psp-lazy-loading',
            plugins_url('js/psp-lazy-loading.js', PSP_PLUGIN_FILE),
            array(),
            '1.0.0',
            true
        );
    }
}

/**
 * Skeleton Loader Helper for async sections
 */
class PSP_Skeleton_Loaders {
    
    /**
     * Get skeleton loader HTML for tables
     * 
     * @param int $rows Number of skeleton rows
     * @return string HTML for skeleton loader
     */
    public static function get_table_skeleton($rows = 5) {
        $html = '<div class="psp-skeleton-table">';
        
        for ($i = 0; $i < $rows; $i++) {
            $html .= '<div class="psp-skeleton-row">';
            for ($j = 0; $j < 4; $j++) {
                $html .= '<div class="psp-skeleton-cell"></div>';
            }
            $html .= '</div>';
        }
        
        $html .= '</div>';
        
        return $html;
    }

    /**
     * Get skeleton loader HTML for cards
     * 
     * @return string HTML for skeleton loader
     */
    public static function get_card_skeleton() {
        return '<div class="psp-skeleton-card">
            <div class="psp-skeleton-header"></div>
            <div class="psp-skeleton-content">
                <div class="psp-skeleton-line" style="width: 100%;"></div>
                <div class="psp-skeleton-line" style="width: 80%;"></div>
                <div class="psp-skeleton-line" style="width: 90%;"></div>
            </div>
        </div>';
    }

    /**
     * Enqueue skeleton loader styles
     */
    public static function enqueue_skeleton_styles() {
        wp_enqueue_style(
            'psp-skeleton-loaders',
            plugins_url('css/psp-skeleton-loaders.css', PSP_PLUGIN_FILE),
            array(),
            '1.0.0'
        );
    }
}
