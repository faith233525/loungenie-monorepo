<?php
/**
 * Ticket Settings Page
 * Admin page to customize ticket system
 */

namespace PSP;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Add admin menu
add_action( 'admin_menu', function() {
	add_submenu_page(
		'edit.php?post_type=psp_ticket',
		__( 'Ticket Settings', 'psp' ),
		__( 'Settings', 'psp' ),
		'manage_options',
		'psp-ticket-settings',
		array( __NAMESPACE__ . '\Ticket_Settings', 'render_page' )
	);
} );

class Ticket_Settings {

	const OPTION_KEY = 'psp_ticket_settings';

	/**
	 * Render settings page
	 */
	public static function render_page() {
		// Handle save
		if ( isset( $_POST['psp_save_settings'] ) && wp_verify_nonce( $_POST['psp_settings_nonce'], 'psp_ticket_settings' ) ) {
			self::save_settings();
			echo '<div class="notice notice-success"><p>' . esc_html__( 'Settings saved successfully!', 'psp' ) . '</p></div>';
		}

		$settings = self::get_settings();

		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Ticket Settings', 'psp' ); ?></h1>

			<form method="POST" class="psp-settings-form">
				<?php wp_nonce_field( 'psp_ticket_settings', 'psp_settings_nonce' ); ?>

				<!-- Ticket Statuses -->
				<div class="psp-settings-section">
					<h2><?php esc_html_e( 'Ticket Statuses', 'psp' ); ?></h2>
					<p class="description"><?php esc_html_e( 'Define the statuses available for tickets. One per line.', 'psp' ); ?></p>

					<table class="psp-status-table">
						<tr>
							<th><?php esc_html_e( 'Status Name', 'psp' ); ?></th>
							<th><?php esc_html_e( 'Label', 'psp' ); ?></th>
							<th><?php esc_html_e( 'Color', 'psp' ); ?></th>
						</tr>
						<?php foreach ( $settings['statuses'] as $key => $status ) : ?>
							<tr>
								<td>
									<input 
										type="text" 
										name="status_key[]" 
										value="<?php echo esc_attr( $key ); ?>" 
										class="regular-text"
										placeholder="e.g., open"
									/>
								</td>
								<td>
									<input 
										type="text" 
										name="status_label[]" 
										value="<?php echo esc_attr( $status['label'] ); ?>" 
										class="regular-text"
										placeholder="e.g., Open"
									/>
								</td>
								<td>
									<input 
										type="color" 
										name="status_color[]" 
										value="<?php echo esc_attr( $status['color'] ); ?>" 
										class="color-picker"
									/>
								</td>
							</tr>
						<?php endforeach; ?>
					</table>
				</div>

				<!-- Ticket Priorities -->
				<div class="psp-settings-section">
					<h2><?php esc_html_e( 'Ticket Priorities', 'psp' ); ?></h2>
					<p class="description"><?php esc_html_e( 'Define priority levels for tickets.', 'psp' ); ?></p>

					<table class="psp-priority-table">
						<tr>
							<th><?php esc_html_e( 'Priority Name', 'psp' ); ?></th>
							<th><?php esc_html_e( 'Label', 'psp' ); ?></th>
							<th><?php esc_html_e( 'Color', 'psp' ); ?></th>
						</tr>
						<?php foreach ( $settings['priorities'] as $key => $priority ) : ?>
							<tr>
								<td>
									<input 
										type="text" 
										name="priority_key[]" 
										value="<?php echo esc_attr( $key ); ?>" 
										class="regular-text"
										placeholder="e.g., low"
									/>
								</td>
								<td>
									<input 
										type="text" 
										name="priority_label[]" 
										value="<?php echo esc_attr( $priority['label'] ); ?>" 
										class="regular-text"
										placeholder="e.g., Low"
									/>
								</td>
								<td>
									<input 
										type="color" 
										name="priority_color[]" 
										value="<?php echo esc_attr( $priority['color'] ); ?>" 
										class="color-picker"
									/>
								</td>
							</tr>
						<?php endforeach; ?>
					</table>
				</div>

				<!-- Email Notifications -->
				<div class="psp-settings-section">
					<h2><?php esc_html_e( 'Email Notifications', 'psp' ); ?></h2>

					<div class="psp-form-group">
						<label for="notification_email">
							<?php esc_html_e( 'Support Email Address', 'psp' ); ?>
						</label>
						<input 
							type="email" 
							id="notification_email" 
							name="notification_email" 
							value="<?php echo esc_attr( $settings['notification_email'] ); ?>" 
							class="regular-text"
							placeholder="support@example.com"
						/>
						<p class="description">
							<?php esc_html_e( 'New tickets and replies will be sent to this email address.', 'psp' ); ?>
						</p>
					</div>

					<div class="psp-form-group">
						<label>
							<input 
								type="checkbox" 
								name="notify_new_ticket" 
								value="1" 
								<?php checked( $settings['notify_new_ticket'], 1 ); ?>
							/>
							<?php esc_html_e( 'Send email when new ticket is created', 'psp' ); ?>
						</label>
					</div>

					<div class="psp-form-group">
						<label>
							<input 
								type="checkbox" 
								name="notify_new_reply" 
								value="1" 
								<?php checked( $settings['notify_new_reply'], 1 ); ?>
							/>
							<?php esc_html_e( 'Send email when ticket gets a reply', 'psp' ); ?>
						</label>
					</div>

					<div class="psp-form-group">
						<label for="email_signature">
							<?php esc_html_e( 'Email Signature', 'psp' ); ?>
						</label>
						<textarea 
							id="email_signature" 
							name="email_signature" 
							class="large-text" 
							rows="4"
						><?php echo esc_textarea( $settings['email_signature'] ); ?></textarea>
						<p class="description">
							<?php esc_html_e( 'This will be added to the end of all outgoing ticket notification emails.', 'psp' ); ?>
						</p>
					</div>
				</div>

				<!-- SLA Settings -->
				<div class="psp-settings-section">
					<h2><?php esc_html_e( 'SLA Response Times (in hours)', 'psp' ); ?></h2>
					<p class="description">
						<?php esc_html_e( 'Set expected response times by priority. Leave blank to disable SLA.', 'psp' ); ?>
					</p>

					<div class="psp-form-group">
						<label for="sla_urgent">
							<?php esc_html_e( 'Urgent:', 'psp' ); ?>
						</label>
						<input 
							type="number" 
							id="sla_urgent" 
							name="sla_urgent" 
							value="<?php echo esc_attr( $settings['sla_urgent'] ); ?>" 
							min="0"
							placeholder="4"
						/>
					</div>

					<div class="psp-form-group">
						<label for="sla_high">
							<?php esc_html_e( 'High:', 'psp' ); ?>
						</label>
						<input 
							type="number" 
							id="sla_high" 
							name="sla_high" 
							value="<?php echo esc_attr( $settings['sla_high'] ); ?>" 
							min="0"
							placeholder="8"
						/>
					</div>

					<div class="psp-form-group">
						<label for="sla_medium">
							<?php esc_html_e( 'Medium:', 'psp' ); ?>
						</label>
						<input 
							type="number" 
							id="sla_medium" 
							name="sla_medium" 
							value="<?php echo esc_attr( $settings['sla_medium'] ); ?>" 
							min="0"
							placeholder="24"
						/>
					</div>

					<div class="psp-form-group">
						<label for="sla_low">
							<?php esc_html_e( 'Low:', 'psp' ); ?>
						</label>
						<input 
							type="number" 
							id="sla_low" 
							name="sla_low" 
							value="<?php echo esc_attr( $settings['sla_low'] ); ?>" 
							min="0"
							placeholder="72"
						/>
					</div>
				</div>

				<!-- Submit -->
				<div class="psp-settings-actions">
					<button type="submit" name="psp_save_settings" class="button button-primary button-large">
						<?php esc_html_e( 'Save Settings', 'psp' ); ?>
					</button>
				</div>
			</form>
		</div>

		<style>
			.psp-settings-form {
				max-width: 900px;
				background: white;
				padding: 20px;
				border-radius: 4px;
			}

			.psp-settings-section {
				margin-bottom: 40px;
				padding-bottom: 30px;
				border-bottom: 1px solid #eee;
			}

			.psp-settings-section h2 {
				margin: 0 0 15px 0;
				font-size: 18px;
				font-weight: 600;
				color: #333;
			}

			.psp-status-table,
			.psp-priority-table {
				width: 100%;
				border-collapse: collapse;
				margin: 20px 0;
			}

			.psp-status-table th,
			.psp-priority-table th {
				text-align: left;
				padding: 10px;
				background: #f5f5f5;
				border: 1px solid #ddd;
				font-weight: 600;
				font-size: 13px;
			}

			.psp-status-table td,
			.psp-priority-table td {
				padding: 10px;
				border: 1px solid #ddd;
			}

			.psp-form-group {
				margin-bottom: 20px;
			}

			.psp-form-group label {
				display: block;
				margin-bottom: 8px;
				font-weight: 600;
				font-size: 14px;
			}

			.psp-form-group input[type="text"],
			.psp-form-group input[type="email"],
			.psp-form-group input[type="number"],
			.psp-form-group textarea {
				width: 100%;
				max-width: 400px;
			}

			.color-picker {
				height: 44px;
				border: 1px solid #ddd;
				border-radius: 4px;
				cursor: pointer;
			}

			.description {
				margin-top: 5px;
				color: #666;
				font-size: 13px;
				font-style: italic;
			}

			.psp-settings-actions {
				margin-top: 30px;
				padding-top: 20px;
				border-top: 1px solid #eee;
			}
		</style>
		<?php
	}

	/**
	 * Get settings with defaults
	 */
	public static function get_settings() {
		$defaults = array(
			'statuses'            => array(
				'open'        => array( 'label' => 'Open', 'color' => '#dc2626' ),
				'in-progress' => array( 'label' => 'In Progress', 'color' => '#ca8a04' ),
				'waiting'     => array( 'label' => 'Waiting', 'color' => '#0ea5e9' ),
				'closed'      => array( 'label' => 'Closed', 'color' => '#16a34a' ),
			),
			'priorities'          => array(
				'low'    => array( 'label' => 'Low', 'color' => '#4338ca' ),
				'medium' => array( 'label' => 'Medium', 'color' => '#b45309' ),
				'high'   => array( 'label' => 'High', 'color' => '#ea580c' ),
				'urgent' => array( 'label' => 'Urgent', 'color' => '#dc2626' ),
			),
			'notification_email'  => get_option( 'admin_email' ),
			'notify_new_ticket'   => 1,
			'notify_new_reply'    => 1,
			'email_signature'     => '',
			'sla_urgent'          => 4,
			'sla_high'            => 8,
			'sla_medium'          => 24,
			'sla_low'             => 72,
		);

		$settings = get_option( self::OPTION_KEY, array() );
		return wp_parse_args( $settings, $defaults );
	}

	/**
	 * Save settings
	 */
	public static function save_settings() {
		$settings = array(
			'statuses'            => array(),
			'priorities'          => array(),
			'notification_email'  => sanitize_email( wp_unslash( $_POST['notification_email'] ?? '' ) ),
			'notify_new_ticket'   => isset( $_POST['notify_new_ticket'] ) ? 1 : 0,
			'notify_new_reply'    => isset( $_POST['notify_new_reply'] ) ? 1 : 0,
			'email_signature'     => wp_kses_post( wp_unslash( $_POST['email_signature'] ?? '' ) ),
			'sla_urgent'          => absint( wp_unslash( $_POST['sla_urgent'] ?? 4 ) ),
			'sla_high'            => absint( wp_unslash( $_POST['sla_high'] ?? 8 ) ),
			'sla_medium'          => absint( wp_unslash( $_POST['sla_medium'] ?? 24 ) ),
			'sla_low'             => absint( wp_unslash( $_POST['sla_low'] ?? 72 ) ),
		);

		// Build statuses
		$status_keys = isset( $_POST['status_key'] ) ? (array) wp_unslash( $_POST['status_key'] ) : array();
		$status_labels = isset( $_POST['status_label'] ) ? (array) wp_unslash( $_POST['status_label'] ) : array();
		$status_colors = isset( $_POST['status_color'] ) ? (array) wp_unslash( $_POST['status_color'] ) : array();

		foreach ( $status_keys as $i => $key ) {
			if ( ! empty( $key ) ) {
				$settings['statuses'][ sanitize_key( $key ) ] = array(
					'label' => sanitize_text_field( $status_labels[ $i ] ?? '' ),
					'color' => sanitize_hex_color( $status_colors[ $i ] ?? '#000000' ),
				);
			}
		}

		// Build priorities
		$priority_keys = isset( $_POST['priority_key'] ) ? (array) wp_unslash( $_POST['priority_key'] ) : array();
		$priority_labels = isset( $_POST['priority_label'] ) ? (array) wp_unslash( $_POST['priority_label'] ) : array();
		$priority_colors = isset( $_POST['priority_color'] ) ? (array) wp_unslash( $_POST['priority_color'] ) : array();

		foreach ( $priority_keys as $i => $key ) {
			if ( ! empty( $key ) ) {
				$settings['priorities'][ sanitize_key( $key ) ] = array(
					'label' => sanitize_text_field( $priority_labels[ $i ] ?? '' ),
					'color' => sanitize_hex_color( $priority_colors[ $i ] ?? '#000000' ),
				);
			}
		}

		update_option( self::OPTION_KEY, $settings );
	}
}
