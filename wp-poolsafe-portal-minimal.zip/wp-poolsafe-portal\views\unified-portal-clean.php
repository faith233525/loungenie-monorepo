<?php
/**
 * CSP-Compliant Portal Layout - PoolSafe Portal v3.3.0
 * 
 * NO inline styles, NO inline scripts, NO inline event handlers
 * All styling via external CSS, all JavaScript via external files
 * 
 * @package PoolSafe_Portal
 * @since 3.3.0
 */

if (!defined('ABSPATH')) {
    exit;
}

// Extract portal context
$current_user = isset($GLOBALS['psp_portal_current_user']) ? $GLOBALS['psp_portal_current_user'] : array('name' => 'User', 'email' => '', 'role' => 'pool_safe_partner');
$user_role = isset($GLOBALS['psp_portal_user_role']) ? $GLOBALS['psp_portal_user_role'] : 'pool_safe_partner';
$visible_tabs = isset($GLOBALS['psp_portal_visible_tabs']) ? $GLOBALS['psp_portal_visible_tabs'] : array('dashboard', 'videos', 'tickets', 'services');
$active_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'dashboard';
$logout_url = wp_logout_url(home_url());
$login_url  = wp_login_url( get_permalink() );

$portal_config = isset($GLOBALS['psp_portal_config']) ? $GLOBALS['psp_portal_config'] : array();
$portal_config_json = esc_attr( wp_json_encode( $portal_config ) );

if (!in_array($active_tab, $visible_tabs)) {
    $active_tab = $visible_tabs[0];
}

$is_admin = current_user_can('manage_options');
?>
<div class="psp-portal-wrapper <?php echo isset($GLOBALS['psp_portal_is_admin']) && $GLOBALS['psp_portal_is_admin'] ? 'psp-admin-view' : ''; ?>"
    data-active-tab="<?php echo esc_attr($active_tab); ?>"
    data-api-url="<?php echo esc_url( rest_url('psp/v1') ); ?>"
    data-ajax-url="<?php echo esc_url( admin_url('admin-ajax.php') ); ?>"
    data-nonce="<?php echo esc_attr( wp_create_nonce('wp_rest') ); ?>"
    data-user="<?php echo esc_attr( wp_json_encode( $current_user ) ); ?>"
    data-user-role="<?php echo esc_attr( $user_role ); ?>"
    data-company-id="<?php echo esc_attr( isset( $portal_config['companyId'] ) ? $portal_config['companyId'] : '' ); ?>"
    data-visible-tabs="<?php echo esc_attr( wp_json_encode( $visible_tabs ) ); ?>"
    data-plugin-url="<?php echo esc_url( PSP_PLUGIN_URL ); ?>"
    data-is-admin="<?php echo $is_admin ? '1' : '0'; ?>"
    data-debug="<?php echo defined('PSP_DEBUG') && PSP_DEBUG ? '1' : '0'; ?>"
    data-config-json="<?php echo $portal_config_json; ?>">
    <!-- Header -->
    <header class="psp-portal-header">
        <div class="psp-header-container">
            <div class="psp-header-left">
                <div class="psp-logo-badge" aria-hidden="true"></div>
                <div class="psp-title-group">
                    <h1 class="psp-header-title">PoolSafe Portal</h1>
                    <p class="psp-header-subtitle">Partner experience hub</p>
                </div>
            </div>
            <div class="psp-header-right">
                <div class="psp-user-meta">
                    <p class="psp-user-name"><?php echo esc_html($current_user['name']); ?></p>
                    <p class="psp-user-role"><?php echo esc_html(ucwords(str_replace('_', ' ', $user_role))); ?></p>
                </div>
                <a href="<?php echo esc_url($logout_url); ?>" class="psp-logout-button">Logout</a>
            </div>
        </div>
    </header>

    <!-- Tab Navigation -->
    <nav class="psp-tab-nav" role="navigation" aria-label="Portal sections">
        <ul class="psp-tab-list" role="tablist">
            <?php if (in_array('dashboard', $visible_tabs)): ?>
            <li class="psp-tab-item" role="presentation">
                <button 
                    class="psp-tab-button <?php echo $active_tab === 'dashboard' ? 'active' : ''; ?>"
                    role="tab"
                    data-tab="dashboard"
                    aria-selected="<?php echo $active_tab === 'dashboard' ? 'true' : 'false'; ?>"
                    aria-controls="dashboard-panel">
                    Dashboard
                </button>
            </li>
            <?php endif; ?>
            
            <?php if (in_array('videos', $visible_tabs)): ?>
            <li class="psp-tab-item" role="presentation">
                <button 
                    class="psp-tab-button <?php echo $active_tab === 'videos' ? 'active' : ''; ?>"
                    role="tab"
                    data-tab="videos"
                    aria-selected="<?php echo $active_tab === 'videos' ? 'true' : 'false'; ?>"
                    aria-controls="videos-panel">
                    Videos
                </button>
            </li>
            <?php endif; ?>
            
            <?php if (in_array('tickets', $visible_tabs)): ?>
            <li class="psp-tab-item" role="presentation">
                <button 
                    class="psp-tab-button <?php echo $active_tab === 'tickets' ? 'active' : ''; ?>"
                    role="tab"
                    data-tab="tickets"
                    aria-selected="<?php echo $active_tab === 'tickets' ? 'true' : 'false'; ?>"
                    aria-controls="tickets-panel">
                    Tickets
                </button>
            </li>
            <?php endif; ?>
            
            <?php if (in_array('services', $visible_tabs)): ?>
            <li class="psp-tab-item" role="presentation">
                <button 
                    class="psp-tab-button <?php echo $active_tab === 'services' ? 'active' : ''; ?>"
                    role="tab"
                    data-tab="services"
                    aria-selected="<?php echo $active_tab === 'services' ? 'true' : 'false'; ?>"
                    aria-controls="services-panel">
                    Services
                </button>
            </li>
            <?php endif; ?>
            
            <?php if (in_array('partners', $visible_tabs)): ?>
            <li class="psp-tab-item" role="presentation">
                <button 
                    class="psp-tab-button <?php echo $active_tab === 'partners' ? 'active' : ''; ?>"
                    role="tab"
                    data-tab="partners"
                    aria-selected="<?php echo $active_tab === 'partners' ? 'true' : 'false'; ?>"
                    aria-controls="partners-panel">
                    Partners
                </button>
            </li>
            <?php endif; ?>
        </ul>
    </nav>

    <!-- Content Area -->
    <main class="psp-content-area">
        <?php if (in_array('dashboard', $visible_tabs)): ?>
        <div id="dashboard-panel" class="psp-tab-panel <?php echo $active_tab === 'dashboard' ? 'active' : ''; ?>" role="tabpanel" aria-labelledby="dashboard">
			<div class="psp-auth-buttons">
				<?php if ( is_user_logged_in() ) : ?>
					<a href="<?php echo esc_url($logout_url); ?>" class="psp-button psp-button-ghost">Logout</a>
				<?php else : ?>
					<a href="<?php echo esc_url($login_url); ?>" class="psp-button psp-button-primary">Login</a>
				<?php endif; ?>
			</div>
            <div class="psp-welcome-banner">
                <h1>Welcome back, <?php echo esc_html($current_user['name']); ?>!</h1>
                <p>Manage your pool services, view tickets, and access partner resources.</p>
            </div>

            <div class="psp-stats-grid">
                <div class="psp-stat-card" data-stat="tickets">
                    <div class="psp-stat-icon">🎫</div>
                    <div class="psp-stat-label">Open Tickets</div>
                    <div class="psp-stat-value" data-stat-value="tickets">-</div>
                </div>
                <div class="psp-stat-card" data-stat="services">
                    <div class="psp-stat-icon">⚙️</div>
                    <div class="psp-stat-label">Active Services</div>
                    <div class="psp-stat-value" data-stat-value="services">-</div>
                </div>
                <div class="psp-stat-card" data-stat="partners">
                    <div class="psp-stat-icon">🤝</div>
                    <div class="psp-stat-label">Partners</div>
                    <div class="psp-stat-value" data-stat-value="partners">-</div>
                </div>
                <div class="psp-stat-card" data-stat="videos">
                    <div class="psp-stat-icon">📹</div>
                    <div class="psp-stat-label">Training Videos</div>
                    <div class="psp-stat-value" data-stat-value="videos">-</div>
                </div>
            </div>

            <div class="psp-section">
                <h2 class="psp-section-title">Quick Actions</h2>
                <div class="psp-button-group">
                    <button class="psp-button psp-button-primary" data-action="new-ticket">Create New Ticket</button>
                    <button class="psp-button psp-button-secondary" data-action="view-services">View Services</button>
                </div>
            </div>

            <div id="dashboard-content" class="psp-dynamic-content">
                <div class="psp-loading">Loading dashboard...</div>
            </div>
        </div>
        <?php endif; ?>

        <?php if (in_array('videos', $visible_tabs)): ?>
        <!-- Videos Tab -->
        <div id="videos-panel" class="psp-tab-panel <?php echo $active_tab === 'videos' ? 'active' : ''; ?>" role="tabpanel" aria-labelledby="videos">
            <h2 class="psp-panel-title">Training Videos</h2>
            <div id="videos-content" class="psp-dynamic-content">
                <div class="psp-loading">Loading videos...</div>
            </div>
        </div>
        <?php endif; ?>

        <?php if (in_array('tickets', $visible_tabs)): ?>
        <!-- Tickets Tab -->
        <div id="tickets-panel" class="psp-tab-panel <?php echo $active_tab === 'tickets' ? 'active' : ''; ?>" role="tabpanel" aria-labelledby="tickets">
            <h2 class="psp-panel-title">Support Tickets</h2>
            <div id="tickets-content" class="psp-dynamic-content">
                <div class="psp-loading">Loading tickets...</div>
            </div>
        </div>
        <?php endif; ?>

        <?php if (in_array('services', $visible_tabs)): ?>
        <!-- Services Tab -->
        <div id="services-panel" class="psp-tab-panel <?php echo $active_tab === 'services' ? 'active' : ''; ?>" role="tabpanel" aria-labelledby="services">
            <h2 class="psp-panel-title">Services</h2>
            <div id="services-content" class="psp-dynamic-content">
                <div class="psp-loading">Loading services...</div>
            </div>
        </div>
        <?php endif; ?>

        <?php if (in_array('partners', $visible_tabs)): ?>
        <!-- Partners Tab (Support/Admin Only) -->
        <div id="partners-panel" class="psp-tab-panel <?php echo $active_tab === 'partners' ? 'active' : ''; ?>" role="tabpanel" aria-labelledby="partners">
            <h2 class="psp-panel-title">Partner Management</h2>
            <div class="psp-section">
                <button class="psp-button psp-button-primary" data-action="upload-csv">Upload CSV</button>
            </div>
            <div id="partners-content" class="psp-dynamic-content">
                <div class="psp-loading">Loading partners...</div>
            </div>
        </div>
        <?php endif; ?>
    </main>
</div>
