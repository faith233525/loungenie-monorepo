<?php
/**
 * Pool Safe Portal - CSV Export System
 * 
 * Handles bulk export of tickets, partners, properties, logs, and more
 * Supports scheduled exports and direct downloads
 * 
 * @package PSP\CSV_Export
 * @version 2.0.0
 */

namespace PSP\CSV_Export;

if (!defined('ABSPATH')) {
    exit;
}

class CSV_Export {
    
    // Export types
    const EXPORT_TYPES = [
        'tickets' => 'Tickets',
        'partners' => 'Partners',
        'properties' => 'Properties',
        'services' => 'Services',
        'activity_logs' => 'Activity Logs',
        'invoices' => 'Invoices',
    ];
    
    /**
     * Initialize CSV Export system
     */
    public static function init() {
        add_action('wp_ajax_psp_export_csv', [__CLASS__, 'handle_ajax_export']);
        add_action('rest_api_init', [__CLASS__, 'register_rest_endpoints']);
        add_action('init', [__CLASS__, 'handle_download']);
    }
    
    /**
     * Register REST API endpoints
     */
    public static function register_rest_endpoints() {
        register_rest_route('psp/v1', '/csv-export', [
            [
                'methods' => 'POST',
                'callback' => [__CLASS__, 'export_data'],
                'permission_callback' => function () {
                    return current_user_can('manage_psp_portal');
                },
            ],
        ]);
        
        // Company-scoped exports for portal users
        register_rest_route('psp/v1', '/export/tickets-csv', [
            'methods' => 'GET',
            'callback' => [__CLASS__, 'export_tickets_csv'],
            'permission_callback' => [__CLASS__, 'check_portal_auth'],
        ]);
        
        register_rest_route('psp/v1', '/export/services-csv', [
            'methods' => 'GET',
            'callback' => [__CLASS__, 'export_services_csv'],
            'permission_callback' => [__CLASS__, 'check_portal_auth'],
        ]);
        
        register_rest_route('psp/v1', '/export/partners-csv', [
            'methods' => 'GET',
            'callback' => [__CLASS__, 'export_partners_csv'],
            'permission_callback' => [__CLASS__, 'check_portal_auth'],
        ]);
    }
    
    /**
     * Check portal authentication
     */
    public static function check_portal_auth() {
        if (!class_exists('PSP\\Company_Auth')) {
            return false;
        }
        $user = \PSP\Company_Auth::validate_session();
        return !empty($user);
    }
    
    /**
     * Export tickets as CSV (company-scoped)
     */
    public static function export_tickets_csv($request) {
        global $wpdb;
        
        $user = \PSP\Company_Auth::validate_session();
        if (!$user) {
            return new \WP_REST_Response(['error' => 'Unauthorized'], 401);
        }

        $tickets_table = $wpdb->prefix . 'psp_tickets';
        $companies_table = $wpdb->prefix . 'psp_companies';
        $contacts_table = $wpdb->prefix . 'psp_company_contacts';

        $where = $user['type'] === 'company' ? $wpdb->prepare("AND co.id = %d", $user['id']) : '';

        $tickets = $wpdb->get_results("
            SELECT 
                t.id, t.ticket_number, t.title, t.status, t.priority,
                co.company_name, c.name as created_by_contact,
                t.created_at, t.updated_at
            FROM $tickets_table t
            LEFT JOIN $companies_table co ON t.partner_id = co.id
            LEFT JOIN $contacts_table c ON t.created_by_contact_id = c.id
            WHERE 1=1 $where
            ORDER BY t.created_at DESC
        ");

        $filename = 'tickets-export-' . date('Y-m-d-His') . '.csv';
        self::output_csv($filename, [
            ['ID', 'Number', 'Title', 'Status', 'Priority', 'Company', 'Created By', 'Created', 'Updated']
        ], $tickets, [
            'id', 'ticket_number', 'title', 'status', 'priority', 'company_name', 'created_by_contact', 'created_at', 'updated_at'
        ]);
    }
    
    /**
     * Export services as CSV (company-scoped)
     */
    public static function export_services_csv($request) {
        global $wpdb;
        
        $user = \PSP\Company_Auth::validate_session();
        if (!$user) {
            return new \WP_REST_Response(['error' => 'Unauthorized'], 401);
        }

        $services_table = $wpdb->prefix . 'psp_service_records';
        $companies_table = $wpdb->prefix . 'psp_companies';
        $contacts_table = $wpdb->prefix . 'psp_company_contacts';

        $where = $user['type'] === 'company' ? $wpdb->prepare("AND co.id = %d", $user['id']) : '';

        $services = $wpdb->get_results("
            SELECT 
                s.id, s.service_date, s.service_type, s.status,
                co.company_name, c.name as scheduled_by_contact, s.created_at
            FROM $services_table s
            LEFT JOIN $companies_table co ON s.partner_id = co.id
            LEFT JOIN $contacts_table c ON s.created_by_contact_id = c.id
            WHERE 1=1 $where
            ORDER BY s.service_date DESC
        ");

        $filename = 'services-export-' . date('Y-m-d-His') . '.csv';
        self::output_csv($filename, [
            ['ID', 'Service Date', 'Type', 'Status', 'Company', 'Scheduled By', 'Created']
        ], $services, [
            'id', 'service_date', 'service_type', 'status', 'company_name', 'scheduled_by_contact', 'created_at'
        ]);
    }
    
    /**
     * Export partners as CSV (support only)
     */
    public static function export_partners_csv($request) {
        global $wpdb;
        
        $user = \PSP\Company_Auth::validate_session();
        if (!$user || $user['type'] !== 'support') {
            return new \WP_REST_Response(['error' => 'Forbidden'], 403);
        }

        $contacts_table = $wpdb->prefix . 'psp_company_contacts';
        $companies_table = $wpdb->prefix . 'psp_companies';

        $contacts = $wpdb->get_results("
            SELECT 
                c.id, c.name as contact_name, c.email, c.phone, c.is_primary,
                co.company_name, co.username, co.status, c.created_at
            FROM $contacts_table c
            LEFT JOIN $companies_table co ON c.company_id = co.id
            WHERE co.status = 'active'
            ORDER BY co.company_name, c.is_primary DESC, c.name
        ");

        $filename = 'partners-export-' . date('Y-m-d-His') . '.csv';
        self::output_csv($filename, [
            ['ID', 'Contact Name', 'Email', 'Phone', 'Primary', 'Company', 'Username', 'Status', 'Created']
        ], $contacts, [
            'id', 'contact_name', 'email', 'phone', 'is_primary', 'company_name', 'username', 'status', 'created_at'
        ]);
    }
    
    /**
     * Output CSV file
     */
    private static function output_csv($filename, $headers, $data, $columns) {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=' . $filename);
        header('Pragma: no-cache');
        header('Expires: 0');

        $output = fopen('php://output', 'w');
        
        foreach ($headers as $header_row) {
            fputcsv($output, $header_row);
        }

        foreach ($data as $row) {
            $csv_row = [];
            foreach ($columns as $col) {
                $csv_row[] = $row->$col ?? 'N/A';
            }
            fputcsv($output, $csv_row);
        }

        fclose($output);
        exit;
    }
    
    /**
     * Export data as CSV via REST API
     */
    public static function export_data($request) {
        $params = $request->get_json_params();
        $export_type = $params['type'] ?? 'tickets';
        $filters = $params['filters'] ?? [];
        
        $export_method = 'export_' . $export_type;
        
        if (!method_exists(__CLASS__, $export_method)) {
            return new \WP_Error('invalid_type', 'Invalid export type');
        }
        
        $data = self::$export_method($filters);
        
        return [
            'type' => $export_type,
            'filename' => self::generate_filename($export_type),
            'header' => $data['header'] ?? [],
            'rows' => $data['rows'] ?? [],
            'count' => count($data['rows'] ?? []),
        ];
    }
    
    /**
     * Export tickets
     */
    public static function export_tickets($filters = []) {
        global $wpdb;
        
        $query = "SELECT 
                    p.ID as ticket_id,
                    p.post_title as title,
                    p.post_date as created,
                    pm1.meta_value as status,
                    pm2.meta_value as priority,
                    pm3.meta_value as assigned_to,
                    pm4.meta_value as partner_id,
                    pm5.meta_value as description
                  FROM {$wpdb->posts} p
                  LEFT JOIN {$wpdb->postmeta} pm1 ON p.ID = pm1.post_id AND pm1.meta_key = 'psp_ticket_status'
                  LEFT JOIN {$wpdb->postmeta} pm2 ON p.ID = pm2.post_id AND pm2.meta_key = 'psp_ticket_priority'
                  LEFT JOIN {$wpdb->postmeta} pm3 ON p.ID = pm3.post_id AND pm3.meta_key = 'psp_ticket_assigned_to'
                  LEFT JOIN {$wpdb->postmeta} pm4 ON p.ID = pm4.post_id AND pm4.meta_key = 'psp_ticket_partner_id'
                  LEFT JOIN {$wpdb->postmeta} pm5 ON p.ID = pm5.post_id AND pm5.meta_key = 'psp_ticket_description'
                  WHERE p.post_type = 'psp_ticket'";
        
        // Apply filters
        if (!empty($filters['status'])) {
            $query .= $wpdb->prepare(" AND pm1.meta_value = %s", $filters['status']);
        }
        
        if (!empty($filters['date_from'])) {
            $query .= $wpdb->prepare(" AND p.post_date >= %s", $filters['date_from']);
        }
        
        if (!empty($filters['date_to'])) {
            $query .= $wpdb->prepare(" AND p.post_date <= %s", $filters['date_to']);
        }
        
        $query .= " ORDER BY p.post_date DESC";
        
        $results = $wpdb->get_results($query);
        
        $header = ['Ticket ID', 'Title', 'Created', 'Status', 'Priority', 'Assigned To', 'Partner ID', 'Description'];
        $rows = [];
        
        foreach ($results as $row) {
            $rows[] = [
                $row->ticket_id,
                $row->title,
                $row->created,
                $row->status ?? 'open',
                $row->priority ?? 'normal',
                $row->assigned_to ?? 'Unassigned',
                $row->partner_id ?? '',
                substr($row->description ?? '', 0, 100),
            ];
        }
        
        return ['header' => $header, 'rows' => $rows];
    }
    
    /**
     * Export partners
     */
    public static function export_partners($filters = []) {
        global $wpdb;
        
        $query = "SELECT 
                    p.ID as partner_id,
                    p.post_title as name,
                    p.post_date as registered,
                    pm1.meta_value as email,
                    pm2.meta_value as phone,
                    pm3.meta_value as status,
                    pm4.meta_value as company_id,
                    pm5.meta_value as address
                  FROM {$wpdb->posts} p
                  LEFT JOIN {$wpdb->postmeta} pm1 ON p.ID = pm1.post_id AND pm1.meta_key = 'psp_partner_email'
                  LEFT JOIN {$wpdb->postmeta} pm2 ON p.ID = pm2.post_id AND pm2.meta_key = 'psp_partner_phone'
                  LEFT JOIN {$wpdb->postmeta} pm3 ON p.ID = pm3.post_id AND pm3.meta_key = 'psp_partner_status'
                  LEFT JOIN {$wpdb->postmeta} pm4 ON p.ID = pm4.post_id AND pm4.meta_key = 'psp_partner_company_id'
                  LEFT JOIN {$wpdb->postmeta} pm5 ON p.ID = pm5.post_id AND pm5.meta_key = 'psp_partner_address'
                  WHERE p.post_type = 'psp_partner'";
        
        if (!empty($filters['status'])) {
            $query .= $wpdb->prepare(" AND pm3.meta_value = %s", $filters['status']);
        }
        
        if (!empty($filters['company_id'])) {
            $query .= $wpdb->prepare(" AND pm4.meta_value = %d", $filters['company_id']);
        }
        
        $query .= " ORDER BY p.post_date DESC";
        
        $results = $wpdb->get_results($query);
        
        $header = ['Partner ID', 'Name', 'Registered', 'Email', 'Phone', 'Status', 'Company ID', 'Address'];
        $rows = [];
        
        foreach ($results as $row) {
            $rows[] = [
                $row->partner_id,
                $row->name,
                $row->registered,
                $row->email ?? '',
                $row->phone ?? '',
                $row->status ?? 'active',
                $row->company_id ?? '',
                $row->address ?? '',
            ];
        }
        
        return ['header' => $header, 'rows' => $rows];
    }
    
    /**
     * Export properties
     */
    public static function export_properties($filters = []) {
        global $wpdb;
        
        $query = "SELECT 
                    p.ID as property_id,
                    p.post_title as name,
                    p.post_date as added,
                    pm1.meta_value as address,
                    pm2.meta_value as city,
                    pm3.meta_value as state,
                    pm4.meta_value as zip,
                    pm5.meta_value as pool_type,
                    pm6.meta_value as status
                  FROM {$wpdb->posts} p
                  LEFT JOIN {$wpdb->postmeta} pm1 ON p.ID = pm1.post_id AND pm1.meta_key = 'psp_property_address'
                  LEFT JOIN {$wpdb->postmeta} pm2 ON p.ID = pm2.post_id AND pm2.meta_key = 'psp_property_city'
                  LEFT JOIN {$wpdb->postmeta} pm3 ON p.ID = pm3.post_id AND pm3.meta_key = 'psp_property_state'
                  LEFT JOIN {$wpdb->postmeta} pm4 ON p.ID = pm4.post_id AND pm4.meta_key = 'psp_property_zip'
                  LEFT JOIN {$wpdb->postmeta} pm5 ON p.ID = pm5.post_id AND pm5.meta_key = 'psp_property_pool_type'
                  LEFT JOIN {$wpdb->postmeta} pm6 ON p.ID = pm6.post_id AND pm6.meta_key = 'psp_property_status'
                  WHERE p.post_type = 'psp_property'";
        
        if (!empty($filters['status'])) {
            $query .= $wpdb->prepare(" AND pm6.meta_value = %s", $filters['status']);
        }
        
        $query .= " ORDER BY p.post_date DESC";
        
        $results = $wpdb->get_results($query);
        
        $header = ['Property ID', 'Name', 'Added', 'Address', 'City', 'State', 'ZIP', 'Pool Type', 'Status'];
        $rows = [];
        
        foreach ($results as $row) {
            $rows[] = [
                $row->property_id,
                $row->name,
                $row->added,
                $row->address ?? '',
                $row->city ?? '',
                $row->state ?? '',
                $row->zip ?? '',
                $row->pool_type ?? '',
                $row->status ?? 'active',
            ];
        }
        
        return ['header' => $header, 'rows' => $rows];
    }
    
    /**
     * Export activity logs
     */
    public static function export_activity_logs($filters = []) {
        global $wpdb;
        $table = $wpdb->prefix . 'psp_activity_logs';
        
        $query = "SELECT * FROM {$table} WHERE 1=1";
        $params = [];
        
        if (!empty($filters['action'])) {
            $query .= " AND action = %s";
            $params[] = $filters['action'];
        }
        
        if (!empty($filters['severity'])) {
            $query .= " AND severity = %s";
            $params[] = $filters['severity'];
        }
        
        if (!empty($filters['date_from'])) {
            $query .= " AND created_at >= %s";
            $params[] = $filters['date_from'];
        }
        
        if (!empty($filters['date_to'])) {
            $query .= " AND created_at <= %s";
            $params[] = $filters['date_to'];
        }
        
        $query .= " ORDER BY created_at DESC";
        
        if (empty($params)) {
            $results = $wpdb->get_results($query);
        } else {
            $results = $wpdb->get_results($wpdb->prepare($query, $params));
        }
        
        $header = ['ID', 'Action', 'User Email', 'Object Type', 'Object ID', 'Partner ID', 'Severity', 'Description', 'IP Address', 'Created'];
        $rows = [];
        
        foreach ($results as $row) {
            $rows[] = [
                $row->id,
                $row->action,
                $row->user_email,
                $row->object_type,
                $row->object_id,
                $row->partner_id,
                $row->severity,
                $row->description,
                $row->ip_address,
                $row->created_at,
            ];
        }
        
        return ['header' => $header, 'rows' => $rows];
    }
    
    /**
     * Export services
     */
    public static function export_services($filters = []) {
        global $wpdb;
        
        $query = "SELECT 
                    p.ID as service_id,
                    p.post_title as name,
                    p.post_date as created,
                    pm1.meta_value as partner_id,
                    pm2.meta_value as property_id,
                    pm3.meta_value as service_type,
                    pm4.meta_value as scheduled_date,
                    pm5.meta_value as status
                  FROM {$wpdb->posts} p
                  LEFT JOIN {$wpdb->postmeta} pm1 ON p.ID = pm1.post_id AND pm1.meta_key = 'psp_service_partner_id'
                  LEFT JOIN {$wpdb->postmeta} pm2 ON p.ID = pm2.post_id AND pm2.meta_key = 'psp_service_property_id'
                  LEFT JOIN {$wpdb->postmeta} pm3 ON p.ID = pm3.post_id AND pm3.meta_key = 'psp_service_type'
                  LEFT JOIN {$wpdb->postmeta} pm4 ON p.ID = pm4.post_id AND pm4.meta_key = 'psp_service_scheduled_date'
                  LEFT JOIN {$wpdb->postmeta} pm5 ON p.ID = pm5.post_id AND pm5.meta_key = 'psp_service_status'
                  WHERE p.post_type = 'psp_service'";
        
        if (!empty($filters['status'])) {
            $query .= $wpdb->prepare(" AND pm5.meta_value = %s", $filters['status']);
        }
        
        $query .= " ORDER BY p.post_date DESC";
        
        $results = $wpdb->get_results($query);
        
        $header = ['Service ID', 'Name', 'Created', 'Partner ID', 'Property ID', 'Service Type', 'Scheduled Date', 'Status'];
        $rows = [];
        
        foreach ($results as $row) {
            $rows[] = [
                $row->service_id,
                $row->name,
                $row->created,
                $row->partner_id,
                $row->property_id,
                $row->service_type,
                $row->scheduled_date,
                $row->status ?? 'pending',
            ];
        }
        
        return ['header' => $header, 'rows' => $rows];
    }
    
    /**
     * Export invoices
     */
    public static function export_invoices($filters = []) {
        global $wpdb;
        
        $query = "SELECT 
                    p.ID as invoice_id,
                    p.post_title as invoice_number,
                    p.post_date as issued,
                    pm1.meta_value as partner_id,
                    pm2.meta_value as amount,
                    pm3.meta_value as status,
                    pm4.meta_value as due_date,
                    pm5.meta_value as paid_date
                  FROM {$wpdb->posts} p
                  LEFT JOIN {$wpdb->postmeta} pm1 ON p.ID = pm1.post_id AND pm1.meta_key = 'psp_invoice_partner_id'
                  LEFT JOIN {$wpdb->postmeta} pm2 ON p.ID = pm2.post_id AND pm2.meta_key = 'psp_invoice_amount'
                  LEFT JOIN {$wpdb->postmeta} pm3 ON p.ID = pm3.post_id AND pm3.meta_key = 'psp_invoice_status'
                  LEFT JOIN {$wpdb->postmeta} pm4 ON p.ID = pm4.post_id AND pm4.meta_key = 'psp_invoice_due_date'
                  LEFT JOIN {$wpdb->postmeta} pm5 ON p.ID = pm5.post_id AND pm5.meta_key = 'psp_invoice_paid_date'
                  WHERE p.post_type = 'psp_invoice'";
        
        if (!empty($filters['status'])) {
            $query .= $wpdb->prepare(" AND pm3.meta_value = %s", $filters['status']);
        }
        
        $query .= " ORDER BY p.post_date DESC";
        
        $results = $wpdb->get_results($query);
        
        $header = ['Invoice ID', 'Invoice Number', 'Issued', 'Partner ID', 'Amount', 'Status', 'Due Date', 'Paid Date'];
        $rows = [];
        
        foreach ($results as $row) {
            $rows[] = [
                $row->invoice_id,
                $row->invoice_number,
                $row->issued,
                $row->partner_id,
                '$' . number_format($row->amount ?? 0, 2),
                $row->status ?? 'pending',
                $row->due_date,
                $row->paid_date ?? 'Not paid',
            ];
        }
        
        return ['header' => $header, 'rows' => $rows];
    }
    
    /**
     * Generate filename for export
     */
    public static function generate_filename($type) {
        return 'psp-' . $type . '-' . current_time('Y-m-d-His') . '.csv';
    }
    
    /**
     * Generate CSV content from header and rows
     */
    public static function generate_csv_content($header, $rows) {
        $output = '';
        
        // Add header
        $output .= self::escape_csv_row($header) . "\n";
        
        // Add rows
        foreach ($rows as $row) {
            $output .= self::escape_csv_row($row) . "\n";
        }
        
        return $output;
    }
    
    /**
     * Escape CSV row values
     */
    private static function escape_csv_row($row) {
        $escaped = [];
        foreach ($row as $value) {
            if (is_array($value)) {
                $value = json_encode($value);
            }
            $escaped[] = '"' . str_replace('"', '""', $value) . '"';
        }
        return implode(',', $escaped);
    }
    
    /**
     * Handle AJAX export request
     */
    public static function handle_ajax_export() {
        check_ajax_referer('psp_export_nonce', 'nonce');
        
        if (!current_user_can('manage_psp_portal')) {
            wp_send_json_error(['message' => 'Unauthorized']);
        }
        
        $export_type = sanitize_text_field($_POST['type'] ?? 'tickets');
        $filters = isset($_POST['filters']) ? (array) $_POST['filters'] : [];
        
        $export_method = 'export_' . $export_type;
        
        if (!method_exists(__CLASS__, $export_method)) {
            wp_send_json_error(['message' => 'Invalid export type']);
        }
        
        $data = self::$export_method($filters);
        $csv_content = self::generate_csv_content($data['header'], $data['rows']);
        $filename = self::generate_filename($export_type);
        
        wp_send_json_success([
            'csv' => $csv_content,
            'filename' => $filename,
            'count' => count($data['rows']),
        ]);
    }
    
    /**
     * Handle CSV file download
     */
    public static function handle_download() {
        if (isset($_GET['psp_download_csv']) && !empty($_GET['csv'])) {
            if (!current_user_can('manage_psp_portal')) {
                wp_die('Unauthorized');
            }
            
            $csv_data = base64_decode(sanitize_text_field($_GET['csv']));
            $filename = sanitize_file_name($_GET['filename'] ?? 'export.csv');
            
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename=' . $filename);
            header('Content-Length: ' . strlen($csv_data));
            
            echo $csv_data;
            exit;
        }
    }
}

// Initialize on WordPress init
CSV_Export::init();
