<?php

namespace PSP;

/**
 * Input Validation & Sanitization
 * 
 * Server-side validation for all form inputs across the portal.
 * Complements client-side validation for security and UX.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Input_Validation {

	/**
	 * Validate and sanitize contact form input.
	 * 
	 * @param array $data Contact data to validate.
	 * @return array ['valid' => bool, 'errors' => array, 'data' => array]
	 */
	public static function validate_contact_form( array $data ): array {
		$errors = array();
		$cleaned = array();

		// First name
		if ( empty( $data['first_name'] ?? '' ) ) {
			$errors['first_name'] = __( 'First name is required', 'psp' );
		} else {
			$cleaned['first_name'] = sanitize_text_field( $data['first_name'] );
			if ( strlen( $cleaned['first_name'] ) > 100 ) {
				$errors['first_name'] = __( 'First name too long (max 100 characters)', 'psp' );
			}
		}

		// Last name
		if ( empty( $data['last_name'] ?? '' ) ) {
			$errors['last_name'] = __( 'Last name is required', 'psp' );
		} else {
			$cleaned['last_name'] = sanitize_text_field( $data['last_name'] );
			if ( strlen( $cleaned['last_name'] ) > 100 ) {
				$errors['last_name'] = __( 'Last name too long (max 100 characters)', 'psp' );
			}
		}

		// Email
		if ( empty( $data['email'] ?? '' ) ) {
			$errors['email'] = __( 'Email is required', 'psp' );
		} else {
			$cleaned['email'] = sanitize_email( $data['email'] );
			if ( ! is_email( $cleaned['email'] ) ) {
				$errors['email'] = __( 'Invalid email address', 'psp' );
			}
		}

		// Phone
		if ( ! empty( $data['phone'] ?? '' ) ) {
			$phone = preg_replace( '/[^\d\+\-\(\)\s]/', '', $data['phone'] );
			$digits = preg_replace( '/\D/', '', $phone );
			if ( strlen( $digits ) < 10 ) {
				$errors['phone'] = __( 'Phone number must be at least 10 digits', 'psp' );
			} else {
				$cleaned['phone'] = $phone;
			}
		}

		return array(
			'valid'  => empty( $errors ),
			'errors' => $errors,
			'data'   => $cleaned,
		);
	}

	/**
	 * Validate company/partner form data.
	 * 
	 * @param array $data Company data to validate.
	 * @return array ['valid' => bool, 'errors' => array, 'data' => array]
	 */
	public static function validate_company_form( array $data ): array {
		$errors = array();
		$cleaned = array();

		// Company name (optional for partial updates, required when provided)
		if ( array_key_exists( 'company_name', $data ) ) {
			$company_name = trim( (string) $data['company_name'] );
			if ( $company_name === '' ) {
				$errors['company_name'] = __( 'Company name cannot be empty', 'psp' );
			} else {
				$cleaned['company_name'] = sanitize_text_field( $company_name );
			}
		}

		// Email (optional for partial updates)
		if ( array_key_exists( 'company_email', $data ) ) {
			$email = sanitize_email( $data['company_email'] );
			if ( empty( $email ) || ! is_email( $email ) ) {
				$errors['company_email'] = __( 'Invalid email address', 'psp' );
			} else {
				$cleaned['company_email'] = $email;
			}
		}

		// Phone (optional for partial updates)
		if ( array_key_exists( 'phone', $data ) ) {
			$raw_phone = (string) $data['phone'];
			$phone     = preg_replace( '/[^\d\+\-\(\)\s]/', '', $raw_phone );
			$digits    = preg_replace( '/\D/', '', $phone );
			if ( $phone === '' ) {
				$errors['phone'] = __( 'Phone number cannot be empty', 'psp' );
			} elseif ( strlen( $digits ) < 7 ) {
				$errors['phone'] = __( 'Phone number must be at least 7 digits', 'psp' );
			} else {
				$cleaned['phone'] = $phone;
			}
		}

		// Address
		if ( array_key_exists( 'street_address', $data ) && $data['street_address'] !== '' ) {
			$cleaned['street_address'] = sanitize_text_field( $data['street_address'] );
		}

		if ( array_key_exists( 'city', $data ) && $data['city'] !== '' ) {
			$cleaned['city'] = sanitize_text_field( $data['city'] );
		}

		if ( array_key_exists( 'state', $data ) && $data['state'] !== '' ) {
			$cleaned['state'] = sanitize_text_field( $data['state'] );
		}

		if ( array_key_exists( 'zip', $data ) && $data['zip'] !== '' ) {
			$zip = sanitize_text_field( $data['zip'] );
			// Allow international formats; basic length guard
			if ( strlen( $zip ) > 20 ) {
				$errors['zip'] = __( 'Invalid ZIP/Postal code length', 'psp' );
			} else {
				$cleaned['zip'] = $zip;
			}
		}

		if ( array_key_exists( 'country', $data ) && $data['country'] !== '' ) {
			$cleaned['country'] = sanitize_text_field( $data['country'] );
		}

		// Venue type (optional)
		if ( array_key_exists( 'venue_type', $data ) ) {
			$venue_types = array( 'resort', 'residential', 'commercial', 'community', 'hotel', 'waterpark', 'surf_park', 'custom' );
			$value       = sanitize_text_field( $data['venue_type'] );
			if ( $value === '' ) {
				// allow clearing
				$cleaned['venue_type'] = '';
			} elseif ( in_array( $value, $venue_types, true ) ) {
				$cleaned['venue_type'] = $value;
			} else {
				$errors['venue_type'] = __( 'Invalid venue type', 'psp' );
			}
		}

		// Color (top_colour) optional, allow presets, names, hex, or sanitized label
		if ( array_key_exists( 'top_colour', $data ) ) {
			$color        = sanitize_text_field( $data['top_colour'] );
			$presets      = Input_Fields::get_color_presets();
			$preset_keys  = array_keys( $presets );
			$preset_names = array_map( static function ( $c ) {
				return strtolower( $c['name'] );
			}, $presets );
			$is_hex       = preg_match( '/^#[0-9a-fA-F]{6}$/', $color );
			if ( $color === '' ) {
				$cleaned['top_colour'] = '';
			} elseif ( $is_hex || in_array( $color, $preset_keys, true ) || in_array( strtolower( $color ), $preset_names, true ) || strlen( $color ) <= 100 ) {
				// accept known presets, hex, or any reasonable custom label
				$cleaned['top_colour'] = $color;
			} else {
				$errors['top_colour'] = __( 'Invalid color value', 'psp' );
			}
		}

		// Management company
		if ( array_key_exists( 'management_company', $data ) ) {
			$cleaned['management_company'] = sanitize_text_field( $data['management_company'] );
		}

		// Units
		if ( array_key_exists( 'units', $data ) ) {
			$units = intval( $data['units'] );
			if ( $units < 0 ) {
				$errors['units'] = __( 'Units cannot be negative', 'psp' );
			} else {
				$cleaned['units'] = $units;
			}
		}

		// Lock type (L&F, MAKE, Custom)
		if ( array_key_exists( 'lock_type', $data ) ) {
			$allowed = array( 'L&F', 'MAKE', 'Custom', 'custom', 'L&amp;F' );
			$value   = sanitize_text_field( $data['lock_type'] );
			if ( $value === '' ) {
				$cleaned['lock_type'] = '';
			} elseif ( in_array( $value, $allowed, true ) ) {
				$cleaned['lock_type'] = $value === 'L&amp;F' ? 'L&F' : $value;
			} else {
				$errors['lock_type'] = __( 'Invalid lock type', 'psp' );
			}
		}

		// Lock metadata
		foreach ( array( 'master_code', 'sub_master_code', 'lock_part', 'key_code' ) as $lock_field ) {
			if ( array_key_exists( $lock_field, $data ) ) {
				$cleaned[ $lock_field ] = sanitize_text_field( $data[ $lock_field ] );
			}
		}

		// Operation type
		if ( array_key_exists( 'operation_type', $data ) ) {
			$op_types = array( 'yearly', 'seasonal' );
			$value    = sanitize_text_field( $data['operation_type'] );
			if ( $value === '' ) {
				$cleaned['operation_type'] = '';
			} elseif ( in_array( $value, $op_types, true ) ) {
				$cleaned['operation_type'] = $value;
			} else {
				$errors['operation_type'] = __( 'Invalid operation type', 'psp' );
			}
		}

		// Seasonal dates (if seasonal)
		if ( isset( $cleaned['operation_type'] ) && $cleaned['operation_type'] === 'seasonal' ) {
			if ( empty( $data['seasonal_open_date'] ?? '' ) ) {
				$errors['seasonal_open_date'] = __( 'Season open date is required for seasonal operations', 'psp' );
			} else {
				$cleaned['seasonal_open_date'] = sanitize_text_field( $data['seasonal_open_date'] );
			}

			if ( empty( $data['seasonal_close_date'] ?? '' ) ) {
				$errors['seasonal_close_date'] = __( 'Season close date is required for seasonal operations', 'psp' );
			} else {
				$cleaned['seasonal_close_date'] = sanitize_text_field( $data['seasonal_close_date'] );
			}
		}

		return array(
			'valid'  => empty( $errors ),
			'errors' => $errors,
			'data'   => $cleaned,
		);
	}

	/**
	 * Validate ticket form data.
	 * 
	 * @param array $data Ticket data to validate.
	 * @return array ['valid' => bool, 'errors' => array, 'data' => array]
	 */
	public static function validate_ticket_form( array $data ): array {
		$errors = array();
		$cleaned = array();

		// Title
		if ( empty( $data['title'] ?? '' ) ) {
			$errors['title'] = __( 'Ticket title is required', 'psp' );
		} else {
			$cleaned['title'] = sanitize_text_field( $data['title'] );
			if ( strlen( $cleaned['title'] ) > 200 ) {
				$errors['title'] = __( 'Title too long (max 200 characters)', 'psp' );
			}
		}

		// Description
		if ( empty( $data['description'] ?? '' ) ) {
			$errors['description'] = __( 'Description is required', 'psp' );
		} else {
			$cleaned['description'] = wp_kses_post( $data['description'] );
			if ( strlen( $cleaned['description'] ) > 5000 ) {
				$errors['description'] = __( 'Description too long (max 5000 characters)', 'psp' );
			}
		}

		// Category
		if ( ! empty( $data['category'] ?? '' ) ) {
			$categories = array( 'general', 'billing', 'technical', 'service', 'other' );
			$value      = sanitize_text_field( $data['category'] );
			if ( in_array( $value, $categories, true ) ) {
				$cleaned['category'] = $value;
			} else {
				$errors['category'] = __( 'Invalid category', 'psp' );
			}
		}

		// Priority
		if ( ! empty( $data['priority'] ?? '' ) ) {
			$priorities = array( 'low', 'medium', 'high', 'urgent' );
			$value      = sanitize_text_field( $data['priority'] );
			if ( in_array( $value, $priorities, true ) ) {
				$cleaned['priority'] = $value;
			} else {
				$errors['priority'] = __( 'Invalid priority', 'psp' );
			}
		}

		return array(
			'valid'  => empty( $errors ),
			'errors' => $errors,
			'data'   => $cleaned,
		);
	}

	/**
	 * Validate password change request.
	 * 
	 * @param string $current_password Current password.
	 * @param string $new_password New password.
	 * @param string $confirm_password Password confirmation.
	 * @param int $user_id User ID to verify.
	 * @return array ['valid' => bool, 'error' => '']
	 */
	public static function validate_password_change( string $current_password, string $new_password, string $confirm_password, int $user_id ): array {
		// Check if passwords match
		if ( $new_password !== $confirm_password ) {
			return array(
				'valid' => false,
				'error' => __( 'New passwords do not match', 'psp' ),
			);
		}

		// Check password strength
		$strength_check = Input_Fields::validate_password_strength( $new_password );
		if ( ! $strength_check['valid'] ) {
			return array(
				'valid' => false,
				'error' => implode( '; ', $strength_check['errors'] ),
			);
		}

		// Verify current password is correct
		if ( ! wp_check_password( $current_password, get_user_by( 'id', $user_id )->user_pass, $user_id ) ) {
			return array(
				'valid' => false,
				'error' => __( 'Current password is incorrect', 'psp' ),
			);
		}

		return array(
			'valid' => true,
			'error' => '',
		);
	}

	/**
	 * Sanitize user input based on field type.
	 * 
	 * @param string $type Field type (text, email, phone, etc).
	 * @param string $value Value to sanitize.
	 * @return string Sanitized value.
	 */
	public static function sanitize_field( string $type, string $value ): string {
		switch ( $type ) {
			case 'email':
				return sanitize_email( $value );
			case 'phone':
				return preg_replace( '/[^\d\+\-\(\)\s]/', '', $value );
			case 'url':
				return esc_url_raw( $value );
			case 'textarea':
				return wp_kses_post( $value );
			case 'text':
			default:
				return sanitize_text_field( $value );
		}
	}
}
