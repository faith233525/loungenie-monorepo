<?php
namespace PSP;

/**
 * API Failure Alerting System
 * Sends email alerts when API connections fail or tickets cannot sync
 * Helps ops team catch issues quickly
 *
 * @since 1.1.0
 */

if (!defined('ABSPATH')) {
	exit;
}

class API_Failure_Alerter {

	/**
	 * Initialize alerting system
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public static function init() {
		add_action('psp_check_api_connections', [self::class, 'check_all_connections']);
		add_action('psp_sync_failed', [self::class, 'handle_sync_failure']);

		// Schedule connection checks (every 30 minutes)
		if (!wp_next_scheduled('psp_check_api_connections')) {
			wp_schedule_event(time(), 'psp_half_hourly', 'psp_check_api_connections');
		}

		// Register custom schedule
		add_filter('cron_schedules', [self::class, 'add_schedules']);
	}

	/**
	 * Add custom cron schedules
	 *
	 * @since 1.1.0
	 * @param array $schedules Existing schedules.
	 * @return array Updated schedules.
	 */
	public static function add_schedules($schedules) {
		$schedules['psp_half_hourly'] = [
			'interval' => 30 * MINUTE_IN_SECONDS,
			// Use plain string to avoid triggering translations before init
			'display' => 'Every 30 minutes',
		];

		return $schedules;
	}

	/**
	 * Check all API connections
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public static function check_all_connections() {
		$services = ['outlook', 'hubspot'];

		foreach ($services as $service) {
			$status = Connection_Tester::test_connection($service);

			if (!$status['connected']) {
				self::send_alert($service, $status['error'] ?? 'Unknown error');
			}
		}
	}

	/**
	 * Handle sync failure
	 *
	 * @since 1.1.0
	 * @param array $data Failure data.
	 * @return void
	 */
	public static function handle_sync_failure($data = []) {
		$service = $data['service'] ?? '';
		$error = $data['error'] ?? '';
		$tickets = $data['tickets'] ?? [];

		if (empty($service) || empty($error)) {
			return;
		}

		self::send_alert($service, $error, [
			'type' => 'sync_failure',
			'tickets_affected' => count($tickets),
		]);
	}

	/**
	 * Send alert email
	 *
	 * @since 1.1.0
	 * @param string $service Service name.
	 * @param string $error Error message.
	 * @param array  $context Additional context.
	 * @return bool True if email was sent.
	 */
	private static function send_alert($service, $error, $context = []) {
		// Get alert recipients
		$recipients = self::get_alert_recipients();

		if (empty($recipients)) {
			return false;
		}

		// Check alert cooldown (don't spam)
		if (self::is_alert_cooldown($service)) {
			return false;
		}

		// Build email
		$subject = sprintf(
			'[%s] PoolSafe Portal API Alert: %s Connection Failed',
			strtoupper($service),
			ucfirst($service)
		);

		$message = self::build_alert_email($service, $error, $context);

		// Send email
		$result = wp_mail(implode(',', $recipients), $subject, $message, [
			'Content-Type: text/html; charset=UTF-8',
		]);

		if ($result) {
			// Log alert sent
			Audit_Logger::log([
				'action' => 'api_alert_sent',
				'setting' => $service,
				'new_value' => json_encode([
					'error' => $error,
					'recipients' => count($recipients),
					'context' => $context,
				]),
			]);

			// Set cooldown
			set_transient('psp_alert_cooldown_' . $service, true, 1 * HOUR_IN_SECONDS);
		}

		return $result;
	}

	/**
	 * Get alert recipients
	 *
	 * @since 1.1.0
	 * @return array Email addresses.
	 */
	private static function get_alert_recipients() {
		$recipients = [];

		// Get ticketing support email
		$ticketing_settings = get_option('psp_ticketing_settings', []);
		if (!empty($ticketing_settings['support_email'])) {
			$recipients[] = $ticketing_settings['support_email'];
		}

		// Get all managers
		$managers = get_users([
			'role' => 'psp_manager',
			'fields' => 'ID',
		]);

		foreach ($managers as $manager_id) {
			$user = get_userdata($manager_id);
			if ($user) {
				$recipients[] = $user->user_email;
			}
		}

		// Get WordPress admin email as fallback
		if (empty($recipients)) {
			$recipients[] = get_option('admin_email');
		}

		return array_unique($recipients);
	}

	/**
	 * Check if alert is in cooldown period
	 *
	 * @since 1.1.0
	 * @param string $service Service name.
	 * @return bool True if in cooldown.
	 */
	private static function is_alert_cooldown($service) {
		return get_transient('psp_alert_cooldown_' . $service) === true;
	}

	/**
	 * Build alert email HTML
	 *
	 * @since 1.1.0
	 * @param string $service Service name.
	 * @param string $error Error message.
	 * @param array  $context Additional context.
	 * @return string Email HTML.
	 */
	private static function build_alert_email($service, $error, $context = []) {
		$site_name = get_bloginfo('name');
		$admin_url = admin_url('admin.php?page=psp-settings#' . $service);

		$html = '<html><body style="font-family: Arial, sans-serif;">';
		$html .= '<div style="max-width: 600px; margin: 0 auto;">';
		$html .= '<h2 style="color: #d32f2f;">API Connection Alert</h2>';
		$html .= '<p>A connection issue has been detected with your ' . strtoupper($service) . ' integration:</p>';
		$html .= '<div style="background: #fff3cd; border-left: 4px solid #ffc107; padding: 15px; margin: 20px 0;">';
		$html .= '<strong>Error:</strong> ' . esc_html($error) . '<br>';
		$html .= '<strong>Service:</strong> ' . strtoupper($service) . '<br>';
		$html .= '<strong>Time:</strong> ' . current_time('Y-m-d H:i:s') . '<br>';

		if (!empty($context['type']) && 'sync_failure' === $context['type']) {
			$html .= '<strong>Type:</strong> Sync Failure<br>';
			if (!empty($context['tickets_affected'])) {
				$html .= '<strong>Tickets Affected:</strong> ' . intval($context['tickets_affected']) . '<br>';
			}
		}

		$html .= '</div>';

		$html .= '<p><strong>Next Steps:</strong></p>';
		$html .= '<ol>';
		$html .= '<li>Review your API credentials in the <a href="' . esc_attr($admin_url) . '">PoolSafe Settings</a></li>';
		$html .= '<li>Verify your ' . strtoupper($service) . ' service is operational</li>';
		$html .= '<li>Check your network connectivity</li>';
		$html .= '<li>Review the <a href="' . admin_url('admin.php?page=psp-settings#audit') . '">Audit Log</a> for more details</li>';
		$html .= '</ol>';

		$html .= '<p style="color: #666; font-size: 12px; margin-top: 30px;">';
		$html .= 'This is an automated alert from ' . esc_html($site_name) . ' PoolSafe Portal. ';
		$html .= 'If you believe this is an error, please contact your administrator.';
		$html .= '</p>';

		$html .= '</div></body></html>';

		return $html;
	}

	/**
	 * Log API event (for monitoring)
	 *
	 * @since 1.1.0
	 * @param string $service Service name.
	 * @param string $event Event type.
	 * @param array  $data Event data.
	 * @return bool|int Log ID.
	 */
	public static function log_event($service, $event, $data = []) {
		return Audit_Logger::log([
			'action' => 'api_event',
			'setting' => $service . '_' . $event,
			'new_value' => json_encode($data),
		]);
	}

	/**
	 * Get API health status
	 *
	 * @since 1.1.0
	 * @return array Health status for all services.
	 */
	public static function get_health_status() {
		$services = ['outlook', 'hubspot'];
		$health = [];

		foreach ($services as $service) {
			$status = Connection_Tester::test_connection($service);
			$health[$service] = [
				'healthy' => $status['connected'],
				'last_checked' => $status['last_tested'] ?? 'Never',
				'error' => $status['error'] ?? '',
			];
		}

		return $health;
	}
}
