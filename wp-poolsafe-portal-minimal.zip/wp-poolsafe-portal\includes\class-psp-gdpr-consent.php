<?php

namespace PSP;

/**
 * GDPR Consent Management
 * 
 * Manages user consents for data processing, marketing, cookies, etc.
 * Implements granular consent tracking and withdrawal capabilities.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class GDPR_Consent {

	// Consent types
	const CONSENT_PROCESSING = 'data_processing';
	const CONSENT_MARKETING = 'marketing';
	const CONSENT_ANALYTICS = 'analytics';
	const CONSENT_COOKIES = 'cookies';
	const CONSENT_PROFILING = 'profiling';
	const CONSENT_THIRD_PARTY = 'third_party';

	/**
	 * Initialize consent management
	 * 
	 * @return void
	 */
	public static function init(): void {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
		add_action( 'wp_footer', array( __CLASS__, 'output_consent_notice' ) );
	}

	/**
	 * Register REST API routes
	 * 
	 * @return void
	 */
	public static function register_routes(): void {
		// Get user consents
		register_rest_route(
			'psp/v1',
			'/user/consents',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'get_user_consents' ),
				'permission_callback' => array( __CLASS__, 'check_auth' ),
			)
		);

		// Update consent
		register_rest_route(
			'psp/v1',
			'/user/consents/(?P<type>[a-z_]+)',
			array(
				'methods'             => 'PUT',
				'callback'            => array( __CLASS__, 'update_consent' ),
				'permission_callback' => array( __CLASS__, 'check_auth' ),
				'args'                => array(
					'given' => array(
						'type'     => 'boolean',
						'required' => true,
					),
				),
			)
		);

		// Withdraw consent
		register_rest_route(
			'psp/v1',
			'/user/consents/(?P<type>[a-z_]+)/withdraw',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'withdraw_consent' ),
				'permission_callback' => array( __CLASS__, 'check_auth' ),
			)
		);

		// Record consent (for frontend)
		register_rest_route(
			'psp/v1',
			'/consents/record',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'record_consent' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'type'   => array(
						'type'     => 'string',
						'required' => true,
					),
					'given'  => array(
						'type'     => 'boolean',
						'required' => true,
					),
					'source' => array(
						'type' => 'string',
					),
				),
			)
		);

		// Get consent history
		register_rest_route(
			'psp/v1',
			'/user/consent-history',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'get_consent_history' ),
				'permission_callback' => array( __CLASS__, 'check_auth' ),
			)
		);
	}

	/**
	 * Check if user is authenticated (portal or WordPress admin)
	 * 
	 * @return bool
	 */
	public static function check_auth(): bool {
		return ( isset( $_SESSION['psp_user_id'] ) && ! empty( $_SESSION['psp_user_id'] ) ) || is_user_logged_in();
	}

	/**
	 * Get user consents
	 * 
	 * @return \WP_REST_Response
	 */
	public static function get_user_consents(): \WP_REST_Response {
		global $wpdb;

		$user_id = absint( $_SESSION['psp_user_id'] ?? 0 );
		
		// Anonymous users get default consents
		if ( $user_id === 0 ) {
			return Error_Handler::success( self::get_default_consents() );
		}

		$consents = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT type, given, updated_at FROM {$wpdb->prefix}psp_gdpr_consents 
				WHERE user_id = %d ORDER BY type",
				$user_id
			),
			ARRAY_A
		);

		if ( empty( $consents ) ) {
			return Error_Handler::success( self::get_default_consents() );
		}

		// Build associative array
		$consent_map = array();
		foreach ( $consents as $consent ) {
			$consent_map[ $consent['type'] ] = array(
				'given'      => (bool) $consent['given'],
				'updated_at' => $consent['updated_at'],
			);
		}

		// Merge with defaults
		$defaults = self::get_default_consents();
		foreach ( $defaults as $type => $default ) {
			if ( ! isset( $consent_map[ $type ] ) ) {
				$consent_map[ $type ] = $default;
			}
		}

		return Error_Handler::success( $consent_map );
	}

	/**
	 * Get default consents
	 * 
	 * @return array
	 */
	private static function get_default_consents(): array {
		return array(
			self::CONSENT_PROCESSING => array(
				'given'       => false,
				'description' => __( 'I consent to process my personal data for service delivery', 'psp' ),
				'required'    => true,
			),
			self::CONSENT_MARKETING  => array(
				'given'       => false,
				'description' => __( 'I consent to receive marketing communications', 'psp' ),
				'required'    => false,
			),
			self::CONSENT_ANALYTICS  => array(
				'given'       => false,
				'description' => __( 'I consent to analytics and usage tracking', 'psp' ),
				'required'    => false,
			),
			self::CONSENT_COOKIES    => array(
				'given'       => false,
				'description' => __( 'I consent to use of cookies and similar technologies', 'psp' ),
				'required'    => false,
			),
			self::CONSENT_PROFILING  => array(
				'given'       => false,
				'description' => __( 'I consent to profiling for personalized experience', 'psp' ),
				'required'    => false,
			),
			self::CONSENT_THIRD_PARTY => array(
				'given'       => false,
				'description' => __( 'I consent to share data with third-party partners', 'psp' ),
				'required'    => false,
			),
		);
	}

	/**
	 * Update consent
	 * 
	 * @param \WP_REST_Request $request REST request
	 * @return \WP_REST_Response
	 */
	public static function update_consent( \WP_REST_Request $request ): \WP_REST_Response {
		global $wpdb;

		$user_id = absint( $_SESSION['psp_user_id'] ?? 0 );
		if ( $user_id === 0 ) {
			return Error_Handler::unauthorized();
		}

		$type = sanitize_text_field( $request->get_param( 'type' ) );
		$given = filter_var( $request->get_param( 'given' ), FILTER_VALIDATE_BOOLEAN );

		// Validate consent type
		$defaults = self::get_default_consents();
		if ( ! isset( $defaults[ $type ] ) ) {
			return Error_Handler::validation_error( 'type', __( 'Invalid consent type', 'psp' ) );
		}

		// Check if consent exists
		$exists = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT id FROM {$wpdb->prefix}psp_gdpr_consents WHERE user_id = %d AND type = %s",
				$user_id,
				$type
			)
		);

		if ( $exists ) {
			$wpdb->update(
				"{$wpdb->prefix}psp_gdpr_consents",
				array(
					'given'      => $given ? 1 : 0,
					'updated_at' => current_time( 'mysql' ),
				),
				array(
					'user_id' => $user_id,
					'type'    => $type,
				),
				array( '%d', '%s' ),
				array( '%d', '%s' )
			);
		} else {
			$wpdb->insert(
				"{$wpdb->prefix}psp_gdpr_consents",
				array(
					'user_id'    => $user_id,
					'type'       => $type,
					'given'      => $given ? 1 : 0,
					'created_at' => current_time( 'mysql' ),
					'updated_at' => current_time( 'mysql' ),
				),
				array( '%d', '%s', '%d', '%s', '%s' )
			);
		}

		// Log consent change
		Audit_Logger::log_event(
			'consent_updated',
			wp_json_encode(
				array(
					'type'  => $type,
					'given' => $given,
				)
			),
			'consent',
			$user_id
		);

		return Error_Handler::success(
			array(
				'type'       => $type,
				'given'      => $given,
				'updated_at' => current_time( 'mysql' ),
			),
			__( 'Consent updated', 'psp' )
		);
	}

	/**
	 * Withdraw consent
	 * 
	 * @param \WP_REST_Request $request REST request
	 * @return \WP_REST_Response
	 */
	public static function withdraw_consent( \WP_REST_Request $request ): \WP_REST_Response {
		global $wpdb;

		$user_id = absint( $_SESSION['psp_user_id'] ?? 0 );
		if ( $user_id === 0 ) {
			return Error_Handler::unauthorized();
		}

		$type = sanitize_text_field( $request->get_param( 'type' ) );

		// Validate consent type
		$defaults = self::get_default_consents();
		if ( ! isset( $defaults[ $type ] ) ) {
			return Error_Handler::validation_error( 'type', __( 'Invalid consent type', 'psp' ) );
		}

		// Check if it's required
		if ( $defaults[ $type ]['required'] ) {
			return Error_Handler::validation_error(
				'type',
				__( 'This consent cannot be withdrawn as it is required for service delivery', 'psp' )
			);
		}

		// Update consent
		$wpdb->update(
			"{$wpdb->prefix}psp_gdpr_consents",
			array(
				'given'      => 0,
				'updated_at' => current_time( 'mysql' ),
			),
			array(
				'user_id' => $user_id,
				'type'    => $type,
			),
			array( '%d', '%s' ),
			array( '%d', '%s' )
		);

		// Log withdrawal
		Audit_Logger::log_event(
			'consent_withdrawn',
			wp_json_encode( array( 'type' => $type ) ),
			'consent',
			$user_id
		);

		return Error_Handler::success(
			null,
			__( 'Consent withdrawn', 'psp' )
		);
	}

	/**
	 * Record consent (for unauthenticated users)
	 * 
	 * @param \WP_REST_Request $request REST request
	 * @return \WP_REST_Response
	 */
	public static function record_consent( \WP_REST_Request $request ): \WP_REST_Response {
		global $wpdb;

		$type = sanitize_text_field( $request->get_param( 'type' ) );
		$given = filter_var( $request->get_param( 'given' ), FILTER_VALIDATE_BOOLEAN );
		$source = sanitize_text_field( $request->get_param( 'source' ) ?? 'frontend' );

		// Validate consent type
		$defaults = self::get_default_consents();
		if ( ! isset( $defaults[ $type ] ) ) {
			return Error_Handler::validation_error( 'type', __( 'Invalid consent type', 'psp' ) );
		}

		// Get or create anonymous user consent
		$user_id = absint( $_SESSION['psp_user_id'] ?? 0 );
		$ip_address = self::get_client_ip();

		// Store in session
		if ( ! isset( $_SESSION['psp_consents'] ) ) {
			$_SESSION['psp_consents'] = array();
		}

		$_SESSION['psp_consents'][ $type ] = array(
			'given'      => $given,
			'recorded_at' => current_time( 'mysql' ),
			'source'     => $source,
		);

		// Store in database for tracking
		$wpdb->insert(
			"{$wpdb->prefix}psp_gdpr_consent_log",
			array(
				'user_id'    => $user_id > 0 ? $user_id : null,
				'type'       => $type,
				'given'      => $given ? 1 : 0,
				'source'     => $source,
				'ip_address' => $ip_address,
				'created_at' => current_time( 'mysql' ),
			),
			array( '%d', '%s', '%d', '%s', '%s', '%s' )
		);

		return Error_Handler::success(
			array(
				'type'    => $type,
				'given'   => $given,
				'source'  => $source,
			)
		);
	}

	/**
	 * Get consent history
	 * 
	 * @return \WP_REST_Response
	 */
	public static function get_consent_history(): \WP_REST_Response {
		global $wpdb;

		$user_id = absint( $_SESSION['psp_user_id'] ?? 0 );
		if ( $user_id === 0 ) {
			return Error_Handler::unauthorized();
		}

		$history = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT type, given, updated_at FROM {$wpdb->prefix}psp_gdpr_consents 
				WHERE user_id = %d ORDER BY updated_at DESC",
				$user_id
			),
			ARRAY_A
		);

		return Error_Handler::success( $history ?: array() );
	}

	/**
	 * Output consent notice on frontend
	 * 
	 * @return void
	 */
	public static function output_consent_notice(): void {
		if ( is_user_logged_in() ) {
			return; // Skip for logged-in users
		}

		?>
		<div id="psp-consent-notice" class="psp-consent-notice" style="display:none;">
			<div class="psp-consent-content">
				<h3><?php esc_html_e( 'Your Privacy Matters', 'psp' ); ?></h3>
				<p><?php esc_html_e( 'We use cookies and similar technologies to enhance your experience and analyze usage.', 'psp' ); ?></p>
				
				<div class="psp-consent-options">
					<label>
						<input type="checkbox" name="consent_processing" checked>
						<?php esc_html_e( 'Essential Data Processing', 'psp' ); ?>
					</label>
					<label>
						<input type="checkbox" name="consent_marketing">
						<?php esc_html_e( 'Marketing Communications', 'psp' ); ?>
					</label>
					<label>
						<input type="checkbox" name="consent_analytics">
						<?php esc_html_e( 'Analytics Tracking', 'psp' ); ?>
					</label>
					<label>
						<input type="checkbox" name="consent_cookies">
						<?php esc_html_e( 'Cookies & Tracking', 'psp' ); ?>
					</label>
				</div>

				<div class="psp-consent-actions">
					<button id="psp-accept-all"><?php esc_html_e( 'Accept All', 'psp' ); ?></button>
					<button id="psp-save-preferences"><?php esc_html_e( 'Save Preferences', 'psp' ); ?></button>
					<a href="/privacy-policy"><?php esc_html_e( 'Privacy Policy', 'psp' ); ?></a>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Get client IP address
	 * 
	 * @return string
	 */
	private static function get_client_ip(): string {
		if ( ! empty( $_SERVER['HTTP_CLIENT_IP'] ) ) {
			$ip = $_SERVER['HTTP_CLIENT_IP'];
		} elseif ( ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
			$ip = explode( ',', $_SERVER['HTTP_X_FORWARDED_FOR'] )[0];
		} else {
			$ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
		}

		return sanitize_text_field( $ip );
	}
}
