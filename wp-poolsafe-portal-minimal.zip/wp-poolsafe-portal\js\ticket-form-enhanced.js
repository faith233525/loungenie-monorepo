/**
 * Enhanced Ticket Form Handling with Validation Error Display
 * 
 * This module integrates the ValidationErrorHandler to display
 * field-specific error messages from REST API responses.
 * 
 * Replace the corresponding functions in portal.js with these versions.
 */

/**
 * Create Quick Ticket (Admin/Staff view)
 * Enhanced with field-specific error display
 */
async function createQuickTicket() {
    const status = document.getElementById('psp-create-ticket-status');
    const saveBtn = document.getElementById('psp-create-ticket-save');
    const form = document.getElementById('psp-quick-ticket-form');

    const partnerId = parseInt(
        (document.getElementById('psp-new-ticket-partner-id') || {}).value || '0',
    );
    const title = (document.getElementById('psp-new-ticket-title') || {}).value || '';
    const priority = (document.getElementById('psp-new-ticket-priority') || {}).value || 'medium';
    const units = (document.getElementById('psp-new-ticket-units') || {}).value || '';
    const content = (document.getElementById('psp-new-ticket-content') || {}).value || '';

    // Clear previous errors
    if (form && typeof ValidationErrorHandler !== 'undefined') {
        ValidationErrorHandler.clearErrors(form);
    }

    // Basic presence check before API call
    const errors = {};
    if (!title) {
        errors.title = 'Title is required';
    }
    if (!content) {
        errors.description = 'Description is required';
    }

    if (Object.keys(errors).length > 0) {
        if (form && typeof ValidationErrorHandler !== 'undefined') {
            ValidationErrorHandler.displayErrors(errors, form);
        }
        if (status) {
            status.textContent = 'Please correct the errors below';
            status.style.color = 'var(--psp-danger)';
        }
        return;
    }

    if (status) {
        status.textContent = 'Creating ticket...';
        status.style.color = 'var(--psp-fg-light)';
    }
    if (saveBtn) {
        saveBtn.disabled = true;
    }

    try {
        const payload = {
            title: title,
            description: content,
            priority: priority,
            category: '',
        };

        const res = await fetch(PSP_PORTAL.rest.base + '/tickets', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-WP-Nonce': PSP_PORTAL.rest.nonce,
            },
            body: JSON.stringify(payload),
        });

        const data = await res.json();

        // Handle validation errors from API
        if (!data.success && data.errors) {
            if (form && typeof ValidationErrorHandler !== 'undefined') {
                ValidationErrorHandler.displayErrors(data.errors, form);
            }
            if (status) {
                status.textContent = data.message || 'Validation failed';
                status.style.color = 'var(--psp-danger)';
            }
            return;
        }

        if (!res.ok) {
            throw new Error('Ticket creation failed');
        }

        if (status) {
            status.textContent = '✓ Ticket #' + (data.ticket_id || '') + ' created!';
            status.style.color = 'var(--psp-success)';
        }

        setTimeout(() => {
            if (form) {
                form.style.display = 'none';
            }
            clearTicketForm();
            if (status) {
                status.textContent = '';
            }
            openPartnerProfile(partnerId);
        }, 1500);
    } catch (e) {
        if (status) {
            status.textContent = 'Failed to create ticket: ' + e.message;
            status.style.color = '#dc2626';
        }
    } finally {
        if (saveBtn) {
            saveBtn.disabled = false;
        }
    }
}

/**
 * Create Ticket (Customer/Partner form)
 * Enhanced with field-specific error display
 */
async function createTicket() {
    const form = document.getElementById('psp-ticket-create');
    const firstName = (document.getElementById('psp-ticket-first-name') || {}).value || '';
    const lastName = (document.getElementById('psp-ticket-last-name') || {}).value || '';
    const position = (document.getElementById('psp-ticket-position') || {}).value || '';
    const contactEmail = (document.getElementById('psp-ticket-email') || {}).value || '';
    const contactNumber = (document.getElementById('psp-ticket-number') || {}).value || '';
    const unitsAffected = (document.getElementById('psp-ticket-units-affected') || {}).value || '';
    const title = (document.getElementById('psp-ticket-title') || {}).value || '';
    const content = (document.getElementById('psp-ticket-content') || {}).value || '';
    const filesInput = document.getElementById('psp-ticket-files');
    const status = document.getElementById('psp-ticket-create-status');

    // Clear previous errors
    if (form && typeof ValidationErrorHandler !== 'undefined') {
        ValidationErrorHandler.clearErrors(form);
    }

    // Prepare payload
    const payload = {
        title: title,
        description: content,
        first_name: firstName,
        last_name: lastName,
        email: contactEmail,
        phone: contactNumber,
        position: position,
    };

    if (status) {
        status.textContent = 'Creating ticket...';
        status.style.color = '#666';
    }

    try {
        // Send ticket creation request
        const res = await fetch(PSP_PORTAL.rest.base + '/tickets', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-WP-Nonce': PSP_PORTAL.rest.nonce,
            },
            body: JSON.stringify(payload),
        });

        const data = await res.json();

        // Handle validation errors from API
        if (!data.success && data.errors) {
            if (form && typeof ValidationErrorHandler !== 'undefined') {
                ValidationErrorHandler.displayErrors(data.errors, form);
            }
            if (status) {
                status.textContent = data.message || 'Please correct the errors below';
                status.style.color = '#dc2626';
            }
            return;
        }

        if (!res.ok) {
            throw new Error('Create failed');
        }

        const ticketId = data.ticket_id;

        // Upload files if any
        if (filesInput && filesInput.files && filesInput.files.length > 0) {
            status.textContent = 'Uploading attachments...';

            for (let i = 0; i < filesInput.files.length; i++) {
                const formData = new FormData();
                formData.append('file', filesInput.files[i]);
                formData.append('ticket_id', ticketId);

                const uploadRes = await fetch(PSP_PORTAL.api.base + '/attachments', {
                    method: 'POST',
                    headers: {
                        'X-WP-Nonce': PSP_PORTAL.api.nonce,
                    },
                    body: formData,
                });

                if (!uploadRes.ok) {
                    console.warn('Failed to upload file:', filesInput.files[i].name);
                }
            }

            status.textContent = 'Ticket created successfully with attachments!';
            status.style.color = '#065f46';
        } else {
            status.textContent = 'Ticket created successfully!';
            status.style.color = '#065f46';
        }

        // Clear form
        const fieldsToClear = [
            'psp-ticket-first-name',
            'psp-ticket-last-name',
            'psp-ticket-position',
            'psp-ticket-email',
            'psp-ticket-number',
            'psp-ticket-units-affected',
            'psp-ticket-title',
            'psp-ticket-content',
        ];

        fieldsToClear.forEach(fieldId => {
            const field = document.getElementById(fieldId);
            if (field) {
                field.value = '';
                field.classList.remove('validation-error');
            }
        });

        if (filesInput) {
            filesInput.value = '';
        }
        const filePreview = document.getElementById('psp-ticket-files-preview');
        if (filePreview) {
            filePreview.innerHTML = '';
        }

        setTimeout(() => {
            if (status) {
                status.textContent = '';
            }
            // Reload tickets list
            if (typeof fetchTickets === 'function') {
                fetchTickets();
            }
        }, 1500);
    } catch (e) {
        console.error('Ticket creation error:', e);
        if (status) {
            status.textContent = 'Failed to create ticket: ' + e.message;
            status.style.color = '#dc2626';
        }
    }
}

/**
 * Setup field error clearing on input
 */
function setupValidationErrorClearance() {
    const form = document.getElementById('psp-ticket-create');
    if (form && typeof ValidationErrorHandler !== 'undefined') {
        ValidationErrorHandler.setupFieldClearance(form);
    }

    const quickForm = document.getElementById('psp-quick-ticket-form');
    if (quickForm && typeof ValidationErrorHandler !== 'undefined') {
        ValidationErrorHandler.setupFieldClearance(quickForm);
    }
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', setupValidationErrorClearance);
} else {
    setupValidationErrorClearance();
}
