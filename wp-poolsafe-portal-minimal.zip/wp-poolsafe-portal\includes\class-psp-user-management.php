<?php
/**
 * User Management - Admin interface for managing usernames and passwords
 * Allows admins/support staff to update partner account credentials
 *
 * @package    PoolSafe_Portal
 * @subpackage PoolSafe_Portal/includes
 */

if (!defined('ABSPATH')) {
    exit;
}

class PSP_User_Management {

    /**
     * Initialize user management
     */
    public static function init() {
        add_action('admin_menu', array(__CLASS__, 'add_user_management_menu'));
        add_action('wp_ajax_psp_update_user_password', array(__CLASS__, 'ajax_update_password'));
        add_action('wp_ajax_psp_update_user_username', array(__CLASS__, 'ajax_update_username'));
        add_action('wp_ajax_psp_reset_user_password', array(__CLASS__, 'ajax_reset_password'));
        add_action('wp_ajax_psp_get_users_list', array(__CLASS__, 'ajax_get_users_list'));
    }

    /**
     * Add menu item to WordPress admin
     */
    public static function add_user_management_menu() {
        add_submenu_page(
            'poolsafe-settings',
            'User Management',
            'User Management',
            'manage_options',
            'poolsafe-user-management',
            array(__CLASS__, 'render_user_management_page')
        );
    }

    /**
     * Render user management page
     */
    public static function render_user_management_page() {
        global $wpdb;

        // Check permissions
        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }

        // Get all portal users
        $users = $wpdb->get_results(
            "SELECT u.id, u.username, u.email, u.first_name, u.last_name, u.status, 
                    c.company_name, cu.company_id
             FROM {$wpdb->prefix}psp_company_users u
             LEFT JOIN {$wpdb->prefix}psp_partners c ON u.company_id = c.id
             ORDER BY c.company_name, u.first_name"
        );

        ?>
        <div class="wrap">
            <h1>Portal User Management</h1>
            <p>Manage username and password for all portal users.</p>

            <div id="psp-users-table">
                <table class="widefat striped">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Company</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $user) : ?>
                            <tr id="user-row-<?php echo esc_attr($user->id); ?>">
                                <td><?php echo esc_html($user->first_name . ' ' . $user->last_name); ?></td>
                                <td>
                                    <span class="user-username"><?php echo esc_html($user->username); ?></span>
                                </td>
                                <td><?php echo esc_html($user->email); ?></td>
                                <td><?php echo esc_html($user->company_name ?: 'N/A'); ?></td>
                                <td>
                                    <span class="status-badge <?php echo esc_attr($user->status); ?>">
                                        <?php echo esc_html(ucfirst($user->status)); ?>
                                    </span>
                                </td>
                                <td>
                                    <button class="button button-small edit-user-btn" data-user-id="<?php echo esc_attr($user->id); ?>">Edit</button>
                                    <button class="button button-small reset-password-btn" data-user-id="<?php echo esc_attr($user->id); ?>">Reset Password</button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Edit User Modal -->
        <div id="psp-edit-user-modal" style="display:none;">
            <div class="psp-modal-content">
                <h2>Edit User</h2>
                <form id="psp-edit-user-form">
                    <input type="hidden" id="edit-user-id" name="user_id">
                    <?php wp_nonce_field('psp_user_management', 'psp_nonce'); ?>

                    <p>
                        <label for="edit-username">Username:</label>
                        <input type="text" id="edit-username" name="username" required>
                    </p>

                    <p>
                        <label for="edit-password">New Password:</label>
                        <input type="password" id="edit-password" name="password" placeholder="Leave blank to keep current">
                        <small>Leave blank to keep the current password</small>
                    </p>

                    <p>
                        <label for="edit-password-confirm">Confirm Password:</label>
                        <input type="password" id="edit-password-confirm" name="password_confirm" placeholder="Leave blank to keep current">
                    </p>

                    <p>
                        <button type="submit" class="button button-primary">Save Changes</button>
                        <button type="button" class="button" onclick="pspCloseModal()">Cancel</button>
                    </p>
                </form>
            </div>
        </div>

        <style>
            #psp-edit-user-modal {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0,0,0,0.5);
                display: flex;
                align-items: center;
                justify-content: center;
                z-index: 9999;
            }

            .psp-modal-content {
                background: white;
                padding: 30px;
                border-radius: 8px;
                max-width: 500px;
                width: 90%;
                box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            }

            .psp-modal-content h2 {
                margin-top: 0;
            }

            .status-badge {
                padding: 4px 8px;
                border-radius: 3px;
                font-size: 12px;
                font-weight: bold;
            }

            .status-badge.active {
                background: #d4edda;
                color: #155724;
            }

            .status-badge.inactive {
                background: #f8d7da;
                color: #721c24;
            }

            .widefat button {
                margin-right: 5px;
            }
        </style>

        <script>
            document.addEventListener('DOMContentLoaded', function() {
                // Edit user button
                document.querySelectorAll('.edit-user-btn').forEach(btn => {
                    btn.addEventListener('click', function() {
                        const userId = this.dataset.userId;
                        const row = document.getElementById('user-row-' + userId);
                        const username = row.querySelector('.user-username').textContent;

                        document.getElementById('edit-user-id').value = userId;
                        document.getElementById('edit-username').value = username;
                        document.getElementById('edit-password').value = '';
                        document.getElementById('edit-password-confirm').value = '';

                        document.getElementById('psp-edit-user-modal').style.display = 'flex';
                    });
                });

                // Reset password button
                document.querySelectorAll('.reset-password-btn').forEach(btn => {
                    btn.addEventListener('click', function() {
                        const userId = this.dataset.userId;
                        const row = document.getElementById('user-row-' + userId);
                        const userName = row.querySelector('td:nth-child(1)').textContent;

                        if (confirm('Generate random password for ' + userName + '?')) {
                            pspResetPassword(userId);
                        }
                    });
                });

                // Edit form submission
                document.getElementById('psp-edit-user-form').addEventListener('submit', function(e) {
                    e.preventDefault();

                    const userId = document.getElementById('edit-user-id').value;
                    const username = document.getElementById('edit-username').value;
                    const password = document.getElementById('edit-password').value;
                    const passwordConfirm = document.getElementById('edit-password-confirm').value;

                    // Validate
                    if (!username) {
                        alert('Username is required');
                        return;
                    }

                    if (password !== passwordConfirm) {
                        alert('Passwords do not match');
                        return;
                    }

                    // Send update
                    const data = new FormData();
                    data.append('action', 'psp_update_user_password');
                    data.append('user_id', userId);
                    data.append('username', username);
                    data.append('password', password);
                    data.append('psp_nonce', document.querySelector('[name="psp_nonce"]').value);

                    fetch(ajaxurl, {
                        method: 'POST',
                        body: data
                    })
                    .then(res => res.json())
                    .then(data => {
                        if (data.success) {
                            alert('User updated successfully');
                            pspCloseModal();
                            location.reload();
                        } else {
                            alert('Error: ' + (data.data || 'Unknown error'));
                        }
                    })
                    .catch(err => alert('Error updating user'));
                });
            });

            function pspCloseModal() {
                document.getElementById('psp-edit-user-modal').style.display = 'none';
            }

            function pspResetPassword(userId) {
                const data = new FormData();
                data.append('action', 'psp_reset_user_password');
                data.append('user_id', userId);
                data.append('psp_nonce', document.querySelector('[name="psp_nonce"]').value);

                fetch(ajaxurl, {
                    method: 'POST',
                    body: data
                })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        alert('New password: ' + data.data.password + '\n\nPassword has been reset. Share this with the user.');
                        location.reload();
                    } else {
                        alert('Error: ' + (data.data || 'Unknown error'));
                    }
                })
                .catch(err => alert('Error resetting password'));
            }

            // Close modal when clicking outside
            document.getElementById('psp-edit-user-modal').addEventListener('click', function(e) {
                if (e.target === this) {
                    pspCloseModal();
                }
            });
        </script>
        <?php
    }

    /**
     * AJAX: Update user password
     */
    public static function ajax_update_password() {
        check_ajax_referer('psp_user_management', 'psp_nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }

        global $wpdb;

        $user_id = intval($_POST['user_id']);
        $username = sanitize_text_field($_POST['username']);
        $password = isset($_POST['password']) && !empty($_POST['password']) ? sanitize_text_field($_POST['password']) : null;

        // Validate username
        if (empty($username)) {
            wp_send_json_error('Username is required');
        }

        // Check if username already exists (for another user)
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}psp_company_users WHERE username = %s AND id != %d",
            $username,
            $user_id
        ));

        if ($existing) {
            wp_send_json_error('Username already exists');
        }

        // Update username
        $updated = $wpdb->update(
            $wpdb->prefix . 'psp_company_users',
            array('username' => $username),
            array('id' => $user_id),
            array('%s'),
            array('%d')
        );

        if ($updated === false) {
            wp_send_json_error('Failed to update username');
        }

        // Update password if provided
        if ($password) {
            $password_hash = password_hash($password, PASSWORD_BCRYPT);
            $wpdb->update(
                $wpdb->prefix . 'psp_company_users',
                array('password' => $password_hash),
                array('id' => $user_id),
                array('%s'),
                array('%d')
            );
        }

        // Log activity
        self::log_user_management_activity('update_credentials', "Username updated for user ID: $user_id", $user_id);

        wp_send_json_success('User updated successfully');
    }

    /**
     * AJAX: Reset user password to random
     */
    public static function ajax_reset_password() {
        check_ajax_referer('psp_user_management', 'psp_nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }

        global $wpdb;

        $user_id = intval($_POST['user_id']);

        // Generate random password
        $new_password = wp_generate_password(12, true);
        $password_hash = password_hash($new_password, PASSWORD_BCRYPT);

        // Update password
        $updated = $wpdb->update(
            $wpdb->prefix . 'psp_company_users',
            array('password' => $password_hash),
            array('id' => $user_id),
            array('%s'),
            array('%d')
        );

        if ($updated === false) {
            wp_send_json_error('Failed to reset password');
        }

        // Log activity
        self::log_user_management_activity('reset_password', "Password reset for user ID: $user_id", $user_id);

        wp_send_json_success(array(
            'password' => $new_password,
            'message' => 'Password reset successfully'
        ));
    }

    /**
     * Log user management activities
     */
    private static function log_user_management_activity($action, $description, $user_id) {
        global $wpdb;

        $current_user = wp_get_current_user();

        $wpdb->insert(
            $wpdb->prefix . 'psp_audit_log',
            array(
                'user_id' => $current_user->ID,
                'action' => $action,
                'description' => $description,
                'entity_type' => 'user',
                'entity_id' => $user_id,
                'ip_address' => $_SERVER['REMOTE_ADDR'],
                'timestamp' => current_time('mysql'),
                'status' => 'success'
            ),
            array('%d', '%s', '%s', '%s', '%d', '%s', '%s', '%s')
        );
    }
}

// Initialize on plugins_loaded
add_action('plugins_loaded', array('PSP_User_Management', 'init'));
