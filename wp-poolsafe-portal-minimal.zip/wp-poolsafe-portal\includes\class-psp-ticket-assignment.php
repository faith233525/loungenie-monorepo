<?php
/**
 * Ticket Assignment System
 * Assign tickets to support staff and track assignment history
 */

if (!defined('ABSPATH')) {
    exit;
}

class PSP_Ticket_Assignment {
    
    public function __construct() {
        add_action('rest_api_init', [$this, 'register_endpoints']);
    }
    
    /**
     * Register assignment endpoints
     */
    public function register_endpoints() {
        register_rest_route('psp/v1', '/tickets/(?P<ticket_id>\d+)/assign', [
            'methods' => 'POST',
            'callback' => [$this, 'assign_ticket'],
            'permission_callback' => [$this, 'check_admin'],
        ]);
        
        register_rest_route('psp/v1', '/tickets/(?P<ticket_id>\d+)/unassign', [
            'methods' => 'POST',
            'callback' => [$this, 'unassign_ticket'],
            'permission_callback' => [$this, 'check_admin'],
        ]);
        
        register_rest_route('psp/v1', '/tickets/assigned-to-me', [
            'methods' => 'GET',
            'callback' => [$this, 'get_assigned_tickets'],
            'permission_callback' => [$this, 'check_auth'],
        ]);
        
        register_rest_route('psp/v1', '/staff/workload', [
            'methods' => 'GET',
            'callback' => [$this, 'get_staff_workload'],
            'permission_callback' => [$this, 'check_admin'],
        ]);
    }
    
    /**
     * Check if admin/staff
     */
    public function check_admin() {
        $user = $_SESSION['psp_user'] ?? null;
        return $user && in_array($user['role'], ['admin', 'staff']);
    }
    
    /**
     * Check if authenticated
     */
    public function check_auth() {
        return !empty($_SESSION['psp_user']);
    }
    
    /**
     * Assign ticket to user
     */
    public function assign_ticket($request) {
        global $wpdb;
        
        $user = $_SESSION['psp_user'] ?? null;
        if (!$user || $user['role'] !== 'admin') {
            return new WP_Error('forbidden', 'Admin only', ['status' => 403]);
        }
        
        $ticket_id = intval($request['ticket_id']);
        $data = $request->get_json_params();
        
        if (empty($data['assigned_to'])) {
            return new WP_Error('invalid', 'assigned_to required', ['status' => 400]);
        }
        
        $ticket = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}psp_tickets WHERE id = %d",
            $ticket_id
        ));
        
        if (!$ticket) {
            return new WP_Error('not_found', 'Ticket not found', ['status' => 404]);
        }
        
        $assigned_user = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}psp_company_users WHERE id = %d",
            intval($data['assigned_to'])
        ));
        
        if (!$assigned_user || !in_array($assigned_user->role, ['admin', 'staff'])) {
            return new WP_Error('invalid', 'Invalid user', ['status' => 400]);
        }
        
        // Store previous assignment
        if ($ticket->assigned_to) {
            $wpdb->insert(
                "{$wpdb->prefix}psp_ticket_assignment_history",
                [
                    'ticket_id' => $ticket_id,
                    'assigned_by' => $user['id'],
                    'assigned_to' => $ticket->assigned_to,
                    'assigned_at' => $ticket->assigned_at,
                    'unassigned_at' => current_time('mysql'),
                ]
            );
        }
        
        // Update ticket
        $wpdb->update(
            "{$wpdb->prefix}psp_tickets",
            [
                'assigned_to' => intval($data['assigned_to']),
                'assigned_at' => current_time('mysql'),
                'updated_at' => current_time('mysql'),
            ],
            ['id' => $ticket_id]
        );
        
        // Log activity
        $this->log_activity(
            'ticket_assigned',
            "Ticket assigned to {$assigned_user->name}",
            $user['id'],
            $ticket->partner_id
        );
        
        // Send notification
        do_action('psp_ticket_assigned', $ticket_id, intval($data['assigned_to']), $user);
        
        return rest_ensure_response([
            'success' => true,
            'message' => 'Ticket assigned successfully',
        ]);
    }
    
    /**
     * Unassign ticket
     */
    public function unassign_ticket($request) {
        global $wpdb;
        
        $user = $_SESSION['psp_user'] ?? null;
        if (!$user || $user['role'] !== 'admin') {
            return new WP_Error('forbidden', 'Admin only', ['status' => 403]);
        }
        
        $ticket_id = intval($request['ticket_id']);
        
        $ticket = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}psp_tickets WHERE id = %d",
            $ticket_id
        ));
        
        if (!$ticket) {
            return new WP_Error('not_found', 'Ticket not found', ['status' => 404]);
        }
        
        if (!$ticket->assigned_to) {
            return new WP_Error('invalid', 'Ticket not assigned', ['status' => 400]);
        }
        
        // Store assignment history
        $wpdb->insert(
            "{$wpdb->prefix}psp_ticket_assignment_history",
            [
                'ticket_id' => $ticket_id,
                'assigned_by' => $user['id'],
                'assigned_to' => $ticket->assigned_to,
                'assigned_at' => $ticket->assigned_at,
                'unassigned_at' => current_time('mysql'),
            ]
        );
        
        // Clear assignment
        $wpdb->update(
            "{$wpdb->prefix}psp_tickets",
            [
                'assigned_to' => NULL,
                'assigned_at' => NULL,
                'updated_at' => current_time('mysql'),
            ],
            ['id' => $ticket_id]
        );
        
        // Log activity
        $this->log_activity(
            'ticket_unassigned',
            'Ticket unassigned',
            $user['id'],
            $ticket->partner_id
        );
        
        return rest_ensure_response([
            'success' => true,
            'message' => 'Ticket unassigned successfully',
        ]);
    }
    
    /**
     * Get tickets assigned to current user
     */
    public function get_assigned_tickets($request) {
        global $wpdb;
        
        $user = $_SESSION['psp_user'] ?? null;
        if (!$user) {
            return new WP_Error('unauthorized', 'Not authenticated', ['status' => 401]);
        }
        
        $status = sanitize_text_field($request->get_param('status')) ?? '';
        $priority = sanitize_text_field($request->get_param('priority')) ?? '';
        $page = intval($request->get_param('page')) ?: 1;
        $per_page = intval($request->get_param('per_page')) ?: 20;
        $offset = ($page - 1) * $per_page;
        
        $where = "t.assigned_to = %d";
        $params = [$user['id']];
        
        if (!empty($status)) {
            $where .= " AND t.status = %s";
            $params[] = $status;
        }
        
        if (!empty($priority)) {
            $where .= " AND t.priority = %s";
            $params[] = $priority;
        }
        
        $total = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}psp_tickets t WHERE {$where}",
                ...$params
            )
        );
        
        $tickets = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT t.*, p.name as company_name FROM {$wpdb->prefix}psp_tickets t
                 LEFT JOIN {$wpdb->prefix}psp_partners p ON t.partner_id = p.id
                 WHERE {$where}
                 ORDER BY t.priority DESC, t.created_at ASC
                 LIMIT %d OFFSET %d",
                ...array_merge($params, [$per_page, $offset])
            )
        );
        
        return rest_ensure_response([
            'success' => true,
            'data' => $tickets,
            'pagination' => [
                'page' => $page,
                'per_page' => $per_page,
                'total' => intval($total),
                'pages' => ceil($total / $per_page),
            ],
        ]);
    }
    
    /**
     * Get staff workload
     */
    public function get_staff_workload($request) {
        global $wpdb;
        
        $user = $_SESSION['psp_user'] ?? null;
        if (!$user || $user['role'] !== 'admin') {
            return new WP_Error('forbidden', 'Admin only', ['status' => 403]);
        }
        
        // Get all staff
        $staff = $wpdb->get_results(
            "SELECT id, name, email FROM {$wpdb->prefix}psp_company_users 
             WHERE role IN ('admin', 'staff') AND status = 'active'
             ORDER BY name ASC"
        );
        
        $workload = [];
        
        foreach ($staff as $member) {
            $open_tickets = intval($wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}psp_tickets 
                 WHERE assigned_to = %d AND status != 'closed'",
                $member->id
            )));
            
            $avg_response_time = $wpdb->get_var($wpdb->prepare(
                "SELECT AVG(TIMESTAMPDIFF(HOUR, created_at, updated_at))
                 FROM {$wpdb->prefix}psp_tickets 
                 WHERE assigned_to = %d AND status = 'closed'",
                $member->id
            ));
            
            $workload[] = [
                'id' => $member->id,
                'name' => $member->name,
                'email' => $member->email,
                'open_tickets' => $open_tickets,
                'avg_response_hours' => round($avg_response_time, 1) ?? 0,
            ];
        }
        
        return rest_ensure_response([
            'success' => true,
            'data' => $workload,
        ]);
    }
    
    /**
     * Log activity
     */
    private function log_activity($action, $description, $user_id, $entity_id) {
        global $wpdb;
        
        $wpdb->insert(
            "{$wpdb->prefix}psp_audit_log",
            [
                'action' => $action,
                'description' => $description,
                'user_id' => $user_id,
                'entity_id' => $entity_id,
                'created_at' => current_time('mysql'),
            ]
        );
    }
}

// Initialize
new PSP_Ticket_Assignment();
