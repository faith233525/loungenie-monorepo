// assets/js/psp-push-sw.js
// Service Worker for Pool Safe Portal push notifications

self.addEventListener('push', function (event) {
  let data = {};
  if (event.data) {
    data = event.data.json();
  }
  const title = data.title || 'Pool Safe Portal';
  const options = {
    body: data.body || 'You have a new notification.',
    icon: '/assets/img/psp-icon.png',
    data: data.url || '/portal#tickets',
  };
  event.waitUntil(self.registration.showNotification(title, options));
});

self.addEventListener('notificationclick', function (event) {
  event.notification.close();
  event.waitUntil(
    clients.matchAll({ type: 'window' }).then(function (clientList) {
      for (var i = 0; i < clientList.length; i++) {
        var client = clientList[i];
        if (client.url === event.notification.data && 'focus' in client) {
          return client.focus();
        }
      }
      if (clients.openWindow) {
        return clients.openWindow(event.notification.data);
      }
    }),
  );
});
