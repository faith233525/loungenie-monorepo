<?php
/**
 * Support Dashboard for Portal Access
 * Provides complete support staff interface WITHOUT WordPress admin
 * All operations performed through portal UI only
 * 
 * @package PoolSafe_Portal
 */

if (!defined('ABSPATH')) {
    exit;
}

class PSP_Support_Dashboard {
    
    public static function init() {
        add_action('plugins_loaded', array(__CLASS__, 'register_hooks'));
    }
    
    public static function register_hooks() {
        // Register AJAX handlers for support operations
        add_action('wp_ajax_psp_get_partner_list', array(__CLASS__, 'ajax_get_partner_list'));
        add_action('wp_ajax_psp_get_partner_details', array(__CLASS__, 'ajax_get_partner_details'));
        add_action('wp_ajax_psp_update_partner', array(__CLASS__, 'ajax_update_partner'));
        add_action('wp_ajax_psp_get_tickets', array(__CLASS__, 'ajax_get_tickets'));
        add_action('wp_ajax_psp_update_ticket', array(__CLASS__, 'ajax_update_ticket'));
        add_action('wp_ajax_psp_assign_ticket', array(__CLASS__, 'ajax_assign_ticket'));
        add_action('wp_ajax_psp_get_users', array(__CLASS__, 'ajax_get_users'));
        add_action('wp_ajax_psp_create_user', array(__CLASS__, 'ajax_create_user'));
        add_action('wp_ajax_psp_update_user', array(__CLASS__, 'ajax_update_user'));
        add_action('wp_ajax_psp_get_audit_log', array(__CLASS__, 'ajax_get_audit_log'));
    }
    
    /**
     * Check if current user is support staff
     */
    public static function check_support_access() {
        $user = wp_get_current_user();
        if (!$user->ID) {
            wp_send_json_error('Not authenticated');
        }
        
        $is_support = in_array('psp_support', $user->roles) || 
                     in_array('administrator', $user->roles);
        
        if (!$is_support && !current_user_can('psp_support')) {
            wp_send_json_error('Insufficient permissions');
        }
        
        return $user;
    }
    
    /**
     * AJAX: Get list of all partners
     */
    public static function ajax_get_partner_list() {
        check_ajax_referer('psp_ajax_nonce');
        self::check_support_access();
        
        global $wpdb;
        
        $page = isset($_GET['page']) ? absint($_GET['page']) : 1;
        $per_page = 25;
        $offset = ($page - 1) * $per_page;
        
        $partners = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}psp_partners 
             ORDER BY company_name ASC 
             LIMIT %d OFFSET %d",
            $per_page, $offset
        ));
        
        $total = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}psp_partners");
        
        wp_send_json_success(array(
            'partners' => $partners,
            'total' => $total,
            'pages' => ceil($total / $per_page)
        ));
    }
    
    /**
     * AJAX: Get partner details
     */
    public static function ajax_get_partner_details() {
        check_ajax_referer('psp_ajax_nonce');
        self::check_support_access();
        
        global $wpdb;
        
        $partner_id = absint($_GET['partner_id']);
        
        // Get partner info
        $partner = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}psp_partners WHERE id = %d",
            $partner_id
        ));
        
        if (!$partner) {
            wp_send_json_error('Partner not found');
        }
        
        // Get partner users
        $users = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}psp_company_users WHERE company_id = %d",
            $partner_id
        ));
        
        // Get recent tickets
        $tickets = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}psp_tickets 
             WHERE company_id = %d 
             ORDER BY created_at DESC 
             LIMIT 10",
            $partner_id
        ));
        
        wp_send_json_success(array(
            'partner' => $partner,
            'users' => $users,
            'tickets' => $tickets
        ));
    }
    
    /**
     * AJAX: Update partner information
     */
    public static function ajax_update_partner() {
        check_ajax_referer('psp_ajax_nonce');
        self::check_support_access();
        
        global $wpdb;
        
        $partner_id = absint($_POST['partner_id']);
        $data = array(
            'company_name' => sanitize_text_field($_POST['company_name'] ?? ''),
            'phone' => sanitize_text_field($_POST['phone'] ?? ''),
            'street_address' => sanitize_text_field($_POST['street_address'] ?? ''),
            'city' => sanitize_text_field($_POST['city'] ?? ''),
            'state' => sanitize_text_field($_POST['state'] ?? ''),
            'zip' => sanitize_text_field($_POST['zip'] ?? ''),
            'country' => sanitize_text_field($_POST['country'] ?? ''),
            'units' => absint($_POST['units'] ?? 0),
            'pool_colour' => sanitize_text_field($_POST['pool_colour'] ?? ''),
        );
        
        $updated = $wpdb->update(
            $wpdb->prefix . 'psp_partners',
            $data,
            array('id' => $partner_id),
            array('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s'),
            array('%d')
        );
        
        if ($updated !== false) {
            self::log_audit_activity('partner_updated', 'Updated partner information', $partner_id);
            wp_send_json_success('Partner updated');
        } else {
            wp_send_json_error($wpdb->last_error);
        }
    }
    
    /**
     * AJAX: Get all tickets (with filters)
     */
    public static function ajax_get_tickets() {
        check_ajax_referer('psp_ajax_nonce');
        self::check_support_access();
        
        global $wpdb;
        
        $page = isset($_GET['page']) ? absint($_GET['page']) : 1;
        $per_page = 25;
        $offset = ($page - 1) * $per_page;
        
        $where = "1=1";
        $args = array();
        
        // Filter by partner
        if (!empty($_GET['partner_id'])) {
            $where .= " AND company_id = %d";
            $args[] = absint($_GET['partner_id']);
        }
        
        // Filter by status
        if (!empty($_GET['status'])) {
            $where .= " AND status = %s";
            $args[] = sanitize_text_field($_GET['status']);
        }
        
        // Filter by priority
        if (!empty($_GET['priority'])) {
            $where .= " AND priority = %s";
            $args[] = sanitize_text_field($_GET['priority']);
        }
        
        // Search by title/description
        if (!empty($_GET['search'])) {
            $where .= " AND (title LIKE %s OR description LIKE %s)";
            $search = '%' . $wpdb->esc_like($_GET['search']) . '%';
            $args[] = $search;
            $args[] = $search;
        }
        
        // Build query
        $query = "SELECT * FROM {$wpdb->prefix}psp_tickets 
                  WHERE $where 
                  ORDER BY created_at DESC 
                  LIMIT %d OFFSET %d";
        
        $args[] = $per_page;
        $args[] = $offset;
        
        $tickets = $wpdb->get_results($wpdb->prepare($query, ...$args));
        
        // Get total count
        $count_query = "SELECT COUNT(*) FROM {$wpdb->prefix}psp_tickets WHERE $where";
        $total = $wpdb->get_var($wpdb->prepare($count_query, ...array_slice($args, 0, -2)));
        
        wp_send_json_success(array(
            'tickets' => $tickets,
            'total' => $total,
            'pages' => ceil($total / $per_page)
        ));
    }
    
    /**
     * AJAX: Update ticket status/priority
     */
    public static function ajax_update_ticket() {
        check_ajax_referer('psp_ajax_nonce');
        self::check_support_access();
        
        global $wpdb;
        
        $ticket_id = absint($_POST['ticket_id']);
        
        $update_data = array();
        $update_format = array();
        
        if (!empty($_POST['status'])) {
            $update_data['status'] = sanitize_text_field($_POST['status']);
            $update_format[] = '%s';
        }
        
        if (!empty($_POST['priority'])) {
            $update_data['priority'] = sanitize_text_field($_POST['priority']);
            $update_format[] = '%s';
        }
        
        if (!empty($_POST['assigned_to'])) {
            $update_data['assigned_to'] = absint($_POST['assigned_to']);
            $update_format[] = '%d';
        }
        
        $updated = $wpdb->update(
            $wpdb->prefix . 'psp_tickets',
            $update_data,
            array('id' => $ticket_id),
            $update_format,
            array('%d')
        );
        
        if ($updated !== false) {
            self::log_audit_activity('ticket_updated', "Updated ticket #$ticket_id", $ticket_id);
            wp_send_json_success('Ticket updated');
        } else {
            wp_send_json_error($wpdb->last_error);
        }
    }
    
    /**
     * AJAX: Assign ticket to support team member
     */
    public static function ajax_assign_ticket() {
        check_ajax_referer('psp_ajax_nonce');
        self::check_support_access();
        
        global $wpdb;
        
        $ticket_id = absint($_POST['ticket_id']);
        $assigned_to = absint($_POST['assigned_to']);
        
        $updated = $wpdb->update(
            $wpdb->prefix . 'psp_tickets',
            array('assigned_to' => $assigned_to),
            array('id' => $ticket_id),
            array('%d'),
            array('%d')
        );
        
        if ($updated !== false) {
            // Log assignment
            self::log_audit_activity('ticket_assigned', "Assigned ticket #$ticket_id", $ticket_id);
            
            // Get assignee name for notification
            $assignee = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}psp_company_users WHERE id = %d",
                $assigned_to
            ));
            
            wp_send_json_success(array(
                'message' => 'Ticket assigned',
                'assignee' => $assignee
            ));
        } else {
            wp_send_json_error($wpdb->last_error);
        }
    }
    
    /**
     * AJAX: Get partner users
     */
    public static function ajax_get_users() {
        check_ajax_referer('psp_ajax_nonce');
        self::check_support_access();
        
        global $wpdb;
        
        $partner_id = absint($_GET['partner_id']);
        
        $users = $wpdb->get_results($wpdb->prepare(
            "SELECT id, username, email, first_name, last_name, role, status, created_at 
             FROM {$wpdb->prefix}psp_company_users 
             WHERE company_id = %d 
             ORDER BY first_name ASC",
            $partner_id
        ));
        
        wp_send_json_success($users);
    }
    
    /**
     * AJAX: Create new user for partner
     */
    public static function ajax_create_user() {
        check_ajax_referer('psp_ajax_nonce');
        self::check_support_access();
        
        global $wpdb;
        
        $company_id = absint($_POST['company_id']);
        $username = sanitize_text_field($_POST['username']);
        $email = sanitize_email($_POST['email']);
        $password = sanitize_text_field($_POST['password']);
        
        // Check username unique
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}psp_company_users WHERE username = %s",
            $username
        ));
        
        if ($existing) {
            wp_send_json_error('Username already exists');
        }
        
        $password_hash = password_hash($password, PASSWORD_BCRYPT);
        
        $inserted = $wpdb->insert(
            $wpdb->prefix . 'psp_company_users',
            array(
                'company_id' => $company_id,
                'username' => $username,
                'password' => $password_hash,
                'email' => $email,
                'first_name' => sanitize_text_field($_POST['first_name'] ?? ''),
                'last_name' => sanitize_text_field($_POST['last_name'] ?? ''),
                'role' => 'user',
                'status' => 'active',
                'created_at' => current_time('mysql')
            ),
            array('%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')
        );
        
        if ($inserted) {
            self::log_audit_activity('user_created', "Created user: $username", $company_id);
            wp_send_json_success(array(
                'id' => $wpdb->insert_id,
                'username' => $username,
                'email' => $email
            ));
        } else {
            wp_send_json_error($wpdb->last_error);
        }
    }
    
    /**
     * AJAX: Update user account
     */
    public static function ajax_update_user() {
        check_ajax_referer('psp_ajax_nonce');
        self::check_support_access();
        
        global $wpdb;
        
        $user_id = absint($_POST['user_id']);
        
        $update_data = array(
            'email' => sanitize_email($_POST['email'] ?? ''),
            'first_name' => sanitize_text_field($_POST['first_name'] ?? ''),
            'last_name' => sanitize_text_field($_POST['last_name'] ?? ''),
        );
        
        if (!empty($_POST['password'])) {
            $update_data['password'] = password_hash($_POST['password'], PASSWORD_BCRYPT);
        }
        
        if (!empty($_POST['status'])) {
            $update_data['status'] = sanitize_text_field($_POST['status']);
        }
        
        $updated = $wpdb->update(
            $wpdb->prefix . 'psp_company_users',
            $update_data,
            array('id' => $user_id),
            array_fill(0, count($update_data), '%s'),
            array('%d')
        );
        
        if ($updated !== false) {
            self::log_audit_activity('user_updated', "Updated user #$user_id", $user_id);
            wp_send_json_success('User updated');
        } else {
            wp_send_json_error($wpdb->last_error);
        }
    }
    
    /**
     * AJAX: Get audit log entries
     */
    public static function ajax_get_audit_log() {
        check_ajax_referer('psp_ajax_nonce');
        self::check_support_access();
        
        global $wpdb;
        
        $page = isset($_GET['page']) ? absint($_GET['page']) : 1;
        $per_page = 50;
        $offset = ($page - 1) * $per_page;
        
        $entries = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}psp_audit_log 
             ORDER BY created_at DESC 
             LIMIT %d OFFSET %d",
            $per_page, $offset
        ));
        
        $total = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}psp_audit_log");
        
        wp_send_json_success(array(
            'entries' => $entries,
            'total' => $total,
            'pages' => ceil($total / $per_page)
        ));
    }
    
    /**
     * Log activity to audit table
     */
    public static function log_audit_activity($action, $description, $object_id = null) {
        global $wpdb;
        
        $user = wp_get_current_user();
        
        $wpdb->insert(
            $wpdb->prefix . 'psp_audit_log',
            array(
                'user_id' => $user->ID,
                'action' => $action,
                'description' => $description,
                'object_id' => $object_id,
                'ip_address' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
                'created_at' => current_time('mysql')
            ),
            array('%d', '%s', '%s', '%d', '%s', '%s')
        );
    }
}

// Initialize on plugins_loaded
add_action('plugins_loaded', array('PSP_Support_Dashboard', 'init'));
