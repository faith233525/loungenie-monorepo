<?php
/**
 * Email Template - Ticket Reply Notification
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 600px;
            margin: 0 auto;
            background-color: #f9f9f9;
        }
        .email-container {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 8px 8px 0 0;
            text-align: center;
        }
        .header h1 {
            margin: 0;
            font-size: 24px;
        }
        .content {
            padding: 20px;
        }
        .reply-box {
            background-color: #f9f9f9;
            border-left: 4px solid #667eea;
            padding: 15px;
            margin: 20px 0;
            border-radius: 4px;
        }
        .reply-author {
            font-weight: bold;
            color: #667eea;
            margin-bottom: 10px;
        }
        .reply-text {
            color: #333;
            margin: 0;
        }
        .button {
            display: inline-block;
            background-color: #667eea;
            color: white;
            padding: 12px 24px;
            text-decoration: none;
            border-radius: 4px;
            margin: 20px 0;
            font-weight: bold;
        }
        .button:hover {
            background-color: #5568d3;
        }
        .footer {
            text-align: center;
            color: #666;
            font-size: 12px;
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #eee;
        }
    </style>
</head>
<body>
    <div class="email-container">
        <div class="header">
            <h1>💬 New Reply to Your Ticket</h1>
        </div>

        <div class="content">
            <p>Hello <?php echo isset($recipient_name) ? esc_html($recipient_name) : 'there'; ?>,</p>

            <p>There's a new reply to your ticket <strong>#<?php echo isset($ticket_number) ? esc_html($ticket_number) : '—'; ?></strong>:</p>

            <p><strong><?php echo isset($ticket_title) ? esc_html($ticket_title) : '—'; ?></strong></p>

            <div class="reply-box">
                <div class="reply-author">
                    <?php echo isset($reply_author) ? esc_html($reply_author) : 'Support'; ?>
                    <span style="color: #999; font-weight: normal; font-size: 12px;">
                        <?php echo isset($reply_date) ? date_i18n('M d, Y @ g:i A', strtotime($reply_date)) : ''; ?>
                    </span>
                </div>
                <p class="reply-text"><?php echo isset($reply_text) ? wp_kses_post($reply_text) : '—'; ?></p>
            </div>

            <center>
                <a href="<?php echo isset($ticket_url) ? esc_url($ticket_url) : '#'; ?>" class="button">
                    Reply to Ticket →
                </a>
            </center>

            <p>Please review the reply and respond if necessary.</p>
        </div>

        <div class="footer">
            <p>PoolSafe Portal | Support Team</p>
            <p>This is an automated email. Please do not reply directly to this message.</p>
        </div>
    </div>
</body>
</html>
