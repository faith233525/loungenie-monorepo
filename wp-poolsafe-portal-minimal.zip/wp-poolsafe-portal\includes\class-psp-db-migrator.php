<?php
/**
 * Database Migration System
 *
 * Handles incremental database schema updates for the PoolSafe Portal plugin.
 * Runs automatically on plugin load and applies migrations based on version comparison.
 *
 * @package PoolSafe_Portal
 * @version 3.2.5
 * @since 3.2.5
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * PSP_DB_Migrator Class
 *
 * Manages database schema versioning and migrations.
 */
class PSP_DB_Migrator {

	/**
	 * Database version option key
	 */
	const DB_VERSION_OPTION = 'psp_db_version';

	/**
	 * Current database schema version
	 * Increment this when adding new migrations
	 */
	const CURRENT_DB_VERSION = '3.2.5';

	/**
	 * Initialize the migrator
	 * Hooks into WordPress plugins_loaded to check for migrations
	 */
	public static function init() {
		add_action( 'plugins_loaded', array( __CLASS__, 'maybe_migrate' ), 5 );
	}

	/**
	 * Check if migration is needed and run if necessary
	 */
	public static function maybe_migrate() {
		$installed_version = get_option( self::DB_VERSION_OPTION, '0.0.0' );

		// Skip if already at current version
		if ( version_compare( $installed_version, self::CURRENT_DB_VERSION, '>=' ) ) {
			return;
		}

		// Run migrations
		$result = self::run_migrations( $installed_version );

		if ( $result ) {
			// Update database version on success
			update_option( self::DB_VERSION_OPTION, self::CURRENT_DB_VERSION );
			
			// Clear all caches after migration
			wp_cache_flush();
			
			// Log successful migration
			PSP_Logger::info( sprintf(
				'Database migrated from %s to %s',
				$installed_version,
				self::CURRENT_DB_VERSION
			) );
		} else {
			// Log migration failure
			PSP_Logger::error( sprintf(
				'Database migration FAILED from %s to %s',
				$installed_version,
				self::CURRENT_DB_VERSION
			) );
		}
	}

	/**
	 * Run all necessary migrations based on current version
	 *
	 * @param string $from_version Current installed version
	 * @return bool True on success, false on failure
	 */
	private static function run_migrations( $from_version ) {
		global $wpdb;

		try {
			// Migration: 3.0.0 - Add priority column to tickets
			if ( version_compare( $from_version, '3.0.0', '<' ) ) {
				self::migrate_3_0_0();
			}

			// Migration: 3.1.0 - Add indexes for performance
			if ( version_compare( $from_version, '3.1.0', '<' ) ) {
				self::migrate_3_1_0();
			}

			// Migration: 3.2.0 - Add visibility columns to videos
			if ( version_compare( $from_version, '3.2.0', '<' ) ) {
				self::migrate_3_2_0();
			}

			// Migration: 3.2.5 - Add notification preferences
			if ( version_compare( $from_version, '3.2.5', '<' ) ) {
				self::migrate_3_2_5();
			}

			return true;

		} catch ( Exception $e ) {
			PSP_Logger::exception( $e, 'Database migration error' );
			return false;
		}
	}

	/**
	 * Migration 3.0.0: Add priority column to tickets table
	 */
	private static function migrate_3_0_0() {
		global $wpdb;
		$table = $wpdb->prefix . 'psp_tickets';

		// Check if column already exists
		$column_exists = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS 
				WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s AND COLUMN_NAME = 'priority'",
				DB_NAME,
				$table
			)
		);

		if ( empty( $column_exists ) ) {
			$wpdb->query(
				"ALTER TABLE {$table} 
				ADD COLUMN priority VARCHAR(20) DEFAULT 'medium' AFTER status"
			);
			
			// Add index
			$wpdb->query( "CREATE INDEX idx_priority ON {$table}(priority)" );
		}
	}

	/**
	 * Migration 3.1.0: Add performance indexes
	 */
	private static function migrate_3_1_0() {
		global $wpdb;

		$indexes = array(
			$wpdb->prefix . 'psp_tickets'         => array(
				'idx_status_created' => 'status, created_at',
				'idx_partner_status' => 'partner_id, status',
			),
			$wpdb->prefix . 'psp_service_records' => array(
				'idx_partner_date' => 'partner_id, service_date',
			),
			$wpdb->prefix . 'psp_company_users'   => array(
				'idx_company_status' => 'company_id, status',
			),
		);

		foreach ( $indexes as $table => $table_indexes ) {
			foreach ( $table_indexes as $index_name => $columns ) {
				// Check if index exists
				$index_exists = $wpdb->get_results(
					$wpdb->prepare(
						"SHOW INDEX FROM {$table} WHERE Key_name = %s",
						$index_name
					)
				);

				if ( empty( $index_exists ) ) {
					$wpdb->query(
						"CREATE INDEX {$index_name} ON {$table}({$columns})"
					);
				}
			}
		}
	}

	/**
	 * Migration 3.2.0: Add visibility columns to videos table
	 */
	private static function migrate_3_2_0() {
		global $wpdb;
		$table = $wpdb->prefix . 'psp_videos';

		$columns_to_add = array(
			'visibility_type'  => "VARCHAR(50) DEFAULT 'all'",
			'visibility_value' => "VARCHAR(255) DEFAULT ''",
		);

		foreach ( $columns_to_add as $column => $definition ) {
			$column_exists = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS 
					WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s AND COLUMN_NAME = %s",
					DB_NAME,
					$table,
					$column
				)
			);

			if ( empty( $column_exists ) ) {
				$wpdb->query(
					"ALTER TABLE {$table} ADD COLUMN {$column} {$definition}"
				);
			}
		}
	}

	/**
	 * Migration 3.2.5: Add notification preferences columns
	 */
	private static function migrate_3_2_5() {
		global $wpdb;
		$prefs_table = $wpdb->prefix . 'psp_user_notification_preferences';

		// Check if table exists, if not create it
		$table_exists = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES 
				WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s",
				DB_NAME,
				$prefs_table
			)
		);

		if ( ! $table_exists ) {
			$charset_collate = $wpdb->get_charset_collate();
			
			$sql = "CREATE TABLE {$prefs_table} (
				id INT AUTO_INCREMENT PRIMARY KEY,
				user_id INT NOT NULL,
				notification_type VARCHAR(50) NOT NULL,
				enabled TINYINT(1) DEFAULT 1,
				created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
				
				UNIQUE KEY unique_user_type (user_id, notification_type),
				INDEX idx_user_id (user_id)
			) {$charset_collate}";

			require_once ABSPATH . 'wp-admin/includes/upgrade.php';
			dbDelta( $sql );
		}
	}

	/**
	 * Get current database version
	 *
	 * @return string Database version
	 */
	public static function get_db_version() {
		return get_option( self::DB_VERSION_OPTION, '0.0.0' );
	}

	/**
	 * Force migration (for manual trigger via admin)
	 * Use with caution - only for debugging
	 *
	 * @return bool Success status
	 */
	public static function force_migrate() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return false;
		}

		$installed_version = get_option( self::DB_VERSION_OPTION, '0.0.0' );
		return self::run_migrations( $installed_version );
	}

	/**
	 * Rollback to previous version (emergency use only)
	 * 
	 * @param string $target_version Version to rollback to
	 * @return bool Success status
	 */
	public static function rollback( $target_version ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return false;
		}

		// Only allow rollback to valid versions
		$valid_versions = array( '3.0.0', '3.1.0', '3.2.0', '3.2.5' );
		
		if ( ! in_array( $target_version, $valid_versions, true ) ) {
			return false;
		}

		// Update version (note: this doesn't undo schema changes)
		update_option( self::DB_VERSION_OPTION, $target_version );
		
		PSP_Logger::warning( "Database version rolled back to {$target_version}" );
		
		return true;
	}
}

// Initialize the migrator
PSP_DB_Migrator::init();
