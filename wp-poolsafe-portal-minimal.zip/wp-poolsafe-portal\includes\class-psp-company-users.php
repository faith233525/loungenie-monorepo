<?php
namespace PSP;
// ...existing code...

class Company_Users {

	/**
	 * Initialize company user management.
	 */
	public static function init(): void {
		// Only register partner_id meta now
		self::register_user_meta( 'partner_id', 'integer' ); // Linked partner/company
	}

	/**
	 * Register user meta field.
	 */
	private static function register_user_meta( string $key, string $type ): void {
		register_meta(
			'user',
			"psp_{$key}",
			array(
				'type'          => $type,
				'single'        => true,
				'show_in_rest'  => false,
				'auth_callback' => function () {
					return is_user_logged_in();
				},
			)
		);
	}

	/**
	 * Get linked user IDs for a partner.
	 */
	public static function get_linked_user_ids( int $partner_id ): array {
		$raw = get_post_meta( $partner_id, 'psp_user_ids', true );
		if ( ! $raw ) {
			return array();
		}
		$ids = json_decode( $raw, true );
		return is_array( $ids ) ? array_filter( array_map( 'intval', $ids ) ) : array();
	}

	/**
	 * Save linked user IDs for a partner.
	 */
	public static function save_linked_user_ids( int $partner_id, array $ids ): void {
		$ids = array_values( array_unique( array_filter( array_map( 'intval', $ids ) ) ) );
		update_post_meta( $partner_id, 'psp_user_ids', wp_json_encode( $ids ) );
	}

	/**
	 * Link a user to a partner.
	 */
	public static function link_user( int $partner_id, int $user_id ): bool {
		if ( ! get_post( $partner_id ) || get_post_type( $partner_id ) !== 'psp_partner' ) {
			return false;
		}
		$ids = self::get_linked_user_ids( $partner_id );
		if ( ! in_array( $user_id, $ids, true ) ) {
			$ids[] = $user_id;
			self::save_linked_user_ids( $partner_id, $ids );
		}
		update_user_meta( $user_id, 'psp_partner_id', $partner_id );
		// Assign primary if none
		$primary = intval( get_post_meta( $partner_id, 'psp_primary_user_id', true ) );
		if ( $primary === 0 ) {
			update_post_meta( $partner_id, 'psp_primary_user_id', $user_id );
		}
		return true;
	}

	/**
	 * Unlink a user from a partner.
	 */
	public static function unlink_user( int $partner_id, int $user_id ): bool {
		$ids = self::get_linked_user_ids( $partner_id );
		$new = array_diff( $ids, array( $user_id ) );
		self::save_linked_user_ids( $partner_id, $new );
		$primary = intval( get_post_meta( $partner_id, 'psp_primary_user_id', true ) );
		if ( $primary === $user_id ) {
			// Reassign primary to first remaining or clear
			$next = reset( $new );
			if ( $next ) {
				update_post_meta( $partner_id, 'psp_primary_user_id', $next );
			} else {
				delete_post_meta( $partner_id, 'psp_primary_user_id' );
			}
		}
		// Clear user meta link if it matches this partner
		$linked = intval( get_user_meta( $user_id, 'psp_partner_id', true ) );
		if ( $linked === $partner_id ) {
			delete_user_meta( $user_id, 'psp_partner_id' );
		}
		return true;
	}

	/**
	 * Set primary user for a partner.
	 */
	public static function set_primary( int $partner_id, int $user_id ): bool {
		$ids = self::get_linked_user_ids( $partner_id );
		if ( ! in_array( $user_id, $ids, true ) ) {
			return false;
		}
		update_post_meta( $partner_id, 'psp_primary_user_id', $user_id );
		return true;
	}

	/**
	 * Get primary user for a partner.
	 */
	public static function get_primary( int $partner_id ): int {
		return intval( get_post_meta( $partner_id, 'psp_primary_user_id', true ) );
	}

	/**
	 * Get user objects for a partner.
	 */
	public static function get_partner_users( int $partner_id ): array {
		$ids   = self::get_linked_user_ids( $partner_id );
		$users = array();
		foreach ( $ids as $uid ) {
			$u = get_user_by( 'ID', $uid );
			if ( $u ) {
				$users[] = $u;
			}
		}
		return $users;
	}

	/**
	 * Get notification preferences for a user.
	 */
	public static function get_user_notify_prefs( int $user_id ): array {
		// Always enabled, all categories/channels by default
		return array(
			'enabled'    => true,
			'categories' => array( 'tickets', 'service_records', 'alerts', 'announcements' ),
			'channels'   => array( 'portal', 'email' ),
		);
	}

	// Notification migration logic removed
}
