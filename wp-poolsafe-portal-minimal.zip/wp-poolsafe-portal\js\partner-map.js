/**
 * PoolSafe Portal - Partner Map Module
 * Handles partner location mapping and visualization
 */

(function () {
    'use strict';

    // Partner Map initialization
    window.PSP = window.PSP || {};

    /**
     * Initialize partner map
     */
    PSP.initPartnerMap = function (containerId, options) {
        const container = document.getElementById(containerId);
        if (!container) {
            console.error('Partner map container not found: ' + containerId);
            return;
        }

        options = options || {};
        options.zoom = options.zoom || 10;
        options.center = options.center || { lat: 40, lng: -95 };

        // Initialize Leaflet map
        const map = L.map(containerId, {
            center: [options.center.lat, options.center.lng],
            zoom: options.zoom,
            scrollWheelZoom: true,
            dragging: true
        });

        // Add OpenStreetMap tile layer
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors',
            maxZoom: 19,
            minZoom: 4
        }).addTo(map);

        // Add zoom controls
        L.control.zoom({ position: 'topright' }).addTo(map);

        // Initialize marker cluster group
        const markerCluster = L.markerClusterGroup({
            maxClusterRadius: 80,
            iconCreateFunction: function (cluster) {
                const count = cluster.getChildCount();
                let size = 'small';
                let color = '#3b82f6';

                if (count > 100) {
                    size = 'large';
                    color = '#dc2626';
                } else if (count > 50) {
                    size = 'medium';
                    color = '#f59e0b';
                }

                return L.divIcon({
                    html: '<div style="background:' + color + ';width:40px;height:40px;border-radius:50%;display:flex;align-items:center;justify-content:center;color:white;font-weight:bold;font-size:12px;border:2px solid white;box-shadow:0 2px 6px rgba(0,0,0,0.2);">' + count + '</div>',
                    iconSize: L.point(40, 40),
                    className: 'psp-map-cluster'
                });
            }
        });

        // Create legend
        const legend = L.control({ position: 'bottomleft' });
        legend.onAdd = function () {
            const div = L.DomUtil.create('div', 'psp-map-legend');
            div.innerHTML = `
                <div style="background:white;border:1px solid #e5e7eb;border-radius:6px;padding:10px;font-size:12px;max-width:200px;box-shadow:0 2px 4px rgba(0,0,0,0.1);">
                    <div style="margin-bottom:8px;font-weight:600;">Legend</div>
                    <div style="margin:6px 0;color:#374151;">
                        <span style="display:inline-block;width:12px;height:12px;background:#3b82f6;border-radius:50%;margin-right:6px;"></span>Active
                    </div>
                    <div style="margin:6px 0;color:#374151;">
                        <span style="display:inline-block;width:12px;height:12px;background:#f59e0b;border-radius:50%;margin-right:6px;"></span>Maintenance
                    </div>
                    <div style="margin:6px 0;color:#374151;">
                        <span style="display:inline-block;width:12px;height:12px;background:#6b7280;border-radius:50%;margin-right:6px;"></span>Inactive
                    </div>
                </div>
            `;
            return div;
        };
        legend.addTo(map);

        // Fetch and display locations
        PSP.fetchMapLocations(map, markerCluster);

        // Store map instance for external access
        PSP.mapInstance = map;
        PSP.markerCluster = markerCluster;

        return map;
    };

    /**
     * Fetch partner locations from API
     */
    PSP.fetchMapLocations = function (map, markerCluster) {
        const apiUrl = (PSP_PORTAL && PSP_PORTAL.rest && PSP_PORTAL.rest.base) ? PSP_PORTAL.rest.base : '/wp-json/psp/v1';

        fetch(apiUrl + '/map/locations', {
            headers: {
                'X-WP-Nonce': (PSP_PORTAL && PSP_PORTAL.rest) ? PSP_PORTAL.rest.nonce : ''
            }
        })
            .then(res => {
                if (!res.ok) throw new Error('Failed to fetch locations');
                return res.json();
            })
            .then(data => {
                if (!data.features || !Array.isArray(data.features)) {
                    console.warn('Invalid GeoJSON response');
                    return;
                }

                const bounds = [];

                // Add markers for each location
                data.features.forEach(feature => {
                    if (feature.geometry && feature.geometry.type === 'Point') {
                        const coords = feature.geometry.coordinates;
                        const props = feature.properties;

                        // Create marker with appropriate color
                        const markerColor = props.color || '#3b82f6';
                        const markerIcon = L.divIcon({
                            html: '<div style="background:' + markerColor + ';width:32px;height:40px;border-radius:50% 50% 50% 0;transform:rotate(-45deg);border:2px solid white;box-shadow:0 2px 6px rgba(0,0,0,0.15);display:flex;align-items:center;justify-content:center;color:white;font-size:16px;line-height:1;">' + (props.icon || '📍') + '</div>',
                            iconSize: L.point(32, 40),
                            iconAnchor: L.point(16, 40),
                            popupAnchor: L.point(0, -40),
                            className: 'psp-map-marker'
                        });

                        const marker = L.marker(
                            [coords[1], coords[0]],
                            { icon: markerIcon }
                        );

                        // Create popup content
                        const popupHtml = `
                            <div class="psp-map-marker-popup">
                                <h4>${props.name || 'Location'}</h4>
                                <p><strong>${props.partner_name || ''}</strong></p>
                                <p>${props.address || ''}</p>
                                <p style="font-size:11px;color:#999;margin-top:6px;">
                                    <strong>Status:</strong> ${props.status || 'unknown'}
                                </p>
                            </div>
                        `;

                        marker.bindPopup(popupHtml, { maxWidth: 250 });
                        markerCluster.addLayer(marker);

                        bounds.push([coords[1], coords[0]]);
                    }
                });

                // Add cluster group to map
                if (markerCluster.getLayers().length > 0) {
                    map.addLayer(markerCluster);

                    // Fit bounds if markers exist
                    if (bounds.length > 0) {
                        const group = new L.featureGroup(markerCluster.getLayers().map(m => m));
                        map.fitBounds(group.getBounds(), { padding: [50, 50] });
                    }
                } else {
                    // Show "no data" message
                    const noDataDiv = L.control({ position: 'center' });
                    noDataDiv.onAdd = function () {
                        const div = L.DomUtil.create('div', 'psp-map-notice');
                        div.innerHTML = `
                            <div style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);background:white;padding:30px;border-radius:8px;box-shadow:0 4px 12px rgba(0,0,0,0.15);text-align:center;max-width:400px;z-index:400;">
                                <div style="font-size:48px;margin-bottom:16px;">📍</div>
                                <div style="font-size:16px;font-weight:600;margin-bottom:8px;">No locations yet</div>
                                <div style="font-size:13px;color:#666;line-height:1.6;">
                                    Partners will appear on the map once they have valid addresses.
                                </div>
                            </div>
                        `;
                        return div;
                    };
                    noDataDiv.addTo(map);
                }
            })
            .catch(err => {
                console.error('Map locations error:', err);
                const errorDiv = L.control({ position: 'center' });
                errorDiv.onAdd = function () {
                    const div = L.DomUtil.create('div', 'psp-map-error');
                    div.innerHTML = `
                        <div style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);background:white;padding:30px;border-radius:8px;box-shadow:0 4px 12px rgba(0,0,0,0.15);text-align:center;max-width:400px;z-index:400;">
                            <div style="font-size:48px;margin-bottom:16px;">⚠️</div>
                            <div style="font-size:16px;font-weight:600;margin-bottom:8px;">Error loading map</div>
                            <div style="font-size:13px;color:#666;margin-bottom:12px;">
                                ${err.message}
                            </div>
                            <button onclick="location.reload()" style="background:#3b82f6;color:white;border:none;padding:8px 16px;border-radius:4px;cursor:pointer;font-size:12px;">Retry</button>
                        </div>
                    `;
                    return div;
                };
                errorDiv.addTo(map);
            });
    };

    /**
     * Fetch partner locations from API (deprecated - use fetchMapLocations)
     */
    PSP.fetchPartnerLocations = function () {
        const apiUrl = (PSP_PORTAL && PSP_PORTAL.rest && PSP_PORTAL.rest.base) ? PSP_PORTAL.rest.base : '/wp-json/psp/v1';

        return fetch(apiUrl + '/map/locations', {
            headers: {
                'X-WP-Nonce': (PSP_PORTAL && PSP_PORTAL.rest) ? PSP_PORTAL.rest.nonce : ''
            }
        })
            .then(res => {
                if (!res.ok) throw new Error('Failed to fetch partner locations');
                return res.json();
            })
            .catch(err => {
                console.error('Partner locations error:', err);
                return { features: [] };
            });
    };

    /**
     * Display partner on map
     */
    PSP.addPartnerMarker = function (mapInstance, partner) {
        if (!mapInstance || !partner) return;

        const markerColor = partner.color || '#3b82f6';
        const markerIcon = L.divIcon({
            html: '<div style="background:' + markerColor + ';width:32px;height:40px;border-radius:50% 50% 50% 0;transform:rotate(-45deg);border:2px solid white;box-shadow:0 2px 6px rgba(0,0,0,0.15);display:flex;align-items:center;justify-content:center;color:white;font-size:16px;line-height:1;">' + (partner.icon || '📍') + '</div>',
            iconSize: L.point(32, 40),
            iconAnchor: L.point(16, 40),
            popupAnchor: L.point(0, -40)
        });

        const marker = L.marker(
            [partner.latitude, partner.longitude],
            { icon: markerIcon }
        );

        const popupHtml = `
            <div class="psp-map-marker-popup">
                <h4>${partner.name || 'Location'}</h4>
                <p><strong>${partner.partner_name || ''}</strong></p>
                <p>${partner.address || ''}</p>
                <p style="font-size:11px;color:#999;margin-top:6px;">
                    <strong>Status:</strong> ${partner.status || 'unknown'}
                </p>
            </div>
        `;

        marker.bindPopup(popupHtml, { maxWidth: 250 });

        if (PSP.markerCluster) {
            PSP.markerCluster.addLayer(marker);
        } else {
            marker.addTo(mapInstance);
        }

        return marker;
    };

    /**
     * Center map on partner location
     */
    PSP.centerMapOnPartner = function (mapInstance, partner) {
        if (!mapInstance || !partner || !partner.latitude || !partner.longitude) return;

        mapInstance.setView(
            [partner.latitude, partner.longitude],
            mapInstance.getZoom() || 14
        );
    };

    /**
     * Filter map by status
     */
    PSP.filterMapByStatus = function (mapInstance, status) {
        if (!mapInstance) return;
        // This would require refetching locations with status filter
        // Implementation left for future enhancement
        console.log('Filter by status:', status);
    };

    // Initialize on document ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function () {
            // Auto-init any partner map containers
            const mapContainers = document.querySelectorAll('[data-psp-map]');
            mapContainers.forEach(container => {
                const options = {
                    zoom: parseInt(container.dataset.pspMapZoom) || 10,
                    center: {
                        lat: parseFloat(container.dataset.pspMapLat) || 40,
                        lng: parseFloat(container.dataset.pspMapLng) || -95
                    }
                };
                PSP.initPartnerMap(container.id, options);
            });
        });
    }
})();
