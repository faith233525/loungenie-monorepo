<?php
namespace PSP;

if (!defined('ABSPATH')) exit;

/**
 * Company-based Authentication System
 * Multiple contacts per company, secure password storage
 */
class Company_Auth {
    
    public static function init() {
        add_action('rest_api_init', [self::class, 'register_routes']);
        add_action('wp_ajax_nopriv_psp_company_login', [self::class, 'ajax_login']);
        add_action('wp_ajax_psp_company_logout', [self::class, 'ajax_logout']);
    }

    public static function register_routes() {
        register_rest_route('psp/v1', '/auth/company/login', [
            'methods' => 'POST',
            'callback' => [self::class, 'rest_login'],
            'permission_callback' => '__return_true',
        ]);
        
        register_rest_route('psp/v1', '/auth/company/logout', [
            'methods' => 'POST',
            'callback' => [self::class, 'rest_logout'],
            'permission_callback' => '__return_true',
        ]);
        
        register_rest_route('psp/v1', '/auth/validate', [
            'methods' => 'GET',
            'callback' => [self::class, 'rest_validate'],
            'permission_callback' => '__return_true',
        ]);
    }

    public static function ajax_login() {
        check_ajax_referer('psp_auth', 'nonce');
        
        $username = sanitize_text_field($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        
        $result = self::authenticate_company($username, $password);
        
        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result);
        }
    }

    public static function rest_login($request) {
        $username = sanitize_text_field($request->get_param('username'));
        $password = $request->get_param('password');
        
        $result = self::authenticate_company($username, $password);
        
        if ($result['success']) {
            return new \WP_REST_Response($result, 200);
        } else {
            return new \WP_REST_Response($result, 401);
        }
    }

    public static function authenticate_company($username, $password) {
        global $wpdb;
        
        if (empty($username) || empty($password)) {
            return ['success' => false, 'message' => 'Username and password required'];
        }

        $table = $wpdb->prefix . 'psp_companies';
        $company = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table WHERE username = %s AND status = 'active'",
            $username
        ));

        if (!$company) {
            sleep(1); // Prevent timing attacks
            return ['success' => false, 'message' => 'Invalid credentials'];
        }

        if (!password_verify($password, $company->password_hash)) {
            sleep(1);
            self::log_login_attempt($company->id, false);
            return ['success' => false, 'message' => 'Invalid credentials'];
        }

        // Get primary contact for this company
        $contacts_table = $wpdb->prefix . 'psp_company_contacts';
        $primary_contact = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $contacts_table WHERE company_id = %d ORDER BY is_primary DESC, id ASC LIMIT 1",
            $company->id
        ));

        // Create session with contact tracking
        $contact_id = $primary_contact ? $primary_contact->id : null;
        $session = self::create_session($company->id, 'company', $contact_id);
        
        // Update last login
        $wpdb->update($table, 
            ['last_login' => current_time('mysql')],
            ['id' => $company->id],
            ['%s'],
            ['%d']
        );

        self::log_login_attempt($company->id, true);

        return [
            'success' => true,
            'session_token' => $session['token'],
            'user' => [
                'id' => $company->id,
                'type' => 'company',
                'name' => $company->company_name,
                'username' => $company->username,
                'role' => 'partner',
                'can_edit' => false, // Partners are view-only
                'contact_id' => $contact_id,
                'contact_name' => $primary_contact ? $primary_contact->name : null,
                'contact_email' => $primary_contact ? $primary_contact->email : null
            ]
        ];
    }

    public static function create_session($entity_id, $type = 'company', $contact_id = null) {
        global $wpdb;
        
        $token = bin2hex(random_bytes(32));
        $expires = time() + (7 * DAY_IN_SECONDS); // 7 day sessions
        
        $table = $wpdb->prefix . 'psp_sessions';
        $wpdb->insert($table, [
            'token' => hash('sha256', $token),
            'entity_id' => $entity_id,
            'entity_type' => $type,
            'contact_id' => $contact_id,
            'expires_at' => date('Y-m-d H:i:s', $expires),
            'created_at' => current_time('mysql')
        ]);

        // Set cookie
        setcookie('psp_session', $token, $expires, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true);

        return ['token' => $token, 'expires' => $expires];
    }

    public static function validate_session($token = null) {
        global $wpdb;
        
        if (!$token) {
            $token = $_COOKIE['psp_session'] ?? null;
        }
        
        if (!$token) {
            return false;
        }

        $token_hash = hash('sha256', $token);
        $table = $wpdb->prefix . 'psp_sessions';
        
        $session = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table WHERE token = %s AND expires_at > NOW()",
            $token_hash
        ));

        if (!$session) {
            return false;
        }

        // Get entity data
        if ($session->entity_type === 'company') {
            $company_table = $wpdb->prefix . 'psp_companies';
            $entity = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM $company_table WHERE id = %d AND status = 'active'",
                $session->entity_id
            ));
            
            if (!$entity) return false;
            
            // Get contact information if available
            $contact_data = null;
            if ($session->contact_id) {
                $contacts_table = $wpdb->prefix . 'psp_company_contacts';
                $contact = $wpdb->get_row($wpdb->prepare(
                    "SELECT * FROM $contacts_table WHERE id = %d",
                    $session->contact_id
                ));
                if ($contact) {
                    $contact_data = [
                        'id' => $contact->id,
                        'name' => $contact->name,
                        'email' => $contact->email,
                        'phone' => $contact->phone,
                        'is_primary' => (bool)$contact->is_primary
                    ];
                }
            }
            
            return [
                'id' => $entity->id,
                'type' => 'company',
                'name' => $entity->company_name,
                'username' => $entity->username,
                'role' => 'partner',
                'can_edit' => false, // Partners are view-only
                'session_id' => $session->id,
                'contact_id' => $session->contact_id,
                'contact' => $contact_data
            ];
        } elseif ($session->entity_type === 'support') {
            // Support user from WP users table
            $user = get_userdata($session->entity_id);
            if (!$user) return false;
            
            return [
                'id' => $user->ID,
                'type' => 'support',
                'name' => $user->display_name,
                'email' => $user->user_email,
                'role' => 'support',
                'can_edit' => true, // Support has full access
                'session_id' => $session->id
            ];
        }

        return false;
    }

    public static function rest_validate($request) {
        $token = $request->get_header('X-PSP-Session') ?? $_COOKIE['psp_session'] ?? null;
        $user = self::validate_session($token);
        
        if ($user) {
            return new \WP_REST_Response(['valid' => true, 'user' => $user], 200);
        } else {
            return new \WP_REST_Response(['valid' => false], 401);
        }
    }

    public static function ajax_logout() {
        self::destroy_session();
        wp_send_json_success(['message' => 'Logged out']);
    }

    public static function rest_logout($request) {
        self::destroy_session();
        return new \WP_REST_Response(['success' => true], 200);
    }

    public static function destroy_session($token = null) {
        global $wpdb;
        
        if (!$token) {
            $token = $_COOKIE['psp_session'] ?? null;
        }
        
        if ($token) {
            $token_hash = hash('sha256', $token);
            $table = $wpdb->prefix . 'psp_sessions';
            $wpdb->delete($table, ['token' => $token_hash]);
        }

        setcookie('psp_session', '', time() - 3600, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true);
    }

    public static function get_company_contacts($company_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'psp_company_contacts';
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table WHERE company_id = %d ORDER BY is_primary DESC, id ASC",
            $company_id
        ));
    }

    private static function log_login_attempt($company_id, $success) {
        global $wpdb;
        $table = $wpdb->prefix . 'psp_login_log';
        
        $wpdb->insert($table, [
            'company_id' => $company_id,
            'success' => $success ? 1 : 0,
            'ip_address' => $_SERVER['REMOTE_ADDR'] ?? '',
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            'created_at' => current_time('mysql')
        ]);
    }
}
