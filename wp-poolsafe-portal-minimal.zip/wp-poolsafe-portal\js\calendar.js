// PoolSafe Calendar Integration
// Uses FullCalendar.io (https://fullcalendar.io/)
// This file expects FullCalendar to be loaded via CDN in the page header.

(function () {
  function $(id) {
    return document.getElementById(id);
  }

  async function fetchEvents() {
    // Fetch events from REST API and map to FullCalendar format
    try {
      const res = await fetch(PSP_PORTAL.rest.base + '/calendar-events', {
        headers: { 'X-WP-Nonce': PSP_PORTAL.rest.nonce },
      });
      if (!res.ok) {
        throw new Error('Failed to load events');
      }
      const items = await res.json();
      return (items || []).map((ev) => ({
        id: ev.id,
        title: ev.title,
        start: ev.start_date,
        end: ev.end_date,
        color: ev.partner_id ? '#3AA6B9' : '#f59e42', // Example: color by partner
        extendedProps: {
          description: ev.description,
          partner_id: ev.partner_id,
        },
      }));
    } catch {
      return [];
    }
  }

  async function createEvent({ title, start, end, description }) {
    try {
      const res = await fetch(PSP_PORTAL.rest.base + '/calendar-events', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-WP-Nonce': PSP_PORTAL.rest.nonce,
        },
        body: JSON.stringify({
          title,
          start_date: start,
          end_date: end,
          description,
        }),
      });
      if (!res.ok) {
        throw new Error('Failed to create event');
      }
      return await res.json();
    } catch {
      alert('Failed to create event.');
      return null;
    }
  }

  function setupCalendar() {
    const el = $('psp-calendar');
    if (!el || typeof FullCalendar === 'undefined') {
      return;
    }
    fetchEvents().then((events) => {
      const calendar = new FullCalendar.Calendar(el, {
        initialView: 'dayGridMonth',
        height: 600,
        headerToolbar: {
          left: 'prev,next today',
          center: 'title',
          right: 'dayGridMonth,timeGridWeek,timeGridDay',
        },
        events: events,
        eventClick: function (info) {
          const ev = info.event;
          const desc = ev.extendedProps.description || '';
          const edit = confirm(
            `Event: ${ev.title}\n${desc ? '\n' + desc : ''}\n\nEdit this event?`,
          );
          if (edit) {
            const newTitle = prompt('Edit event title:', ev.title);
            if (newTitle && newTitle !== ev.title) {
              // For demo: just update title in UI (implement PUT in backend for real editing)
              ev.setProp('title', newTitle);
              // TODO: send update to backend
            }
          }
        },
        dateClick: function (info) {
          // Show event creation prompt
          const title = prompt('Event title for ' + info.dateStr + ':');
          if (title) {
            createEvent({
              title,
              start: info.dateStr,
              end: info.dateStr,
              description: '',
            }).then((newEv) => {
              if (newEv && newEv.id) {
                calendar.addEvent({
                  id: newEv.id,
                  title,
                  start: info.dateStr,
                  end: info.dateStr,
                  color: '#3AA6B9',
                });
              }
            });
          }
        },
        // ...existing code...
      });
      calendar.render();
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', setupCalendar);
  } else {
    setupCalendar();
  }
})();
