<?php
/**
 * PoolSafe Portal - Admin Status Dashboard Widget
 * 
 * Provides quick status overview in WordPress admin dashboard
 * Shows API health, database connections, configuration status
 * 
 * @package PSP
 * @version 2.5.3
 */

if (!defined('ABSPATH')) {
    exit;
}

class PSP_Admin_Status {

    /**
     * Initialize admin status features
     */
    public static function init() {
        if (!is_admin()) {
            return;
        }

        add_action('wp_dashboard_setup', [__CLASS__, 'register_widget']);
        add_action('admin_head', [__CLASS__, 'add_widget_styles']);
    }

    /**
     * Register the dashboard widget
     */
    public static function register_widget() {
        wp_add_dashboard_widget(
            'psp_status_widget',
            'PoolSafe Portal Status',
            [__CLASS__, 'render_widget']
        );
    }

    /**
     * Render the status widget
     */
    public static function render_widget() {
        $status = self::get_system_status();
        ?>
        <div class="psp-status-widget">
            <table class="widefat striped">
                <tbody>
                    <tr>
                        <td><strong>Plugin Version:</strong></td>
                        <td><code><?php echo esc_html(defined('PSP_VERSION') ? PSP_VERSION : 'Unknown'); ?></code></td>
                    </tr>
                    <tr>
                        <td><strong>WordPress Version:</strong></td>
                        <td><?php global $wp_version; echo esc_html($wp_version); ?></td>
                    </tr>
                    <tr>
                        <td><strong>PHP Version:</strong></td>
                        <td><?php echo esc_html(PHP_VERSION); ?></td>
                    </tr>
                    <tr>
                        <td><strong>Debug Mode:</strong></td>
                        <td>
                            <span style="color: <?php echo (defined('WP_DEBUG') && WP_DEBUG) ? 'green' : 'gray'; ?>">
                                <?php echo (defined('WP_DEBUG') && WP_DEBUG) ? '✓ Enabled' : '✗ Disabled'; ?>
                            </span>
                        </td>
                    </tr>
                    <tr>
                        <td><strong>REST API:</strong></td>
                        <td>
                            <span style="color: <?php echo $status['rest_api'] ? 'green' : 'red'; ?>">
                                <?php echo $status['rest_api'] ? '✓ Active' : '✗ Error'; ?>
                            </span>
                        </td>
                    </tr>
                    <tr>
                        <td><strong>Database:</strong></td>
                        <td>
                            <span style="color: <?php echo $status['database'] ? 'green' : 'red'; ?>">
                                <?php echo $status['database'] ? '✓ Connected' : '✗ Error'; ?>
                            </span>
                        </td>
                    </tr>
                    <tr>
                        <td><strong>Cache:</strong></td>
                        <td>
                            <?php if ($status['cache_type']) : ?>
                                <code><?php echo esc_html($status['cache_type']); ?></code> (<?php echo $status['cache_active'] ? 'Active' : 'Inactive'; ?>)
                            <?php else : ?>
                                <span style="color: gray;">Default</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td><strong>Custom Post Types:</strong></td>
                        <td><?php echo esc_html($status['post_types_count']); ?> registered</td>
                    </tr>
                </tbody>
            </table>

            <div style="margin-top: 15px; padding-top: 15px; border-top: 1px solid #eee;">
                <p style="margin: 5px 0; font-size: 12px; color: #666;">
                    <strong>Last Updated:</strong> <code><?php echo esc_html(current_time('Y-m-d H:i:s')); ?></code>
                </p>
                <p style="margin: 5px 0; font-size: 12px; color: #666;">
                    <a href="<?php echo esc_url(admin_url('admin.php?page=psp-settings')); ?>">→ Portal Settings</a>
                    | <a href="<?php echo esc_url(admin_url('admin.php?page=psp')); ?>">→ Portal Dashboard</a>
                </p>
            </div>
        </div>
        <?php
    }

    /**
     * Get system status information
     */
    private static function get_system_status() {
        global $wpdb;

        // Check REST API
        $rest_api = rest_url();
        $rest_active = !empty($rest_api);

        // Check database connection
        $database_active = !empty($wpdb) && $wpdb->get_results('SELECT 1');

        // Check cache
        $cache_type = self::get_cache_type();
        $cache_active = function_exists('wp_cache_is_enabled') ? wp_cache_is_enabled() : wp_using_ext_object_cache();

        // Count registered custom post types
        $post_types = get_post_types(['_builtin' => false], 'objects');
        $psp_types = array_filter($post_types, function ($pt) {
            return strpos($pt->name, 'psp_') === 0;
        });
        $post_types_count = count($psp_types);

        return [
            'rest_api' => $rest_active,
            'database' => (bool)$database_active,
            'cache_type' => $cache_type,
            'cache_active' => $cache_active,
            'post_types_count' => $post_types_count,
        ];
    }

    /**
     * Detect cache system in use
     */
    private static function get_cache_type() {
        if (function_exists('w3tc_pgcache_flush')) {
            return 'W3 Total Cache';
        }
        if (class_exists('WpFastestCache')) {
            return 'WP Fastest Cache';
        }
        if (defined('WP_SUPER_CACHE')) {
            return 'WP Super Cache';
        }
        if (defined('WP_CACHE') && WP_CACHE) {
            return 'Object Cache';
        }
        return false;
    }

    /**
     * Add widget styling
     */
    public static function add_widget_styles() {
        ?>
        <style>
            #psp_status_widget .psp-status-widget {
                font-size: 13px;
            }
            #psp_status_widget .psp-status-widget code {
                background: #f5f5f5;
                padding: 2px 5px;
                border-radius: 3px;
                font-family: monospace;
                font-size: 12px;
            }
            #psp_status_widget .psp-status-widget table td {
                padding: 8px;
                vertical-align: middle;
            }
            #psp_status_widget .psp-status-widget table td:first-child {
                width: 40%;
                background: #f9f9f9;
            }
            #psp_status_widget .psp-status-widget span {
                font-weight: bold;
            }
            #psp_status_widget .psp-status-widget a {
                text-decoration: none;
                color: #0073aa;
            }
            #psp_status_widget .psp-status-widget a:hover {
                color: #005a87;
            }
        </style>
        <?php
    }
}

// Initialize on admin
if (is_admin()) {
    PSP_Admin_Status::init();
}
