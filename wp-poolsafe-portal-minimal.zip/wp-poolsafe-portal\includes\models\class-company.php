<?php
/**
 * Unified Company Data Model
 *
 * Single source of truth for all company/partner data.
 * Every feature reads/writes from this model.
 *
 * @package PoolSafe_Portal
 * @since 3.0.0
 */

namespace PSP;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Company {

	/**
	 * Company post ID
	 */
	private int $id = 0;

	/**
	 * Company data array (cached)
	 */
	private array $data = [];

	/**
	 * Initialize with company post ID
	 */
	public function __construct( int $id = 0 ) {
		$this->id = $id;
		if ( $id ) {
			$this->load();
		}
	}

	/**
	 * Load company data from database
	 */
	private function load(): void {
		$post = get_post( $this->id );
		if ( ! $post || 'psp_partner' !== $post->post_type ) {
			$this->data = [];
			return;
		}

		$this->data = [
			'id'                 => $this->id,
			'name'               => $post->post_title,
			'description'        => $post->post_content,
			'management_company' => get_post_meta( $this->id, 'management_company', true ) ?: '',
			'address'            => get_post_meta( $this->id, 'address', true ) ?: '',
			'city'               => get_post_meta( $this->id, 'city', true ) ?: '',
			'state'              => get_post_meta( $this->id, 'state', true ) ?: '',
			'zip'                => get_post_meta( $this->id, 'zip', true ) ?: '',
			'country'            => get_post_meta( $this->id, 'country', true ) ?: 'US',
			'latitude'           => (float) ( get_post_meta( $this->id, 'latitude', true ) ?: 0 ),
			'longitude'          => (float) ( get_post_meta( $this->id, 'longitude', true ) ?: 0 ),
			'primary_contact'    => get_post_meta( $this->id, 'primary_contact', true ) ?: '',
			'contact_email'      => get_post_meta( $this->id, 'contact_email', true ) ?: '',
			'contact_phone'      => get_post_meta( $this->id, 'contact_phone', true ) ?: '',
			'units'              => array_map( 'intval', (array) get_post_meta( $this->id, 'units', true ) ?: [] ),
			'unit_count'         => (int) get_post_meta( $this->id, 'unit_count', true ) ?: 0,
			'lock_type'          => get_post_meta( $this->id, 'lock_type', true ) ?: '',
			'tag_color'          => get_post_meta( $this->id, 'tag_color', true ) ?: '#007cba',
			'status'             => get_post_meta( $this->id, 'status', true ) ?: 'active',
			'subscription_tier'  => get_post_meta( $this->id, 'subscription_tier', true ) ?: 'standard',
			'hubspot_company_id' => get_post_meta( $this->id, 'hubspot_company_id', true ) ?: '',
			'created_at'         => $post->post_date,
			'updated_at'         => $post->post_modified,
		];
	}

	/**
	 * Get company data as array
	 */
	public function to_array(): array {
		return $this->data ?: [];
	}

	/**
	 * Get single property with type casting
	 */
	public function get( string $key, $default = null ) {
		return $this->data[ $key ] ?? $default;
	}

	/**
	 * Set company data (does NOT save to DB)
	 */
	public function set( string $key, $value ): self {
		$this->data[ $key ] = $value;
		return $this;
	}

	/**
	 * Save company to database
	 */
	public function save(): bool {
		if ( ! $this->id ) {
			// Create new company post
			$post_id = wp_insert_post( [
				'post_type'   => 'psp_partner',
				'post_title'  => $this->data['name'] ?? '',
				'post_status' => 'publish',
			] );

			if ( is_wp_error( $post_id ) ) {
				return false;
			}

			$this->id = $post_id;
		} else {
			// Update existing post
			wp_update_post( [
				'ID'           => $this->id,
				'post_title'   => $this->data['name'] ?? '',
				'post_content' => $this->data['description'] ?? '',
			] );
		}

		// Save all metadata
		$meta_keys = [
			'management_company',
			'address',
			'city',
			'state',
			'zip',
			'country',
			'latitude',
			'longitude',
			'primary_contact',
			'contact_email',
			'contact_phone',
			'units',
			'unit_count',
			'lock_type',
			'tag_color',
			'status',
			'subscription_tier',
			'hubspot_company_id',
		];

		foreach ( $meta_keys as $key ) {
			if ( isset( $this->data[ $key ] ) ) {
				update_post_meta( $this->id, $key, $this->data[ $key ] );
			}
		}

		return true;
	}

	/**
	 * Delete company from database
	 */
	public function delete(): bool {
		if ( ! $this->id ) {
			return false;
		}
		wp_delete_post( $this->id, true );
		return true;
	}

	/**
	 * Get all tickets for this company
	 */
	public function get_tickets( array $args = [] ): array {
		$defaults = [
			'post_type'      => 'psp_ticket',
			'posts_per_page' => -1,
			'meta_key'       => 'partner_id',
			'meta_value'     => $this->id,
		];

		$args = wp_parse_args( $args, $defaults );
		$posts = get_posts( $args );

		return array_map( function( $post ) {
			return [
				'id'        => $post->ID,
				'title'     => $post->post_title,
				'status'    => get_post_meta( $post->ID, 'status', true ) ?: 'open',
				'priority'  => get_post_meta( $post->ID, 'priority', true ) ?: 'normal',
				'created'   => $post->post_date,
				'updated'   => $post->post_modified,
			];
		}, $posts );
	}

	/**
	 * Get all operations/service visits for this company
	 */
	public function get_operations( array $args = [] ): array {
		$defaults = [
			'post_type'      => 'psp_operation',
			'posts_per_page' => -1,
			'meta_key'       => 'company_id',
			'meta_value'     => $this->id,
		];

		$args = wp_parse_args( $args, $defaults );
		$posts = get_posts( $args );

		return array_map( function( $post ) {
			return [
				'id'         => $post->ID,
				'visit_type' => get_post_meta( $post->ID, 'visit_type', true ) ?: 'service',
				'visit_date' => get_post_meta( $post->ID, 'visit_date', true ) ?: '',
				'duration'   => (int) get_post_meta( $post->ID, 'duration', true ) ?: 0,
				'staff_id'   => (int) get_post_meta( $post->ID, 'staff_id', true ) ?: 0,
				'notes'      => get_post_meta( $post->ID, 'notes', true ) ?: '',
				'created'    => $post->post_date,
			];
		}, $posts );
	}

	/**
	 * Get location data (coordinates + address)
	 */
	public function get_location(): array {
		return [
			'address'   => $this->get( 'address' ) . ', ' . $this->get( 'city' ) . ', ' . $this->get( 'state' ) . ' ' . $this->get( 'zip' ),
			'latitude'  => $this->get( 'latitude' ),
			'longitude' => $this->get( 'longitude' ),
		];
	}

	/**
	 * Get company contacts (users associated with this company)
	 */
	public function get_contacts(): array {
		$args = [
			'meta_key'   => 'psp_partner_id',
			'meta_value' => $this->id,
		];

		$users = get_users( $args );

		return array_map( function( $user ) {
			return [
				'id'    => $user->ID,
				'name'  => $user->display_name,
				'email' => $user->user_email,
				'role'  => $user->roles[0] ?? 'subscriber',
			];
		}, $users );
	}

	/**
	 * Sync this company to HubSpot (if enabled)
	 */
	public function sync_to_hubspot(): bool {
		if ( ! class_exists( 'PSP_HubSpot' ) ) {
			return false;
		}

		return PSP_HubSpot::sync_company( $this->id, $this->to_array() );
	}

	/**
	 * Static: Get company by ID
	 */
	public static function get_by_id( int $id ): ?self {
		$company = new self( $id );
		return $company->data ? $company : null;
	}

	/**
	 * Static: Get all companies
	 */
	public static function get_all( array $args = [] ): array {
		$defaults = [
			'post_type'      => 'psp_partner',
			'posts_per_page' => -1,
			'post_status'    => 'publish',
		];

		$args  = wp_parse_args( $args, $defaults );
		$posts = get_posts( $args );

		return array_map( function( $post ) {
			return new self( $post->ID );
		}, $posts );
	}

	/**
	 * Static: Create new company
	 */
	public static function create( array $data ): ?self {
		$company = new self();
		foreach ( $data as $key => $value ) {
			$company->set( $key, $value );
		}

		if ( $company->save() ) {
			return $company;
		}

		return null;
	}

	/**
	 * Static: Search companies by name or tag
	 */
	public static function search( string $query, int $limit = 10 ): array {
		$args = [
			'post_type'      => 'psp_partner',
			'posts_per_page' => $limit,
			's'              => $query,
			'post_status'    => 'publish',
		];

		$posts = get_posts( $args );

		return array_map( function( $post ) {
			return new self( $post->ID );
		}, $posts );
	}
}
