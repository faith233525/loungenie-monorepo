<?php
/**
 * Pool Safe Portal - Partner Location Map System
 * 
 * Interactive map display of partner locations with property details
 * Supports filtering, clustering, and real-time updates
 * 
 * @package PSP\Partner_Map
 * @version 2.0.0
 */

namespace PSP\Partner_Map;

if (!defined('ABSPATH')) {
    exit;
}

class Partner_Map {
    
    /**
     * Initialize Partner Map system
     */
    public static function init() {
        add_action('rest_api_init', [__CLASS__, 'register_rest_endpoints']);
        add_action('wp_enqueue_scripts', [__CLASS__, 'enqueue_map_assets']);
        add_action('admin_enqueue_scripts', [__CLASS__, 'enqueue_admin_map_assets']);
    }
    
    /**
     * Enqueue map assets
     */
    public static function enqueue_map_assets() {
        if (!is_user_logged_in()) {
            return;
        }
        
        // Leaflet map library
        wp_enqueue_style(
            'leaflet-css',
            'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css',
            [],
            '1.9.4'
        );
        
        wp_enqueue_script(
            'leaflet-js',
            'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js',
            [],
            '1.9.4',
            true
        );
        
        // Leaflet Cluster
        wp_enqueue_style(
            'leaflet-markercluster-css',
            'https://cdnjs.cloudflare.com/ajax/libs/leaflet.markercluster/1.5.0/MarkerCluster.css',
            [],
            '1.5.0'
        );
        
        wp_enqueue_script(
            'leaflet-markercluster-js',
            'https://cdnjs.cloudflare.com/ajax/libs/leaflet.markercluster/1.5.0/leaflet.markercluster.min.js',
            ['leaflet-js'],
            '1.5.0',
            true
        );
        
        // Custom map script
        wp_enqueue_script(
            'psp-partner-map',
            plugins_url('../js/partner-map.js', __FILE__),
            ['leaflet-js', 'leaflet-markercluster-js'],
            '2.0.0',
            true
        );
        
        // Custom map styles
        wp_enqueue_style(
            'psp-partner-map-css',
            plugins_url('../css/partner-map.css', __FILE__),
            [],
            '2.0.0'
        );
    }
    
    /**
     * Enqueue admin map assets
     */
    public static function enqueue_admin_map_assets() {
        if (!current_user_can('manage_psp_portal')) {
            return;
        }
        
        wp_enqueue_style(
            'leaflet-css',
            'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css',
            [],
            '1.9.4'
        );
        
        wp_enqueue_script(
            'leaflet-js',
            'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js',
            [],
            '1.9.4',
            true
        );
    }
    
    /**
     * Register REST API endpoints
     */
    public static function register_rest_endpoints() {
        register_rest_route('psp/v1', '/map/locations', [
            'methods' => 'GET',
            'callback' => [__CLASS__, 'get_map_locations'],
            'permission_callback' => function () {
                return is_user_logged_in();
            },
            'args' => [
                'filter' => ['type' => 'string', 'required' => false],
                'bounds' => ['type' => 'string', 'required' => false],
                'zoom' => ['type' => 'integer', 'required' => false],
            ],
        ]);
        
        register_rest_route('psp/v1', '/map/stats', [
            'methods' => 'GET',
            'callback' => [__CLASS__, 'get_map_stats'],
            'permission_callback' => function () {
                return is_user_logged_in();
            },
        ]);
        
        register_rest_route('psp/v1', '/map/heatmap', [
            'methods' => 'GET',
            'callback' => [__CLASS__, 'get_heatmap_data'],
            'permission_callback' => function () {
                return current_user_can('manage_psp_portal');
            },
        ]);
    }
    
    /**
     * Get map locations with filtering
     */
    public static function get_map_locations($request) {
        global $wpdb;
        
        $user_id = get_current_user_id();
        $user = get_user_by('ID', $user_id);
        $user_roles = (array) $user->roles;
        
        $filter = $request->get_param('filter') ?? 'all';
        $bounds = $request->get_param('bounds');
        
        // Build query
        $query = "SELECT 
                    p.ID as property_id,
                    p.post_title as property_name,
                    pm1.meta_value as latitude,
                    pm2.meta_value as longitude,
                    pm3.meta_value as address,
                    pm4.meta_value as city,
                    pm5.meta_value as status,
                    pr.ID as partner_id,
                    pr.post_title as partner_name,
                    prm.meta_value as partner_status
                  FROM {$wpdb->posts} p
                  LEFT JOIN {$wpdb->postmeta} pm1 ON p.ID = pm1.post_id AND pm1.meta_key = 'psp_property_latitude'
                  LEFT JOIN {$wpdb->postmeta} pm2 ON p.ID = pm2.post_id AND pm2.meta_key = 'psp_property_longitude'
                  LEFT JOIN {$wpdb->postmeta} pm3 ON p.ID = pm3.post_id AND pm3.meta_key = 'psp_property_address'
                  LEFT JOIN {$wpdb->postmeta} pm4 ON p.ID = pm4.post_id AND pm4.meta_key = 'psp_property_city'
                  LEFT JOIN {$wpdb->postmeta} pm5 ON p.ID = pm5.post_id AND pm5.meta_key = 'psp_property_status'
                  LEFT JOIN {$wpdb->postmeta} pm6 ON p.ID = pm6.post_id AND pm6.meta_key = 'psp_property_partner_id'
                  LEFT JOIN {$wpdb->posts} pr ON pm6.meta_value = pr.ID AND pr.post_type = 'psp_partner'
                  LEFT JOIN {$wpdb->postmeta} prm ON pr.ID = prm.post_id AND prm.meta_key = 'psp_partner_status'
                  WHERE p.post_type = 'psp_property'
                  AND pm1.meta_value IS NOT NULL
                  AND pm2.meta_value IS NOT NULL";
        
        // Role-based filtering
        if (in_array('pool_safe_partner', $user_roles)) {
            $partner_id = get_user_meta($user_id, 'psp_partner_id', true);
            $query .= $wpdb->prepare(" AND pm6.meta_value = %d", $partner_id);
        }
        
        // Filter by status
        if ($filter === 'active') {
            $query .= " AND pm5.meta_value = 'active'";
        } elseif ($filter === 'maintenance') {
            $query .= " AND pm5.meta_value = 'maintenance'";
        } elseif ($filter === 'inactive') {
            $query .= " AND pm5.meta_value = 'inactive'";
        }
        
        // Add boundary filter if provided
        if (!empty($bounds)) {
            $bounds_data = json_decode($bounds, true);
            if (isset($bounds_data['north'], $bounds_data['south'], $bounds_data['east'], $bounds_data['west'])) {
                $query .= $wpdb->prepare(
                    " AND pm1.meta_value BETWEEN %f AND %f AND pm2.meta_value BETWEEN %f AND %f",
                    $bounds_data['south'],
                    $bounds_data['north'],
                    $bounds_data['west'],
                    $bounds_data['east']
                );
            }
        }
        
        $query .= " ORDER BY p.post_title ASC LIMIT 1000";
        
        $results = $wpdb->get_results($query);
        
        $locations = [];
        foreach ($results as $row) {
            if (empty($row->latitude) || empty($row->longitude)) {
                continue;
            }
            
            $locations[] = [
                'id' => $row->property_id,
                'name' => $row->property_name,
                'latitude' => (float) $row->latitude,
                'longitude' => (float) $row->longitude,
                'address' => $row->address . ', ' . $row->city,
                'status' => $row->status ?? 'unknown',
                'partner_id' => $row->partner_id,
                'partner_name' => $row->partner_name,
                'partner_status' => $row->partner_status ?? 'active',
                'icon' => self::get_status_icon($row->status ?? 'unknown'),
                'color' => self::get_status_color($row->status ?? 'unknown'),
            ];
        }
        
        return [
            'type' => 'FeatureCollection',
            'features' => array_map([__CLASS__, 'format_geojson_feature'], $locations),
            'count' => count($locations),
        ];
    }
    
    /**
     * Get map statistics
     */
    public static function get_map_stats($request) {
        global $wpdb;
        
        $stats = [
            'total_properties' => (int) $wpdb->get_var(
                "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'psp_property'"
            ),
            'active_properties' => (int) $wpdb->get_var(
                "SELECT COUNT(p.ID) FROM {$wpdb->posts} p 
                 JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id 
                 WHERE p.post_type = 'psp_property' AND pm.meta_key = 'psp_property_status' AND pm.meta_value = 'active'"
            ),
            'maintenance_properties' => (int) $wpdb->get_var(
                "SELECT COUNT(p.ID) FROM {$wpdb->posts} p 
                 JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id 
                 WHERE p.post_type = 'psp_property' AND pm.meta_key = 'psp_property_status' AND pm.meta_value = 'maintenance'"
            ),
            'properties_with_coordinates' => (int) $wpdb->get_var(
                "SELECT COUNT(DISTINCT p.ID) FROM {$wpdb->posts} p
                 JOIN {$wpdb->postmeta} pm1 ON p.ID = pm1.post_id AND pm1.meta_key = 'psp_property_latitude'
                 JOIN {$wpdb->postmeta} pm2 ON p.ID = pm2.post_id AND pm2.meta_key = 'psp_property_longitude'
                 WHERE p.post_type = 'psp_property'"
            ),
            'total_partners' => (int) $wpdb->get_var(
                "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'psp_partner'"
            ),
        ];
        
        return $stats;
    }
    
    /**
     * Get heatmap data (density of properties)
     */
    public static function get_heatmap_data($request) {
        global $wpdb;
        
        $query = "SELECT 
                    pm1.meta_value as latitude,
                    pm2.meta_value as longitude,
                    COUNT(p.ID) as density
                  FROM {$wpdb->posts} p
                  JOIN {$wpdb->postmeta} pm1 ON p.ID = pm1.post_id AND pm1.meta_key = 'psp_property_latitude'
                  JOIN {$wpdb->postmeta} pm2 ON p.ID = pm2.post_id AND pm2.meta_key = 'psp_property_longitude'
                  WHERE p.post_type = 'psp_property'
                  GROUP BY pm1.meta_value, pm2.meta_value
                  HAVING latitude IS NOT NULL AND longitude IS NOT NULL";
        
        $results = $wpdb->get_results($query);
        
        $heatmap_data = [];
        foreach ($results as $row) {
            $heatmap_data[] = [
                (float) $row->latitude,
                (float) $row->longitude,
                (int) $row->density,
            ];
        }
        
        return $heatmap_data;
    }
    
    /**
     * Format location as GeoJSON feature
     */
    private static function format_geojson_feature($location) {
        return [
            'type' => 'Feature',
            'geometry' => [
                'type' => 'Point',
                'coordinates' => [(float) $location['longitude'], (float) $location['latitude']],
            ],
            'properties' => [
                'id' => $location['id'],
                'name' => $location['name'],
                'address' => $location['address'],
                'status' => $location['status'],
                'partner_name' => $location['partner_name'],
                'partner_id' => $location['partner_id'],
                'icon' => $location['icon'],
                'color' => $location['color'],
            ],
        ];
    }
    
    /**
     * Get marker icon based on property status
     */
    private static function get_status_icon($status) {
        $icons = [
            'active' => '✓',
            'maintenance' => '🔧',
            'inactive' => '○',
            'unknown' => '?',
        ];
        
        return $icons[$status] ?? $icons['unknown'];
    }
    
    /**
     * Get color based on property status
     */
    private static function get_status_color($status) {
        $colors = [
            'active' => '#22C55E',      // Green
            'maintenance' => '#F59E0B', // Amber
            'inactive' => '#EF4444',    // Red
            'unknown' => '#9CA3AF',     // Gray
        ];
        
        return $colors[$status] ?? $colors['unknown'];
    }
    
    /**
     * Get distance between two coordinates (in miles)
     */
    public static function calculate_distance($lat1, $lon1, $lat2, $lon2) {
        $earth_radius = 3959; // Miles
        
        $lat1_rad = deg2rad($lat1);
        $lat2_rad = deg2rad($lat2);
        $delta_lat = deg2rad($lat2 - $lat1);
        $delta_lon = deg2rad($lon2 - $lon1);
        
        $a = sin($delta_lat / 2) * sin($delta_lat / 2) +
             cos($lat1_rad) * cos($lat2_rad) *
             sin($delta_lon / 2) * sin($delta_lon / 2);
        
        $c = 2 * atan2(sqrt($a), sqrt(1 - $a));
        
        return $earth_radius * $c;
    }
}

// Initialize on WordPress init
Partner_Map::init();
