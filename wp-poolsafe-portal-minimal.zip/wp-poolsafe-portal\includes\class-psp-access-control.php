<?php
namespace PSP;

/**
 * Global access control: protect all pages, hide menus for guests, redirect to login.
 *
 * @package PoolSafePortal
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
// ...existing code...

class Access_Control {


	/**
	 * Initialize access control hooks for frontend and admin.
	 * NOTE: Currently disabled - causing admin issues
	 *
	 * @return void
	 */
	public static function init(): void {
		// Temporarily disabled to debug admin access issues
		return;
		
		// Frontend redirect for non-logged-in users (except allowed endpoints)
		add_action( 'template_redirect', array( __CLASS__, 'maybe_redirect_guest' ) );

		// Hide theme navigation menus for guests
		add_filter( 'wp_nav_menu_args', array( __CLASS__, 'filter_nav_menu_args' ) );
		add_filter( 'wp_nav_menu_items', array( __CLASS__, 'filter_nav_menu_items' ), 99, 2 );

		// Hide admin bar for non-logged-in and non-admin/support users
		add_filter( 'show_admin_bar', array( __CLASS__, 'hide_admin_bar' ) );
	}

	/**
	 * Redirect unauthenticated visitors to portal login page, except allowed routes.
	 *
	 * @return void
	 */
	public static function maybe_redirect_guest(): void {
		try {
			if ( ! function_exists( 'is_user_logged_in' ) ) {
				error_log( '[PSP Access] is_user_logged_in() not available' );
				return;
			}
			
			if ( is_user_logged_in() ) {
				return; // Authenticated: allow.
			}

			// Allow WordPress core login, registration, logout
			if ( self::is_core_auth_page() ) {
				return;
			}

			// Allow our custom login shortcode page (slug: login or portal-login for backward compatibility)
			if ( self::is_portal_login_page() ) {
				return;
			}

			// Allow OAuth callback & start endpoints
			if ( self::is_oauth_flow_request() ) {
				return;
			}

			// Allow AJAX, REST API, cron, and admin-post actions
			if ( self::is_system_request() ) {
				return;
			}

			// Allow robots, favicon, assets
			if ( self::is_public_asset_request() ) {
				return;
			}

			// Otherwise redirect to login page
			// Prefer new /login slug; keep /portal-login working if user browses directly
			$login_url = self::get_login_url();
			
			if ( empty( $login_url ) ) {
				error_log( '[PSP Access] Failed to get login URL for redirect' );
				return;
			}
			
			if ( ! function_exists( 'wp_safe_redirect' ) ) {
				error_log( '[PSP Access] wp_safe_redirect() not available' );
				return;
			}
			
			// Preserve intended URL for post-login redirect (optional future enhancement)
			wp_safe_redirect( $login_url );
			exit;
		} catch ( \Exception $e ) {
			error_log( '[PSP Access] Redirect failed: ' . $e->getMessage() );
		}
	}

	/**
	 * WordPress core auth endpoints
	 */
	public static function is_core_auth_page(): bool {
		return ( function_exists( 'is_page' ) && ( is_page( 'wp-login.php' ) ) ) || self::is_login_php();
	}

	/**
	 * Detect direct wp-login.php access
	 */
	public static function is_login_php(): bool {
		$script = isset( $_SERVER['SCRIPT_NAME'] ) ? wp_basename( $_SERVER['SCRIPT_NAME'] ) : '';
		return $script === 'wp-login.php';
	}

	/**
	 * Detect portal login page by path or content (simple heuristic)
	 */
	public static function is_portal_login_page(): bool {
		try {
			// Check URL path
			$req_uri = isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '';
			
			if ( empty( $req_uri ) ) {
				return false;
			}
			
			if ( strpos( $req_uri, '/portal-login' ) !== false ) {
				return true;
			}
			if ( strpos( $req_uri, '/login' ) !== false ) {
				return true;
			}
			return false; // We rely on slug; content scan would require a query.
		} catch ( \Exception $e ) {
			error_log( '[PSP Access] is_portal_login_page check failed: ' . $e->getMessage() );
			return false;
		}
	}

	/**
	 * Resolve login URL with graceful fallback
	 */
	public static function get_login_url(): string {
		try {
			// Get configured login slug from settings
			$settings = function_exists( 'get_option' ) ? get_option( 'psp_settings', array() ) : array();
			
			if ( ! is_array( $settings ) ) {
				error_log( '[PSP Access] Settings is not an array' );
				$settings = array();
			}
			
			$slug = isset( $settings['login_page_slug'] ) && $settings['login_page_slug'] ? $settings['login_page_slug'] : 'login';

			// If a page with configured slug exists, use its permalink
			if ( function_exists( 'get_page_by_path' ) && function_exists( 'get_permalink' ) ) {
				$p = get_page_by_path( $slug );
				if ( $p && isset( $p->ID ) ) {
					$url = get_permalink( $p );
					if ( $url ) {
						return $url;
					}
				}
				// Fallback to portal-login for backward compatibility
				$p2 = get_page_by_path( 'portal-login' );
				if ( $p2 && isset( $p2->ID ) ) {
					$url = get_permalink( $p2 );
					if ( $url ) {
						return $url;
					}
				}
			}
			// Otherwise fall back to home_url with configured slug
			if ( function_exists( 'home_url' ) ) {
				return home_url( '/' . $slug );
			}
			// Last resort: relative path
			return '/' . $slug;
		} catch ( \Exception $e ) {
			error_log( '[PSP Access] get_login_url failed: ' . $e->getMessage() );
			return '/login'; // Fallback
		}
	}

	/**
	 * OAuth flow endpoints (start & callback)
	 */
	public static function is_oauth_flow_request(): bool {
		try {
			if ( ! function_exists( 'sanitize_key' ) ) {
				error_log( '[PSP Access] sanitize_key() not available' );
				return false;
			}
			
			$action = isset( $_GET['action'] ) ? sanitize_key( $_GET['action'] ) : '';
			
			if ( $action === 'psp_graph_oauth_start' || $action === 'psp_graph_oauth_callback' ) {
				return true;
			}
			return false;
		} catch ( \Exception $e ) {
			error_log( '[PSP Access] OAuth flow check failed: ' . $e->getMessage() );
			return false;
		}
	}

	/**
	 * System/internal requests that should not be blocked
	 */
	public static function is_system_request(): bool {
		if ( defined( 'DOING_AJAX' ) && DOING_AJAX ) {
			return true;
		}
		if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
			return true;
		}
		if ( defined( 'DOING_CRON' ) && DOING_CRON ) {
			return true;
		}
		// admin-post.php endpoints
		$script = isset( $_SERVER['SCRIPT_NAME'] ) ? wp_basename( $_SERVER['SCRIPT_NAME'] ) : '';
		if ( $script === 'admin-post.php' ) {
			return true;
		}
		return false;
	}

	/**
	 * Allow public assets (css/js/images) & well-known
	 */
	public static function is_public_asset_request(): bool {
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '';
		// Basic exclusions
		$allowed_prefixes = array( '/wp-content/uploads/', '/wp-content/plugins/', '/wp-includes/', '/favicon.ico', '/robots.txt', '/.well-known/' );
		foreach ( $allowed_prefixes as $prefix ) {
			if ( strpos( $uri, $prefix ) !== false ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Hide menus by returning empty container for guests.
	 *
	 * @param  array $args Menu arguments.
	 * @return array Modified menu arguments.
	 */
	public static function filter_nav_menu_args( $args ) {
		if ( ! is_user_logged_in() ) {
			// Replace walker / output with empty ul to avoid theme fallback.
			$args['echo']        = false;
			$args['fallback_cb'] = '__return_empty_string';
			$args['menu']        = 0; // Force no specific menu.
		}
		return $args;
	}

	/**
	 * Ensure menu items are empty for guests regardless of theme behavior.
	 *
	 * @param  string $items Menu items HTML.
	 * @param  array  $args  Menu arguments.
	 * @return string Modified menu items HTML.
	 */
	public static function filter_nav_menu_items( $items, $args ) {
		if ( ! is_user_logged_in() ) {
			return '';
		}
		return $items;
	}

	/**
	 * Hide admin bar for all guests.
	 *
	 * @param  bool $show Whether to show the admin bar.
	 * @return bool True to show, false to hide.
	 */
	public static function hide_admin_bar( $show ): bool {
		if ( ! is_user_logged_in() ) {
			return false;
		}
		return $show;
	}
}
