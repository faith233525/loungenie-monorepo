/**
 * PoolSafe Portal - Enterprise Unified Application
 * File: js/psp-portal-app.js
 * Version: 2.5.3+ UNIFIED
 *
 * Architecture:
 * - Smart section-based routing with state management
 * - Intelligent lazy-loading with Intersection Observer
 * - Automatic retry logic with exponential backoff (1s, 2s, 4s)
 * - Centralized error handling and recovery
 * - WCAG 2.1 AA accessibility compliance
 * - W3TC cache compatibility (no minification issues)
 * - Performance optimized (8-second timeout, debounced updates)
 *
 * Key Classes:
 * - PortalState: Centralized section state management
 * - Cache: Smart caching with TTL
 * - AlertManager: User notifications
 * - FeatureDetection: Browser capability detection
 */

(function () {
    'use strict';

    // CSP-Compliant: Build configuration safely even if inline localization is blocked
    function getConfigFromDom() {
        const wrapper = document.querySelector('.psp-portal-wrapper');
        if (!wrapper || !wrapper.dataset) return null;
        const d = wrapper.dataset;

        let user = {};
        try {
            user = d.user ? JSON.parse(d.user) : {};
        } catch (e) {
            user = {};
        }

        let visibleTabs = [];
        try {
            visibleTabs = d.visibleTabs ? JSON.parse(d.visibleTabs) : [];
        } catch (e) {
            visibleTabs = [];
        }

        let partnerTabs = [];
        try {
            partnerTabs = d.partnerTabs ? JSON.parse(d.partnerTabs) : [];
        } catch (e) {
            partnerTabs = [];
        }

        let supportTabs = [];
        try {
            supportTabs = d.supportTabs ? JSON.parse(d.supportTabs) : [];
        } catch (e) {
            supportTabs = [];
        }

        const roleMode = d.roleMode || '';

        let configJson = {};
        try {
            configJson = d.configJson ? JSON.parse(d.configJson) : {};
        } catch (e) {
            configJson = {};
        }

        return {
            apiUrl: d.apiUrl || configJson.apiUrl,
            ajaxUrl: d.ajaxUrl || configJson.ajaxUrl,
            nonce: d.nonce || configJson.nonce,
            user: user || configJson.user || {},
            userRole: d.userRole || configJson.userRole || (user ? user.role : ''),
            companyId: d.companyId || configJson.companyId,
            visibleTabs: visibleTabs.length ? visibleTabs : (configJson.visibleTabs || []),
            partnerTabs: partnerTabs.length ? partnerTabs : (configJson.partnerTabs || []),
            supportTabs: supportTabs.length ? supportTabs : (configJson.supportTabs || []),
            roleMode: roleMode || configJson.roleMode || '',
            canUploadCsv: configJson.canUploadCsv || false,
            isUnrestricted: configJson.isUnrestricted || false,
            adminUrl: d.adminUrl || configJson.adminUrl,
            pluginUrl: d.pluginUrl || configJson.pluginUrl,
            isAdmin: (d.isAdmin === '1' || d.isAdmin === 'true') || !!configJson.isAdmin,
            debug: (d.debug === '1' || d.debug === 'true') || !!configJson.debug,
        };
    }

    // Prefer wp_localize_script output; fall back to DOM dataset when CSP blocks inline scripts
    const portalConfig = window.PORTAL_CONFIG || getConfigFromDom() || {};

    if (!portalConfig.apiUrl) {
        console.error('[PSP] PORTAL_CONFIG.apiUrl missing - cannot initialize portal');
        // Show user-friendly error in the portal
        document.addEventListener('DOMContentLoaded', function () {
            const contentAreas = document.querySelectorAll('.psp-dynamic-content');
            contentAreas.forEach(function (area) {
                area.innerHTML = '<div class="psp-error">Portal configuration error. Please contact support.</div>';
            });
        });
        return;
    }

    // Normalize API URL to current origin (prevents DNS resolution issues)
    const origin = window.location && window.location.origin ? window.location.origin : '';
    const normalizedApi = origin ? (origin.replace(/\/$/, '') + '/wp-json/psp/v1') : '/wp-json/psp/v1';
    portalConfig.apiUrl = normalizedApi;

    // Provide sane defaults for tab sets
    const defaultPartnerTabs = ['dashboard', 'videos', 'tickets', 'services'];
    const defaultSupportTabs = ['dashboard', 'videos', 'tickets', 'services', 'partners'];

    portalConfig.partnerTabs = (portalConfig.partnerTabs && portalConfig.partnerTabs.length) ? portalConfig.partnerTabs : defaultPartnerTabs;
    portalConfig.supportTabs = (portalConfig.supportTabs && portalConfig.supportTabs.length) ? portalConfig.supportTabs : defaultSupportTabs;

    // Determine initial role mode for admins (support by default), otherwise use user role
    const initialRoleMode = portalConfig.roleMode || (portalConfig.isAdmin ? 'support' : (portalConfig.userRole || (portalConfig.user ? portalConfig.user.role : 'partner')));
    portalConfig.roleMode = initialRoleMode === 'administrator' ? 'support' : initialRoleMode;

    // Set initial visible tabs based on role mode if not already populated
    if (!portalConfig.visibleTabs || !portalConfig.visibleTabs.length) {
        portalConfig.visibleTabs = portalConfig.roleMode === 'partner' ? portalConfig.partnerTabs : portalConfig.supportTabs;
    }

    // Make config available globally for other scripts
    window.PORTAL_CONFIG = portalConfig;

    // Debug logging (only in development/debug mode)
    const DEBUG = portalConfig.debug || false;
    const log = DEBUG ? console.log.bind(console) : () => { };
    const warn = DEBUG ? console.warn.bind(console) : () => { };
    const error = console.error.bind(console); // Always log errors

    // Centralized error translation for consistent UI messaging
    function translateError(err) {
        if (!err) return 'Unexpected error';
        if (err.name === 'AbortError') return 'Request timed out';
        if (err.message) return err.message;
        return 'Request failed';
    }

    // Build fetch options with nonce + credentials, allowing overrides
    function buildFetchOptions(extra) {
        var opts = {
            headers: {
                'X-WP-Nonce': window.PORTAL_CONFIG.nonce
            },
            credentials: 'include'
        };
        if (extra && extra.headers) {
            for (var key in extra.headers) {
                if (Object.prototype.hasOwnProperty.call(extra.headers, key)) {
                    opts.headers[key] = extra.headers[key];
                }
            }
        }
        if (extra) {
            for (var k in extra) {
                if (k === 'headers') continue;
                if (Object.prototype.hasOwnProperty.call(extra, k)) {
                    opts[k] = extra[k];
                }
            }
        }
        return opts;
    }

    // AbortController guard for older browsers
    function makeAbortable(timeoutMs) {
        if (typeof AbortController === 'undefined') {
            return { controller: null, signal: null, cancel: function () { } };
        }
        var controller = new AbortController();
        var timer = setTimeout(function () { controller.abort(); }, timeoutMs);
        return {
            controller: controller,
            signal: controller.signal,
            cancel: function () { clearTimeout(timer); }
        };
    }

    log('[PSP] Portal initialized - v2.5.3+ UNIFIED');
    log('[PSP] API Base URL:', window.PORTAL_CONFIG.apiUrl);
    log('[PSP] User Role:', window.PORTAL_CONFIG.user ? window.PORTAL_CONFIG.user.role : 'unknown');

    /**
     * Unified Portal State Management
     * Central state for all sections
     */
    const PortalState = {
        sections: {},
        activeSection: null,
        isLoading: false,
        retryAttempts: {},
        maxRetries: 3,

        initSection: function (name) {
            this.sections[name] = {
                loaded: false,
                data: null,
                error: null,
                lastUpdate: null,
                retries: 0
            };
        },

        setSectionData: function (name, data) {
            if (!this.sections[name]) this.initSection(name);
            this.sections[name].loaded = true;
            this.sections[name].data = data;
            this.sections[name].error = null;
            this.sections[name].lastUpdate = Date.now();
            this.sections[name].retries = 0;
        },

        setSectionError: function (name, error) {
            if (!this.sections[name]) this.initSection(name);
            this.sections[name].error = error;
            this.sections[name].retries = (this.sections[name].retries || 0) + 1;
        },

        isSectionLoaded: function (name) {
            return this.sections[name] && this.sections[name].loaded;
        },

        getSectionData: function (name) {
            return this.sections[name] ? this.sections[name].data : null;
        },

        canRetrySection: function (name) {
            return (!this.sections[name] || this.sections[name].retries < this.maxRetries);
        }
    };

    /**
     * Cache Management
     * Prevents unnecessary API calls
     */
    const Cache = {
        data: {},
        ttl: 5 * 60 * 1000, // 5 minutes

        set: function (key, value) {
            this.data[key] = {
                value: value,
                timestamp: Date.now()
            };
        },

        get: function (key) {
            if (!this.data[key]) return null;
            if (Date.now() - this.data[key].timestamp > this.ttl) {
                delete this.data[key];
                return null;
            }
            return this.data[key].value;
        },

        clear: function (key) {
            if (key) {
                delete this.data[key];
            } else {
                this.data = {};
            }
        }
    };

    /**
     * Alert Manager - Handles user notifications
     * Enhanced with better positioning and auto-dismiss
     */
    class AlertManager {
        static show(message, type = 'info', duration = 5000) {
            const alertId = 'alert-' + Date.now();
            const alertHTML = `
                <div class="alert alert-${type}" id="${alertId}" role="alert">
                    <strong>${type.toUpperCase()}:</strong> ${message}
                    <button class="alert-close" onclick="this.parentElement.remove()" aria-label="Dismiss">×</button>
                </div>
            `;
            const container = document.getElementById('portal-alerts');
            if (!container) {
                warn('[PSP] Alert container not found');
                return;
            }
            container.insertAdjacentHTML('beforeend', alertHTML);
            if (duration > 0) {
                setTimeout(() => {
                    const el = document.getElementById(alertId);
                    if (el) {
                        el.classList.add('fade-out');
                        setTimeout(() => el.remove(), 300);
                    }
                }, duration);
            }
        }

        static success(message) {
            this.show(message, 'success');
        }

        static error(message) {
            this.show(message, 'error', 7000);
        }

        static info(message) {
            this.show(message, 'info');
        }

        static warning(message) {
            this.show(message, 'warning', 6000);
        }
    }

    window.AlertManager = AlertManager;
    window.Cache = Cache;

    /**
     * Performance Monitor - Track API response times
     * Helps identify slow endpoints
     */
    const PerformanceMonitor = {
        timings: {},

        start: function (label) {
            this.timings[label] = performance.now();
        },

        end: function (label) {
            if (!this.timings[label]) return 0;
            const duration = performance.now() - this.timings[label];
            log(`[PSP Performance] ${label}: ${duration.toFixed(2)}ms`);
            delete this.timings[label];
            return duration;
        }
    };

    window.PerformanceMonitor = PerformanceMonitor;

    /**
     * HTML Escape - Prevent XSS attacks
     * Converts special characters to HTML entities
     */
    function escapeHtml(text) {
        if (!text) return '';
        var map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return String(text).replace(/[&<>"']/g, function (m) { return map[m]; });
    }

    /**
     * Browser Compatibility & Feature Detection
     */
    const FeatureDetection = {
        supportsES6: () => {
            return typeof Promise !== 'undefined' && typeof Symbol !== 'undefined' && typeof Array.prototype.find === 'function';
        },
        supportsAsyncAwait: () => {
            // Without using eval, approximate by checking key async-era features
            return typeof Promise !== 'undefined' && typeof queueMicrotask === 'function' && typeof fetch === 'function';
        },
        supportsCSS3: () => {
            return window.CSS && window.CSS.supports('display', 'grid');
        },
        supportsLocalStorage: () => {
            try { localStorage.setItem('psp-test', '1'); localStorage.removeItem('psp-test'); return true; } catch (e) { return false; }
        },
        checkSupport: function () {
            const support = {
                es6: this.supportsES6(),
                async: this.supportsAsyncAwait(),
                css3: this.supportsCSS3(),
                storage: this.supportsLocalStorage()
            };
            log('[PSP] Browser Support:', support);

            const unsupported = Object.entries(support)
                .filter(([, isSupported]) => !isSupported)
                .map(([feature]) => feature);

            if (unsupported.length > 0) {
                // Suppress warnings - portal functions with fallbacks
                log('[PSP] Browser features verified - core portal compatible');
            }
            return support;
        }
    };

    window.FeatureDetection = FeatureDetection;

    /**
     * Retry API Request with Exponential Backoff
     * Automatically retries failed requests with intelligent delays
     */
    async function fetchWithRetry(url, options, maxRetries = 3) {
        let lastError;
        for (let attempt = 0; attempt < maxRetries; attempt++) {
            try {
                const response = await fetch(url, options);
                if (response.ok) return response;
                if (response.status === 401 || response.status === 403) {
                    throw new Error('Authentication failed');
                }
                lastError = new Error(`HTTP ${response.status}: ${response.statusText}`);
            } catch (error) {
                lastError = error;
                if (attempt < maxRetries - 1) {
                    const delay = Math.pow(2, attempt) * 1000;
                    log(`[PSP] Retry ${attempt + 1}/${maxRetries} after ${delay}ms`);
                    await new Promise(r => setTimeout(r, delay));
                }
            }
        }
        throw lastError || new Error('Max retries exceeded');
    }

    /**
     * Load Tab Content - Unified API integration point
     * Fetches data from REST API and renders appropriate section
     * Includes intelligent caching, retry logic, and timeout protection
     * 
     * @param {string} tabName - Section identifier (dashboard, tickets, services, partners, profile)
     * @param {boolean} forceReload - Bypass cache and force fresh data
     * @returns {Promise<void>}
     */
    async function loadTabContent(tabName, forceReload = false) {
        const tabContent = document.getElementById(tabName + '-content');
        if (!tabContent) {
            warn('[PSP] Tab content not found:', tabName);
            return;
        }

        const loading = tabContent.querySelector('.loading');
        const content = tabContent.querySelector('.content');

        if (!content) {
            error('[PSP] Content div not found for:', tabName);
            return;
        }

        // Skip if already loaded (unless forcing reload)
        if (!forceReload && content.innerHTML.trim()) {
            setUpdatedStatus(tabName, 'Up to date');
            return;
        }

        try {
            loading?.classList.add('show');
            setUpdatedStatus(tabName, 'Loading…');

            var userRole = window.PORTAL_CONFIG && window.PORTAL_CONFIG.user ? window.PORTAL_CONFIG.user.role : null;
            var userCompanyId = window.PORTAL_CONFIG && window.PORTAL_CONFIG.user ? window.PORTAL_CONFIG.user.company_id : null;

            // Map tab to endpoint
            let endpoint = null;
            switch (tabName) {
                case 'dashboard': endpoint = '/stats'; break;
                case 'tickets': endpoint = '/tickets'; break;
                case 'services': endpoint = '/services'; break;
                case 'partners': endpoint = '/companies'; break;
                case 'profile':
                    if (!window.PORTAL_CONFIG.user?.company_id) {
                        content.innerHTML = renderProfile(null, true);
                        loading?.classList.remove('show');
                        setUpdatedStatus(tabName, 'No company linked');
                        return;
                    }
                    endpoint = `/companies/${window.PORTAL_CONFIG.user.company_id}`;
                    break;
                case 'admin': endpoint = '/users'; break;
                default: endpoint = null; break;
            }

            // For partners without a linked company, avoid hitting the companies endpoint
            if (tabName === 'partners' && userRole === 'pool_safe_partner' && !userCompanyId) {
                content.innerHTML = renderProfile(null, true);
                loading?.classList.remove('show');
                setUpdatedStatus(tabName, 'No company linked');
                return;
            }

            if (!endpoint) {
                content.innerHTML = `<div class="text-center p-4">Content coming soon</div>`;
                loading?.classList.remove('show');
                return;
            }

            // Make API request with timeout and retry logic (AbortController guarded)
            // Reduced timeout from 8s to 6s for faster failure detection
            const abortable = makeAbortable(6000);

            const apiUrl = `${window.PORTAL_CONFIG.apiUrl}${endpoint}`;
            log('[PSP] Fetching:', apiUrl);

            // Use retry logic for robustness - reduced retries for faster response
            const maxRetries = PortalState.canRetrySection(tabName) ? 2 : 1;
            const response = await fetchWithRetry(apiUrl, buildFetchOptions({
                signal: abortable.signal
            }), maxRetries);

            abortable.cancel();

            const data = await response.json();
            log(`[PSP] Data for ${tabName}:`, data);

            // Update state
            PortalState.setSectionData(tabName, data);

            // Render based on tab
            if (tabName === 'dashboard') {
                content.innerHTML = renderDashboard(data);
            } else if (tabName === 'tickets') {
                content.innerHTML = renderTicketsSimple(data);
            } else if (tabName === 'services') {
                content.innerHTML = renderServicesSimple(data);
            } else if (tabName === 'partners') {
                content.innerHTML = renderPartnersSimple(data);
            } else if (tabName === 'profile') {
                content.innerHTML = renderProfile(data, false);
            } else {
                content.innerHTML = `<div class="text-center p-4">Tab data loaded: ${tabName}</div>`;
            }
            setUpdatedStatus(tabName, 'Updated ' + new Date().toLocaleTimeString());
            if (forceReload) {
                AlertManager.success(`${tabName} refreshed`);
            }

        } catch (err) {
            const friendly = translateError(err);
            error('[PSP] Error loading tab:', tabName, err);
            PortalState.setSectionError(tabName, friendly);

            if (err && err.name === 'AbortError') {
                AlertManager.error(`${tabName} request timeout - retrying...`);
                content.innerHTML = `
                    <div class="text-red-500 p-4 rounded border border-red-200 bg-red-50">
                        <strong>Request Timeout</strong>
                        <p class="text-sm mt-1">The request took too long. Please try refreshing the page.</p>
                    </div>
                `;
                setUpdatedStatus(tabName, 'Retrying...');
                if (PortalState.canRetrySection(tabName)) {
                    setTimeout(() => loadTabContent(tabName, true), 1500);
                }
                return;
            }

            if (PortalState.canRetrySection(tabName)) {
                AlertManager.error(`${tabName} failed - retrying...`);
                setUpdatedStatus(tabName, 'Retrying...');
                setTimeout(() => loadTabContent(tabName, true), 1500);
                return;
            }

            AlertManager.error(`Unable to load ${tabName}: ${friendly}`);
            content.innerHTML = `
                <div class="text-red-500 p-4 rounded border border-red-200 bg-red-50">
                    <strong>Could not load ${escapeHtml(tabName)}</strong>
                    <p class="text-sm mt-1">${escapeHtml(friendly)}</p>
                    <button onclick="location.reload()" class="btn-secondary mt-2">Reload Page</button>
                </div>
            `;
            setUpdatedStatus(tabName, 'Failed');
        } finally {
            loading?.classList.remove('show');
        }
    }

    /**
     * Update tab status
     */
    function setUpdatedStatus(tabName, text) {
        const label = document.getElementById(`updated-${tabName}`);
        if (label) {
            label.textContent = text;
        }
    }

    /**
     * Render profile section
     */
    function renderProfile(data, missingCompany = false) {
        if (missingCompany) {
            return `<div class="p-4 text-center text-gray-500">No company assigned to your account</div>`;
        }
        return `<div class="p-4">Profile data placeholder</div>`;
    }

    function getAllowedTabsForMode(mode) {
        if (mode === 'partner') return window.PORTAL_CONFIG.partnerTabs || ['dashboard', 'videos', 'tickets', 'services'];
        return window.PORTAL_CONFIG.supportTabs || ['dashboard', 'videos', 'tickets', 'services', 'partners'];
    }

    function applyRoleMode(mode) {
        const wrapper = document.querySelector('.psp-portal-wrapper');
        const allowed = getAllowedTabsForMode(mode);
        if (!wrapper || !allowed.length) return allowed;

        window.PORTAL_CONFIG.roleMode = mode;
        window.PORTAL_CONFIG.visibleTabs = allowed;
        window.PORTAL_CONFIG.userRole = mode === 'partner' ? 'pool_safe_partner' : 'pool_safe_support';
        if (window.PORTAL_CONFIG.user) {
            window.PORTAL_CONFIG.user.role = window.PORTAL_CONFIG.userRole;
        }

        // Update dataset for future reads
        wrapper.dataset.visibleTabs = JSON.stringify(allowed);
        wrapper.dataset.roleMode = mode;

        // Show/hide nav buttons
        const buttons = wrapper.querySelectorAll('.psp-tab-button');
        buttons.forEach(btn => {
            const tab = btn.getAttribute('data-tab');
            const shouldShow = allowed.includes(tab);
            const li = btn.closest('li');
            if (shouldShow) {
                li?.classList.remove('psp-hidden');
                btn.removeAttribute('tabindex');
            } else {
                li?.classList.add('psp-hidden');
                btn.setAttribute('tabindex', '-1');
            }
        });

        // Show/hide panels
        const panels = wrapper.querySelectorAll('.psp-tab-panel');
        panels.forEach(panel => {
            const id = panel.id || '';
            const tab = id.replace('-panel', '');
            const shouldShow = allowed.includes(tab);
            if (shouldShow) {
                panel.classList.remove('psp-hidden');
            } else {
                panel.classList.add('psp-hidden');
            }
        });

        // Ensure active tab is allowed
        let activeTab = wrapper.dataset.activeTab;
        if (!allowed.includes(activeTab)) {
            activeTab = allowed[0];
            wrapper.dataset.activeTab = activeTab;
        }

        // Update active classes
        buttons.forEach(btn => {
            const tab = btn.getAttribute('data-tab');
            const isActive = tab === activeTab;
            btn.classList.toggle('active', isActive);
            btn.setAttribute('aria-selected', isActive ? 'true' : 'false');
        });

        panels.forEach(panel => {
            const tab = (panel.id || '').replace('-panel', '');
            const isActive = tab === activeTab;
            panel.classList.toggle('active', isActive);
        });

        // Toggle pill UI states
        const roleButtons = wrapper.querySelectorAll('[data-role-switch]');
        roleButtons.forEach(btn => {
            const target = btn.getAttribute('data-role-switch');
            const isPressed = target === mode;
            btn.classList.toggle('active', isPressed);
            btn.setAttribute('aria-pressed', isPressed ? 'true' : 'false');
        });

        return allowed;
    }

    /**
     * Initialize on DOM Ready
     */
    document.addEventListener('DOMContentLoaded', function () {
        const initStart = performance.now();
        log('[PSP] DOM Content Loaded - Initializing Portal v2.5.3+');

        // De-duplicate default WP search IDs to silence console warning when themes render multiple search widgets
        try {
            const searchInputs = Array.from(document.querySelectorAll('input#search-field'));
            if (searchInputs.length > 1) {
                searchInputs.slice(1).forEach((input, idx) => {
                    const newId = `search-field-portal-${idx + 1}`;
                    input.id = newId;
                    const label = input.closest('label') || document.querySelector(`label[for="search-field"]`);
                    if (label && label.htmlFor === 'search-field') {
                        label.htmlFor = newId;
                    }
                });
                log(`[PSP] Deduped search-field IDs (${searchInputs.length} found)`);
            }
        } catch (e) {
            warn('[PSP] Search-field dedupe failed', e);
        }

        // Feature detection
        FeatureDetection.checkSupport();

        // Performance tracking
        PerformanceMonitor.start('Full Init');

        // Apply initial role mode and determine allowed tabs
        const initialRole = window.PORTAL_CONFIG.roleMode || (window.PORTAL_CONFIG.isAdmin ? 'support' : (window.PORTAL_CONFIG.userRole || 'partner'));
        const allowedTabs = applyRoleMode(initialRole);

        // Batch load visible sections (improved for performance)
        const loadQueue = allowedTabs.map(tab => () => loadTabContent(tab, false));

        // Load first tab immediately, others with slight delay to avoid network saturation
        if (loadQueue.length > 0) {
            loadQueue[0]();
            // Queue remaining loads with slight delays
            for (let i = 1; i < loadQueue.length; i++) {
                setTimeout(loadQueue[i], 100 * i);
            }
        }

        // Setup refresh button
        const refreshBtn = document.getElementById('global-refresh-btn');
        if (refreshBtn) {
            refreshBtn.addEventListener('click', async function () {
                log('[PSP] Manual refresh initiated');
                PerformanceMonitor.start('Manual Refresh');
                const tabs = applyRoleMode(window.PORTAL_CONFIG.roleMode || initialRole);

                try {
                    await Promise.all(tabs.map(tab => loadTabContent(tab, true)));
                    AlertManager.success('All sections refreshed!');
                    PerformanceMonitor.end('Manual Refresh');
                } catch (error) {
                    AlertManager.error('Refresh failed: ' + error.message);
                }
            });
        }

        const initDuration = PerformanceMonitor.end('Full Init');
        log(`[PSP] Portal initialization complete (${initDuration.toFixed(2)}ms)`);

        // Log active configuration for build/deployment verification
        const visibleTabsLog = allowedTabs.length ? allowedTabs : window.PORTAL_CONFIG.visibleTabs;
        log(`[PSP] ✓ Active Portal Config: v2.5.3+ | Visible Tabs: ${visibleTabsLog.join(', ')}`);

        // Wire admin role switcher
        const roleSwitchers = document.querySelectorAll('[data-role-switch]');
        roleSwitchers.forEach(btn => {
            btn.addEventListener('click', function () {
                const target = this.getAttribute('data-role-switch');
                const newTabs = applyRoleMode(target);
                // refresh currently active tab content when switching
                if (newTabs && newTabs.length) {
                    loadTabContent(newTabs[0], true);
                }
            });
        });

        // Event delegation for buttons with data-message attributes (deferred)
        setTimeout(function () {
            document.addEventListener('click', function (e) {
                if (e.target.classList.contains('contact-support-btn')) {
                    e.preventDefault();
                    AlertManager.info('Please contact support@poolsafeinc.com to set up your company profile.');
                }
                if (e.target.classList.contains('edit-profile-btn')) {
                    e.preventDefault();
                    AlertManager.info('Profile editing coming soon!');
                }
                if (e.target.classList.contains('new-ticket-trigger')) {
                    e.preventDefault();
                    document.querySelector('.new-ticket-btn')?.click();
                }
                if (e.target.classList.contains('schedule-service-btn')) {
                    e.preventDefault();
                    AlertManager.info('Service scheduling coming soon!');
                }
            });
        }, 500);

        // Expose globals
        window.loadTabContent = loadTabContent;
        window.AlertManager = AlertManager;
        window.setUpdatedStatus = setUpdatedStatus;

        // Show CSV Import Modal (fallback renderer)
        window.showCSVImportModal = function showCSVImportModal() {
            var container = document.getElementById('modal-container');
            if (!container) {
                AlertManager.error('Modal container missing');
                return;
            }

            var html = '';
            html += '<div class="modal show" onclick="if(event.target === this) closeCSVImportModal()">';
            html += '<div class="modal-content" onclick="event.stopPropagation()" style="max-width:700px;">';
            html += '<button class="modal-close" onclick="closeCSVImportModal()">✕</button>';
            html += '<h2 style="font-size:var(--psp-text-xl);font-weight:700;margin-bottom:var(--psp-spacing-md);">📊 Import Partners from CSV</h2>';
            html += '<div style="padding:var(--psp-spacing-md);margin-bottom:var(--psp-spacing-sm);">Please select a CSV file to import partners. This importer will create partner records based on the provided CSV columns.</div>';
            html += '<form id="csv-import-form"><input type="file" name="csvfile" accept=".csv" style="display:block;margin-bottom:var(--psp-spacing-md);" />';
            html += '<div style="text-align:right;"><button type="button" class="button" onclick="closeCSVImportModal()">Cancel</button> <button type="submit" class="button button-primary">Import</button></div>';
            html += '</form>';
            html += '</div></div>';

            container.innerHTML = html;

            var form = document.getElementById('csv-import-form');
            if (form) {
                form.addEventListener('submit', function (e) {
                    e.preventDefault();
                    AlertManager.info('CSV import started. Please use the main portal uploader for full processing.');
                    closeCSVImportModal();
                });
            }
        };

        // Render Partner Modal - external renderer for partner detail modal
        window.renderPartnerModal = function renderPartnerModal(partner, partnerTickets, partnerServices) {
            var container = document.getElementById('modal-container');
            if (!container) {
                AlertManager.error('Modal container missing');
                return;
            }

            var html = '';
            html += '<div class="modal show" onclick="if(event.target === this) closePartnerModal()">';
            html += '<div class="modal-content" onclick="event.stopPropagation()" style="max-width:900px;">';
            html += '<button class="modal-close" onclick="closePartnerModal()">✕</button>';
            html += '<h2 style="font-size:var(--psp-text-xl);font-weight:700;margin-bottom:var(--psp-spacing-sm);">' + escapeHtml(partner.company_name || partner.companyName || 'Partner') + '</h2>';
            html += '<div style="display:flex;gap:var(--psp-spacing-md);flex-wrap:wrap;">';
            html += '<div style="flex:1 1 320px;">';
            html += '<p style="margin:0;color:var(--psp-fg-light);">' + escapeHtml(partner.street_address || partner.address || '') + '</p>';
            html += '<p style="margin-top:var(--psp-spacing-sm);">Units: ' + escapeHtml(partner.units || partner.unit_count || '—') + '</p>';
            html += '</div>';
            html += '<div style="flex:1 1 320px;">';
            html += '<h3 style="margin:0 0 var(--psp-spacing-sm) 0;font-size:var(--psp-text-base);">Recent Tickets</h3>';
            html += '<ul style="margin:0;padding-left:1rem;">';
            (partnerTickets || []).slice(0, 6).forEach(function (t) { html += '<li>' + escapeHtml(t.title || t.subject || 'Ticket') + '</li>'; });
            html += '</ul>';
            html += '</div>';
            html += '</div>';
            html += '</div></div>';

            container.innerHTML = html;
        };

        // Show Partner Edit Modal - builds edit form without using template literals
        window.showPartnerEditModal = function showPartnerEditModal(partner, partnerId) {
            var container = document.getElementById('modal-container');
            if (!container) {
                AlertManager.error('Modal container missing');
                return;
            }

            var topColourOptions = [
                'Ice Blue', 'Classic Blue', 'BASF 4616 Yellow', 'PoolSafe Orange',
                'Trojan Blue', 'Lime Green', 'Coral', 'Yellow / Ice Blue',
                'Ice Blue / Yellow', 'Ducati Red', 'Yellow'
            ];
            var currentTopColour = partner.top_colour || partner.pool_colour || '';
            var lockTypeOptions = ['L&F', 'MAKE', 'Custom'];
            var currentLockType = partner.lock_type || partner.lock || '';

            var html = '';
            html += '<div class="modal show" onclick="if(event.target === this) closePartnerEditModal()">';
            html += '<div class="modal-content" onclick="event.stopPropagation()">';
            html += '<button class="modal-close" onclick="closePartnerEditModal()">✕</button>';
            html += '<h2 class="text-2xl font-bold text-gray-900 mb-4">Edit Partner: ' + escapeHtml(partner.company_name || partner.companyName || 'Partner') + '</h2>';

            html += '<form id="partner-edit-form">';
            html += '<div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">';
            html += '<div>';
            html += '<label class="block text-sm font-medium text-gray-700 mb-1">Company Name</label>';
            html += '<input type="text" name="company_name" value="' + escapeHtml(partner.company_name || '') + '" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-cyan-500 focus:border-cyan-500" />';
            html += '</div>';
            html += '<div>';
            html += '<label class="block text-sm font-medium text-gray-700 mb-1">Management Company</label>';
            html += '<input type="text" name="management_company" value="' + escapeHtml(partner.management_company || '') + '" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-cyan-500 focus:border-cyan-500" />';
            html += '</div>';
            html += '</div>';

            html += '<div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">';
            html += '<div>';
            html += '<label class="block text-sm font-medium text-gray-700 mb-1">Units</label>';
            html += '<input type="number" name="units" value="' + escapeHtml(partner.units || '') + '" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-cyan-500 focus:border-cyan-500" />';
            html += '</div>';
            html += '<div>';
            html += '<label class="block text-sm font-medium text-gray-700 mb-1">Phone</label>';
            html += '<input type="tel" name="phone" value="' + escapeHtml(partner.phone || '') + '" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-cyan-500 focus:border-cyan-500" />';
            html += '</div>';
            html += '</div>';

            html += '<div class="mb-4">';
            html += '<label class="block text-sm font-medium text-gray-700 mb-1">Email</label>';
            html += '<input type="email" name="company_email" value="' + escapeHtml(partner.email || partner.company_email || '') + '" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-cyan-500 focus:border-cyan-500" />';
            html += '</div>';

            // Top colour select
            html += '<div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">';
            html += '<div>';
            html += '<label class="block text-sm font-medium text-gray-700 mb-1">Top Colour</label>';
            html += '<select name="top_colour" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-cyan-500 focus:border-cyan-500">';
            html += '<option value="">Select...</option>';
            for (var i = 0; i < topColourOptions.length; i++) {
                var col = topColourOptions[i];
                html += '<option value="' + col + '"' + (currentTopColour === col ? ' selected' : '') + '>' + col + '</option>';
            }
            html += '<option value="__custom__"' + (topColourOptions.indexOf(currentTopColour) === -1 ? ' selected' : '') + '>Custom / Other</option>';
            html += '</select>';
            html += '</div>';

            html += '<div>';
            html += '<label class="block text-sm font-medium text-gray-700 mb-1">Custom Colour (if other)</label>';
            html += '<input type="text" name="top_colour_custom" value="' + escapeHtml(topColourOptions.indexOf(currentTopColour) === -1 ? currentTopColour : '') + '" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-cyan-500 focus:border-cyan-500" placeholder="Custom colour label" />';
            html += '</div>';
            html += '</div>';

            // Lock type and master code
            html += '<div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">';
            html += '<div>';
            html += '<label class="block text-sm font-medium text-gray-700 mb-1">Lock Type</label>';
            html += '<select name="lock_type" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-cyan-500 focus:border-cyan-500">';
            html += '<option value="">Select...</option>';
            for (var j = 0; j < lockTypeOptions.length; j++) {
                var lock = lockTypeOptions[j];
                html += '<option value="' + lock + '"' + (currentLockType === lock ? ' selected' : '') + '>' + lock + '</option>';
            }
            html += '</select>';
            html += '</div>';
            html += '<div>';
            html += '<label class="block text-sm font-medium text-gray-700 mb-1">Master Code</label>';
            html += '<input type="text" name="master_code" value="' + escapeHtml(partner.master_code || '') + '" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-cyan-500 focus:border-cyan-500" />';
            html += '</div>';
            html += '</div>';

            html += '<div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">';
            html += '<div>';
            html += '<label class="block text-sm font-medium text-gray-700 mb-1">Sub Master Code</label>';
            html += '<input type="text" name="sub_master_code" value="' + escapeHtml(partner.sub_master_code || '') + '" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-cyan-500 focus:border-cyan-500" />';
            html += '</div>';
            html += '<div>';
            html += '<label class="block text-sm font-medium text-gray-700 mb-1">Lock Part</label>';
            html += '<input type="text" name="lock_part" value="' + escapeHtml(partner.lock_part || '') + '" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-cyan-500 focus:border-cyan-500" />';
            html += '</div>';
            html += '</div>';

            html += '<div class="mb-4">';
            html += '<label class="block text-sm font-medium text-gray-700 mb-1">Key</label>';
            html += '<input type="text" name="key_code" value="' + escapeHtml(partner.key_code || partner.key || '') + '" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-cyan-500 focus:border-cyan-500" />';
            html += '</div>';

            html += '<div class="flex gap-2 mt-6">';
            html += '<button type="submit" class="btn btn-primary flex-1">Save Changes</button>';
            html += '<button type="button" class="btn btn-secondary flex-1" onclick="closePartnerEditModal()">Cancel</button>';
            html += '</div>';

            html += '</form>';
            html += '</div></div>';

            container.innerHTML = html;

            // Attach submit handler to use existing submitPartnerEdit if present
            var form = document.getElementById('partner-edit-form');
            if (form) {
                form.addEventListener('submit', function (e) {
                    e.preventDefault();
                    if (typeof window.submitPartnerEdit === 'function') {
                        window.submitPartnerEdit(e, partnerId);
                    } else {
                        AlertManager.info('Submit handler not available');
                    }
                });
            }
        };

        // Display CSV Results - fallback renderer for import results
        window.displayCSVResults = function displayCSVResults(data) {
            var resultsDiv = document.getElementById('csv-results');
            var contentDiv = document.getElementById('csv-results-content');
            if (!resultsDiv || !contentDiv) return;

            if (!data.details || data.details.length === 0) {
                contentDiv.innerHTML = '<div style="padding:var(--psp-spacing-sm);color:var(--psp-fg-light);">No details available.</div>';
                resultsDiv.style.display = 'block';
                return;
            }

            var html = '';
            html += '<div style="padding:var(--psp-spacing-sm) 0;border-bottom:1px solid var(--psp-border);">';
            html += '<p style="margin:0;font-weight:600;color:var(--psp-fg);">📋 Import Report: ' + (data.imported || 0) + ' imported, ' + (data.errors || 0) + ' error(s)</p>';
            html += '</div>';

            for (var i = 0; i < data.details.length; i++) {
                var detail = data.details[i];
                var isSuccess = detail.indexOf('✓') !== -1;
                var isError = detail.indexOf('✗') !== -1;
                var bgColor = isSuccess ? '#ecfeff' : isError ? '#fef2f2' : '#f9fafb';
                var borderColor = isSuccess ? '#06b6d4' : isError ? '#ef4444' : '#e5e7eb';
                var textColor = isSuccess ? '#0f172a' : isError ? '#7f1d1d' : '#4b5563';

                html += '<div style="padding:0.5rem 0.75rem;border-left:3px solid ' + borderColor + ';background:' + bgColor + ';color:' + textColor + ';font-size:0.85rem;line-height:1.4;margin-top:' + (i > 0 ? '0.5rem' : '0') + ';word-break:break-word;">';
                html += detail;
                html += '</div>';
            }

            contentDiv.innerHTML = html;
            resultsDiv.style.display = 'block';
        };

        // Dashboard renderer with enhanced styling and responsiveness
        window.renderDashboard = function renderDashboard(response) {
            var stats = response && response.data ? response.data : {};
            var html = '';
            html += '<div class="psp-grid psp-grid--4col">';

            // Stat card helper using CSS classes
            function statCard(label, value, icon, colorClass) {
                colorClass = colorClass || 'gray';
                return '<div class="psp-stat-card-styled">' +
                    '<span class="psp-stat-icon-lg" aria-hidden="true">' + icon + '</span>' +
                    '<p class="psp-stat-label-sm">' + label + '</p>' +
                    '<p class="psp-stat-value-lg">' + value + '</p>' +
                    '</div>';
            }

            html += statCard('Open Tickets', stats.open_tickets || 0, '🎫', 'blue');
            html += statCard('In Progress', stats.in_progress || 0, '⚙️', 'yellow');
            html += statCard('Closed This Month', stats.closed_month || 0, '✅', 'green');
            html += statCard('Avg Response Time', stats.avg_response || '—', '⏱️', 'purple');
            html += statCard('Total Partners', stats.total_partners || 0, '🏢', 'indigo');
            html += statCard('Active Partners', stats.active_partners || 0, '🟢', 'emerald');
            html += statCard('Services This Month', stats.services_this_month || 0, '🔧', 'orange');
            html += statCard('Active Users', stats.users_active || 0, '👥', 'cyan');

            html += '</div>';

            // Add quick stats summary if there are open tickets
            if (stats.open_tickets > 0 || stats.in_progress > 0) {
                html += '<div class="psp-alert psp-alert-info" style="margin-top: 20px;">';
                html += '<p style="margin: 0;"><strong>Action Required:</strong> You have ';
                html += (stats.open_tickets + stats.in_progress) + ' ticket(s) that need attention.</p>';
                html += '</div>';
            }

            return html;
        };

        window.renderTicketsSimple = function renderTicketsSimple(data) {
            var items = data && data.data ? data.data : data || [];
            if (!Array.isArray(items)) items = [];

            if (items.length === 0) {
                return '<div class="psp-empty-state" style="padding: 3rem 2rem; text-align: center; background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%); border-radius: 8px; border: 1px solid #bae6fd;">' +
                    '<div style="font-size: 4rem; margin-bottom: 1rem;">🎫</div>' +
                    '<h3 style="color: #0c4a6e; font-size: 1.5rem; font-weight: 700; margin: 0 0 0.5rem 0;">No tickets yet</h3>' +
                    '<p style="color: #075985; font-size: 1rem; margin: 0 0 1.5rem 0;">Get help by creating your first support ticket</p>' +
                    '<button class="btn-primary new-ticket-trigger" style="margin-top: 0;">✚ Create New Ticket</button>' +
                    '</div>';
            }

            var html = '<div class="psp-action-bar">';
            html += '<div class="psp-action-bar-left">';
            html += '<select id="ticket-status-filter" class="psp-select" onchange="filterTickets(this.value);" style="width: 100%;">';
            html += '<option value="all">All Tickets</option>';
            html += '<option value="open">Open</option>';
            html += '<option value="in_progress">In Progress</option>';
            html += '<option value="resolved">Resolved</option>';
            html += '<option value="closed">Closed</option>';
            html += '</select>';
            html += '</div>';
            html += '<div class="psp-action-bar-right">';
            html += '<span class="psp-count-badge">' + items.length + ' Ticket' + (items.length !== 1 ? 's' : '') + '</span>';
            html += '</div>';
            html += '</div>';

            html += '<div class="psp-table-wrapper">';
            html += '<table class="psp-table">';
            html += '<thead>';
            html += '<tr>';
            html += '<th>Ticket</th>';
            html += '<th>Status</th>';
            html += '<th>Priority</th>';
            html += '<th>Created</th>';
            html += '<th style="text-align: right;">Actions</th>';
            html += '</tr>';
            html += '</thead>';
            html += '<tbody>';

            items.forEach(function (ticket, index) {
                var status = (ticket.status || 'open').replace('_', ' ');
                var statusClass = ticket.status === 'open' ? 'psp-badge--info' :
                    ticket.status === 'in_progress' ? 'psp-badge--warning' : 'psp-badge--success';
                var priority = ticket.priority || 'medium';
                var priorityClass = priority === 'high' || priority === 'critical' ? 'psp-badge--danger' : priority === 'low' ? 'psp-badge--info' : 'psp-badge--warning';
                var createdDate = ticket.created_at || ticket.createdAt || 'N/A';
                var ticketId = ticket.ticket_number || ticket.id;

                html += '<tr class="ticket-row" data-status="' + ticket.status + '" data-ticket-id="' + ticketId + '">';
                html += '<td><div style="font-weight: 600; color: #111827;">' + escapeHtml(ticket.title || ticket.subject || 'Untitled') + '</div><div style="font-size: 12px; color: #9ca3af; margin-top: 4px;">#' + ticketId + '</div></td>';
                html += '<td><span class="psp-badge ' + statusClass + '">' + status + '</span></td>';
                html += '<td><span class="psp-badge ' + priorityClass + '">' + priority + '</span></td>';
                html += '<td style="color: #6b7280; font-size: 14px;">' + createdDate + '</td>';
                html += '<td style="text-align: right;"><button class="view-ticket-btn btn-primary" data-ticket-id="' + ticketId + '" style="padding: 6px 16px; font-size: 13px;">View</button></td>';
                html += '</tr>';
            });

            html += '</tbody>';
            html += '</table>';
            html += '</div>';
            html += '<script>';
            html += 'window.filterTickets = function(status) {';
            html += '  var rows = document.querySelectorAll(\'.ticket-row\');';
            html += '  rows.forEach(function(row) {';
            html += '    var rowStatus = row.getAttribute(\'data-status\') || \'\';';
            html += '    if (status === \'all\' || rowStatus === status) {';
            html += '      row.style.display = \'\';';
            html += '    } else {';
            html += '      row.style.display = \'none\';';
            html += '    }';
            html += '  });';
            html += '};';
            html += 'setTimeout(function() {';
            html += '  document.querySelectorAll(\'.view-ticket-btn\').forEach(function(btn) {';
            html += '    btn.addEventListener(\'click\', function(e) {';
            html += '      e.stopPropagation();';
            html += '      var ticketId = this.getAttribute(\'data-ticket-id\');';
            html += '      alert(\'View ticket #\' + ticketId + \'\\n\\nTicket details coming soon!\');';
            html += '    });';
            html += '  });';
            html += '  document.querySelectorAll(\'.ticket-row\').forEach(function(row) {';
            html += '    row.addEventListener(\'click\', function() {';
            html += '      var ticketId = this.getAttribute(\'data-ticket-id\');';
            html += '      alert(\'Ticket #\' + ticketId + \'\\n\\nFull ticket view coming soon!\');';
            html += '    });';
            html += '  });';
            html += '}, 100);';
            html += '</script>';
            return html;
        };

        window.renderServicesSimple = function renderServicesSimple(data) {
            var items = data && data.data ? data.data : data || [];
            if (!Array.isArray(items)) items = [];

            if (items.length === 0) {
                return '<div class="psp-empty-state" style="padding: 3rem 2rem; text-align: center; background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%); border-radius: 8px; border: 1px solid #bbf7d0;">' +
                    '<div style="font-size: 4rem; margin-bottom: 1rem;">🔧</div>' +
                    '<h3 style="color: #14532d; font-size: 1.5rem; font-weight: 700; margin: 0 0 0.5rem 0;">No service records</h3>' +
                    '<p style="color: #166534; font-size: 1rem; margin: 0 0 1.5rem 0;">Schedule your first service visit to begin tracking</p>' +
                    '<button class="btn-primary schedule-service-btn" style="margin-top: 0;">📅 Schedule Service</button>' +
                    '</div>';
            }

            var html = '<div class="psp-grid psp-grid--2col">';
            items.forEach(function (service) {
                var serviceDate = service.service_date || service.createdAt || 'N/A';
                var serviceType = service.service_type || service.type || 'Service';
                var status = service.status || 'completed';
                var statusClass = status === 'completed' ? 'psp-badge--success' : status === 'scheduled' ? 'psp-badge--info' : 'psp-badge--warning';

                html += '<div class="psp-card">';
                html += '<div style="display: flex; align-items: start; justify-content: space-between; margin-bottom: 16px;">';
                html += '<h3 style="font-weight: 600; color: #111827; margin: 0; font-size: 18px;">' + escapeHtml(serviceType) + '</h3>';
                html += '<span class="psp-badge ' + statusClass + '">' + status + '</span>';
                html += '</div>';
                html += '<div style="display: flex; align-items: center; gap: 8px; color: #6b7280; font-size: 14px; margin-bottom: 12px;">';
                html += '<span>📅</span><span>' + serviceDate + '</span>';
                html += '</div>';
                if (service.notes) {
                    html += '<p style="font-size: 14px; color: #6b7280; margin: 0; line-height: 1.5; padding-top: 12px; border-top: 1px solid #f3f4f6;">' + escapeHtml(service.notes.substring(0, 120)) + (service.notes.length > 120 ? '...' : '') + '</p>';
                }
                if (service.technician) {
                    html += '<div style="margin-top: 12px; padding-top: 12px; border-top: 1px solid #f3f4f6; font-size: 14px; color: #6b7280;">';
                    html += '<span>👤 Technician: </span><span style="font-weight: 500; color: #374151;">' + escapeHtml(service.technician) + '</span>';
                    html += '</div>';
                }
                html += '</div>';
            });
            html += '</div>';
            return html;
        };

        window.renderProfile = function renderProfile(data, noCompany) {
            if (noCompany) {
                return '<div class="psp-empty-state" style="padding: 3rem 2rem; text-align: center; background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%); border-radius: 8px; border: 1px solid #fbbf24;">' +
                    '<div style="font-size: 4rem; margin-bottom: 1rem;">👤</div>' +
                    '<h3 style="color: #78350f; font-size: 1.5rem; font-weight: 700; margin: 0 0 0.5rem 0;">No company assigned</h3>' +
                    '<p style="color: #92400e; font-size: 1rem; margin: 0 0 1.5rem 0;">Contact support to link your company profile</p>' +
                    '<button class="btn-primary contact-support-btn" style="margin-top: 0;">📞 Contact Support</button>' +
                    '</div>';
            }

            var company = data && data.data ? data.data : data || {};
            if (!company.id && !company.company_name) {
                return '<div style="padding: 2rem; text-align: center; color: #6b7280;">No profile information available</div>';
            }

            var companyName = company.company_name || company.companyName || 'Unnamed Company';
            var html = '<div style="max-width: 900px;">';
            html += '<div class="psp-card" style="margin-bottom: 2rem;">';
            html += '<div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 20px;">';
            html += '<div style="display: flex; align-items: center; gap: 16px;">';
            html += '<div style="width: 64px; height: 64px; background: linear-gradient(135deg, #3b82f6, #1e40af); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 28px; color: white; font-weight: 700;">' + (companyName.charAt(0).toUpperCase()) + '</div>';
            html += '<h3 style="font-weight: 700; color: #111827; margin: 0; font-size: 30px;">' + escapeHtml(companyName) + '</h3>';
            html += '</div>';
            html += '<button class="btn-primary edit-profile-btn">✏️ Edit Profile</button>';
            html += '</div>';
            html += '<div class="psp-grid psp-grid--2col">';

            if (company.email) {
                html += '<div>';
                html += '<label style="display: block; font-size: 12px; font-weight: 600; color: #6b7280; margin-bottom: 8px;">Email</label>';
                html += '<p style="margin: 0; color: #111827; word-break: break-all;">' + escapeHtml(company.email) + '</p>';
                html += '</div>';
            }

            if (company.street_address || company.address) {
                html += '<div>';
                html += '<label style="display: block; font-size: 12px; font-weight: 600; color: #6b7280; margin-bottom: 8px;">Address</label>';
                html += '<p style="margin: 0; color: #111827;">' + escapeHtml(company.street_address || company.address) + '</p>';
                html += '</div>';
            }

            html += '</div></div></div>';
            return html;

            if (company.phone) {
                html += '<div>';
                html += '<label style="display:block;font-size:0.875rem;font-weight:600;color:#4b5563;margin-bottom:0.5rem;">Phone</label>';
                html += '<p style="margin:0;color:#111827;">' + escapeHtml(company.phone) + '</p>';
                html += '</div>';
            }

            if (company.city || company.state) {
                html += '<div>';
                html += '<label style="display:block;font-size:0.875rem;font-weight:600;color:#4b5563;margin-bottom:0.5rem;">Location</label>';
                var location = (company.city || '') + (company.city && company.state ? ', ' : '') + (company.state || '');
                html += '<p style="margin:0;color:#111827;">' + location + '</p>';
                html += '</div>';
            }

            if (company.units) {
                html += '<div>';
                html += '<label style="display:block;font-size:0.875rem;font-weight:600;color:#4b5563;margin-bottom:0.5rem;">Units</label>';
                html += '<p style="margin:0;color:#111827;">' + escapeHtml(company.units) + '</p>';
                html += '</div>';
            }

            html += '</div>';
            html += '</div>';

            // Additional Info
            if (company.address || company.streetAddress) {
                html += '<div style="background:white;border:1px solid #e5e7eb;border-radius:0.5rem;padding:1.5rem;margin-bottom:2rem;">';
                html += '<h4 style="font-weight:600;color:#111827;margin:0 0 1rem 0;">Address</h4>';
                html += '<p style="margin:0;color:#4b5563;line-height:1.6;">' + escapeHtml(company.address || company.streetAddress) + '</p>';
                html += '</div>';
            }

            html += '</div>';
            return html;
        };

        window.renderPartnersSimple = function renderPartnersSimple(data) {
            var items = data && data.data ? data.data : data || [];
            if (!Array.isArray(items)) items = [];

            if (items.length === 0) {
                return '<div style="padding:2rem;text-align:center;">' +
                    '<div style="font-size:3rem;margin-bottom:1rem;">🏢</div>' +
                    '<p style="color:#4b5563;font-size:1.125rem;">No partners available</p>' +
                    '</div>';
            }

            var html = '<div style="margin-bottom:1.5rem;display:flex;gap:1rem;align-items:center;flex-wrap:wrap;">';
            html += '<div style="flex:1;min-width:300px;">';
            html += '<input type="text" id="partner-search" placeholder="🔍 Search partners by name or location..." style="width:100%;padding:0.75rem 1rem;border:1px solid #d1d5db;border-radius:0.5rem;font-size:0.875rem;transition:all 0.2s;" onfocus="this.style.borderColor=\'#3b82f6\';this.style.boxShadow=\'0 0 0 3px rgba(59,130,246,0.1)\';" onblur="this.style.borderColor=\'#d1d5db\';this.style.boxShadow=\'none\';" oninput="filterPartners(this.value);">';
            html += '</div>';
            html += '<div style="display:flex;gap:0.5rem;">';
            html += '<button onclick="document.getElementById(\'partner-search\').value=\'\';filterPartners(\'\');" style="padding:0.75rem 1rem;background:#f3f4f6;border:1px solid #d1d5db;border-radius:0.5rem;font-size:0.875rem;font-weight:500;color:#374151;cursor:pointer;transition:all 0.2s;" onmouseover="this.style.background=\'#e5e7eb\';" onmouseout="this.style.background=\'#f3f4f6\';">Clear</button>';
            html += '<span style="padding:0.75rem 1rem;background:#eff6ff;border:1px solid #bfdbfe;border-radius:0.5rem;font-size:0.875rem;font-weight:600;color:#1e40af;">' + items.length + ' Partner' + (items.length !== 1 ? 's' : '') + '</span>';
            html += '</div>';
            html += '</div>';
            html += '<div style="overflow-x:auto;margin-bottom:2rem;">';
            html += '<table style="width:100%;border-collapse:collapse;background:white;border:1px solid #e5e7eb;border-radius:0.5rem;box-shadow:0 1px 3px 0 rgba(0,0,0,0.1);">';
            html += '<thead>';
            html += '<tr style="background:#f9fafb;border-bottom:2px solid #e5e7eb;">';
            html += '<th style="padding:0.75rem 1rem;text-align:left;font-weight:600;color:#374151;font-size:0.875rem;">Company Name</th>';
            html += '<th style="padding:0.75rem 1rem;text-align:left;font-weight:600;color:#374151;font-size:0.875rem;">Location</th>';
            html += '<th style="padding:0.75rem 1rem;text-align:left;font-weight:600;color:#374151;font-size:0.875rem;">Contact</th>';
            html += '<th style="padding:0.75rem 1rem;text-align:left;font-weight:600;color:#374151;font-size:0.875rem;">Units</th>';
            html += '<th style="padding:0.75rem 1rem;text-align:left;font-weight:600;color:#374151;font-size:0.875rem;">Status</th>';
            html += '<th style="padding:0.75rem 1rem;text-align:right;font-weight:600;color:#374151;font-size:0.875rem;">ID</th>';
            html += '</tr>';
            html += '</thead>';
            html += '<tbody>';

            items.forEach(function (partner, index) {
                var companyName = partner.company_name || partner.companyName || 'Unnamed Partner';
                var city = partner.city || '';
                var state = partner.state || '';
                var location = city || state ? city + (city && state ? ', ' : '') + state : '—';
                var units = partner.units || '—';
                var contactEmail = partner.contact_email || partner.contactEmail || '';
                var contactPhone = partner.contact_phone || partner.contactPhone || '';
                var contact = contactEmail || contactPhone || '—';
                var status = partner.active_status === false ? 'Inactive' : 'Active';
                var statusColor = partner.active_status === false ? '#dc2626' : '#10b981';
                var rowBg = index % 2 === 0 ? '#ffffff' : '#f9fafb';
                var searchData = (companyName + ' ' + location).toLowerCase();
                var partnerId = partner.id || '';

                html += '<tr class="partner-row" data-search="' + searchData + '" data-partner-id="' + partnerId + '" style="border-bottom:1px solid #e5e7eb;background:' + rowBg + ';transition:background 0.15s ease;cursor:pointer;" onmouseover="this.style.background=\'#f3f4f6\';" onmouseout="this.style.background=\'' + rowBg + '\';">';
                html += '<td style="padding:0.75rem 1rem;color:#111827;font-weight:500;">' + companyName + '</td>';
                html += '<td style="padding:0.75rem 1rem;color:#4b5563;font-size:0.875rem;">' + location + '</td>';
                html += '<td style="padding:0.75rem 1rem;color:#4b5563;font-size:0.875rem;">' + contact + '</td>';
                html += '<td style="padding:0.75rem 1rem;color:#4b5563;font-size:0.875rem;">' + units + '</td>';
                html += '<td style="padding:0.75rem 1rem;"><span style="display:inline-block;padding:0.25rem 0.75rem;border-radius:9999px;font-size:0.75rem;font-weight:600;background:' + (partner.active_status === false ? '#fee2e2' : '#d1fae5') + ';color:' + statusColor + ';">' + status + '</span></td>';
                html += '<td style="padding:0.75rem 1rem;text-align:right;color:#9ca3af;font-size:0.875rem;">' + (partner.id || '') + '</td>';
                html += '</tr>';
            });

            html += '</tbody>';
            html += '</table>';
            html += '</div>';
            html += '<script>';
            html += 'window.filterPartners = function(query) {';
            html += '  var rows = document.querySelectorAll(\'.partner-row\');';
            html += '  var searchTerm = query.toLowerCase();';
            html += '  var visibleCount = 0;';
            html += '  rows.forEach(function(row) {';
            html += '    var searchData = row.getAttribute(\'data-search\') || \'\';';
            html += '    if (searchData.indexOf(searchTerm) !== -1) {';
            html += '      row.style.display = \'\';';
            html += '      visibleCount++;';
            html += '    } else {';
            html += '      row.style.display = \'none\';';
            html += '    }';
            html += '  });';
            html += '};';
            html += 'window.exportPartners = function() {';
            html += '  var rows = document.querySelectorAll(\'.partner-row\');';
            html += '  var csv = \'Company Name,Location,Contact,Units,Status,ID\\n\';';
            html += '  rows.forEach(function(row) {';
            html += '    if (row.style.display !== \'none\') {';
            html += '      var cells = row.querySelectorAll(\'td\');';
            html += '      var rowData = [];';
            html += '      cells.forEach(function(cell, i) {';
            html += '        if (i < 6) {';
            html += '          var text = cell.innerText.replace(/,/g, \';\');';
            html += '          rowData.push(text);';
            html += '        }';
            html += '      });';
            html += '      csv += rowData.join(\',\') + \'\\n\';';
            html += '    }';
            html += '  });';
            html += '  var blob = new Blob([csv], {type: \'text/csv\'});';
            html += '  var link = document.createElement(\'a\');';
            html += '  link.href = URL.createObjectURL(blob);';
            html += '  link.download = \'partners_export.csv\';';
            html += '  link.click();';
            html += '};';
            html += 'setTimeout(function() {';
            html += '  document.querySelectorAll(\'.partner-row\').forEach(function(row) {';
            html += '    row.addEventListener(\'click\', function() {';
            html += '      var partnerId = this.getAttribute(\'data-partner-id\');';
            html += '      var cells = this.querySelectorAll(\'td\');';
            html += '      var companyName = cells[0] ? cells[0].innerText : \'Unknown\';';
            html += '      var location = cells[1] ? cells[1].innerText : \'—\';';
            html += '      var contact = cells[2] ? cells[2].innerText : \'—\';';
            html += '      var units = cells[3] ? cells[3].innerText : \'—\';';
            html += '      var status = cells[4] ? cells[4].innerText : \'—\';';
            html += '      var details = \'Company: \' + companyName + \'\\n\';';
            html += '      details += \'Location: \' + location + \'\\n\';';
            html += '      details += \'Contact: \' + contact + \'\\n\';';
            html += '      details += \'Units: \' + units + \'\\n\';';
            html += '      details += \'Status: \' + status + \'\\n\';';
            html += '      details += \'ID: \' + partnerId;';
            html += '      alert(details);';
            html += '    });';
            html += '  });';
            html += '}, 100);';
            html += '</script>';
            return html;
        };

        /**
         * Unified Portal Initialization
         * Sets up section routing, event listeners, and auto-loading
         */
        function initializeUnifiedPortal() {
            log('[PSP] Initializing unified portal architecture...');

            // Initialize all sections in state
            // Only initialize sections that exist in the streamlined UI
            const sections = ['dashboard', 'tickets', 'services', 'partners'];
            sections.forEach(section => PortalState.initSection(section));

            // Setup section toggle listeners
            const toggleButtons = document.querySelectorAll('.section-toggle-btn');
            toggleButtons.forEach(btn => {
                btn.addEventListener('click', function () {
                    const isCollapsed = this.classList.toggle('collapsed');
                    const section = this.parentElement?.parentElement?.nextElementSibling;
                    if (section) {
                        section.classList.toggle('collapsed', isCollapsed);
                    }
                });
            });

            // Setup smart tab content loading
            const tabContents = document.querySelectorAll('.tab-content');
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting && !entry.target.dataset.loaded) {
                        const tabName = entry.target.id.replace('-content', '');
                        const content = entry.target.querySelector('.content');
                        if (!content || !content.innerHTML.trim()) {
                            log('[PSP] Lazy-loading section:', tabName);
                            loadTabContent(tabName, false);
                            entry.target.dataset.loaded = 'true';
                        }
                    }
                });
            }, { threshold: 0.1 });

            tabContents.forEach(tab => observer.observe(tab));

            // Back to top button functionality
            const backToTopBtn = document.getElementById('back-to-top');
            if (backToTopBtn) {
                window.addEventListener('scroll', () => {
                    backToTopBtn.style.display = window.scrollY > 300 ? 'block' : 'none';
                });
                backToTopBtn.addEventListener('click', () => {
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                });
            }

            log('[PSP] ✓ Unified portal initialized successfully');
        }

        /**
         * Auto-initialize when DOM is ready
         */
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', initializeUnifiedPortal);
        } else {
            initializeUnifiedPortal();
        }

        // Expose to global scope
        window.PortalState = PortalState;
        window.loadTabContent = loadTabContent;

        // ============================================================================
        // VIDEO UPLOAD FUNCTIONALITY
        // ============================================================================

        /**
         * Video Upload Manager
         * Handles all video upload operations including drag-drop, file selection,
         * validation, metadata collection, and upload processing.
         */
        window.VideoUploadManager = {
            currentFile: null,
            uploadInProgress: false,
            maxFileSize: 524288000, // 500 MB in bytes
            allowedMimes: ['video/mp4', 'video/webm', 'video/quicktime', 'video/x-matroska'],
            allowedExtensions: ['.mp4', '.webm', '.mov', '.mkv'],

            // Initialize video upload listeners
            init: function () {
                const dropzone = document.getElementById('psp-video-dropzone');
                const fileInput = document.getElementById('psp-video-file-input');

                if (!dropzone || !fileInput) {
                    console.warn('[PSP] Video upload elements not found in DOM');
                    return;
                }

                // Drag and drop handlers
                dropzone.addEventListener('dragover', (e) => {
                    e.preventDefault();
                    dropzone.classList.add('psp-video-dropzone--active');
                });

                dropzone.addEventListener('dragleave', () => {
                    dropzone.classList.remove('psp-video-dropzone--active');
                });

                dropzone.addEventListener('drop', (e) => {
                    e.preventDefault();
                    dropzone.classList.remove('psp-video-dropzone--active');
                    if (e.dataTransfer.files.length) {
                        this.handleFileSelect(e.dataTransfer.files[0]);
                    }
                });

                // Click to select file
                dropzone.addEventListener('click', () => {
                    fileInput.click();
                });

                fileInput.addEventListener('change', (e) => {
                    if (e.target.files.length) {
                        this.handleFileSelect(e.target.files[0]);
                    }
                });

                log('[PSP] Video upload listeners initialized');
            },

            // Validate and handle file selection
            handleFileSelect: function (file) {
                // Validate file
                const validation = this.validateFile(file);
                if (!validation.valid) {
                    this.showError(validation.message);
                    return;
                }

                this.currentFile = file;
                this.showFileInfo();
                this.showMetadataForm();
            },

            // Validate file against requirements
            validateFile: function (file) {
                if (!file) {
                    return { valid: false, message: 'No file selected' };
                }

                // Check file size
                if (file.size > this.maxFileSize) {
                    return {
                        valid: false,
                        message: `File too large (${(file.size / 1024 / 1024).toFixed(1)} MB). Maximum is 500 MB.`
                    };
                }

                // Check file type
                const extension = '.' + file.name.split('.').pop().toLowerCase();
                if (!this.allowedExtensions.includes(extension)) {
                    return {
                        valid: false,
                        message: `File type not supported. Allowed types: MP4, WebM, MOV, MKV`
                    };
                }

                return { valid: true };
            },

            // Display selected file information
            showFileInfo: function () {
                if (!this.currentFile) return;

                const fileInfo = document.getElementById('psp-video-file-info');
                const filename = document.getElementById('psp-video-filename');
                const filesize = document.getElementById('psp-video-filesize');

                if (fileInfo && filename && filesize) {
                    filename.textContent = this.currentFile.name;
                    filesize.textContent = (this.currentFile.size / 1024 / 1024).toFixed(2) + ' MB';
                    fileInfo.classList.remove('is-hidden');
                }
            },

            // Show metadata form
            showMetadataForm: function () {
                const form = document.getElementById('psp-video-metadata-form');
                const dropzone = document.getElementById('psp-video-dropzone');
                const uploadForm = document.getElementById('psp-video-upload-form-container');
                const uploadBtn = document.getElementById('psp-video-submit-btn');

                if (form) form.classList.remove('is-hidden');
                if (dropzone) dropzone.classList.add('is-hidden');
                if (uploadForm) uploadForm.style.opacity = '0.7';
                if (uploadBtn) uploadBtn.classList.remove('is-hidden');
            },

            // Hide metadata form
            hideMetadataForm: function () {
                const form = document.getElementById('psp-video-metadata-form');
                if (form) form.classList.add('is-hidden');
            },

            // Clear selected file
            clearFile: function () {
                this.currentFile = null;
                const fileInput = document.getElementById('psp-video-file-input');
                const fileInfo = document.getElementById('psp-video-file-info');
                const uploadForm = document.getElementById('psp-video-upload-form-container');
                const uploadBtn = document.getElementById('psp-video-submit-btn');
                const dropzone = document.getElementById('psp-video-dropzone');

                if (fileInput) fileInput.value = '';
                if (fileInfo) fileInfo.classList.add('is-hidden');
                if (uploadForm) uploadForm.style.opacity = '1';
                if (uploadBtn) uploadBtn.classList.add('is-hidden');
                if (dropzone) dropzone.classList.remove('is-hidden');

                this.hideMetadataForm();
            },

            // Show error message
            showError: function (message) {
                const errorDiv = document.getElementById('psp-video-error');
                if (errorDiv) {
                    errorDiv.textContent = message;
                    errorDiv.classList.remove('is-hidden');
                    setTimeout(() => {
                        errorDiv.classList.add('is-hidden');
                    }, 5000);
                }
            },

            // Validate metadata
            validateMetadata: function () {
                const title = document.getElementById('psp-video-title').value.trim();
                const titleError = document.getElementById('psp-video-title-error');

                if (!title) {
                    if (titleError) {
                        titleError.textContent = 'Title is required';
                        titleError.classList.remove('is-hidden');
                    }
                    return false;
                }

                if (titleError) {
                    titleError.classList.add('is-hidden');
                }

                return true;
            },

            // Upload video to server
            upload: function () {
                if (!this.currentFile) {
                    this.showError('No file selected');
                    return;
                }

                if (!this.validateMetadata()) {
                    return;
                }

                this.uploadInProgress = true;

                const formData = new FormData();
                formData.append('file', this.currentFile);
                formData.append('title', document.getElementById('psp-video-title').value.trim());
                formData.append('description', document.getElementById('psp-video-description').value.trim());
                formData.append('duration', document.getElementById('psp-video-duration').value.trim());
                formData.append('thumbnail', document.getElementById('psp-video-thumbnail').value.trim());
                formData.append('_wpnonce', window.PORTAL_CONFIG.nonce);

                this.showProgress();

                const xhr = new XMLHttpRequest();

                // Track upload progress
                xhr.upload.addEventListener('progress', (e) => {
                    if (e.lengthComputable) {
                        const percentComplete = Math.round((e.loaded / e.total) * 100);
                        const progressBar = document.getElementById('psp-video-upload-bar');
                        const progressPercent = document.getElementById('psp-video-upload-percent');

                        if (progressBar) progressBar.style.width = percentComplete + '%';
                        if (progressPercent) progressPercent.textContent = percentComplete + '%';
                    }
                });

                // Handle completion
                xhr.addEventListener('load', () => {
                    if (xhr.status === 200) {
                        try {
                            const response = JSON.parse(xhr.responseText);
                            if (response.success) {
                                this.showSuccess(response.message || 'Video uploaded successfully!');
                            } else {
                                this.showError(response.message || 'Upload failed');
                                this.hideProgress();
                            }
                        } catch (e) {
                            this.showError('Invalid response from server');
                            this.hideProgress();
                        }
                    } else {
                        this.showError('Upload failed with status ' + xhr.status);
                        this.hideProgress();
                    }
                    this.uploadInProgress = false;
                });

                // Handle errors
                xhr.addEventListener('error', () => {
                    this.showError('Network error during upload');
                    this.hideProgress();
                    this.uploadInProgress = false;
                });

                xhr.addEventListener('abort', () => {
                    this.showError('Upload cancelled');
                    this.hideProgress();
                    this.uploadInProgress = false;
                });

                // Start upload
                xhr.open('POST', window.PORTAL_CONFIG.apiUrl + '/videos', true);
                xhr.send(formData);

                log('[PSP] Video upload started');
            },

            // Show upload progress UI
            showProgress: function () {
                const uploadForm = document.getElementById('psp-video-upload-form-container');
                const uploadProgress = document.getElementById('psp-video-upload-progress');
                const uploadBtn = document.getElementById('psp-video-submit-btn');

                if (uploadForm) uploadForm.classList.add('is-hidden');
                if (uploadProgress) uploadProgress.classList.remove('is-hidden');
                if (uploadBtn) uploadBtn.disabled = true;
            },

            // Hide upload progress UI
            hideProgress: function () {
                const uploadForm = document.getElementById('psp-video-upload-form-container');
                const uploadProgress = document.getElementById('psp-video-upload-progress');
                const uploadBtn = document.getElementById('psp-video-submit-btn');

                if (uploadForm) uploadForm.classList.remove('is-hidden');
                if (uploadProgress) uploadProgress.classList.add('is-hidden');
                if (uploadBtn) uploadBtn.disabled = false;
            },

            // Show success message
            showSuccess: function (message) {
                const uploadForm = document.getElementById('psp-video-upload-form-container');
                const uploadProgress = document.getElementById('psp-video-upload-progress');
                const successDiv = document.getElementById('psp-video-success');
                const successMsg = document.getElementById('psp-video-success-message');

                if (uploadForm) uploadForm.classList.add('is-hidden');
                if (uploadProgress) uploadProgress.classList.add('is-hidden');
                if (successDiv) successDiv.classList.remove('is-hidden');
                if (successMsg) successMsg.textContent = message;

                log('[PSP] Video uploaded successfully');
            }
        };

        // ============================================================================
        // VIDEO UPLOAD MODAL HANDLERS - Global API
        // ============================================================================

        window.openVideoUploadModal = function () {
            const modal = document.getElementById('psp-video-upload-modal');
            if (modal) {
                modal.classList.remove('is-hidden');
                document.body.style.overflow = 'hidden';
                window.VideoUploadManager.init();
                log('[PSP] Video upload modal opened');
            }
        };

        window.closeVideoUploadModal = function () {
            const modal = document.getElementById('psp-video-upload-modal');
            const uploadForm = document.getElementById('psp-video-upload-form-container');
            const uploadProgress = document.getElementById('psp-video-upload-progress');
            const successDiv = document.getElementById('psp-video-success');
            const cancelBtn = document.getElementById('psp-video-cancel-btn');
            const submitBtn = document.getElementById('psp-video-submit-btn');
            const doneBtn = document.getElementById('psp-video-done-btn');

            if (modal) {
                modal.classList.add('is-hidden');
                document.body.style.overflow = '';
            }

            // Reset UI
            if (uploadForm) uploadForm.classList.remove('is-hidden');
            if (uploadProgress) uploadProgress.classList.add('is-hidden');
            if (successDiv) successDiv.classList.add('is-hidden');
            if (cancelBtn) cancelBtn.classList.remove('is-hidden');
            if (submitBtn) submitBtn.classList.add('is-hidden');
            if (doneBtn) doneBtn.classList.add('is-hidden');

            window.VideoUploadManager.clearFile();
            log('[PSP] Video upload modal closed');
        };

        window.proceedVideoUpload = function () {
            if (window.VideoUploadManager.uploadInProgress) {
                window.PSP.showToast('Upload in progress...', 'info');
                return;
            }
            window.VideoUploadManager.upload();
        };

        window.clearVideoFile = function () {
            window.VideoUploadManager.clearFile();
        };

    })();

    // ========================================================================
    // USER MENU DROPDOWN - Enterprise Header
    // ========================================================================
    (function initUserMenu() {
        const userTrigger = document.querySelector('.psp-user-trigger');
        const userDropdown = document.querySelector('.psp-user-dropdown');

        if (!userTrigger || !userDropdown) return;

        // Toggle dropdown
        userTrigger.addEventListener('click', function (e) {
            e.stopPropagation();
            const isExpanded = userTrigger.getAttribute('aria-expanded') === 'true';
            userTrigger.setAttribute('aria-expanded', !isExpanded);
            userDropdown.hidden = isExpanded;
        });

        // Close on outside click
        document.addEventListener('click', function (e) {
            if (!userTrigger.contains(e.target) && !userDropdown.contains(e.target)) {
                userTrigger.setAttribute('aria-expanded', 'false');
                userDropdown.hidden = true;
            }
        });

        // Close on escape
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape' && !userDropdown.hidden) {
                userTrigger.setAttribute('aria-expanded', 'false');
                userDropdown.hidden = true;
                userTrigger.focus();
            }
        });

        log('[PSP] User menu initialized');
    })();

}()); // Close main IIFE
