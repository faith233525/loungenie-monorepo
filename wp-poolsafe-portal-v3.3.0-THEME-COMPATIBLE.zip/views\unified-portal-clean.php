<?php
/**
 * CSP-Compliant Portal Layout - PoolSafe Portal v3.3.0
 * 
 * NO inline styles, NO inline scripts, NO inline event handlers
 * All styling via external CSS, all JavaScript via external files
 * 
 * @package PoolSafe_Portal
 * @since 3.3.0
 */

if (!defined('ABSPATH')) {
    exit;
}

// Extract portal context
$current_user = isset($GLOBALS['psp_portal_current_user']) ? $GLOBALS['psp_portal_current_user'] : array('name' => 'User', 'email' => '', 'role' => 'pool_safe_partner');
$user_role = isset($GLOBALS['psp_portal_user_role']) ? $GLOBALS['psp_portal_user_role'] : 'pool_safe_partner';
$visible_tabs = isset($GLOBALS['psp_portal_visible_tabs']) ? $GLOBALS['psp_portal_visible_tabs'] : array('dashboard', 'videos', 'tickets', 'services');
$active_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'dashboard';
$logout_url = wp_logout_url(home_url());
$login_url  = wp_login_url( get_permalink() );

$portal_config = isset($GLOBALS['psp_portal_config']) ? $GLOBALS['psp_portal_config'] : array();
$portal_config_json = esc_attr( wp_json_encode( $portal_config ) );

if (!in_array($active_tab, $visible_tabs)) {
    $active_tab = $visible_tabs[0];
}

$is_admin = current_user_can('manage_options');
$partner_tabs = array('dashboard', 'videos', 'tickets', 'services');
$support_tabs = array('dashboard', 'videos', 'tickets', 'services', 'partners');
$role_mode = $is_admin ? 'support' : $user_role;
?>
<div class="psp-portal-wrapper <?php echo isset($GLOBALS['psp_portal_is_admin']) && $GLOBALS['psp_portal_is_admin'] ? 'psp-admin-view' : ''; ?>"
    data-active-tab="<?php echo esc_attr($active_tab); ?>"
    data-api-url="<?php echo esc_url( rest_url('psp/v1') ); ?>"
    data-ajax-url="<?php echo esc_url( admin_url('admin-ajax.php') ); ?>"
    data-nonce="<?php echo esc_attr( wp_create_nonce('wp_rest') ); ?>"
    data-user="<?php echo esc_attr( wp_json_encode( $current_user ) ); ?>"
    data-user-role="<?php echo esc_attr( $user_role ); ?>"
    data-company-id="<?php echo esc_attr( isset( $portal_config['companyId'] ) ? $portal_config['companyId'] : '' ); ?>"
    data-visible-tabs="<?php echo esc_attr( wp_json_encode( $visible_tabs ) ); ?>"
    data-partner-tabs="<?php echo esc_attr( wp_json_encode( $partner_tabs ) ); ?>"
    data-support-tabs="<?php echo esc_attr( wp_json_encode( $support_tabs ) ); ?>"
    data-role-mode="<?php echo esc_attr( $role_mode ); ?>"
    data-plugin-url="<?php echo esc_url( PSP_PLUGIN_URL ); ?>"
    data-is-admin="<?php echo $is_admin ? '1' : '0'; ?>"
    data-debug="<?php echo defined('PSP_DEBUG') && PSP_DEBUG ? '1' : '0'; ?>"
    data-config-json="<?php echo $portal_config_json; ?>">
    <!-- Header -->
    <header class="psp-portal-header">
        <div class="psp-header-container">
            <div class="psp-header-left">
                <?php if ( has_custom_logo() ) : ?>
                    <div class="psp-logo-container">
                        <?php the_custom_logo(); ?>
                    </div>
                <?php else : ?>
                    <div class="psp-logo-fallback">
                        <svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect width="40" height="40" rx="8" fill="var(--psp-color-primary)"/>
                            <path d="M12 20C12 15.5817 15.5817 12 20 12C24.4183 12 28 15.5817 28 20C28 24.4183 24.4183 28 20 28C15.5817 28 12 24.4183 12 20Z" stroke="white" stroke-width="2" fill="none"/>
                            <circle cx="20" cy="20" r="3" fill="white"/>
                        </svg>
                    </div>
                <?php endif; ?>
                <div class="psp-header-brand">
                    <h1 class="psp-header-title"><?php echo esc_html( get_bloginfo('name') ); ?></h1>
                    <p class="psp-header-subtitle">Portal</p>
                </div>
            </div>
            <div class="psp-header-center">
                <?php if ( $is_admin ) : ?>
                <div class="psp-view-switcher" role="group" aria-label="Switch portal view">
                    <button type="button" class="psp-view-btn" data-role-switch="support" aria-pressed="<?php echo $role_mode === 'support' ? 'true' : 'false'; ?>">
                        <svg width="16" height="16" fill="currentColor"><path d="M8 2a2 2 0 012 2v1h3a1 1 0 011 1v9a1 1 0 01-1 1H3a1 1 0 01-1-1V6a1 1 0 011-1h3V4a2 2 0 012-2h2zm2 3V4H6v1h4z"/></svg>
                        Support
                    </button>
                    <button type="button" class="psp-view-btn" data-role-switch="partner" aria-pressed="<?php echo $role_mode === 'partner' ? 'true' : 'false'; ?>">
                        <svg width="16" height="16" fill="currentColor"><path d="M8 8a3 3 0 100-6 3 3 0 000 6zm-5 6a5 5 0 0110 0H3z"/></svg>
                        Partner
                    </button>
                </div>
                <?php endif; ?>
            </div>
            <div class="psp-header-right">
                <div class="psp-header-actions">
                    <button type="button" class="psp-icon-btn" aria-label="Notifications" title="Notifications">
                        <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/>
                        </svg>
                        <span class="psp-badge">3</span>
                    </button>
                    <button type="button" class="psp-icon-btn" aria-label="Help" title="Help & Support">
                        <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="10" cy="10" r="9"/>
                            <path d="M10 14v.01M10 11a2 2 0 012-2 2 2 0 00-2-2 2 2 0 00-2 2"/>
                        </svg>
                    </button>
                    <a href="<?php echo esc_url($logout_url); ?>" class="psp-btn psp-btn-logout" title="Sign Out">
                        <svg width="18" height="18" fill="currentColor">
                            <path d="M3 3a1 1 0 011-1h12a1 1 0 011 1v12a1 1 0 01-1 1h-2v-2h1V4H5v10h1v2H4a1 1 0 01-1-1V3z"/>
                            <path d="M11 10l-3-3v2H5v2h3v2l3-3z"/>
                        </svg>
                        <span class="psp-btn-text">Logout</span>
                    </a>
                </div>
                <div class="psp-user-menu">
                    <button type="button" class="psp-user-trigger" aria-haspopup="true" aria-expanded="false">
                        <div class="psp-user-avatar">
                            <?php echo esc_html( strtoupper( substr( $current_user['name'], 0, 1 ) ) ); ?>
                        </div>
                        <div class="psp-user-info">
                            <span class="psp-user-name"><?php echo esc_html($current_user['name']); ?></span>
                            <span class="psp-user-role"><?php echo esc_html(ucwords(str_replace('_', ' ', $user_role))); ?></span>
                        </div>
                        <svg width="16" height="16" fill="currentColor" class="psp-chevron">
                            <path d="M4.5 6L8 9.5 11.5 6"/>
                        </svg>
                    </button>
                    <div class="psp-user-dropdown" hidden>
                        <a href="#" class="psp-dropdown-item">
                            <svg width="16" height="16" fill="currentColor"><path d="M10 2a1 1 0 011 1v1.323l3.954 1.582 1.846-.615A1 1 0 0118 6.25v4.5a1 1 0 01-1.2.98l-1.846-.616L11 12.677V14a1 1 0 01-1 1H3a1 1 0 01-1-1V3a1 1 0 011-1h7z"/></svg>
                            Account Settings
                        </a>
                        <a href="#" class="psp-dropdown-item">
                            <svg width="16" height="16" fill="currentColor"><path d="M5 3a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2V5a2 2 0 00-2-2H5zm0 2h10v7h-2l-1 2H8l-1-2H5V5z"/></svg>
                            Preferences
                        </a>
                        <div class="psp-dropdown-divider"></div>
                        <a href="<?php echo esc_url($logout_url); ?>" class="psp-dropdown-item psp-logout">
                            <svg width="16" height="16" fill="currentColor"><path d="M3 3a1 1 0 011-1h12a1 1 0 011 1v12a1 1 0 01-1 1h-2v-2h1V4H5v10h1v2H4a1 1 0 01-1-1V3z"/><path d="M11 10l-3-3v2H5v2h3v2l3-3z"/></svg>
                            Sign Out
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- Tab Navigation -->
    <nav class="psp-tab-nav" role="navigation" aria-label="Portal sections">
        <ul class="psp-tab-list" role="tablist">
            <?php if (in_array('dashboard', $visible_tabs)): ?>
            <li class="psp-tab-item" role="presentation">
                <button 
                    class="psp-tab-button <?php echo $active_tab === 'dashboard' ? 'active' : ''; ?>"
                    role="tab"
                    data-tab="dashboard"
                    aria-selected="<?php echo $active_tab === 'dashboard' ? 'true' : 'false'; ?>"
                    aria-controls="dashboard-panel">
                    Dashboard
                </button>
            </li>
            <?php endif; ?>
            
            <?php if (in_array('videos', $visible_tabs)): ?>
            <li class="psp-tab-item" role="presentation">
                <button 
                    class="psp-tab-button <?php echo $active_tab === 'videos' ? 'active' : ''; ?>"
                    role="tab"
                    data-tab="videos"
                    aria-selected="<?php echo $active_tab === 'videos' ? 'true' : 'false'; ?>"
                    aria-controls="videos-panel">
                    Videos
                </button>
            </li>
            <?php endif; ?>
            
            <?php if (in_array('tickets', $visible_tabs)): ?>
            <li class="psp-tab-item" role="presentation">
                <button 
                    class="psp-tab-button <?php echo $active_tab === 'tickets' ? 'active' : ''; ?>"
                    role="tab"
                    data-tab="tickets"
                    aria-selected="<?php echo $active_tab === 'tickets' ? 'true' : 'false'; ?>"
                    aria-controls="tickets-panel">
                    Tickets
                </button>
            </li>
            <?php endif; ?>
            
            <?php if (in_array('services', $visible_tabs)): ?>
            <li class="psp-tab-item" role="presentation">
                <button 
                    class="psp-tab-button <?php echo $active_tab === 'services' ? 'active' : ''; ?>"
                    role="tab"
                    data-tab="services"
                    aria-selected="<?php echo $active_tab === 'services' ? 'true' : 'false'; ?>"
                    aria-controls="services-panel">
                    Services
                </button>
            </li>
            <?php endif; ?>
            
            <?php if (in_array('partners', $visible_tabs)): ?>
            <li class="psp-tab-item" role="presentation">
                <button 
                    class="psp-tab-button <?php echo $active_tab === 'partners' ? 'active' : ''; ?>"
                    role="tab"
                    data-tab="partners"
                    aria-selected="<?php echo $active_tab === 'partners' ? 'true' : 'false'; ?>"
                    aria-controls="partners-panel">
                    Partners
                </button>
            </li>
            <?php endif; ?>
        </ul>
    </nav>

    <!-- Content Area -->
    <main class="psp-content-area">
        <?php if (in_array('dashboard', $visible_tabs)): ?>
        <div id="dashboard-panel" class="psp-tab-panel <?php echo $active_tab === 'dashboard' ? 'active' : ''; ?>" role="tabpanel" aria-labelledby="dashboard">
			<div class="psp-auth-buttons">
				<?php if ( is_user_logged_in() ) : ?>
					<a href="<?php echo esc_url($logout_url); ?>" class="psp-button psp-button-ghost">Logout</a>
				<?php else : ?>
					<a href="<?php echo esc_url($login_url); ?>" class="psp-button psp-button-primary">Login</a>
				<?php endif; ?>
			</div>
            <div class="psp-welcome-banner">
                <h1>Welcome back, <?php echo esc_html($current_user['name']); ?>!</h1>
                <p>Manage your pool services, view tickets, and access partner resources.</p>
            </div>

            <div class="psp-stats-grid">
                <div class="psp-stat-card" data-stat="tickets">
                    <div class="psp-stat-icon">🎫</div>
                    <div class="psp-stat-label">Open Tickets</div>
                    <div class="psp-stat-value" data-stat-value="tickets">-</div>
                </div>
                <div class="psp-stat-card" data-stat="services">
                    <div class="psp-stat-icon">⚙️</div>
                    <div class="psp-stat-label">Active Services</div>
                    <div class="psp-stat-value" data-stat-value="services">-</div>
                </div>
                <div class="psp-stat-card" data-stat="partners">
                    <div class="psp-stat-icon">🤝</div>
                    <div class="psp-stat-label">Partners</div>
                    <div class="psp-stat-value" data-stat-value="partners">-</div>
                </div>
                <div class="psp-stat-card" data-stat="videos">
                    <div class="psp-stat-icon">📹</div>
                    <div class="psp-stat-label">Training Videos</div>
                    <div class="psp-stat-value" data-stat-value="videos">-</div>
                </div>
            </div>

            <div class="psp-section">
                <h2 class="psp-section-title">Quick Actions</h2>
                <div class="psp-button-group">
                    <button class="psp-button psp-button-primary" data-action="new-ticket">Create New Ticket</button>
                    <button class="psp-button psp-button-secondary" data-action="view-services">View Services</button>
                </div>
            </div>

            <div id="dashboard-content" class="psp-dynamic-content">
                <div class="psp-loading">Loading dashboard...</div>
            </div>
        </div>
        <?php endif; ?>

        <?php if (in_array('videos', $visible_tabs)): ?>
        <!-- Videos Tab -->
        <div id="videos-panel" class="psp-tab-panel <?php echo $active_tab === 'videos' ? 'active' : ''; ?>" role="tabpanel" aria-labelledby="videos">
            <h2 class="psp-panel-title">Training Videos</h2>
            <div id="videos-content" class="psp-dynamic-content">
                <div class="psp-loading">Loading videos...</div>
            </div>
        </div>
        <?php endif; ?>

        <?php if (in_array('tickets', $visible_tabs)): ?>
        <!-- Tickets Tab -->
        <div id="tickets-panel" class="psp-tab-panel <?php echo $active_tab === 'tickets' ? 'active' : ''; ?>" role="tabpanel" aria-labelledby="tickets">
            <h2 class="psp-panel-title">Support Tickets</h2>
            <div id="tickets-content" class="psp-dynamic-content">
                <div class="psp-loading">Loading tickets...</div>
            </div>
        </div>
        <?php endif; ?>

        <?php if (in_array('services', $visible_tabs)): ?>
        <!-- Services Tab -->
        <div id="services-panel" class="psp-tab-panel <?php echo $active_tab === 'services' ? 'active' : ''; ?>" role="tabpanel" aria-labelledby="services">
            <h2 class="psp-panel-title">Services</h2>
            <div id="services-content" class="psp-dynamic-content">
                <div class="psp-loading">Loading services...</div>
            </div>
        </div>
        <?php endif; ?>

        <?php if (in_array('partners', $visible_tabs)): ?>
        <!-- Partners Tab (Support/Admin Only) -->
        <div id="partners-panel" class="psp-tab-panel <?php echo $active_tab === 'partners' ? 'active' : ''; ?>" role="tabpanel" aria-labelledby="partners">
            <h2 class="psp-panel-title">Partner Management</h2>
            <div class="psp-section">
                <button class="psp-button psp-button-primary" data-action="upload-csv">Upload CSV</button>
            </div>
            <div id="partners-content" class="psp-dynamic-content">
                <div class="psp-loading">Loading partners...</div>
            </div>
        </div>
        <?php endif; ?>
    </main>
</div>
